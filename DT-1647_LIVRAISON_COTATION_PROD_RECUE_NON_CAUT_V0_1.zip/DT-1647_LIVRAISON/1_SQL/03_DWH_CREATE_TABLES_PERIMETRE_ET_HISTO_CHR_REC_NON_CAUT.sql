/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   03  -  TABLES DE PERIMETRE ET DE REPRISE DES DATES DE CHR   (base DWH)

   dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
       Derniere version de chaque pret a fin de mois (remplace PITMAX_SEQ_PWTPRT
       du code fourni, renommee comme le demandait son commentaire).
   dbo.PITOPE_PERIMETRE_REC_NON_CAUT
       La table de perimetre de la carte, 1 ligne par pret. Types recopies de
       dbo.PWTPRT.
   dbo.PITOPE_COT_COMP_REC_NON_CAUT
       Derniere cotation historisee (arrete precedent) par operation : sert
       la regle "dates de CHR inchangees si la CHR n'evolue pas". Remplace
       PITOPE_COT_COMP / IOM.MNI.PITOPE_COT_PB_COMP (liste a ne pas utiliser).
   ============================================================================ */
USE [DWH]
GO

SELECT TOP (0) PRT.CD_PRET, PRT.NO_SEQ_PRT
INTO   dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
FROM   dbo.PWTPRT AS PRT;

CREATE UNIQUE CLUSTERED INDEX UX_PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
    ON dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT (CD_PRET, NO_SEQ_PRT);
GO

SELECT TOP (0)
       CAST(NULL AS NUMERIC(6, 0)) AS CD_DAT_ARR_AAM,
       PRT.CD_OP, PRT.CD_PRET, PRT.NO_SEQ_PRT, PRT.CD_ETAP, PRT.CD_STATUT,
       PRT.CD_NATUR_PRET, PRT.DJ_DATE_DEB, PRT.MT_PRET_PFI,
       CAST(NULL AS DATETIME)      AS DT_MAJ
INTO   dbo.PITOPE_PERIMETRE_REC_NON_CAUT
FROM   dbo.PWTPRT AS PRT;

CREATE UNIQUE CLUSTERED INDEX UX_PITOPE_PERIMETRE_REC_NON_CAUT
    ON dbo.PITOPE_PERIMETRE_REC_NON_CAUT (CD_PRET);

CREATE NONCLUSTERED INDEX IX_PITOPE_PERIMETRE_REC_NON_CAUT_CD_OP
    ON dbo.PITOPE_PERIMETRE_REC_NON_CAUT (CD_OP)
    INCLUDE (NO_SEQ_PRT, DJ_DATE_DEB, MT_PRET_PFI);
GO

CREATE TABLE dbo.PITOPE_COT_COMP_REC_NON_CAUT
(
    CD_OP                   CHAR(10)        NOT NULL,
    NO_SEQ                  INT             NOT NULL,
    CD_DAT_ARR_AAM_PDT      NUMERIC(6, 0)   NULL,   -- arrete de la cotation relue
    CD_DER_CHR_LGD_DEF      CHAR(2)         NULL,   -- NULL : pas de defaut sur ce perimetre
    CD_CHR_PD_PDT           CHAR(1)         NULL,   -- CHR PD CIBLE de l'arrete precedent
    CD_CHR_LGD_PDT          CHAR(2)         NULL,
    DT_REF_CHR_PD           DATETIME        NULL,
    DT_REF_CHR_LGD          DATETIME        NULL,
    FL_DEF_PASS             TINYINT         NULL,
    DT_REF_CHR_PD_REENT     DATETIME        NULL,   -- NULL : pas de reentree en defaut
    DT_REF_CHR_LGD_REENT    DATETIME        NULL,
    CD_CHR_PD_REENT         CHAR(1)         NULL,
    CD_CHR_LGD_REEENT       CHAR(2)         NULL,   -- orthographe d'origine (PITOPE_COT_COMP)
    CONSTRAINT PK_PITOPE_COT_COMP_REC_NON_CAUT PRIMARY KEY CLUSTERED (CD_OP, NO_SEQ)
);
GO
