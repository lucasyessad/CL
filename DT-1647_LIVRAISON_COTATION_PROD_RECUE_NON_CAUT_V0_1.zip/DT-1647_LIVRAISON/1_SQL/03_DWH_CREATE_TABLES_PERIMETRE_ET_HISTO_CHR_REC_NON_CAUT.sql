/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   03  -  TABLES DE PERIMETRE ET DE REPRISE DES DATES DE CHR

   Base       : DWH          (schema logique ODI : MSSQL_DWH)

   dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
       Derniere version connue de chaque pret a la fin du mois de l'arrete
       calcule (1 ligne par CD_PRET). Remplace la table PITMAX_SEQ_PWTPRT du
       code perimetre fourni, dont le commentaire demandait justement de
       "changer le nom de la table et creer un index sur le pret sequence" :
       le nom PITMAX_SEQ_PWTPRT est generique et risquait d'etre partage
       avec une autre chaine. La table est placee dans DWH.dbo (schema
       logique MSSQL_DWH, comme toutes les tables PITOPE de la cotation)
       plutot que dans MSSQL_STAGING : un seul schema logique pour toute la
       chaine, pas de dependance supplementaire a la topologie.

   dbo.PITOPE_PERIMETRE_REC_NON_CAUT
       La "table de perimetre" de la carte. 1 ligne par pret du perimetre :
       prets recus (etape CLA, EAU, EDI, PEC, SIG), absents de l'encours
       engage (EWTENC) et de l'encours non engage (EWTNEC) de l'arrete, et
       dont AUCUN pret de la meme operation n'est cautionne ou engage.
       Les types de colonnes sont recopies de dbo.PWTPRT (SELECT TOP 0 ...
       INTO) : aucune hypothese sur la longueur de CD_PRET ou des codes.

   dbo.PITOPE_COT_COMP_REC_NON_CAUT
       Equivalent allege de PITOPE_COT_COMP. Pour chaque operation du
       perimetre, la derniere cotation deja historisee dans
       DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT sur un arrete ANTERIEUR. Elle
       alimente les colonnes *_PDT relues par le calcul des dates de
       reference de CHR, pour respecter la regle metier :
       "Si la CHR n'evolue pas alors les dates de validite de CHR ne
       changent pas".
       Le mapping d'origine IOM.MNI.PITOPE_COT_PB_COMP.Ins lisait PDTOPE_COT
       (stock engage / non engage) : il est dans la liste des mappings a ne
       pas utiliser, mais le moteur a besoin de l'historique. On le
       remplace donc par cette table, alimentee depuis l'historique du
       perimetre lui-meme.

   Script rejouable : ne cree une table que si elle est absente.
   ============================================================================ */
USE [DWH]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/* ---------------------------------------------------------------------------
   1. Derniere version de pret a image fin de mois
--------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT', N'U') IS NULL
BEGIN
    SELECT TOP (0)
           PRT.CD_PRET,
           PRT.NO_SEQ_PRT
    INTO   dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
    FROM   dbo.PWTPRT AS PRT;

    CREATE UNIQUE CLUSTERED INDEX UX_PITOPE_MAX_SEQ_PRT_REC_NON_CAUT
        ON dbo.PITOPE_MAX_SEQ_PRT_REC_NON_CAUT (CD_PRET ASC, NO_SEQ_PRT ASC);
END
GO

/* ---------------------------------------------------------------------------
   2. Table de perimetre
--------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.PITOPE_PERIMETRE_REC_NON_CAUT', N'U') IS NULL
BEGIN
    SELECT TOP (0)
           CAST(NULL AS NUMERIC(6, 0)) AS CD_DAT_ARR_AAM,
           PRT.CD_OP,
           PRT.CD_PRET,
           PRT.NO_SEQ_PRT,
           PRT.CD_ETAP,
           PRT.CD_STATUT,
           PRT.CD_NATUR_PRET,
           PRT.DJ_DATE_DEB,
           PRT.MT_PRET_PFI,
           CAST(NULL AS DATETIME)      AS DT_MAJ
    INTO   dbo.PITOPE_PERIMETRE_REC_NON_CAUT
    FROM   dbo.PWTPRT AS PRT;

    CREATE UNIQUE CLUSTERED INDEX UX_PITOPE_PERIMETRE_REC_NON_CAUT
        ON dbo.PITOPE_PERIMETRE_REC_NON_CAUT (CD_PRET ASC);

    CREATE NONCLUSTERED INDEX IX_PITOPE_PERIMETRE_REC_NON_CAUT_CD_OP
        ON dbo.PITOPE_PERIMETRE_REC_NON_CAUT (CD_OP ASC)
        INCLUDE (NO_SEQ_PRT, DJ_DATE_DEB, MT_PRET_PFI);
END
GO

/* ---------------------------------------------------------------------------
   3. Derniere cotation historisee par operation (reprise des dates de CHR)
--------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.PITOPE_COT_COMP_REC_NON_CAUT', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PITOPE_COT_COMP_REC_NON_CAUT
    (
        CD_OP                   CHAR(10)        NOT NULL,
        NO_SEQ                  INT             NOT NULL,
        CD_DAT_ARR_AAM_PDT      NUMERIC(6, 0)   NULL,   -- arrete de la cotation relue
        CD_DER_CHR_LGD_DEF      CHAR(2)         NULL,   -- toujours NULL : pas de defaut sur ce perimetre
        CD_CHR_PD_PDT           CHAR(1)         NULL,   -- CHR PD CIBLE de l'arrete precedent
        CD_CHR_LGD_PDT          CHAR(2)         NULL,
        DT_REF_CHR_PD           DATETIME        NULL,
        DT_REF_CHR_LGD          DATETIME        NULL,
        FL_DEF_PASS             TINYINT         NULL,
        DT_REF_CHR_PD_REENT     DATETIME        NULL,   -- toujours NULL : pas de reentree en defaut
        DT_REF_CHR_LGD_REENT    DATETIME        NULL,
        CD_CHR_PD_REENT         CHAR(1)         NULL,
        CD_CHR_LGD_REEENT       CHAR(2)         NULL,   -- orthographe d'origine conservee (PITOPE_COT_COMP)
        CONSTRAINT PK_PITOPE_COT_COMP_REC_NON_CAUT PRIMARY KEY CLUSTERED (CD_OP ASC, NO_SEQ ASC)
    );
END
GO
