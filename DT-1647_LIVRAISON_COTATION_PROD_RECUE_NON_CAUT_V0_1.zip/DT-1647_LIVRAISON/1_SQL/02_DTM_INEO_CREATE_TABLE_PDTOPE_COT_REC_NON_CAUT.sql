/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   02  -  TABLE CIBLE HISTORISEE PAR ARRETE  -  DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT

   Base       : DTM_INEO     (schema logique ODI : MSSQL_DTM1)
   Role       : historique mensuel de la cotation du perimetre recu non
                cautionne. Une photo complete par arrete (CD_DAT_ARR_AAM).
                Alimentee par le scenario fils 2 (insertion, decrit dans une
                autre carte) en annule et remplace de l'arrete calcule.
                Relue par le scenario fils 1 pour conserver les dates de
                validite de CHR quand la CHR n'evolue pas (regle metier).
   Source     : script fourni dans la carte (SCRIPT_PDTOPE_COT_REC_NON_CAUT.sql)

   CORRECTIONS PAR RAPPORT AU SCRIPT FOURNI
   ----------------------------------------
   1. CD_TRAIT supprime, comme demande dans la carte ("structure iso de la
      PDTOPE_COT sauf CD_TRAIT pas utile"). Le script fourni le gardait
      encore, en NOT NULL.

   2. DT_REF_TRAIT supprime et remplace par CD_DAT_ARR_AAM (deja fait dans le
      script fourni, conserve).

   3. CLE PRIMAIRE : le script fourni posait la PK sur (CD_OP, NO_SEQ) seuls.
      Or la table est historisee par arrete : une meme operation, non
      cautionnee plusieurs mois de suite, est presente a chaque arrete avec
      le meme NO_SEQ. Des le deuxieme arrete, l'insertion echouait en
      violation de cle (Msg 2627).
      -> PK sur (CD_DAT_ARR_AAM, CD_OP, NO_SEQ), CD_DAT_ARR_AAM passe NOT NULL.
      L'ordre de cle (arrete en tete) sert directement l'annule et remplace
      (DELETE ... WHERE CD_DAT_ARR_AAM = @arrete).

   4. Index secondaire IX_..._CD_OP : sert la relecture du dernier arrete
      connu par operation (etape 23 du scenario fils 1).

   5. Contraintes DEFAULT nommees (evite des noms systeme differents selon
      les environnements, ce qui complique les scripts de livraison suivants).

   ============================================================================ */
USE [DTM_INEO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE dbo.PDTOPE_COT_REC_NON_CAUT
(
    CD_DAT_ARR_AAM          NUMERIC(6, 0)   NOT NULL,
    NO_SEQ                  INT             NOT NULL,
    CD_OP                   CHAR(10)        NOT NULL,
    FL_OP_MEP               TINYINT         NULL CONSTRAINT DF_PDTOPE_COT_REC_NON_CAUT_FL_OP_MEP  DEFAULT ((0)),
    FL_REL                  TINYINT         NULL,
    TX_LTV                  NUMERIC(6, 4)   NULL,
    DT_MEP_OP               DATETIME        NULL,
    NB_INT                  INT             NULL,
    FL_DEF_OP               TINYINT         NULL,
    DD_DEF_OP               DATETIME        NULL,
    DF_DEF_OP               DATETIME        NULL,
    FL_DEF_PASS             TINYINT         NULL,
    NB_PASS_HIST_LGD        INT             NULL,
    FL_DEC_DET              TINYINT         NULL,
    DT_DEC_DET              DATETIME        NULL,
    FL_PROC_SUR             TINYINT         NULL,
    DT_PROC_SUR             DATETIME        NULL,
    FL_PROC_EXE             TINYINT         NULL,
    DT_PROC_EXE             DATETIME        NULL,
    FL_PROC_COLL            TINYINT         NULL,
    DT_PROC_COLL            DATETIME        NULL,
    FL_103_104              TINYINT         NULL CONSTRAINT DF_PDTOPE_COT_REC_NON_CAUT_FL_103_104 DEFAULT ((0)),
    DT_103_104              DATETIME        NULL,
    CD_DER_CHR_LGD_DEF      CHAR(2)         NULL,
    DT_FIN_REL              DATETIME        NULL,
    DT_ANN_FIN_REL          DATETIME        NULL,
    CD_CHR_PD               CHAR(1)         NULL,
    CD_CHR_LGD              CHAR(2)         NULL,
    NU_VERS_CHR             NUMERIC(5, 2)   NULL,
    CD_COTE_ENCOURS         CHAR(2)         NULL,
    NB_NOTE_ENCOURS         NUMERIC(6, 4)   NULL,
    NU_VERS_ENCOURS         NUMERIC(5, 2)   NULL,
    CD_USER_MAJ             CHAR(8)         NULL,
    FL_VER_CRT              TINYINT         NULL,
    DD_VAL                  DATETIME        NULL,
    DF_VAL                  DATETIME        NULL,
    DT_MAJ                  DATETIME        NULL,
    DT_REF_CHR_PD           DATETIME        NULL,
    DT_REF_CHR_LGD          DATETIME        NULL,
    CD_CHR_PD_CIBLE         CHAR(1)         NULL,
    FL_DADP_ACTIF           BIT             NULL,
    FL_DEJA_DADP            BIT             NULL,
    FL_IMP                  BIT             NULL,
    FL_DEF                  BIT             NULL,
    FL_CTX                  BIT             NULL,
    FL_CTX_MOTIF_5XX        BIT             NULL,
    FL_STOCK_DEF            BIT             NULL,
    FL_OPE_VIVANTE          BIT             NULL,
    NB_DUR_DEF              INT             NULL,
    CD_DNE_CHR_LGD_SAIN     VARCHAR(2)      NULL,
    AGE_OP                  INT             NULL,
    ANC_BANC_EMP1_EVO       INT             NULL,
    ANC_BANC_EMP2_EVO       INT             NULL,
    MT_CHARGE_CSM_PFI       FLOAT           NULL,
    MT_REV_PFI              FLOAT           NULL,
    FL_REL_VIV              BIT             NULL,
    LL_RGP_2                VARCHAR(38)     NULL,
    MT_APPOR_PFI            FLOAT           NULL,
    MT_PATRIM_MOB           FLOAT           NULL,
    CD_CSP_EMP1             VARCHAR(6)      NULL,
    CD_ETAT_CIVIL           VARCHAR(6)      NULL,
    NB_DUR                  INT             NULL,
    CD_NATUR_OP_PFI         VARCHAR(3)      NULL,
    CD_NAT_EMP1             VARCHAR(6)      NULL,
    CD_NAT_EMP2             VARCHAR(6)      NULL,
    CD_NIV_TAUX             VARCHAR(4)      NULL,
    DT_EVT                  DATETIME2(3)    NULL,
    DT_ARR_AMJ              DATETIME2(7)    NULL,
    MT_EAD_OBS              NUMERIC(15, 2)  NULL,
    PRES_PATR_HORS_OP       INT             NULL,
    DT_DERN_DEF             DATETIME2(3)    NULL,
    CONSTRAINT PK_PDTOPE_COT_REC_NON_CAUT PRIMARY KEY CLUSTERED (CD_DAT_ARR_AAM ASC, CD_OP ASC, NO_SEQ ASC)
        WITH (FILLFACTOR = 100)
);

CREATE NONCLUSTERED INDEX IX_PDTOPE_COT_REC_NON_CAUT_CD_OP
    ON dbo.PDTOPE_COT_REC_NON_CAUT (CD_OP ASC, CD_DAT_ARR_AAM DESC, NO_SEQ DESC)
    INCLUDE (CD_CHR_PD, CD_CHR_LGD, CD_CHR_PD_CIBLE, DT_REF_CHR_PD, DT_REF_CHR_LGD, FL_DEF_PASS);
GO
