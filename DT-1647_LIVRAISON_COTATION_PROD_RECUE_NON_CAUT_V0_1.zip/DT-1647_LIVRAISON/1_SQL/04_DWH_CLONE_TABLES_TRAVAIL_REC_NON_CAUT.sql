/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   04  -  STRUCTURES DE TRAVAIL DEDIEES AU PERIMETRE (DUPLICATION)

   Base       : DWH          (schema logique ODI : MSSQL_DWH)

   La carte demande de dupliquer le scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS
   et ses mappings "et les structures de donnees", puis de creer des
   structures cibles dediees a ce perimetre. Raison : les deux traitements
   videraient sinon les memes tables de travail (truncate en debut de
   mapping) ; lances le meme soir, l'un ecraserait les donnees de l'autre.

   Ce script cree chaque table de travail XXX_REC_NON_CAUT a l'identique de
   la table XXX existante :
     - colonnes, types, nullabilite : SELECT TOP (0) * INTO ;
     - cle primaire et index : recopies depuis le catalogue (sys.indexes),
       renommes avec le suffixe _REC_NON_CAUT.
   Aucune structure n'est donc ecrite a la main : impossible de diverger de
   la table d'origine telle qu'elle est en production.

   Comportement
     - table source absente  -> erreur, arret (environnement incomplet) ;
     - table cible deja la   -> ignoree (script rejouable) ;
     - index columnstore     -> non recopie, signale (aucun attendu ici).

   Prerequis : SQL Server 2017+ (STRING_AGG). Le script fourni dans la carte
   utilise OPTIMIZE_FOR_SEQUENTIAL_KEY, donc 2019+ : prerequis satisfait.

   NB : PITOPE_COT et PITOPE_COT_COMP ne sont pas dupliquees ici : leurs
   equivalents ont une structure propre (scripts 01 et 03).
   ============================================================================ */
USE [DWH]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET NOCOUNT ON;

DECLARE @SUFFIXE SYSNAME = N'_REC_NON_CAUT';

DECLARE @TABLES TABLE (NO_ORDRE INT NOT NULL PRIMARY KEY, TABLE_SOURCE SYSNAME NOT NULL);
INSERT INTO @TABLES (NO_ORDRE, TABLE_SOURCE) VALUES
    ( 1, N'PITOPE_COT_REF_PRT_INT'),
    ( 2, N'PITOPE_COT_REF_PRT'),
    ( 3, N'PITOPE_COT_REF_OPE'),
    ( 4, N'PITOPE_COT_PER0_M'),
    ( 5, N'PWTOPE_POC_SCR_INT'),
    ( 6, N'PWTOPE_POC_SCR'),
    ( 7, N'PWTOPE_APT_SCR_INT'),
    ( 8, N'PWTOPE_APT_SCR'),
    ( 9, N'PWTOPE_CHA_SCR_INT'),
    (10, N'PWTOPE_CHA_SCR'),
    (11, N'PWTPRT_SCR_INT'),
    (12, N'PWTPRT_SCR'),
    (13, N'PWTINT_SCR_INT'),
    (14, N'PRTIND_INT'),
    (15, N'PWTINT_SCR'),
    (16, N'PITOPE_COT_SCR'),
    (17, N'PITOPE_COT_SCR_MOT'),
    (18, N'PITOPE_COT_MOT'),
    (19, N'PITOPE_COT_MOT_RES');

/* Controle prealable : toutes les sources doivent exister ------------------ */
DECLARE @manquantes NVARCHAR(MAX);
SELECT @manquantes = STRING_AGG(T.TABLE_SOURCE, N', ')
FROM @TABLES T
WHERE OBJECT_ID(N'dbo.' + T.TABLE_SOURCE, N'U') IS NULL;

IF @manquantes IS NOT NULL
BEGIN
    DECLARE @msg NVARCHAR(2000) = N'Tables sources absentes de DWH.dbo : ' + @manquantes
                                + N'. Duplication annulee, aucune table creee.';
    THROW 50101, @msg, 1;
END

DECLARE @no INT = 0, @src SYSNAME, @tgt SYSNAME, @sql NVARCHAR(MAX);

WHILE 1 = 1
BEGIN
    SELECT TOP (1) @no = NO_ORDRE, @src = TABLE_SOURCE
    FROM @TABLES WHERE NO_ORDRE > @no ORDER BY NO_ORDRE;
    IF @@ROWCOUNT = 0 BREAK;

    SET @tgt = @src + @SUFFIXE;

    IF OBJECT_ID(N'dbo.' + @tgt, N'U') IS NOT NULL
    BEGIN
        PRINT N'[IGNOREE] dbo.' + @tgt + N' existe deja.';
        CONTINUE;
    END

    /* 1. Colonnes ----------------------------------------------------------- */
    SET @sql = N'SELECT TOP (0) * INTO dbo.' + QUOTENAME(@tgt) + N' FROM dbo.' + QUOTENAME(@src) + N';';
    EXEC sys.sp_executesql @sql;
    PRINT N'[CREEE]   dbo.' + @tgt + N' (structure de dbo.' + @src + N')';

    /* 2. Cle primaire et index ---------------------------------------------- */
    DECLARE @idx TABLE (
        INDEX_ID INT, NOM SYSNAME, TYPE_DESC NVARCHAR(60), IS_PK BIT, IS_UNIQUE BIT,
        IS_UQ_CONSTRAINT BIT, FILTRE NVARCHAR(MAX), FILL TINYINT);
    DELETE FROM @idx;

    INSERT INTO @idx
    SELECT i.index_id, i.name, i.type_desc, i.is_primary_key, i.is_unique,
           i.is_unique_constraint, i.filter_definition, i.fill_factor
    FROM sys.indexes i
    WHERE i.object_id = OBJECT_ID(N'dbo.' + @src)
      AND i.type IN (1, 2)              -- clustered / nonclustered rowstore
      AND i.is_hypothetical = 0
      AND i.is_disabled = 0;

    IF EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.' + @src) AND type IN (5, 6))
        PRINT N'  [ATTENTION] index columnstore sur dbo.' + @src + N' non recopie.';

    DECLARE @iid INT = -1, @nom SYSNAME, @typ NVARCHAR(60), @pk BIT, @uq BIT, @uqc BIT,
            @filtre NVARCHAR(MAX), @fill TINYINT, @cles NVARCHAR(MAX), @incl NVARCHAR(MAX), @nouveau SYSNAME;
    SET @iid = -1;   -- remise a zero explicite du curseur d'index a chaque table

    WHILE 1 = 1
    BEGIN
        SELECT TOP (1) @iid = INDEX_ID, @nom = NOM, @typ = TYPE_DESC, @pk = IS_PK, @uq = IS_UNIQUE,
                       @uqc = IS_UQ_CONSTRAINT, @filtre = FILTRE, @fill = FILL
        FROM @idx WHERE INDEX_ID > @iid ORDER BY INDEX_ID;
        IF @@ROWCOUNT = 0 BREAK;

        SELECT @cles = STRING_AGG(CAST(QUOTENAME(c.name) + CASE WHEN ic.is_descending_key = 1 THEN N' DESC' ELSE N' ASC' END AS NVARCHAR(MAX)), N', ')
                       WITHIN GROUP (ORDER BY ic.key_ordinal)
        FROM sys.index_columns ic
        JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE ic.object_id = OBJECT_ID(N'dbo.' + @src) AND ic.index_id = @iid AND ic.key_ordinal > 0;

        SELECT @incl = STRING_AGG(CAST(QUOTENAME(c.name) AS NVARCHAR(MAX)), N', ')
                       WITHIN GROUP (ORDER BY ic.index_column_id)
        FROM sys.index_columns ic
        JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
        WHERE ic.object_id = OBJECT_ID(N'dbo.' + @src) AND ic.index_id = @iid
          AND ic.is_included_column = 1;

        /* Nom : on remplace le nom de la table source par celui de la cible,
           sinon on suffixe. Tronque a 128 caracteres. */
        SET @nouveau = LEFT(CASE WHEN CHARINDEX(@src, @nom) > 0 THEN REPLACE(@nom, @src, @tgt)
                                 ELSE @nom + @SUFFIXE END, 128);

        IF @pk = 1
            SET @sql = N'ALTER TABLE dbo.' + QUOTENAME(@tgt) + N' ADD CONSTRAINT ' + QUOTENAME(@nouveau)
                     + N' PRIMARY KEY ' + CASE WHEN @typ = N'CLUSTERED' THEN N'CLUSTERED' ELSE N'NONCLUSTERED' END
                     + N' (' + @cles + N')'
                     + CASE WHEN @fill BETWEEN 1 AND 99 THEN N' WITH (FILLFACTOR = ' + CAST(@fill AS NVARCHAR(3)) + N')' ELSE N'' END
                     + N';';
        ELSE
            SET @sql = N'CREATE ' + CASE WHEN @uq = 1 OR @uqc = 1 THEN N'UNIQUE ' ELSE N'' END
                     + CASE WHEN @typ = N'CLUSTERED' THEN N'CLUSTERED' ELSE N'NONCLUSTERED' END
                     + N' INDEX ' + QUOTENAME(@nouveau) + N' ON dbo.' + QUOTENAME(@tgt) + N' (' + @cles + N')'
                     + CASE WHEN @incl IS NOT NULL THEN N' INCLUDE (' + @incl + N')' ELSE N'' END
                     + CASE WHEN @filtre IS NOT NULL THEN N' WHERE ' + @filtre ELSE N'' END
                     + CASE WHEN @fill BETWEEN 1 AND 99 THEN N' WITH (FILLFACTOR = ' + CAST(@fill AS NVARCHAR(3)) + N')' ELSE N'' END
                     + N';';

        EXEC sys.sp_executesql @sql;
        PRINT N'           + ' + @nouveau;
    END
END
GO

/* Controle : les 19 tables doivent exister avec le meme nombre de colonnes
   que leur source.
-------------------------------------------------------------------------------
SELECT s.name AS TABLE_SOURCE, t.name AS TABLE_CIBLE,
       (SELECT COUNT(*) FROM sys.columns WHERE object_id = s.object_id) AS NB_COL_SOURCE,
       (SELECT COUNT(*) FROM sys.columns WHERE object_id = t.object_id) AS NB_COL_CIBLE
FROM sys.tables s
LEFT JOIN sys.tables t ON t.name = s.name + N'_REC_NON_CAUT' AND t.schema_id = s.schema_id
WHERE s.schema_id = SCHEMA_ID(N'dbo')
  AND s.name IN (N'PITOPE_COT_REF_PRT_INT', N'PITOPE_COT_REF_PRT', N'PITOPE_COT_REF_OPE',
                 N'PITOPE_COT_PER0_M', N'PWTOPE_POC_SCR_INT', N'PWTOPE_POC_SCR',
                 N'PWTOPE_APT_SCR_INT', N'PWTOPE_APT_SCR', N'PWTOPE_CHA_SCR_INT',
                 N'PWTOPE_CHA_SCR', N'PWTPRT_SCR_INT', N'PWTPRT_SCR', N'PWTINT_SCR_INT',
                 N'PRTIND_INT', N'PWTINT_SCR', N'PITOPE_COT_SCR', N'PITOPE_COT_SCR_MOT',
                 N'PITOPE_COT_MOT', N'PITOPE_COT_MOT_RES')
ORDER BY s.name;
---------------------------------------------------------------------------- */
