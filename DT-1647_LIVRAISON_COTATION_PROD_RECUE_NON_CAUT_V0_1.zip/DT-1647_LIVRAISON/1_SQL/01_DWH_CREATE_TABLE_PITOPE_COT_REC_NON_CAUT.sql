/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   01  -  TABLE DE TRAVAIL FINALE DU SCENARIO FILS 1  -  DWH.dbo.PITOPE_COT_REC_NON_CAUT

   Base       : DWH          (schema logique ODI : MSSQL_DWH)
   Role       : equivalent de PITOPE_COT pour le perimetre des operations
                recues, non cautionnees, non reglees. Elle est videe puis
                rechargee a chaque arrete calcule. Elle contient la cotation
                prudentielle (CD_CHR_PD = 'K') et la CHR cible calculee par le
                moteur (CD_CHR_PD_CIBLE).
   Source     : script fourni dans la carte (SCRIPT_PITOPE_COT_REC_NON_CAUT.sql)

   CORRECTIONS PAR RAPPORT AU SCRIPT FOURNI
   ----------------------------------------
   1. Nom de cle primaire : le script fourni nommait la contrainte
      PK_PITOPE_COT. Ce nom est deja porte par la table PITOPE_COT dans le
      meme schema : le CREATE TABLE echouait (Msg 2714, objet deja existant).
      Renommee PK_PITOPE_COT_REC_NON_CAUT.

   2. Colonnes annotees "pas necessaire" : CONSERVEES. Elles entrent toutes
      dans le buffer positionnel du moteur de cotation (dbo.fCotationSQL,
      mapping IOM.MNI.PITOPE_COT_MOT_REC_NON_CAUT.Ins) : CD_TRAIT en
      position 1, FL_DEF_OP, FL_DEC_DET, DT_DEC_DET, FL_PROC_*, DT_PROC_*,
      FL_103_104, DT_103_104 ensuite. Les supprimer obligerait a reecrire le
      buffer et ferait diverger le calcul de celui du stock cautionne.
      Elles restent a NULL sur ce perimetre (pas de contentieux, pas de
      defaut) : le buffer les remplace par leurs valeurs neutres ('0' /
      blancs), exactement comme pour le stock non engage.

   3. CD_TRAIT recoit une valeur par defaut 'M' : le moteur attend un code
      traitement en premiere position du buffer.

   ============================================================================ */
USE [DWH]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE dbo.PITOPE_COT_REC_NON_CAUT
(
    NO_SEQ              INT             NOT NULL,
    CD_TRAIT            CHAR(1)         NOT NULL CONSTRAINT DF_PITOPE_COT_REC_NON_CAUT_CD_TRAIT DEFAULT ('M'),
    CD_OP               CHAR(10)        NOT NULL,
    FL_OP_MEP           TINYINT         NULL,
    FL_REL              TINYINT         NULL,
    TX_LTV              NUMERIC(6, 4)   NULL,
    DT_MEP_OP           DATETIME        NULL,
    NB_INT              INT             NULL,
    FL_DEF_OP           TINYINT         NULL,
    DD_DEF_OP           DATETIME        NULL,
    DF_DEF_OP           DATETIME        NULL,
    FL_DEC_DET          TINYINT         NULL,
    DT_DEC_DET          DATETIME        NULL,
    FL_PROC_SUR         TINYINT         NULL,
    DT_PROC_SUR         DATETIME        NULL,
    FL_PROC_EXE         TINYINT         NULL,
    DT_PROC_EXE         DATETIME        NULL,
    FL_PROC_COLL        TINYINT         NULL,
    DT_PROC_COLL        DATETIME        NULL,
    FL_103_104          TINYINT         NULL,
    DT_103_104          DATETIME        NULL,
    CD_CHR_LGD_COUR     CHAR(2)         NULL,
    DF_REL              DATETIME        NULL,
    DT_ANN_FIN_REL      DATETIME        NULL,
    DT_REF              DATETIME        NULL,
    CD_CHR_PD           CHAR(1)         NULL,
    CD_CHR_LGD          CHAR(2)         NULL,
    DT_VAL_CHR          DATETIME        NULL,
    NU_VERS_CHR         NUMERIC(5, 2)   NULL,
    CD_COTE_ENCOURS     CHAR(2)         NULL,
    NB_NOTE_ENCOURS     NUMERIC(6, 4)   NULL,
    NU_VERS_ENCOURS     NUMERIC(5, 2)   NULL,
    NB_PASS_HIST_LGD    INT             NULL,
    DD_VAL              DATETIME        NULL,
    DF_VAL              DATETIME        NULL,
    DT_MAJ              DATETIME        NULL,
    RES                 VARCHAR(19)     NULL,
    FL_VER_CRT          TINYINT         NULL,
    CD_USR_MAJ          CHAR(8)         NULL,
    CD_CHR_PD_CIBLE     VARCHAR(1)      NULL,
    DT_REF_TRAIT        DATETIME        NULL,
    DT_REF_CHR_PD       DATETIME        NULL,
    DT_REF_CHR_LGD      DATETIME        NULL,
    FL_DEF_PASS         TINYINT         NULL,
    DD_DEB_DEF_1        DATETIME        NULL,
    CONSTRAINT PK_PITOPE_COT_REC_NON_CAUT PRIMARY KEY CLUSTERED (CD_OP ASC, NO_SEQ ASC)
        WITH (FILLFACTOR = 90)
);
GO
