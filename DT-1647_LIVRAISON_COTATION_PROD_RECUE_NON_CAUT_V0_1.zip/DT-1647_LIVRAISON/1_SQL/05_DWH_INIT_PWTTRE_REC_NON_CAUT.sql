/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   05  -  INITIALISATION DU SUIVI DE TRAITEMENT (PWTTRE)  -  A JOUER UNE FOIS

   Base       : DWH          (schema logique ODI : MSSQL_DWH)

   Les scenarios fils utilisent les procedures maison IOR.T003 (debut) et
   IOR.T004 (fin), qui lisent et mettent a jour LEUR ligne de dbo.PWTTRE
   (cle LB_NOM_SCN_SUN = nom du scenario). Sans cette ligne :
     - T003 ne met rien a jour et n'insere aucun suivi PWTSDC ;
     - la variable INEO.V040_DatDonATraiter_V0_1 reste vide ;
     - tous les mappings tournent avec une date NULL et ne produisent rien,
       SANS ERREUR. D'ou ce script.

   Lignes creees
     IOM_MNI_COTATION_PROD_RECUE_CHGODS  : scenario fils 1 (perimetre, score,
                                            cotation) - livre ici.
     IMM_MNI_COTATION_PROD_RECUE_CHGDTM  : scenario fils 2 (insertion dans
                                            PDTOPE_COT_REC_NON_CAUT) - decrit
                                            dans une autre carte. La ligne est
                                            creee des maintenant pour que le
                                            package pere puisse la piloter.

   La ligne du fils 1 sert aussi de reference de periode au package pere
   (meme principe que IOM_MNI_COTATION_PRUD avec IOM_MNI_COTATION_PRUD_CHGODS) :
     DA_DEB_DEL_TRT = "date des donnees" du dernier arrete calcule
                      (1er jour du mois qui suit l'arrete).
     DA_FIN_DEL_FOR = borne haute optionnelle (NULL = aujourd'hui).

   CONVENTION DE DATE (identique a toute la cotation prudentielle)
     date des donnees a traiter  = 1er jour du mois M+1
     arrete calcule              = dernier jour du mois M
                                 = date des donnees - DAY(date des donnees)
     Ex. date des donnees 2026-08-01  ->  arrete 2026-07-31 (CD_DAT_ARR_AAM 202607)

   PARAMETRE
     @DA_DEB_DEL_TRT_INIT = '2026-07-01' : le premier arrete calcule sera
     juillet 2026, premier mois concerne par la mise en place de l'API score
     d'octroi (11/07/2026). Avancer ou reculer selon la profondeur de reprise
     souhaitee par la DRM.

   La structure de PWTTRE n'est pas decrite dans les sources de la carte :
   les lignes sont donc creees par recopie dynamique de la ligne du
   scenario existant IOM_MNI_COTATION_PRUD_MENS_CHGODS (toutes colonnes),
   en surchargeant seulement les colonnes de pilotage.

   Script rejouable : une ligne deja presente n'est pas modifiee.
   ============================================================================ */
USE [DWH]
GO
SET NOCOUNT ON;

DECLARE @DA_DEB_DEL_TRT_INIT DATETIME = '20260701';        -- << PARAMETRE
DECLARE @SCN_MODELE SYSNAME = N'IOM_MNI_COTATION_PRUD_MENS_CHGODS';

IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE WHERE LB_NOM_SCN_SUN = @SCN_MODELE)
    THROW 50201, N'Ligne modele IOM_MNI_COTATION_PRUD_MENS_CHGODS absente de dbo.PWTTRE : initialisation impossible.', 1;

DECLARE @A_CREER TABLE (LB_NOM_SCN_SUN SYSNAME NOT NULL PRIMARY KEY);
INSERT INTO @A_CREER VALUES (N'IOM_MNI_COTATION_PROD_RECUE_CHGODS'),
                            (N'IMM_MNI_COTATION_PROD_RECUE_CHGDTM');

DECLARE @cols NVARCHAR(MAX), @vals NVARCHAR(MAX), @sql NVARCHAR(MAX), @nom SYSNAME;

/* Liste des colonnes recopiables (hors identite / calculees) avec surcharge */
SELECT @cols = STRING_AGG(CAST(QUOTENAME(c.name) AS NVARCHAR(MAX)), N', ') WITHIN GROUP (ORDER BY c.column_id),
       @vals = STRING_AGG(CAST(CASE c.name
                        WHEN N'LB_NOM_SCN_SUN' THEN N'@nom'
                        WHEN N'DA_DEB_DEL_TRT' THEN N'@deb'
                        WHEN N'DA_FIN_DEL_FOR' THEN N'NULL'
                        WHEN N'DA_DON_A_TRT'   THEN N'NULL'
                        WHEN N'DA_DER_TRT'     THEN N'NULL'
                        WHEN N'NO_SEQ'         THEN N'0'
                        ELSE QUOTENAME(c.name) END AS NVARCHAR(MAX)), N', ') WITHIN GROUP (ORDER BY c.column_id)
FROM sys.columns c
WHERE c.object_id = OBJECT_ID(N'dbo.PWTTRE')
  AND c.is_identity = 0
  AND c.is_computed = 0;

SET @sql = N'INSERT INTO dbo.PWTTRE (' + @cols + N') SELECT ' + @vals
         + N' FROM dbo.PWTTRE WHERE LB_NOM_SCN_SUN = @modele;';

DECLARE c_scn CURSOR LOCAL FAST_FORWARD FOR SELECT LB_NOM_SCN_SUN FROM @A_CREER;
OPEN c_scn;
FETCH NEXT FROM c_scn INTO @nom;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF EXISTS (SELECT 1 FROM dbo.PWTTRE WHERE LB_NOM_SCN_SUN = @nom)
        PRINT N'[IGNOREE] PWTTRE ' + @nom + N' existe deja (non modifiee).';
    ELSE
    BEGIN
        EXEC sys.sp_executesql @sql,
             N'@nom SYSNAME, @deb DATETIME, @modele SYSNAME',
             @nom = @nom, @deb = @DA_DEB_DEL_TRT_INIT, @modele = @SCN_MODELE;
        PRINT N'[CREEE]   PWTTRE ' + @nom + N' - DA_DEB_DEL_TRT = '
              + CONVERT(NVARCHAR(10), @DA_DEB_DEL_TRT_INIT, 23);
    END
    FETCH NEXT FROM c_scn INTO @nom;
END
CLOSE c_scn;
DEALLOCATE c_scn;
GO

/* Controle
-------------------------------------------------------------------------------
SELECT LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_FIN_DEL_FOR, DA_DON_A_TRT, NO_SEQ, DA_DER_TRT
FROM DWH.dbo.PWTTRE
WHERE LB_NOM_SCN_SUN IN (N'IOM_MNI_COTATION_PROD_RECUE_CHGODS', N'IMM_MNI_COTATION_PROD_RECUE_CHGDTM');

Recalcul de plusieurs arretes (annule et remplace) : reculer DA_DEB_DEL_TRT
de la ligne du fils 1, ex. pour recalculer a partir de l'arrete d'aout 2026 :
UPDATE DWH.dbo.PWTTRE SET DA_DEB_DEL_TRT = '20260801'
WHERE LB_NOM_SCN_SUN = N'IOM_MNI_COTATION_PROD_RECUE_CHGODS';
---------------------------------------------------------------------------- */
