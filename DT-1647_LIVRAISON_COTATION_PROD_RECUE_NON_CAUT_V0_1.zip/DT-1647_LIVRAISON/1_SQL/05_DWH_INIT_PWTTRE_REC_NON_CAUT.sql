/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   05  -  LIGNES PWTTRE DES TROIS SCENARIOS   (base DWH, a jouer une fois)

   IOM_MNI_COTATION_PROD_RECUE          package pere : sa ligne porte la periode
                                        (DA_DEB_DEL_TRT = dernier passage OK)
   IOM_MNI_COTATION_PROD_RECUE_CHGODS   fils 1 (T003 / T004)
   IMM_MNI_COTATION_PROD_RECUE_CHGDTM   fils 2 (autre carte)

   DA_DEB_DEL_TRT initial = 2026-07-01 : premier arrete calcule = juillet 2026
   (mise en place de l'API score d'octroi le 11/07/2026).

   La structure de PWTTRE n'est pas dans les sources de la carte : les lignes
   sont recopiees de celle de IOM_MNI_COTATION_PRUD_MENS_CHGODS, en
   surchargeant les colonnes de pilotage.
   ============================================================================ */
USE [DWH]
GO

DECLARE @cols NVARCHAR(MAX), @vals NVARCHAR(MAX), @sql NVARCHAR(MAX);

SELECT @cols = STRING_AGG(CAST(QUOTENAME(c.name) AS NVARCHAR(MAX)), N', ') WITHIN GROUP (ORDER BY c.column_id),
       @vals = STRING_AGG(CAST(CASE c.name
                    WHEN N'LB_NOM_SCN_SUN' THEN N'S.LB_NOM_SCN_SUN'
                    WHEN N'DA_DEB_DEL_TRT' THEN N'''20260701'''
                    WHEN N'DA_FIN_DEL_FOR' THEN N'NULL'
                    WHEN N'DA_DON_A_TRT'   THEN N'NULL'
                    WHEN N'DA_DER_TRT'     THEN N'NULL'
                    WHEN N'NO_SEQ'         THEN N'0'
                    ELSE N'M.' + QUOTENAME(c.name) END AS NVARCHAR(MAX)), N', ') WITHIN GROUP (ORDER BY c.column_id)
FROM sys.columns c
WHERE c.object_id = OBJECT_ID(N'dbo.PWTTRE')
  AND c.is_identity = 0
  AND c.is_computed = 0;

SET @sql = N'INSERT INTO dbo.PWTTRE (' + @cols + N')
SELECT ' + @vals + N'
FROM dbo.PWTTRE AS M
CROSS JOIN (VALUES (''IOM_MNI_COTATION_PROD_RECUE''),
                   (''IOM_MNI_COTATION_PROD_RECUE_CHGODS''),
                   (''IMM_MNI_COTATION_PROD_RECUE_CHGDTM'')) AS S (LB_NOM_SCN_SUN)
WHERE M.LB_NOM_SCN_SUN = ''IOM_MNI_COTATION_PRUD_MENS_CHGODS'';';

EXEC sys.sp_executesql @sql;
GO
