/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   99  -  RETOUR ARRIERE COMPLET (A NE JOUER QU'EN CAS D'ABANDON)

   Supprime tous les objets crees par les scripts 01 a 05.
   Aucun objet existant avant la livraison n'est touche : seules des tables
   suffixees _REC_NON_CAUT et les lignes PWTTRE / PITCOT_PERIODE_REPRISE des
   nouveaux scenarios sont supprimees.

   ATTENTION : DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT contient l'historique
   mensuel. Sa suppression est commentee : la decommenter seulement si
   l'historique doit reellement etre perdu.
   ============================================================================ */
USE [DWH]
GO
SET NOCOUNT ON;

DECLARE @TABLES TABLE (NOM SYSNAME NOT NULL PRIMARY KEY);
INSERT INTO @TABLES VALUES
    (N'PITOPE_COT_REC_NON_CAUT'), (N'PITOPE_MAX_SEQ_PRT_REC_NON_CAUT'),
    (N'PITOPE_PERIMETRE_REC_NON_CAUT'), (N'PITOPE_COT_COMP_REC_NON_CAUT'),
    (N'PITOPE_COT_REF_PRT_INT_REC_NON_CAUT'), (N'PITOPE_COT_REF_PRT_REC_NON_CAUT'),
    (N'PITOPE_COT_REF_OPE_REC_NON_CAUT'), (N'PITOPE_COT_PER0_M_REC_NON_CAUT'),
    (N'PWTOPE_POC_SCR_INT_REC_NON_CAUT'), (N'PWTOPE_POC_SCR_REC_NON_CAUT'),
    (N'PWTOPE_APT_SCR_INT_REC_NON_CAUT'), (N'PWTOPE_APT_SCR_REC_NON_CAUT'),
    (N'PWTOPE_CHA_SCR_INT_REC_NON_CAUT'), (N'PWTOPE_CHA_SCR_REC_NON_CAUT'),
    (N'PWTPRT_SCR_INT_REC_NON_CAUT'), (N'PWTPRT_SCR_REC_NON_CAUT'),
    (N'PWTINT_SCR_INT_REC_NON_CAUT'), (N'PRTIND_INT_REC_NON_CAUT'),
    (N'PWTINT_SCR_REC_NON_CAUT'), (N'PITOPE_COT_SCR_REC_NON_CAUT'),
    (N'PITOPE_COT_SCR_MOT_REC_NON_CAUT'), (N'PITOPE_COT_MOT_REC_NON_CAUT'),
    (N'PITOPE_COT_MOT_RES_REC_NON_CAUT');

DECLARE @nom SYSNAME, @sql NVARCHAR(400);
DECLARE c_t CURSOR LOCAL FAST_FORWARD FOR SELECT NOM FROM @TABLES;
OPEN c_t;
FETCH NEXT FROM c_t INTO @nom;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID(N'dbo.' + @nom, N'U') IS NOT NULL
    BEGIN
        SET @sql = N'DROP TABLE dbo.' + QUOTENAME(@nom) + N';';
        EXEC sys.sp_executesql @sql;
        PRINT N'[SUPPRIMEE] dbo.' + @nom;
    END
    FETCH NEXT FROM c_t INTO @nom;
END
CLOSE c_t;
DEALLOCATE c_t;

DELETE FROM dbo.PWTTRE
WHERE LB_NOM_SCN_SUN IN (N'IOM_MNI_COTATION_PROD_RECUE_CHGODS', N'IMM_MNI_COTATION_PROD_RECUE_CHGDTM');

DELETE FROM dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = N'IOM_MNI_COTATION_PROD_RECUE';
GO

/* Historique mensuel - a decommenter volontairement
   (pas de separateur de lot dans ce commentaire : SSMS couperait le lot
   au milieu du commentaire et leverait "Missing end comment mark")
-------------------------------------------------------------------------------
IF OBJECT_ID(N'DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT', N'U') IS NOT NULL
    DROP TABLE DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT;
---------------------------------------------------------------------------- */
