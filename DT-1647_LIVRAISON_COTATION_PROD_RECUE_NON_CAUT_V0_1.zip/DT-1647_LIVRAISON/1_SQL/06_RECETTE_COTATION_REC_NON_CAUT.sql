/* ============================================================================
   DT-1647  -  COTATION PRODUCTION RECUE NON CAUTIONNEE
   06  -  REQUETES DE RECETTE (lecture seule, a jouer dans SSMS)

   Une section par critere d'acceptation de la carte. Chaque requete
   "anomalie" doit renvoyer 0 ligne / 0. Les requetes "information"
   donnent les chiffres a presenter a la DRM.

   A jouer apres une execution du package pere, pour un arrete donne.
   Les sections A a E portent sur la table de travail du fils 1
   (PITOPE_COT_REC_NON_CAUT : contient le DERNIER arrete calcule).
   Les sections F et G portent sur l'historique PDTOPE_COT_REC_NON_CAUT
   (disponible une fois le fils 2 - autre carte - livre).
   ============================================================================ */
USE [DWH]
GO
SET NOCOUNT ON;

DECLARE @CD_DAT_ARR_AAM INT = 202607;                       -- << arrete a recetter (yyyymm)

/* ---------------------------------------------------------------------------
   0. PREREQUIS - structure de PITCOT_PERIODE_REPRISE attendue par le pere
      (colonnes DD_VAL, SEQ, TRAITE, LB_NOM_SCN_SUN). Attendu : 4 lignes.
--------------------------------------------------------------------------- */
SELECT c.name AS COLONNE, t.name AS TYPE_SQL
FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID(N'dbo.PITCOT_PERIODE_REPRISE')
  AND c.name IN (N'DD_VAL', N'SEQ', N'TRAITE', N'LB_NOM_SCN_SUN');

/* ---------------------------------------------------------------------------
   A. INFORMATION - composition du perimetre
--------------------------------------------------------------------------- */
SELECT P.CD_ETAP, P.CD_STATUT,
       COUNT(DISTINCT P.CD_OP) AS NB_OPERATIONS,
       COUNT(*)                AS NB_PRETS,
       SUM(P.MT_PRET_PFI)      AS MT_PRET_PFI
FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT P
WHERE P.CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
GROUP BY P.CD_ETAP, P.CD_STATUT
ORDER BY P.CD_ETAP, P.CD_STATUT;

/* ---------------------------------------------------------------------------
   B. CRITERE "insertion du perimetre dans la table cible"
      et "tout le perimetre est cote"
      Anomalie si NB_NON_COTEES > 0 ou NB_CIBLE_NULLE > 0.
--------------------------------------------------------------------------- */
SELECT
    (SELECT COUNT(DISTINCT CD_OP) FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT WHERE CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM) AS NB_OP_PERIMETRE,
    (SELECT COUNT(*) FROM dbo.PITOPE_COT_REC_NON_CAUT)                                                           AS NB_OP_COTEES,
    (SELECT COUNT(DISTINCT P.CD_OP) FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT P
      WHERE P.CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
        AND NOT EXISTS (SELECT 1 FROM dbo.PITOPE_COT_REC_NON_CAUT C WHERE C.CD_OP = P.CD_OP))                    AS NB_NON_COTEES,
    (SELECT COUNT(*) FROM dbo.PITOPE_COT_REC_NON_CAUT WHERE NULLIF(LTRIM(RTRIM(CD_CHR_PD_CIBLE)), '') IS NULL)    AS NB_CIBLE_NULLE,
    (SELECT COUNT(*) FROM dbo.PITOPE_COT_REC_NON_CAUT WHERE ISNULL(CD_CHR_PD, '') <> 'K')                         AS NB_CHR_PD_DIFF_K,
    (SELECT MIN(CONVERT(CHAR(6), DT_REF_TRAIT, 112)) FROM dbo.PITOPE_COT_REC_NON_CAUT)                            AS ARRETE_TABLE_TRAVAIL;

/* Detail des operations du perimetre non cotees (diagnostic) : a quelle etape
   de la chaine ont-elles disparu ? */
SELECT TOP (200) P.CD_OP,
       CASE WHEN NOT EXISTS (SELECT 1 FROM dbo.PITOPE_COT_REF_OPE_REC_NON_CAUT R WHERE R.CD_OP = P.CD_OP)
                 THEN '05 REF_OPE : pas de version PWTOPE non annulee anterieure a l''arrete'
            WHEN NOT EXISTS (SELECT 1 FROM dbo.PITOPE_COT_SCR_MOT_REC_NON_CAUT S WHERE S.CD_OP = P.CD_OP)
                 THEN '21 SCORE : pas de resultat moteur de score'
            ELSE '22+ COTATION' END AS ETAPE_DE_PERTE
FROM (SELECT DISTINCT CD_OP FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT WHERE CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM) P
WHERE NOT EXISTS (SELECT 1 FROM dbo.PITOPE_COT_REC_NON_CAUT C WHERE C.CD_OP = P.CD_OP)
ORDER BY P.CD_OP;

/* ---------------------------------------------------------------------------
   C. CRITERE "les operations terminees et/ou annulees/refusees sont absentes"
      Information : presence de prets ANN/REF dans le perimetre.
      L'exclusion ANN/REF a ete desactivee le 16/10 (voir README, point
      ouvert 1). Si cette requete renvoie des lignes, faire valider par
      Cyril Costes leur maintien dans le perimetre.
--------------------------------------------------------------------------- */
SELECT P.CD_STATUT, COUNT(DISTINCT P.CD_OP) AS NB_OPERATIONS, COUNT(*) AS NB_PRETS
FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT P
WHERE P.CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
  AND P.CD_STATUT IN ('ANN', 'REF')
GROUP BY P.CD_STATUT;

/* Anomalie : pret hors etapes "recu non regle" -> 0 attendu */
SELECT COUNT(*) AS NB_PRETS_HORS_ETAPES
FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT
WHERE CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
  AND CD_ETAP NOT IN ('CLA', 'EAU', 'EDI', 'PEC', 'SIG');

/* ---------------------------------------------------------------------------
   D. CRITERE "les operations cautionnees ou engagees sont absentes"
      Anomalie : 0 attendu dans les deux colonnes.
--------------------------------------------------------------------------- */
SELECT
    (SELECT COUNT(DISTINCT C.CD_OP)
       FROM dbo.PITOPE_COT_REC_NON_CAUT C
       JOIN dbo.PWTPRT PRT ON PRT.CD_OP = C.CD_OP
       JOIN DWH_ENCOURS.dbo.EWTENC ENC ON ENC.CD_PRET = PRT.CD_PRET AND ENC.DT_ENCOURS = @CD_DAT_ARR_AAM) AS NB_OP_CAUTIONNEES,
    (SELECT COUNT(DISTINCT C.CD_OP)
       FROM dbo.PITOPE_COT_REC_NON_CAUT C
       JOIN dbo.PWTPRT PRT ON PRT.CD_OP = C.CD_OP
       JOIN DWH_ENCOURS.dbo.EWTNEC NEC ON NEC.CD_PRET = PRT.CD_PRET AND NEC.DT_ENCOURS = @CD_DAT_ARR_AAM) AS NB_OP_ENGAGEES;

/* ---------------------------------------------------------------------------
   E. INFORMATION - objectif de la carte : repartition des classes homogenes
      de risque de la production recue non cautionnee
--------------------------------------------------------------------------- */
SELECT C.CD_CHR_PD_CIBLE, C.CD_CHR_LGD,
       COUNT(*)                                            AS NB_OPERATIONS,
       CAST(100.0 * COUNT(*) / SUM(COUNT(*)) OVER () AS DECIMAL(5, 2)) AS PCT
FROM dbo.PITOPE_COT_REC_NON_CAUT C
GROUP BY C.CD_CHR_PD_CIBLE, C.CD_CHR_LGD
ORDER BY C.CD_CHR_PD_CIBLE, C.CD_CHR_LGD;

/* Information - dates de CHR non renseignees (README, point ouvert 3) */
SELECT SUM(CASE WHEN DT_VAL_CHR     IS NULL THEN 1 ELSE 0 END) AS NB_DT_VAL_CHR_NULLE,
       SUM(CASE WHEN DT_REF_CHR_PD  IS NULL THEN 1 ELSE 0 END) AS NB_DT_REF_CHR_PD_NULLE,
       SUM(CASE WHEN DT_REF_CHR_LGD IS NULL THEN 1 ELSE 0 END) AS NB_DT_REF_CHR_LGD_NULLE,
       COUNT(*)                                                AS NB_TOTAL
FROM dbo.PITOPE_COT_REC_NON_CAUT;

/* ---------------------------------------------------------------------------
   F. REGLE "Si la CHR n'evolue pas alors les dates de validite de CHR ne
      changent pas" (historique, apres fils 2)
      Anomalie : 0 attendu. Compare chaque arrete au precedent.
--------------------------------------------------------------------------- */
WITH H AS (
    SELECT CD_OP, CD_DAT_ARR_AAM, CD_CHR_PD_CIBLE, CD_CHR_LGD, DT_REF_CHR_PD, DT_REF_CHR_LGD,
           LAG(CD_CHR_PD_CIBLE) OVER (PARTITION BY CD_OP ORDER BY CD_DAT_ARR_AAM, NO_SEQ) AS CIBLE_PREC,
           LAG(CD_CHR_LGD)      OVER (PARTITION BY CD_OP ORDER BY CD_DAT_ARR_AAM, NO_SEQ) AS LGD_PREC,
           LAG(DT_REF_CHR_PD)   OVER (PARTITION BY CD_OP ORDER BY CD_DAT_ARR_AAM, NO_SEQ) AS DT_PD_PREC
    FROM DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT
)
SELECT COUNT(*) AS NB_DATE_CHR_PD_MODIFIEE_SANS_CHANGEMENT
FROM H
WHERE CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
  AND CIBLE_PREC = CD_CHR_PD_CIBLE
  AND ISNULL(DT_PD_PREC, '19000101') <> ISNULL(DT_REF_CHR_PD, '19000101');

/* ---------------------------------------------------------------------------
   G. STRATEGIE DE RECETTE de la carte : "toutes les operations identifiees
      dans le perimetre doivent avoir une cotation prudentielle, soit
      actualisee, soit deja calculee au moins une fois" (historique)
      Anomalie : 0 attendu.
--------------------------------------------------------------------------- */
SELECT COUNT(DISTINCT P.CD_OP) AS NB_OP_JAMAIS_COTEES
FROM dbo.PITOPE_PERIMETRE_REC_NON_CAUT P
WHERE P.CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
  AND NOT EXISTS (SELECT 1 FROM DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT H
                  WHERE H.CD_OP = P.CD_OP
                    AND H.CD_DAT_ARR_AAM <= @CD_DAT_ARR_AAM
                    AND NULLIF(LTRIM(RTRIM(H.CD_CHR_PD_CIBLE)), '') IS NOT NULL);
GO
