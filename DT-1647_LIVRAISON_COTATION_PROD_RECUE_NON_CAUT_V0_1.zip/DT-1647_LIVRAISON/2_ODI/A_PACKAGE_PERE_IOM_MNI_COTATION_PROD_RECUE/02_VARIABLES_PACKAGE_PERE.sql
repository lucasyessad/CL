/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   VARIABLES DU PACKAGE (projet INEO)

   Trois variables a creer, sur le modele de V_IOM_COT_NBJ / V_IOM_COT_N /
   V_IOM_DatMNICOT_V0_1 du package IOM_MNI_COTATION_PRUD V0_5. Des
   variables NOUVELLES (et non les existantes) : les deux packages peuvent
   ainsi tourner le meme soir sans s'ecraser leurs compteurs.

   Schema logique de rafraichissement : MSSQL_DWH
   ============================================================================ */


/* ----------------------------------------------------------------------------
   INEO.V_IOM_COT_REC_NB_ARR
     Type          : Numerique      Historisation : derniere valeur
     Role          : nombre d'arretes a calculer (borne de la boucle)
     Rafraichissement :
---------------------------------------------------------------------------- */
select count(*)
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
where LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'


/* ----------------------------------------------------------------------------
   INEO.V_IOM_COT_REC_N
     Type          : Numerique      Historisation : derniere valeur
     Role          : compteur de boucle (SEQ de l'arrete en cours)
     Pas de requete de rafraichissement : positionnee a 1 (etape "Affecter"),
     comparee a V_IOM_COT_REC_NB_ARR (etape "Evaluer"), incrementee de 1
     (etape "Affecter" avec increment).
---------------------------------------------------------------------------- */


/* ----------------------------------------------------------------------------
   INEO.V_IOM_COT_REC_DatDon
     Type          : Alphanumerique Historisation : toutes les valeurs
     Role          : date des donnees de l'arrete en cours (trace du journal
                     ODI : on retrouve quel arrete chaque iteration a calcule)
     Rafraichissement :
---------------------------------------------------------------------------- */
select convert(datetime, DD_VAL, 121)
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
where SEQ = #INEO.V_IOM_COT_REC_N
  and TRAITE = 0
  and LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'
