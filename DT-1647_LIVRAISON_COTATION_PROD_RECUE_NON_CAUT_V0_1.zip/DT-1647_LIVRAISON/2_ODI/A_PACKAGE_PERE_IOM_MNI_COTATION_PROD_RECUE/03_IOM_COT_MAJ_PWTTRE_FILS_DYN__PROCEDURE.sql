/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P06  -  PROCEDURE  IOM_COT_MAJ_PWTTRE_FILS_DYN   (dynamique)

   Positionne DA_FIN_DEL_FOR des scenarios fils sur l'arrete en cours ;
   T003 du fils la recopie dans DA_DON_A_TRT -> V040_DatDonATraiter_V0_1.

   Option de procedure (a creer) :
     LB_SCN_FILS   Texte   liste des scenarios fils, separes par des virgules
   Valeur dans ce package :
     IOM_MNI_COTATION_PROD_RECUE_CHGODS,IMM_MNI_COTATION_PROD_RECUE_CHGDTM

   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */
UPDATE <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTTRE
SET    DA_FIN_DEL_FOR = (SELECT P.DD_VAL
                         FROM   <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE AS P
                         WHERE  P.SEQ = #INEO.V_IOM_COT_N
                           AND  P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
WHERE  LB_NOM_SCN_SUN IN (SELECT LTRIM(RTRIM(value))
                          FROM STRING_SPLIT('<?=odiRef.getOption("LB_SCN_FILS") ?>', ','))
