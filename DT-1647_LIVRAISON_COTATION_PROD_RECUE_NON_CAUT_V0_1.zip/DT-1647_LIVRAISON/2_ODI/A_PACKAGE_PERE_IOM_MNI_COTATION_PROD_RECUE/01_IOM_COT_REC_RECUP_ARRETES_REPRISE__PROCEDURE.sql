/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P01  -  PROCEDURE  IOM_COT_REC_RECUP_ARRETES_REPRISE

   Construit la liste des arretes a calculer dans la table maison
   dbo.PITCOT_PERIODE_REPRISE (deja utilisee par IOM_MNI_COTATION_PRUD),
   cloisonnee par LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'.
   C'est la "table de periode de reprise" demandee par la carte ; aucune
   nouvelle table n'est necessaire.

   Modele : procedure IOM_COT_RECUP_DATES_REPRISE_V2 du package
   IOM_MNI_COTATION_PRUD V0_5, avec deux differences :
     - pas MENSUEL (une ligne par arrete) et non plus quotidien : ce
       traitement n'a pas de "gestion du quotidien" (consigne de la carte :
       "il y a beaucoup de choses a enlever, gestion du quotidien, tests,
       qdd...") ;
     - un arrete n'est retenu que si l'encours engage ET l'encours non
       engage de ce mois sont charges : le perimetre se definit par
       exclusion de ces deux encours ; calculer sans eux coterait a tort
       toute la production. La liste s'arrete au premier mois incomplet
       (jamais de trou : les mois suivants attendent le prochain passage).

   Une ligne = une "date des donnees" (1er jour du mois M+1) :
       DD_VAL = 2026-08-01   ->   arrete 2026-07-31

   Bornes lues sur la ligne PWTTRE du scenario fils 1
   (IOM_MNI_COTATION_PROD_RECUE_CHGODS), comme le pere d'origine lit celle de
   IOM_MNI_COTATION_PRUD_CHGODS :
       DD_VAL >  DA_DEB_DEL_TRT                       (dernier arrete calcule)
       DD_VAL <= ISNULL(DA_FIN_DEL_FOR, aujourd'hui)   (borne haute optionnelle)
   Recalcul en annule et remplace : reculer DA_DEB_DEL_TRT (voir
   1_SQL/05_DWH_INIT_PWTTRE_REC_NON_CAUT.sql).

   Structure de PITCOT_PERIODE_REPRISE : colonnes DD_VAL, SEQ, TRAITE,
   LB_NOM_SCN_SUN (noms releves dans le code de production du package
   IOM_MNI_COTATION_PRUD V0_5). L'INSERT nomme ses colonnes.

   Schema logique des taches : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */


/* ============================================================================
   TACHE 1  -  Purge de la liste precedente
   ============================================================================ */
DELETE FROM <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'


/* ============================================================================
   TACHE 2  -  Liste des arretes a calculer
   ============================================================================ */
DECLARE @DEB DATE, @FIN DATE;

SELECT @DEB = CONVERT(DATE, DA_DEB_DEL_TRT, 121),
       @FIN = CONVERT(DATE, ISNULL(DA_FIN_DEL_FOR, GETDATE()), 121)
FROM   <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTTRE
WHERE  LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE_CHGODS';

IF @DEB IS NULL
    THROW 50401, N'IOM_COT_REC_RECUP_ARRETES_REPRISE : ligne PWTTRE IOM_MNI_COTATION_PROD_RECUE_CHGODS absente ou DA_DEB_DEL_TRT vide - jouer 1_SQL/05_DWH_INIT_PWTTRE_REC_NON_CAUT.sql.', 1;

WITH MOIS AS
(
    SELECT DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(@DEB), MONTH(@DEB), 1)) AS DD_VAL
    UNION ALL
    SELECT DATEADD(MONTH, 1, DD_VAL) FROM MOIS WHERE DATEADD(MONTH, 1, DD_VAL) <= @FIN
),
ARRETES AS
(
    SELECT M.DD_VAL,
           CASE WHEN EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "EWTENC", "MSSQL_DWH_ENCOURS", "D") ?> AS ENC
                             WHERE ENC.DT_ENCOURS = YEAR(DATEADD(MONTH, -1, M.DD_VAL)) * 100 + MONTH(DATEADD(MONTH, -1, M.DD_VAL)))
                 AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "EWTNEC", "MSSQL_DWH_ENCOURS", "D") ?> AS NEC
                             WHERE NEC.DT_ENCOURS = YEAR(DATEADD(MONTH, -1, M.DD_VAL)) * 100 + MONTH(DATEADD(MONTH, -1, M.DD_VAL)))
                THEN 1 ELSE 0 END AS FL_ENCOURS_CHARGES
    FROM   MOIS AS M
    WHERE  M.DD_VAL <= @FIN
)
/* On s'arrete au premier mois dont les encours manquent : sauter un mois
   puis calculer le suivant ferait avancer PWTTRE (T004) au-dela d'un arrete
   jamais calcule, qui serait alors perdu sans message. */
INSERT INTO <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
       (DD_VAL, SEQ, TRAITE, LB_NOM_SCN_SUN)
SELECT A.DD_VAL,
       ROW_NUMBER() OVER (ORDER BY A.DD_VAL),
       0,
       'IOM_MNI_COTATION_PROD_RECUE'
FROM   ARRETES AS A
WHERE  A.DD_VAL < ISNULL((SELECT MIN(B.DD_VAL) FROM ARRETES AS B WHERE B.FL_ENCOURS_CHARGES = 0), '99991231')
OPTION (MAXRECURSION 600);
