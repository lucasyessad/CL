/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P09  -  PROCEDURE  IOM_COT_MAJ_PERIODE_REPRISE_DYN   (dynamique)

   Marque l'arrete en cours comme traite.
   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */
UPDATE <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
SET    TRAITE = 1
WHERE  SEQ = #INEO.V_IOM_COT_N
  AND  LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
