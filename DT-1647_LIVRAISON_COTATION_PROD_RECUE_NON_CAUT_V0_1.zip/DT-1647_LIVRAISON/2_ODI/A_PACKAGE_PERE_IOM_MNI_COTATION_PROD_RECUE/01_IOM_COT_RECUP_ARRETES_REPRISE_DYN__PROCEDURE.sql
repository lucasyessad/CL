/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P01  -  PROCEDURE  IOM_COT_RECUP_ARRETES_REPRISE_DYN   (dynamique)

   Liste les arretes mensuels a calculer dans PITCOT_PERIODE_REPRISE.
   Dynamique : tout est cle sur le nom de session (SESS_NAME), comme T003 /
   T004. Reutilisable telle quelle par tout package pere mensuel du meme
   genre, sans modification.

   Bornes = ligne PWTTRE du package pere, figee par T003 en etape P00 :
       DD_VAL >  DA_DEB_DEL_TRT     (dernier passage OK, avance par T004)
       DD_VAL <= DA_DON_A_TRT       (= ISNULL(DA_FIN_DEL_FOR, date batch))
   Une ligne par 1er du mois : DD_VAL 2026-08-01 -> arrete 2026-07-31.

   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */

/* TACHE 1  -  Purge de la liste precedente */
DELETE FROM <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'


/* TACHE 2  -  Liste des arretes a calculer */
DECLARE @DEB DATE, @FIN DATE;

SELECT @DEB = CONVERT(DATE, DA_DEB_DEL_TRT, 121),
       @FIN = CONVERT(DATE, DA_DON_A_TRT, 121)
FROM   <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTTRE
WHERE  LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>';

WITH MOIS AS
(
    SELECT DATEADD(MONTH, 1, DATEFROMPARTS(YEAR(@DEB), MONTH(@DEB), 1)) AS DD_VAL
    UNION ALL
    SELECT DATEADD(MONTH, 1, DD_VAL) FROM MOIS WHERE DATEADD(MONTH, 1, DD_VAL) <= @FIN
)
INSERT INTO <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
       (DD_VAL, SEQ, TRAITE, LB_NOM_SCN_SUN)
SELECT M.DD_VAL,
       ROW_NUMBER() OVER (ORDER BY M.DD_VAL),
       0,
       '<?=odiRef.getSession("SESS_NAME") ?>'
FROM   MOIS AS M
WHERE  M.DD_VAL <= @FIN
OPTION (MAXRECURSION 600);
