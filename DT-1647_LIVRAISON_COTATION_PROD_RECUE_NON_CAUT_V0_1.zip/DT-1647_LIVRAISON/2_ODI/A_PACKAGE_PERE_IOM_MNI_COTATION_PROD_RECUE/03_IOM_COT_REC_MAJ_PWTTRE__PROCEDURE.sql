/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P03  -  PROCEDURE  IOM_COT_REC_MAJ_PWTTRE

   Avant chaque appel des fils : positionne la borne DA_FIN_DEL_FOR des deux
   scenarios fils sur la date des donnees de l'arrete en cours. T003, en
   debut de fils, la recopie dans DA_DON_A_TRT -> V040_DatDonATraiter_V0_1.

   Modele : IOM_COT_MAJ_PWTTRE_V2 du package IOM_MNI_COTATION_PRUD V0_5.

   Le fils 2 (insertion, autre carte) est mis a jour des maintenant : tant
   qu'il n'est pas branche, sa ligne PWTTRE recoit la date sans effet.

   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */
UPDATE <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTTRE
SET    DA_FIN_DEL_FOR = (SELECT P.DD_VAL
                         FROM   <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE AS P
                         WHERE  P.SEQ = #INEO.V_IOM_COT_REC_N
                           AND  P.TRAITE = 0
                           AND  P.LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE')
WHERE  LB_NOM_SCN_SUN IN ('IOM_MNI_COTATION_PROD_RECUE_CHGODS',
                          'IMM_MNI_COTATION_PROD_RECUE_CHGDTM')
