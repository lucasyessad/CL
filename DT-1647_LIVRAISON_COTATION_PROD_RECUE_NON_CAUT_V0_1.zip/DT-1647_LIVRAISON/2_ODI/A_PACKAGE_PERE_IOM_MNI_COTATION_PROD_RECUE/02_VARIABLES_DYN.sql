/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   VARIABLES (projet INEO)

   INEO.V_IOM_COT_N           EXISTANTE, reutilisee : compteur de boucle
                              (pas de requete, affectee / incrementee dans
                              le package). Valeur propre a chaque session.

   Deux variables dynamiques nouvelles (cle = nom de session), reutilisables
   par tout package pere du meme genre.
   Schema logique de rafraichissement : MSSQL_DWH
   ============================================================================ */

/* INEO.V_IOM_COT_NB_ARR_DYN   (numerique)  -  nombre d'arretes a calculer */
select count(*)
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'


/* INEO.V_IOM_COT_DatDon_DYN   (alphanumerique, historisee)  -  date des
   donnees de l'arrete en cours, tracee dans le journal ODI */
select convert(datetime, DD_VAL, 121)
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
where SEQ = #INEO.V_IOM_COT_N
  and LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
