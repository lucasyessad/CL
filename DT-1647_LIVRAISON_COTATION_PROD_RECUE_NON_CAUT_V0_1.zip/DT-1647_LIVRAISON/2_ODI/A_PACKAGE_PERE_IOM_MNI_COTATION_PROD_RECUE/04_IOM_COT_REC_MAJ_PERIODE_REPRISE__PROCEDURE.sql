/* ============================================================================
   DT-1647  -  PACKAGE PERE  IOM_MNI_COTATION_PROD_RECUE (V0_1)
   ETAPE P04  -  PROCEDURE  IOM_COT_REC_MAJ_PERIODE_REPRISE

   Apres succes des fils : marque l'arrete en cours comme traite.
   Modele : IOM_COT_MAJ_PITCOT_PERIODE_REPRISE du package IOM_MNI_COTATION_PRUD V0_5.

   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */
UPDATE <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITCOT_PERIODE_REPRISE
SET    TRAITE = 1
WHERE  SEQ = #INEO.V_IOM_COT_REC_N
  AND  LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'
