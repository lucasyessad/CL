/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 09  -  MAPPING  IOM.MNI.PWTOPE_APT_SCR_INT_REC_NON_CAUT.Ins.V0_1

   Apports - detail

   Duplique de    : IOM.MNI.PWTOPE_APT_SCR_INT.Ins.V0_1  (etape 9 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTOPE_APT_SCR_INT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTOPE_APT                               (MSSQL_DWH)
     - PWTOPE_APT_REL                           (MSSQL_DWH)

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTOPE_APT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTOPE_APT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NU_INDICE_APT, MT_APPOR, RANG)
select  
	PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP,
	APT.NU_INDICE_APT,
	APT.MT_APPOR,
	row_number () OVER (partition by PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP order by APT.NO_SEQ_APT, APT.NU_INDICE_APT)
from
(<?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_APT", "MSSQL_DWH", "D") ?> as APT  
    ON  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = APT.CD_OP
     )  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_APT_REL", "MSSQL_DWH", "D") ?> as APT_REL  
    ON  (PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = APT_REL.CD_OP AND PITOPE_COT_REF_OPE_REC_NON_CAUT.NO_SEQ_OPE = APT_REL.NO_SEQ_OPE) and (APT.CD_OP = APT_REL.CD_OP AND APT_REL.NO_SEQ_APT = APT.NO_SEQ_APT   AND APT_REL.NU_INDICE_APT = APT.NU_INDICE_APT)
where	(1=1)
 and (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1)
