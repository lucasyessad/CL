/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 28  -  PROCEDURE MAISON  IOR.T004.ref_OKfintracechgt.V0_1

   REUTILISEE TELLE QUELLE. Executee seulement si toutes les etapes
   precedentes, controle 27 compris, sont OK.

   Effet sur la ligne PWTTRE du scenario :
       DA_DEB_DEL_TRT = DA_DON_A_TRT   (l'arrete traite devient le point de depart)
       DA_FIN_DEL_FOR = NULL           (le pere repositionne la borne a chaque tour)
       DA_DON_A_TRT   = NULL, NO_SEQ + 1, DA_DER_TRT = maintenant
   Suivi PWTSDC de la session passe a OK.

   Code de reference (extrait du scenario de production, pour controle) :
   ============================================================================ */

/* Maj etat fin traitement */
update	<?=odiRef.getObjectName("L", "PWTSDC", "MSSQL_DWH", "D") ?>
set	DA_FIN_TRT = getDate(),
	LB_STA_TRT = 'OK'
where	LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
and	ID_TRT_ALI = <?=odiRef.getSession("SESS_NO") ?>;

/* Maj date dernier traitement OK */
update	<?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
set	DA_DER_TRT = getDate(),
	DA_DON_A_TRT = null,
	DA_DEB_DEL_TRT = DA_DON_A_TRT,
	DA_FIN_DEL_FOR = null,
	NO_SEQ = NO_SEQ + 1,
	ID_DET_TRT_ALI = <?=odiRef.getSession("SESS_NO") ?>
where	LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>';
