/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 15  -  MAPPING  IOM.MNI.PWTINT_SCR_INT_REC_NON_CAUT.Ins.V0_1

   Intervenants - detail

   Duplique de    : IOM.MNI.PWTINT_SCR_INT.Ins.V0_2  (etape 15 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTINT_SCR_INT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTINT                                   (MSSQL_DWH)

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference de controle (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTINT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTINT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, CD_INDI, NO_SEQ_INT, CD_TYP_IND_OPE, CD_NAT, CD_SITFAM, NU_INTERV, NB_PERS, NB_AGE_PERS_01, NB_AGE_PERS_02, NB_AGE_PERS_03, NB_AGE_PERS_04, NB_AGE_PERS_05, NB_AGE_PERS_06, NB_AGE_PERS_07, NB_AGE_PERS_08, NB_AGE_PERS_09, NB_AGE_PERS_10, NB_AGE_PERS_11, NB_AGE_PERS_12, NB_AGE_PERS_13, NB_AGE_PERS_14, NB_AGE_PERS_15, DM_RELAT_BQUE, CD_CSP_1, DM_ANC_1, DJ_DATE_DEB, RANG)
select  
	INLINE_VIEW.CD_OP_2,
	INLINE_VIEW.CD_INDI_1,
	INLINE_VIEW.NO_SEQ_INT_1,
	INLINE_VIEW.CD_TYP_IND_OPE_1,
	INLINE_VIEW.CD_NAT_1,
	INLINE_VIEW.CD_SITFAM_1,
	INLINE_VIEW.NU_INTERV_1,
	INLINE_VIEW.NB_PERS_1,
	INLINE_VIEW.NB_AGE_PERS_2,
	INLINE_VIEW.NB_AGE_PERS_3,
	INLINE_VIEW.NB_AGE_PERS_4,
	INLINE_VIEW.NB_AGE_PERS_5,
	INLINE_VIEW.NB_AGE_PERS_6,
	INLINE_VIEW.NB_AGE_PERS_7,
	INLINE_VIEW.NB_AGE_PERS_8,
	INLINE_VIEW.NB_AGE_PERS_9,
	INLINE_VIEW.NB_AGE_PERS_16,
	INLINE_VIEW.NB_AGE_PERS_17,
	INLINE_VIEW.NB_AGE_PERS_18,
	INLINE_VIEW.NB_AGE_PERS_19,
	INLINE_VIEW.NB_AGE_PERS_20,
	INLINE_VIEW.NB_AGE_PERS_21,
	INLINE_VIEW.NB_AGE_PERS_22,
	INLINE_VIEW.DM_RELAT_BQUE_1,
	INLINE_VIEW.CD_CSP_2,
	INLINE_VIEW.DM_ANC_2,
	INLINE_VIEW.DJ_DATE_DEB_1,
	INLINE_VIEW.COL
from
(
SELECT 
  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP as CD_OP ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.DJ_DATE_DEB as DJ_DATE_DEB ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG as RANG ,
  PWT_1.CD_OP as CD_OP_1 ,
  PWT_1.CD_INDI as CD_INDI ,
  PWT_1.NO_SEQ_INT as NO_SEQ_INT ,
  PWT_1.DD_VAL as DD_VAL ,
  PWT_1.DF_VAL as DF_VAL ,
  PWT_1.FL_VER_CRT as FL_VER_CRT ,
  PWT_1.CD_TYP_IND_OPE as CD_TYP_IND_OPE ,
  PWT_1.CD_NAT as CD_NAT ,
  PWT_1.CD_SITFAM as CD_SITFAM ,
  PWT_1.NU_INTERV as NU_INTERV ,
  PWT_1.NB_PERS as NB_PERS ,
  PWT_1.NB_AGE_PERS_01 as NB_AGE_PERS_01 ,
  PWT_1.NB_AGE_PERS_02 as NB_AGE_PERS_02 ,
  PWT_1.NB_AGE_PERS_03 as NB_AGE_PERS_03 ,
  PWT_1.NB_AGE_PERS_04 as NB_AGE_PERS_04 ,
  PWT_1.NB_AGE_PERS_05 as NB_AGE_PERS_05 ,
  PWT_1.NB_AGE_PERS_06 as NB_AGE_PERS_06 ,
  PWT_1.NB_AGE_PERS_07 as NB_AGE_PERS_07 ,
  PWT_1.NB_AGE_PERS_08 as NB_AGE_PERS_08 ,
  PWT_1.NB_AGE_PERS_09 as NB_AGE_PERS_09 ,
  PWT_1.NB_AGE_PERS_10 as NB_AGE_PERS_10 ,
  PWT_1.NB_AGE_PERS_11 as NB_AGE_PERS_11 ,
  PWT_1.NB_AGE_PERS_12 as NB_AGE_PERS_12 ,
  PWT_1.NB_AGE_PERS_13 as NB_AGE_PERS_13 ,
  PWT_1.NB_AGE_PERS_14 as NB_AGE_PERS_14 ,
  PWT_1.NB_AGE_PERS_15 as NB_AGE_PERS_15 ,
  PWT_1.DM_RELAT_BQUE as DM_RELAT_BQUE ,
  PWT_1.CD_CSP_1 as CD_CSP_1 ,
  PWT_1.DM_ANC_1 as DM_ANC_1 ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP as CD_OP_2 ,
  PWT_1.CD_INDI as CD_INDI_1 ,
  PWT_1.NO_SEQ_INT as NO_SEQ_INT_1 ,
  PWT_1.CD_TYP_IND_OPE as CD_TYP_IND_OPE_1 ,
  PWT_1.CD_NAT as CD_NAT_1 ,
  PWT_1.CD_SITFAM as CD_SITFAM_1 ,
  PWT_1.NU_INTERV as NU_INTERV_1 ,
  PWT_1.NB_PERS as NB_PERS_1 ,
  PWT_1.NB_AGE_PERS_01 as NB_AGE_PERS_2 ,
  PWT_1.NB_AGE_PERS_02 as NB_AGE_PERS_3 ,
  PWT_1.NB_AGE_PERS_03 as NB_AGE_PERS_4 ,
  PWT_1.NB_AGE_PERS_04 as NB_AGE_PERS_5 ,
  PWT_1.NB_AGE_PERS_05 as NB_AGE_PERS_6 ,
  PWT_1.NB_AGE_PERS_06 as NB_AGE_PERS_7 ,
  PWT_1.NB_AGE_PERS_07 as NB_AGE_PERS_8 ,
  PWT_1.NB_AGE_PERS_08 as NB_AGE_PERS_9 ,
  PWT_1.NB_AGE_PERS_09 as NB_AGE_PERS_16 ,
  PWT_1.NB_AGE_PERS_10 as NB_AGE_PERS_17 ,
  PWT_1.NB_AGE_PERS_11 as NB_AGE_PERS_18 ,
  PWT_1.NB_AGE_PERS_12 as NB_AGE_PERS_19 ,
  PWT_1.NB_AGE_PERS_13 as NB_AGE_PERS_20 ,
  PWT_1.NB_AGE_PERS_14 as NB_AGE_PERS_21 ,
  PWT_1.NB_AGE_PERS_15 as NB_AGE_PERS_22 ,
  PWT_1.DM_RELAT_BQUE as DM_RELAT_BQUE_1 ,
  PWT_1.CD_CSP_1 as CD_CSP_2 ,
  PWT_1.DM_ANC_1 as DM_ANC_2 ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.DJ_DATE_DEB as DJ_DATE_DEB_1 ,
  row_number () OVER (partition by PWT_1.CD_OP, PWT_1.CD_INDI order by PWT_1.DD_VAL desc) as COL ,
  PWT_1.FL_VER_CRT as FL_VER_CRT_1   
FROM 
  <?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PWTINT", "MSSQL_DWH", "D") ?> as PWT_1  
    ON  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = PWT_1.CD_OP and
convert(date,PITOPE_COT_REF_OPE_REC_NON_CAUT.DJ_DATE_DEB,121)
 between convert(date,PWT_1.DD_VAL,121) and convert(date,PWT_1.DF_VAL,121)
WHERE
  (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1
) 
  ) INLINE_VIEW
where	(1=1)
 and (INLINE_VIEW.COL=1) and (INLINE_VIEW.FL_VER_CRT_1 <> 9)
