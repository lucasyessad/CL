/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 18  -  PROCEDURE  IOM.MNI_PWTPRT_SCR_REC_NON_CAUT.Upd.V0_1

   Complements des enregistrements prets / intervenants avant le score.

   Duplique de    : procedure IOM.MNI_PWTPRT_SCR_V0_2.Upd (etape 18 du
                    scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server

   TACHE 1 PWTINT_SCR_UPD          : identique, structures renommees.
   TACHE 2 PWTPRT_SCR_UPD_REL      : identique, structures renommees.
   TACHE 3 PWTPRT_SCR_UPD_DUR_OP   : la sous-requete UNION lisait les prets
       mis en paiement (PDTPDT_MEP, FL_PER = 1) puis les prets non engages
       (PWTPRT, FL_PER = 0 et FL_CALC = 0). Seule la seconde branche est
       conservee : la premiere est toujours vide sur ce perimetre.
   ============================================================================ */

/* ============================================================================
   TACHE 1  -  PWTINT_SCR_UPD
   ============================================================================ */
UPDATE <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTINT_SCR_REC_NON_CAUT
SET NU_INTERV = Req.NU_INTERV
FROM (
    SELECT CD_OP, count(distinct cd_indi_1) NU_INTERV
    FROM <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTINT_SCR_REC_NON_CAUT
    group by CD_OP) AS Req
    
WHERE 
    PWTINT_SCR_REC_NON_CAUT.CD_OP = Req.CD_OP

/* ============================================================================
   TACHE 2  -  PWTPRT_SCR_UPD_REL
   ============================================================================ */
UPDATE
    <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTPRT_SCR_REC_NON_CAUT
SET
        PWTPRT_SCR_REC_NON_CAUT.FL_REL = SCR.FL_REL
FROM
    (
        select  
	PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP,
        max(WPRT_1.FL_REL) over(partition by WPRT_1.CD_OP) FL_REL
from
<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_REF_OPE_REC_NON_CAUT as PITOPE_COT_REF_OPE_REC_NON_CAUT  left JOIN  (
SELECT 
 
  WPRT.CD_OP as CD_OP ,
  WPRT.CD_PRET,
  WPRT.NO_SEQ_PRT,
  case when (WPRT.CD_NATUR_PRET='REL' and WPRT.CD_ETAP='FDP' and WPRT.CD_STATUT in('ACX','ARC','ATE','FMR','RML'))
           then 0
     when (WPRT.CD_NATUR_PRET='REL' and WPRT.CD_ETAP<>'EAU' and WPRT.CD_STATUT='REF')
           then 0
     when (WPRT.CD_NATUR_PRET='REL' and WPRT.CD_STATUT='ANN')
           then 0
     when WPRT.CD_NATUR_PRET<>'REL'
           then 0
    when WPRT.CD_NATUR_PRET is null
           then 0
     else 1
end FL_REL
 
FROM 
  <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.DBO.PWTPRT as WPRT  
WHERE
    ( WPRT.CD_STATUT<>'ANN'
and convert(datetime,convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121))+' 23:59:59.99',121)
between WPRT.DD_VAL and WPRT.DF_VAL
)  
  ) WPRT_1  
    ON  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = WPRT_1.CD_OP
    AND PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1
where	(1=1)
    ) SCR
Where 
    PWTPRT_SCR_REC_NON_CAUT.CD_OP = SCR.CD_OP
	--and PWTPRT_SCR_REC_NON_CAUT.RANG = SCR.RANG

/* ============================================================================
   TACHE 3  -  PWTPRT_SCR_UPD_DUR_OP
   ============================================================================ */
UPDATE
    <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTPRT_SCR_REC_NON_CAUT
SET
        PWTPRT_SCR_REC_NON_CAUT.NB_DUR_10 = SCR.NB_DUR_10,
	PWTPRT_SCR_REC_NON_CAUT.CD_NATUR_PRET_10 = SCR.CD_NATUR_PRET_10,
	PWTPRT_SCR_REC_NON_CAUT.DJ_PFREGLE_1 = SCR.DJ_PFREGLE_1
FROM
    (
        select  
	WPRT_1.CD_OP,
        isnull(RIGHT('000'+ convert(varchar(3),cast(case when WPRT_1.CD_NATUR_PRET_PFI='PBC' then 'REL' else WPRT_1.CD_NATUR_PRET_PFI end as varchar)),3),'000') as CD_NATUR_PRET_10,
	isnull(RIGHT('000'+ convert(varchar(3),cast(WPRT_1.NB_DUR_PFI as varchar)),3),'000') as NB_DUR_10,
	isnull(FORMAT(WPRT_1.DJ_PFREGLE, 'yyyyMMdd'),FORMAT(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)),'yyyyMMdd')) as DJ_PFREGLE_1,
        row_number() over(partition by WPRT_1.CD_OP order by WPRT_1.CD_OP) RANG
from  
(
select 
  REQ_TOT.CD_OP,
  REQ_TOT.CD_PRET,
  REQ_TOT.NO_SEQ_PRT,
  FIRST_VALUE ( REQ_TOT.CD_NATUR_PRET_PFI )   
    OVER (  partition by REQ_TOT.CD_OP order by REQ_TOT.NB_DUR_PFI desc) CD_NATUR_PRET_PFI,
   FIRST_VALUE ( REQ_TOT.NB_DUR_PFI )   
    OVER (  partition by REQ_TOT.CD_OP order by REQ_TOT.NB_DUR_PFI desc) NB_DUR_PFI,
	FIRST_VALUE (case when REQ_TOT.DJ_PFREGLE is null then FORMAT(getDate(),'yyyyMMdd') else REQ_TOT.DJ_PFREGLE end)   
    OVER (  partition by REQ_TOT.CD_OP order by case when REQ_TOT.DJ_PFREGLE is null then FORMAT(getDate(),'yyyyMMdd') else REQ_TOT.DJ_PFREGLE end) DJ_PFREGLE
from
(

select PWTPRT.CD_OP,
PWTPRT.CD_PRET,
  PWTPRT.DJ_PFREGLE,
  PWTPRT.MT_PRET_PFI,
  PWTPRT.NO_SEQ_PRT,
  PWTPRT.NB_DUR_PFI,
  PWTPRT.CD_NATUR_PRET_PFI,
  PWTPRT.TX_PRET_PFI,
  PWTPRT.CD_TYP_TX_PFI  
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_REF_PRT_REC_NON_CAUT inner join <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PWTPRT
on PITOPE_COT_REF_PRT_REC_NON_CAUT.CD_PRET = PWTPRT.CD_PRET
AND PITOPE_COT_REF_PRT_REC_NON_CAUT.NO_SEQ_PRT = PWTPRT.NO_SEQ_PRT
where  PITOPE_COT_REF_PRT_REC_NON_CAUT.FL_PER=0 and
PITOPE_COT_REF_PRT_REC_NON_CAUT.FL_CALC=0
)REQ_TOT
) 
WPRT_1
) SCR
Where 
    PWTPRT_SCR_REC_NON_CAUT.CD_OP = SCR.CD_OP
    and SCR.RANG=1
