/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 22  -  MAPPING  IOM.MNI.PITOPE_COT_REC_NON_CAUT_FIN.Ins.V0_1

   Constitution de la table finale avant appel du moteur de cotation :
   une ligne par operation du perimetre ayant un resultat de score.

   Duplique de    : IOM.MNI.PITOPE_COT_PB_M_FIN.Ins.V0_2 (etape 33 du
                    scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_REC_NON_CAUT (MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        : PITOPE_COT_PER0_M_REC_NON_CAUT, PITOPE_COT_SCR_MOT_REC_NON_CAUT

   MODIFICATIONS DEMANDEES PAR LA CARTE
   ("pour le mapping IOM.MNI.PITOPE_COT_PB_M_FIN.Ins.V0_2, il faudra oter
   toutes les left join avec les tables CTX/DEFAUT")
     - LEFT JOIN PITOPE_COT_PB1 (decheance du terme, MDTCTX_CRC)  : retire
     - LEFT JOIN PITOPE_COT_PB2 (procedure de surendettement)      : retire
     - LEFT JOIN PITOPE_COT_PB3 (procedure d'execution)            : retire
     - LEFT JOIN PITOPE_COT_PB4 (procedure collective)             : retire
     - LEFT JOIN PITOPE_COT_PB5 (103/104, PWTDEF_PRT)              : retire
     - LEFT JOIN PITOPE_COT_PB6 (defaut operation, PWTDEF_OPE)     : retire
     Les colonnes qu'elles alimentaient (FL_/DT_ DEC_DET, PROC_SUR,
     PROC_EXE, PROC_COLL, 103_104, DD_DEF_OP) sont mises a NULL : le buffer
     du moteur les convertit en valeurs neutres ('0' / blancs).

   MODIFICATION INDUITE (non ecrite dans la carte, necessaire)
     La table pivot de l'original est PITOPE_COT_PER_M, alimentee par
     IOM.MNI.PITOPE_COT_PER_M.Ins (liste des mappings defaut a ne pas
     utiliser), a partir de PER0_M + historique LGD + C24 + MEP. Sans elle,
     le mapping n'a plus de source. Elle est remplacee par
     PITOPE_COT_PER0_M_REC_NON_CAUT, en reprenant les valeurs que PER_M
     produit pour une operation SANS defaut, SANS contentieux et NON mise en
     paiement (cas de 100 % du perimetre) :
        NO_SEQ          1           (ROW_NUMBER sur une seule ligne LGD absente)
        CD_TRAIT        'M'
        FL_OP_MEP       0           (operation non mise en paiement)
        DT_MEP_OPE      NULL
        FL_DEF_OP       NULL        (regle CCS 09/09/2026 : pas d'historique LGD -> NULL)
        DD_DEB_DEF / DF_DEF_HIST_LGD / DD_DEB_DEF_1 / NB_PASS_HIST_LGD : NULL
        FL_DEF_HIST     0           (filtre d'origine FL_DEF_HIST IN (0,1) toujours vrai)
        RANG            1           (filtre d'origine RANG = 1 toujours vrai)
        DD_VAL          arrete      DF_VAL  2400-01-01
        DT_REF_TRAIT    arrete      FL_DEF_PASS 0 (FL_DEF_OP <> 0)
     Les colonnes issues du score (FL_REL, TX_LTV, NB_INT, CD_COTE_ENCOURS,
     NB_NOTE_ENCOURS, NU_VERS_ENCOURS) sont calculees avec les memes
     expressions que l'original.

   La jointure INTERNE avec le resultat du score est conservee, comme dans
   l'original.
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(NO_SEQ, CD_TRAIT, CD_OP, FL_OP_MEP, FL_REL, TX_LTV, DT_MEP_OP, NB_INT, FL_DEF_OP, DD_DEF_OP, DF_DEF_OP, FL_DEC_DET, DT_DEC_DET, FL_PROC_SUR, DT_PROC_SUR, FL_PROC_EXE, DT_PROC_EXE, FL_PROC_COLL, DT_PROC_COLL, FL_103_104, DT_103_104, CD_COTE_ENCOURS, NB_NOTE_ENCOURS, NU_VERS_ENCOURS, NB_PASS_HIST_LGD, DD_VAL, DF_VAL, DT_MAJ, FL_VER_CRT, CD_USR_MAJ, DT_REF_TRAIT, FL_DEF_PASS, DD_DEB_DEF_1)
select
	1,
	'M',
	PITOPE_COT_PER0_M_REC_NON_CAUT.CD_OP,
	0,
	PITOPE_COT_SCR_MOT_REC_NON_CAUT.FL_REL,
	PITOPE_COT_SCR_MOT_REC_NON_CAUT.TX_LTV,
	NULL,
	PITOPE_COT_SCR_MOT_REC_NON_CAUT.NB_INT,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,10,2),
	convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,189,7),0))/10000+(convert(numeric(7),SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,198,7)))/10000+
ISNULL(convert(numeric(6),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,207,7),0))/10000,0)+
 ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,216,7),0))/10000,0)+
 ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,225,7),0))/10000,0)+
 ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,234,7),0))/10000,0)+
 ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,243,7),0))/10000,0)+
ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,252,7),0))/10000,0)+
 ISNULL(convert(numeric(7),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,261,7),0))/10000,0)+
 ISNULL(convert(numeric(6),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,270,7),0))/10000,0)+
ISNULL(convert(numeric(6),ISNULL(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,279,7),0))/10000,0),
	cast(SUBSTRING(PITOPE_COT_SCR_MOT_REC_NON_CAUT.RES,176,6) as numeric(5,2)),
	NULL,
	convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)),
	convert(datetime, '2400-01-01', 121),
	getdate(),
	1,
	LEFT('<?=odiRef.getSession("ODI_USER_NAME") ?>', 8),
	convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)),
	0,
	NULL
from
<?= odiRef.getObjectName("L", "PITOPE_COT_PER0_M_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_PER0_M_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PITOPE_COT_SCR_MOT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_SCR_MOT_REC_NON_CAUT
    ON  PITOPE_COT_PER0_M_REC_NON_CAUT.CD_OP = PITOPE_COT_SCR_MOT_REC_NON_CAUT.CD_OP
where	(1=1)
