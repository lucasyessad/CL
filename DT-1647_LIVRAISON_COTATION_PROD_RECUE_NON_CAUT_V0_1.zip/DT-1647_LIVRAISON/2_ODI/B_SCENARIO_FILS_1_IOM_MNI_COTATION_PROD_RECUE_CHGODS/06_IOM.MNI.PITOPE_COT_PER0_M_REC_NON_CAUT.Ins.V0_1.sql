/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 06  -  MAPPING  IOM.MNI.PITOPE_COT_PER0_M_REC_NON_CAUT.Ins.V0_1

   Operations du perimetre et montant de reference

   Duplique de    : IOM.MNI.PITOPE_COT_PER0_M.Ins.V0_1  (etape 6 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_PER0_M_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference de controle (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_PER0_M_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_PER0_M_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, MT_ENCOURS)
select  
	PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP,
	PITOPE_COT_REF_OPE_REC_NON_CAUT.MT_ENCOURS
from
<?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT
where	(1=1)
 and (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1)
