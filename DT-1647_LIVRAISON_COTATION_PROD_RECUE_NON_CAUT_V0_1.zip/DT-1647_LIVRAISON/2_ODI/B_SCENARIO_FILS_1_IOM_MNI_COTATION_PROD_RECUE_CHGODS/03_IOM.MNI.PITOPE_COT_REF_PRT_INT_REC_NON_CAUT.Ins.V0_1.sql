/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 03  -  MAPPING  IOM.MNI.PITOPE_COT_REF_PRT_INT_REC_NON_CAUT.Ins.V0_1

   Prets de reference : point d'entree de toute la chaine score + cotation.

   Duplique de    : IOM.MNI.PITOPE_COT_REF_PRT_INT.Ins.V0_2 (etape 3 du
                    scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_REF_PRT_INT_REC_NON_CAUT (MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Source         : PITOPE_PERIMETRE_REC_NON_CAUT (MSSQL_DWH)

   MODIFICATION (reponse a la question de Jennifer WOO du 08/10 : "la
   nouvelle table de perimetre est supposee remplacer PITOPE_COT_REF_PRT_INT ?")
   -> OUI, en entree. L'original est une UNION de deux branches :
        - branche 1 : prets MIS EN PAIEMENT (EWTENC x PDTPDT_MEP), FL_PER = 1 ;
        - branche 2 : prets NON ENGAGES (EWTNEC x PWTPRT), FL_PER = 0.
      Aucune ne convient : le perimetre est justement HORS EWTENC et HORS
      EWTNEC. Les deux branches sont remplacees par une lecture de la table
      de perimetre, avec le meme format de sortie que la branche 2
      (FL_PER = 0, MT_ENCOURS = MT_PRET_PFI) : toute la suite de la chaine
      suit donc le chemin "non engage" deja eprouve en production.
   La structure cible et la cle CD_DAT_ARR_AAM sont inchangees.
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_REF_PRT_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_REF_PRT_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_PRET, NO_SEQ_PRT, CD_OP, DJ_DATE_DEB, MT_ENCOURS, RANG, FL_PER, CD_DAT_ARR_AAM)
select
	PERIM.CD_PRET,
	PERIM.NO_SEQ_PRT,
	PERIM.CD_OP,
	PERIM.DJ_DATE_DEB,
	PERIM.MT_PRET_PFI,
	row_number () OVER (partition by PERIM.CD_PRET order by PERIM.NO_SEQ_PRT desc),
	0,
	PERIM.CD_DAT_ARR_AAM
from
<?= odiRef.getObjectName("L", "PITOPE_PERIMETRE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PERIM
where	(1=1)
 and (PERIM.CD_DAT_ARR_AAM=cast(CONVERT(varchar(6), DATEADD(month, -1, convert(date,'#INEO.V040_DatDonATraiter_V0_1',121)), 112) as integer))
