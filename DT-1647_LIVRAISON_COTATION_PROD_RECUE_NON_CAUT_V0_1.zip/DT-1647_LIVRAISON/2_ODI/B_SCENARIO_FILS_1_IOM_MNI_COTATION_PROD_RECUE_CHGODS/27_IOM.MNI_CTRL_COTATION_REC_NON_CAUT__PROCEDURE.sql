/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 27  -  PROCEDURE  IOM.MNI_CTRL_COTATION_REC_NON_CAUT   (NOUVELLE)

   Controle BLOQUANT avant T004. Traduit les regles metier de la carte :
     R1  "tout le perimetre est cote"
         -> chaque operation de PITOPE_PERIMETRE_REC_NON_CAUT est presente
            dans PITOPE_COT_REC_NON_CAUT ;
     R2  "les CHR_PD_CIBLE de ces operations ne peuvent pas etre nulles" ;
     R3  "les operations cautionnees ou engagees sont absentes"
         -> aucune operation cotee n'a de pret dans EWTENC / EWTNEC ;
     R4  cotation prudentielle attendue : CD_CHR_PD = 'K' partout ;
     R5  perimetre non vide (un perimetre vide signale un chargement amont
         manquant - PWTPRT, EWTENC, EWTNEC - pas une absence d'activite).

   En cas d'anomalie : THROW -> etape KO -> T004 non executee -> PWTTRE
   n'avance pas -> l'arrete sera repris a la relance. Le message donne le
   nombre d'operations en anomalie par regle et jusqu'a 20 exemples.

   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server
   ============================================================================ */
DECLARE @DT_DONNEES DATETIME = CONVERT(DATETIME, '#INEO.V040_DatDonATraiter_V0_1', 121);
DECLARE @DT_ARRETE  DATE     = DATEADD(DAY, -DAY(@DT_DONNEES), CAST(@DT_DONNEES AS DATE));
DECLARE @CD_DAT_ARR_AAM INT  = YEAR(@DT_ARRETE) * 100 + MONTH(@DT_ARRETE);

DECLARE @NB_PERIMETRE INT, @NB_COTE INT,
        @NB_R1 INT, @EX_R1 NVARCHAR(400),
        @NB_R2 INT, @EX_R2 NVARCHAR(400),
        @NB_R3 INT, @EX_R3 NVARCHAR(400),
        @NB_R4 INT, @EX_R4 NVARCHAR(400);

SELECT @NB_PERIMETRE = COUNT(DISTINCT CD_OP)
FROM   <?=odiRef.getObjectName("L", "PITOPE_PERIMETRE_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
WHERE  CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM;

SELECT @NB_COTE = COUNT(*)
FROM   <?=odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>;

/* R1 - operation du perimetre non cotee */
WITH A AS (
    SELECT DISTINCT P.CD_OP
    FROM   <?=odiRef.getObjectName("L", "PITOPE_PERIMETRE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS P
    WHERE  P.CD_DAT_ARR_AAM = @CD_DAT_ARR_AAM
      AND  NOT EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS C
                       WHERE C.CD_OP = P.CD_OP)
)
SELECT @NB_R1 = (SELECT COUNT(*) FROM A),
       @EX_R1 = (SELECT STRING_AGG(CAST(CD_OP AS NVARCHAR(MAX)), N',') FROM (SELECT TOP (20) CD_OP FROM A ORDER BY CD_OP) X);

/* R2 - CHR PD CIBLE nulle */
WITH A AS (
    SELECT C.CD_OP
    FROM   <?=odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS C
    WHERE  C.CD_CHR_PD_CIBLE IS NULL OR LTRIM(RTRIM(C.CD_CHR_PD_CIBLE)) = ''
)
SELECT @NB_R2 = (SELECT COUNT(*) FROM A),
       @EX_R2 = (SELECT STRING_AGG(CAST(CD_OP AS NVARCHAR(MAX)), N',') FROM (SELECT TOP (20) CD_OP FROM A ORDER BY CD_OP) X);

/* R3 - operation cotee dont un pret est cautionne ou engage a l'arrete */
WITH A AS (
    SELECT DISTINCT C.CD_OP
    FROM   <?=odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS C
    INNER JOIN <?=odiRef.getObjectName("L", "PWTPRT", "MSSQL_DWH", "D") ?> AS PRT
            ON  PRT.CD_OP = C.CD_OP
    INNER JOIN <?=odiRef.getObjectName("L", "PITOPE_MAX_SEQ_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS M
            ON  M.CD_PRET = PRT.CD_PRET AND M.NO_SEQ_PRT = PRT.NO_SEQ_PRT
    WHERE  EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "EWTENC", "MSSQL_DWH_ENCOURS", "D") ?> AS ENC
                   WHERE ENC.CD_PRET = PRT.CD_PRET AND ENC.DT_ENCOURS = @CD_DAT_ARR_AAM)
       OR  EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "EWTNEC", "MSSQL_DWH_ENCOURS", "D") ?> AS NEC
                   WHERE NEC.CD_PRET = PRT.CD_PRET AND NEC.DT_ENCOURS = @CD_DAT_ARR_AAM)
)
SELECT @NB_R3 = (SELECT COUNT(*) FROM A),
       @EX_R3 = (SELECT STRING_AGG(CAST(CD_OP AS NVARCHAR(MAX)), N',') FROM (SELECT TOP (20) CD_OP FROM A ORDER BY CD_OP) X);

/* R4 - cotation prudentielle differente de K */
WITH A AS (
    SELECT C.CD_OP
    FROM   <?=odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS C
    WHERE  ISNULL(C.CD_CHR_PD, '') <> 'K'
)
SELECT @NB_R4 = (SELECT COUNT(*) FROM A),
       @EX_R4 = (SELECT STRING_AGG(CAST(CD_OP AS NVARCHAR(MAX)), N',') FROM (SELECT TOP (20) CD_OP FROM A ORDER BY CD_OP) X);

IF @NB_PERIMETRE = 0 OR @NB_R1 > 0 OR @NB_R2 > 0 OR @NB_R3 > 0 OR @NB_R4 > 0
BEGIN
    DECLARE @msg NVARCHAR(2048) =
          N'DT-1647 controle cotation arrete ' + CAST(@CD_DAT_ARR_AAM AS NVARCHAR(6))
        + N' KO - perimetre ' + CAST(@NB_PERIMETRE AS NVARCHAR(12)) + N' op, cotees ' + CAST(@NB_COTE AS NVARCHAR(12))
        + CASE WHEN @NB_PERIMETRE = 0 THEN N' | R5 perimetre vide (chargement PWTPRT/EWTENC/EWTNEC ?)' ELSE N'' END
        + CASE WHEN @NB_R1 > 0 THEN N' | R1 non cotees: '        + CAST(@NB_R1 AS NVARCHAR(12)) + N' ex ' + ISNULL(@EX_R1, N'') ELSE N'' END
        + CASE WHEN @NB_R2 > 0 THEN N' | R2 CHR_PD_CIBLE nulle: ' + CAST(@NB_R2 AS NVARCHAR(12)) + N' ex ' + ISNULL(@EX_R2, N'') ELSE N'' END
        + CASE WHEN @NB_R3 > 0 THEN N' | R3 cautionnees/engagees: ' + CAST(@NB_R3 AS NVARCHAR(12)) + N' ex ' + ISNULL(@EX_R3, N'') ELSE N'' END
        + CASE WHEN @NB_R4 > 0 THEN N' | R4 CHR_PD <> K: '       + CAST(@NB_R4 AS NVARCHAR(12)) + N' ex ' + ISNULL(@EX_R4, N'') ELSE N'' END;
    THROW 50327, @msg, 1;
END
