/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 05  -  MAPPING  IOM.MNI.PITOPE_COT_REF_OPE_REC_NON_CAUT.Ins.V0_1

   Version d'operation de reference a fin de mois.

   Duplique de    : IOM.MNI.PITOPE_COT_REF_OPE.Ins.V0_3 (etape 5 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_REF_OPE_REC_NON_CAUT (MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        : PITOPE_COT_REF_PRT_REC_NON_CAUT (MSSQL_DWH), PWTOPE (MSSQL_DWH)

   MODIFICATION : l'original est une UNION de deux branches.
     - Branche 1 (SUPPRIMEE) : operations mises en paiement, lues dans
       PDTPDT_MEP_OPE avec FL_PER = 1. Le perimetre ne contient que des
       FL_PER = 0 (etape 03) : cette branche ne ramenait rien, elle est
       retiree avec sa source.
     - Branche 2 (CONSERVEE A L'IDENTIQUE) : version PWTOPE non annulee,
       anterieure a la date du pret et a l'arrete, FL_PER = 0.
   Le ROW_NUMBER final (rang = derniere version d'operation) est inchange.
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ_OPE, DJ_DATE_DEB, MT_ENCOURS, RANG, MT_VAL)
select
	SET_UNION.CD_OP,
	SET_UNION.NO_SEQ_OPE,
	SET_UNION.DJ_DATE_DEB,
	SET_UNION.MT_ENCOURS,
	row_number () OVER (partition by SET_UNION.CD_OP order by SET_UNION.NO_SEQ_OPE desc),
	SET_UNION.MT_VAL
from
(
SELECT
  OPE_1.CD_OP as CD_OP ,
  OPE_1.NO_SEQ_OPE as NO_SEQ_OPE ,
  convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)) as DJ_DATE_DEB ,
  PITOPE_COT_REF_PRT_REC_NON_CAUT.MT_ENCOURS as MT_ENCOURS ,
  OPE_1.MT_VAL as MT_VAL
FROM
  <?= odiRef.getObjectName("L", "PITOPE_COT_REF_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_PRT_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE", "MSSQL_DWH", "D") ?> as OPE_1
    ON  PITOPE_COT_REF_PRT_REC_NON_CAUT.CD_OP = OPE_1.CD_OP AND
/*OPE_1.FL_ETAP_STATUT_CHANGED=1 AND*/
OPE_1.CD_STATUT<>'ANN' AND convert(date,OPE_1.DJ_DATE_DEB,121) <= convert(date,PITOPE_COT_REF_PRT_REC_NON_CAUT.DJ_DATE_DEB,121)
AND convert(date,OPE_1.DJ_DATE_DEB,121)<=convert(date,convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)),121)
AND convert(date,OPE_1.DD_VAL,121)<=convert(date,convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)),121)
WHERE
  (PITOPE_COT_REF_PRT_REC_NON_CAUT.RANG=1 AND
PITOPE_COT_REF_PRT_REC_NON_CAUT.FL_PER=0
)
  ) SET_UNION
where	(1=1)
