/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 23  -  MAPPING  IOM.MNI.PITOPE_COT_COMP_REC_NON_CAUT.Ins.V0_1   (NOUVEAU)

   Derniere cotation connue de chaque operation, pour la regle metier :
   "Si la CHR n'evolue pas alors les dates de validite de CHR ne changent pas."

   Remplace       : IOM.MNI.PITOPE_COT_PB_COMP.Ins.V0_1 + procedure
                    IOM.MNI_PITOPE_COT_COMP.Upd (liste des mappings a ne pas
                    utiliser : ils comparent au stock engage de PDTOPE_COT)
   Cible          : PITOPE_COT_COMP_REC_NON_CAUT (MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        : PITOPE_COT_REC_NON_CAUT (MSSQL_DWH)
                    PDTOPE_COT_REC_NON_CAUT (MSSQL_DTM1) - historique du perimetre

   PRINCIPE
     Pour chaque operation a coter, on relit la ligne historisee la plus
     recente sur un arrete STRICTEMENT ANTERIEUR a l'arrete calcule. Ainsi,
     recalculer un arrete deja historise (annule et remplace) ne relit
     jamais sa propre version.

     CD_CHR_PD_PDT recoit la CHR PD CIBLE precedente (et non CD_CHR_PD, qui
     vaut toujours 'K' sur ce perimetre). C'est elle que l'etape 26 compare
     a la CHR rendue par le moteur :
       - meme CHR qu'a l'arrete precedent -> DT_REF_CHR_PD precedente
         conservee ;
       - CHR differente ou premiere cotation -> DT_REF_CHR_PD = arrete
         calcule.
     Meme logique pour la CHR LGD (CD_CHR_LGD_PDT / DT_REF_CHR_LGD).

     Les colonnes propres au defaut (CD_DER_CHR_LGD_DEF, *_REENT) restent a
     NULL : ce perimetre ne peut pas etre en defaut (carte : "par nature ces
     operations ne peuvent etre en defaut").

     Une ligne par operation de PITOPE_COT_REC_NON_CAUT, historique ou pas
     (jointure gauche) : la jointure interne de l'etape 24 ne perd aucune
     operation.
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_COMP_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_COMP_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ, CD_DAT_ARR_AAM_PDT, CD_DER_CHR_LGD_DEF, CD_CHR_PD_PDT, CD_CHR_LGD_PDT, DT_REF_CHR_PD, DT_REF_CHR_LGD, FL_DEF_PASS, DT_REF_CHR_PD_REENT, DT_REF_CHR_LGD_REENT, CD_CHR_PD_REENT, CD_CHR_LGD_REEENT)
select
	COT.CD_OP,
	COT.NO_SEQ,
	HISTO.CD_DAT_ARR_AAM,
	NULL,
	HISTO.CD_CHR_PD_CIBLE,
	HISTO.CD_CHR_LGD,
	HISTO.DT_REF_CHR_PD,
	HISTO.DT_REF_CHR_LGD,
	HISTO.FL_DEF_PASS,
	NULL,
	NULL,
	NULL,
	NULL
from
<?= odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as COT  LEFT JOIN  (
SELECT
  PDTOPE_COT_REC_NON_CAUT.CD_OP as CD_OP ,
  PDTOPE_COT_REC_NON_CAUT.CD_DAT_ARR_AAM as CD_DAT_ARR_AAM ,
  PDTOPE_COT_REC_NON_CAUT.CD_CHR_PD_CIBLE as CD_CHR_PD_CIBLE ,
  PDTOPE_COT_REC_NON_CAUT.CD_CHR_LGD as CD_CHR_LGD ,
  PDTOPE_COT_REC_NON_CAUT.DT_REF_CHR_PD as DT_REF_CHR_PD ,
  PDTOPE_COT_REC_NON_CAUT.DT_REF_CHR_LGD as DT_REF_CHR_LGD ,
  PDTOPE_COT_REC_NON_CAUT.FL_DEF_PASS as FL_DEF_PASS ,
  row_number () OVER (partition by PDTOPE_COT_REC_NON_CAUT.CD_OP order by PDTOPE_COT_REC_NON_CAUT.CD_DAT_ARR_AAM desc, PDTOPE_COT_REC_NON_CAUT.NO_SEQ desc) as RANG
FROM
  <?= odiRef.getObjectName("L", "PDTOPE_COT_REC_NON_CAUT", "MSSQL_DTM1", "D") ?> as PDTOPE_COT_REC_NON_CAUT
WHERE
  (PDTOPE_COT_REC_NON_CAUT.CD_DAT_ARR_AAM < cast(CONVERT(varchar(6), DATEADD(month, -1, convert(date,'#INEO.V040_DatDonATraiter_V0_1',121)), 112) as integer)
)
  ) HISTO
    ON  COT.CD_OP = HISTO.CD_OP AND HISTO.RANG = 1
where	(1=1)
