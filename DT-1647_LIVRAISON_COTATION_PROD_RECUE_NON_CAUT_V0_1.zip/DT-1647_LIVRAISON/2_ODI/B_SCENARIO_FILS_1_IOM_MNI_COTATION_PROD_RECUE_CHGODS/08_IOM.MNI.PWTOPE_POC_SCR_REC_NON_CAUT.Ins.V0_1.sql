/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 08  -  MAPPING  IOM.MNI.PWTOPE_POC_SCR_REC_NON_CAUT.Ins.V0_1

   Postes de cout - format moteur de score

   Duplique de    : IOM.MNI.PWTOPE_POC_SCR.Ins.V0_2  (etape 8 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTOPE_POC_SCR_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTOPE_POC_SCR_INT_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTOPE_POC_SCR_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTOPE_POC_SCR_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, CD_POSTCOUT_1, MT_POSTCOUT_1, CD_POSTCOUT_2, MT_POSTCOUT_2, CD_POSTCOUT_3, MT_POSTCOUT_3, CD_POSTCOUT_4, MT_POSTCOUT_4, MT_POSTCOUT, MT_ENCOURS, RANG)
select  
	PITOPE_COT_REF_OPE_1.CD_OP,
	isnull(PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_POSTCOUT,'000'),
	isnull(RIGHT('00000000'+convert(varchar(8), cast(PWTOPE_POC_SCR_INT_REC_NON_CAUT.MT_POSTCOUT as int)), 8),'00000000'),
	isnull(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_POSTCOUT) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC),'000'),
	isnull(RIGHT('00000000'+convert(varchar(8), cast(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.MT_POSTCOUT) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC) as int)), 8),'00000000'),
	isnull(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_POSTCOUT,2) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC),'000'),
	isnull(RIGHT('00000000'+convert(varchar(8), cast(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.MT_POSTCOUT,2) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC) as int)), 8),'00000000'),
	isnull(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_POSTCOUT,3) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC),'000'),
	isnull(RIGHT('00000000'+convert(varchar(8), cast(lead(PWTOPE_POC_SCR_INT_REC_NON_CAUT.MT_POSTCOUT,3) over (partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC, PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC) as int)), 8),'00000000'),
	sum(case when PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_POSTCOUT in('ACQ','CON','TER') then PWTOPE_POC_SCR_INT_REC_NON_CAUT.MT_POSTCOUT else 0 end) over(partition by PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP),
	PITOPE_COT_REF_OPE_1.MT_ENCOURS,
	row_number () OVER (partition by PITOPE_COT_REF_OPE_1.CD_OP order by PWTOPE_POC_SCR_INT_REC_NON_CAUT.NO_SEQ_POC,PWTOPE_POC_SCR_INT_REC_NON_CAUT.NU_INDICE_POC)
from
(
SELECT 
  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP as CD_OP ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.MT_ENCOURS as MT_ENCOURS ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG as RANG   
FROM 
  <?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  
WHERE
  (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1
) 
  ) PITOPE_COT_REF_OPE_1  LEFT JOIN  <?= odiRef.getObjectName("L", "PWTOPE_POC_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PWTOPE_POC_SCR_INT_REC_NON_CAUT  
    ON  PITOPE_COT_REF_OPE_1.CD_OP = PWTOPE_POC_SCR_INT_REC_NON_CAUT.CD_OP
where	(1=1)
