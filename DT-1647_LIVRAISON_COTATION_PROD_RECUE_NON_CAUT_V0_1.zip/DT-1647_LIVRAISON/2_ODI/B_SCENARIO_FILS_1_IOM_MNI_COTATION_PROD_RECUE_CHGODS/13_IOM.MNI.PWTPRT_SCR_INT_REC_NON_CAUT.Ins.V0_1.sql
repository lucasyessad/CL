/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 13  -  MAPPING  IOM.MNI.PWTPRT_SCR_INT_REC_NON_CAUT.Ins.V0_1

   Prets de l'operation - detail pour le moteur de score.

   Duplique de    : IOM.MNI.PWTPRT_SCR_INT.Ins.V0_2 (etape 13 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTPRT_SCR_INT_REC_NON_CAUT (MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        : PITOPE_COT_REF_PRT_REC_NON_CAUT, PWTPRT (MSSQL_DWH)

   MODIFICATION : l'original est une UNION de deux branches.
     - Branche 1 (SUPPRIMEE) : prets mis en paiement (FL_PER = 1) lus dans
       PDTPDT_MEP. Toujours vide sur ce perimetre (FL_PER = 0).
     - Branche 2 (CONSERVEE A L'IDENTIQUE) : prets non engages
       (FL_PER = 0 et FL_CALC = 0) lus dans PWTPRT.

   Comportement d'origine conserve tel quel : la jointure gauche vers PWTPRT
   est filtree sur CD_NATUR_PRET_PFI = 'PBC' et CD_TYP_TX_PFI = 'F'. Pour
   les autres prets, taux / montant / duree arrivent a NULL et sont
   remplaces par des zeros a l'etape 14. C'est le fonctionnement actuel du
   stock non engage ; il n'est pas modifie pour rester comparable.
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTPRT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTPRT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ_PRT, CD_NATUR_PRET, TX_PRET, CD_TYP_TX, MT_PRET, NB_DUR_PFI, DJ_PFREGLE, CD_PRET)
select
	SET_ENC_NEC.CD_OP,
	SET_ENC_NEC.NO_SEQ_PRT,
	SET_ENC_NEC.CD_NATUR_PRET_PFI,
	SET_ENC_NEC.TX_PRET_PFI,
	SET_ENC_NEC.CD_TYP_TX_PFI,
	SET_ENC_NEC.MT_PRET_PFI,
	SET_ENC_NEC.NB_DUR_PFI,
	SET_ENC_NEC.DJ_PFREGLE,
	SET_ENC_NEC.CD_PRET
from
(
SELECT
  PITOPE_COT_REF_PRT_1_2.CD_OP as CD_OP ,
  PITOPE_COT_REF_PRT_1_2.NO_SEQ_PRT as NO_SEQ_PRT ,
  WPRT.TX_PRET_PFI as TX_PRET_PFI ,
  WPRT.CD_TYP_TX_PFI as CD_TYP_TX_PFI ,
  WPRT.MT_PRET_PFI as MT_PRET_PFI ,
  WPRT.NB_DUR_PFI as NB_DUR_PFI ,
  isNull(WPRT.DJ_PFREGLE,convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121)-day(convert(datetime,'#INEO.V040_DatDonATraiter_V0_1',121))) as DJ_PFREGLE ,
  PITOPE_COT_REF_PRT_1_2.CD_PRET as CD_PRET ,
  WPRT.CD_NATUR_PRET_PFI as CD_NATUR_PRET_PFI
FROM
  (
SELECT
  PITOPE_COT_REF_PRT_1_1.CD_PRET as CD_PRET ,
  PITOPE_COT_REF_PRT_1_1.NO_SEQ_PRT as NO_SEQ_PRT ,
  PITOPE_COT_REF_PRT_1_1.CD_OP as CD_OP ,
  PITOPE_COT_REF_PRT_1_1.FL_PER as FL_PER ,
  PITOPE_COT_REF_PRT_1_1.FL_CALC as FL_CALC
FROM
  <?= odiRef.getObjectName("L", "PITOPE_COT_REF_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_PRT_1_1
WHERE
  (PITOPE_COT_REF_PRT_1_1.FL_PER=0 and
PITOPE_COT_REF_PRT_1_1.FL_CALC=0
)
  ) PITOPE_COT_REF_PRT_1_2  LEFT JOIN  (
SELECT
  WPRT_1.CD_PRET as CD_PRET ,
  WPRT_1.NO_SEQ_PRT as NO_SEQ_PRT ,
  WPRT_1.CD_NATUR_PRET_PFI as CD_NATUR_PRET_PFI ,
  WPRT_1.NB_DUR_PFI as NB_DUR_PFI ,
  WPRT_1.TX_PRET_PFI as TX_PRET_PFI ,
  WPRT_1.CD_TYP_TX_PFI as CD_TYP_TX_PFI ,
  WPRT_1.MT_PRET_PFI as MT_PRET_PFI ,
  WPRT_1.DJ_PFREGLE as DJ_PFREGLE
FROM
  <?= odiRef.getObjectName("L", "PWTPRT", "MSSQL_DWH", "D") ?> as WPRT_1
WHERE
  (WPRT_1.CD_NATUR_PRET_PFI='PBC' and
WPRT_1.CD_TYP_TX_PFI='F'
)
  ) WPRT
    ON  PITOPE_COT_REF_PRT_1_2.CD_PRET = WPRT.CD_PRET AND PITOPE_COT_REF_PRT_1_2.NO_SEQ_PRT = WPRT.NO_SEQ_PRT
  ) SET_ENC_NEC
where	(1=1)
