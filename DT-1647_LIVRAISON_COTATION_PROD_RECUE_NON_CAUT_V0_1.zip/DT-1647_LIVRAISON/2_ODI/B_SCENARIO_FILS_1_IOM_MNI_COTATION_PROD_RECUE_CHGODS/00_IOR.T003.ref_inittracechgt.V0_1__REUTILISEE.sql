/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 00  -  PROCEDURE MAISON  IOR.T003.ref_inittracechgt.V0_1

   REUTILISEE TELLE QUELLE (aucune modification, aucune duplication).
   Elle travaille sur la ligne PWTTRE dont LB_NOM_SCN_SUN = nom de session,
   donc ici IOM_MNI_COTATION_PROD_RECUE_CHGODS (ligne creee par
   1_SQL/05_DWH_INIT_PWTTRE_REC_NON_CAUT.sql).

   Effet : fige la date des donnees a traiter
       DA_DON_A_TRT = ISNULL(DA_FIN_DEL_FOR, date batch)
   DA_FIN_DEL_FOR est positionnee par le package pere avant chaque appel
   (procedure IOM_COT_MAJ_PWTTRE_FILS_DYN) : le fils traite donc exactement
   l'arrete choisi par la boucle du pere.

   Code de reference (extrait du scenario de production) :
   ============================================================================ */

/* Maj dernier trt lance */
update	<?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
set	ID_DET_TRT_ALI = <?=odiRef.getSession("SESS_NO") ?>,
	DA_DON_A_TRT = isnull(DA_FIN_DEL_FOR, dbo.GETDATE_Batch(getdate()))
where	LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>';

/* Insert suivi traitement */
insert into <?=odiRef.getObjectName("L", "PWTSDC", "MSSQL_DWH", "D") ?> (
	LB_NOM_SCN_SUN, ID_TRT_ALI, NB_VER_SCN_SUN, LB_STA_TRT, DA_DEB_TRT, NO_SEQ, DA_DON_TRT, DA_DEB_DEL_EXT)
select	LB_NOM_SCN_SUN, <?=odiRef.getSession("SESS_NO") ?>, '<?=odiRef.getSession("SCEN_VERSION") ?>',
	'KO', getDate(), NO_SEQ, DA_DON_A_TRT, DA_DEB_DEL_TRT
from	<?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
where	LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'

/* Insert suivi par fichier (aucune ligne PWTCHE pour ce scenario : sans effet) */
