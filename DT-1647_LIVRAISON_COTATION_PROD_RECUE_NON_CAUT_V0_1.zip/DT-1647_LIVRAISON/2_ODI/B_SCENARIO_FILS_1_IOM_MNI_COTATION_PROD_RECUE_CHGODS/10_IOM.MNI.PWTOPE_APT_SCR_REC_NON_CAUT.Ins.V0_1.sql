/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 10  -  MAPPING  IOM.MNI.PWTOPE_APT_SCR_REC_NON_CAUT.Ins.V0_1

   Apports - format moteur de score

   Duplique de    : IOM.MNI.PWTOPE_APT_SCR.Ins.V0_2  (etape 10 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTOPE_APT_SCR_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTOPE_APT_SCR_INT_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference de controle (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTOPE_APT_SCR_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTOPE_APT_SCR_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, MT_APPOR_1, MT_APPOR_2, MT_APPOR_3, MT_APPOR_4, RANG)
select  
	PITOPE_COT_REF_OPE_1.CD_OP,
	isnull(RIGHT('00000000'+convert(varchar(8), cast(sum(PWTOPE_APT_SCR_INT_REC_NON_CAUT.MT_APPOR) over(partition by PWTOPE_APT_SCR_INT_REC_NON_CAUT.CD_OP) as int)), 8),'00000000'),
	'00000000',
	'00000000',
	'00000000',
	row_number () OVER (partition by PITOPE_COT_REF_OPE_1.CD_OP order by PWTOPE_APT_SCR_INT_REC_NON_CAUT.NU_INDICE_APT)
from
(
SELECT 
  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP as CD_OP ,
  PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG as RANG   
FROM 
  <?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  
WHERE
  (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1
) 
  ) PITOPE_COT_REF_OPE_1  LEFT JOIN  <?= odiRef.getObjectName("L", "PWTOPE_APT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PWTOPE_APT_SCR_INT_REC_NON_CAUT  
    ON  PITOPE_COT_REF_OPE_1.CD_OP = PWTOPE_APT_SCR_INT_REC_NON_CAUT.CD_OP
where	(1=1)
