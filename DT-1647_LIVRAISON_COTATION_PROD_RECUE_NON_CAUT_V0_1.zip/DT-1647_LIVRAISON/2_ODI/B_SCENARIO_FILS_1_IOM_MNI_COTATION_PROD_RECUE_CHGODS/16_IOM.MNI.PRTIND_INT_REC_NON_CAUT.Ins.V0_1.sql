/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 16  -  MAPPING  IOM.MNI.PRTIND_INT_REC_NON_CAUT.Ins.V0_1

   Individus des intervenants

   Duplique de    : IOM.MNI.PRTIND_INT.Ins.V0_1  (etape 16 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PRTIND_INT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PRTIND                                   (MSSQL_DWH)
     - PWTINT_SCR_INT_REC_NON_CAUT              (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PRTIND_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PRTIND_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, CD_INDI, NO_SEQ_IND, CD_TYP_IND, CD_SEX, DJ_NAIS, RANG)
select  
	INLINE_VIEW.CD_OP_1,
	INLINE_VIEW.CD_INDI_2,
	INLINE_VIEW.NO_SEQ_IND_1,
	INLINE_VIEW.CD_TYP_IND_1,
	INLINE_VIEW.CD_SEX_1,
	INLINE_VIEW.DJ_NAIS_1,
	INLINE_VIEW.COL
from
(
SELECT 
  PWTINT_SCR_INT_1.CD_OP as CD_OP ,
  PWTINT_SCR_INT_1.CD_INDI as CD_INDI ,
  PWTINT_SCR_INT_1.DJ_DATE_DEB as DJ_DATE_DEB ,
  PWTINT_SCR_INT_1.RANG as RANG ,
  IND.CD_INDI as CD_INDI_1 ,
  IND.NO_SEQ_IND as NO_SEQ_IND ,
  IND.DD_VAL as DD_VAL ,
  IND.DF_VAL as DF_VAL ,
  IND.FL_SUP as FL_SUP ,
  IND.CD_TYP_IND as CD_TYP_IND ,
  IND.CD_SEX as CD_SEX ,
  IND.DJ_NAIS as DJ_NAIS ,
  PWTINT_SCR_INT_1.CD_OP as CD_OP_1 ,
  PWTINT_SCR_INT_1.CD_INDI as CD_INDI_2 ,
  IND.NO_SEQ_IND as NO_SEQ_IND_1 ,
  IND.CD_TYP_IND as CD_TYP_IND_1 ,
  IND.CD_SEX as CD_SEX_1 ,
  IND.DJ_NAIS as DJ_NAIS_1 ,
  row_number () OVER (partition by PWTINT_SCR_INT_1.CD_OP, IND.CD_INDI order by IND.DD_VAL desc) as COL ,
  IND.FL_SUP as FL_SUP_1   
FROM 
  <?= odiRef.getObjectName("L", "PWTINT_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PWTINT_SCR_INT_1  INNER JOIN  <?= odiRef.getObjectName("L", "PRTIND", "MSSQL_DWH", "D") ?> as IND  
    ON  PWTINT_SCR_INT_1.CD_INDI = IND.CD_INDI and
convert(date,PWTINT_SCR_INT_1.DJ_DATE_DEB,121) between convert(date,IND.DD_VAL,121) and convert(date,IND.DF_VAL,121)
WHERE
  (PWTINT_SCR_INT_1.RANG=1
) 
  ) INLINE_VIEW
where	(1=1)
 and (INLINE_VIEW.COL=1) and (INLINE_VIEW.FL_SUP_1<>1)
