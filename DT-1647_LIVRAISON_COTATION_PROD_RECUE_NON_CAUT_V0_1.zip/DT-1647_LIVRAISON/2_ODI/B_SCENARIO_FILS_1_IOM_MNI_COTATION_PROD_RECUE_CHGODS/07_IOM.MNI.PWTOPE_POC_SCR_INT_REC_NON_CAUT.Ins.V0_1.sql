/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 07  -  MAPPING  IOM.MNI.PWTOPE_POC_SCR_INT_REC_NON_CAUT.Ins.V0_1

   Postes de cout - detail

   Duplique de    : IOM.MNI.PWTOPE_POC_SCR_INT.Ins.V0_1  (etape 7 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTOPE_POC_SCR_INT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTOPE_POC                               (MSSQL_DWH)
     - PWTOPE_POC_REL                           (MSSQL_DWH)

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTOPE_POC_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTOPE_POC_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ_POC, NU_INDICE_POC, CD_POSTCOUT, MT_POSTCOUT, MT_ENCOURS, RANG)
select  
	PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP,
	POC.NO_SEQ_POC,
	POC.NU_INDICE_POC,
	POC.CD_POSTCOUT,
	POC.MT_POSTCOUT,
	PITOPE_COT_REF_OPE_REC_NON_CAUT.MT_ENCOURS,
	row_number () OVER (partition by PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP order by POC.NO_SEQ_POC, POC.NU_INDICE_POC)
from
(<?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_POC", "MSSQL_DWH", "D") ?> as POC  
    ON  PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = POC.CD_OP
     )  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_POC_REL", "MSSQL_DWH", "D") ?> as POC_REL  
    ON  (PITOPE_COT_REF_OPE_REC_NON_CAUT.NO_SEQ_OPE = POC_REL.NO_SEQ_OPE AND PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = POC_REL.CD_OP) and (POC_REL.NO_SEQ_POC = POC.NO_SEQ_POC AND POC_REL.NU_INDICE_POC = POC.NU_INDICE_POC   AND POC_REL.CD_OP = POC.CD_OP)
where	(1=1)
 and (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1)
