/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 01  -  VARIABLE (rafraichissement)  INEO.V040_DatDonATraiter_V0_1

   REUTILISEE TELLE QUELLE. Variable globale du projet INEO, lue par nom de
   session : elle renvoie le DA_DON_A_TRT fige par T003 pour CE scenario.

   Toute la chaine en derive :
     date des donnees     = #INEO.V040_DatDonATraiter_V0_1      (ex. 2026-08-01)
     arrete calcule       = date des donnees - DAY(date)        (ex. 2026-07-31)
     CD_DAT_ARR_AAM       = yyyymm de l'arrete                  (ex. 202607)
     DT_ENCOURS EWTENC / EWTNEC = meme yyyymm
   ============================================================================ */
select	convert(datetime,DA_DON_A_TRT,121)
from 	dbo.PWTTRE
where 	LB_NOM_SCN_SUN='<?=odiRef.getSession("SESS_NAME") ?>'
