/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 20  -  PROCEDURE  IOM.MNI_PITOPE_COT_SCR_REC_NON_CAUT.Upd.V0_1

   Corrections de l'enregistrement d'entree du score.

   Duplique de    : procedure IOM.MNI_PITOPE_COT_SCR.Upd.V0_2 (etape 20 du
                    scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Schema logique : MSSQL_DWH  -  Technologie : Microsoft SQL Server

   TACHE 1 PITOPE_COT_SCR_UPD       : identique, structures renommees.
   TACHE 2 PITOPE_COT_SCR_UPD_NULL  : identique, structures renommees.
   TACHE 3 PITOPE_COT_SCR_PF_RGL    : REDUITE a sa derniere instruction.
       La tache d'origine recalcule la date de premier reglement des
       operations PRESENTES DANS L'ENCOURS ENGAGE (EWTENC) dont une partie
       des prets est reglee ou annulee. Par construction aucune operation du
       perimetre n'est dans EWTENC : les tables temporaires #EWT_PRT, #PRT
       et #PRT_DJ_PF seraient vides et la mise a jour sans effet. Seule la
       valeur par defaut finale (19000101 -> date du jour, comme pour le
       stock) s'applique ; c'est la seule instruction conservee.
       Elle ecrivait aussi dans "dbo.PITOPE_COT_SCR" sans catalogue : le nom
       est maintenant qualifie par odiRef, comme les taches 1 et 2.
   ============================================================================ */

/* ============================================================================
   TACHE 1  -  PITOPE_COT_SCR_UPD
   ============================================================================ */
update <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_SCR_REC_NON_CAUT
set PITOPE_COT_SCR_REC_NON_CAUT.NU_VERS_SCORE_QUANTILE=isNull(req.nu_vers_score_quantile,SUBSTRING(PITOPE_COT_SCR_REC_NON_CAUT.CD_OP,2,4)+'1')
from
(
select PITOPE_COT_SCR_REC_NON_CAUT.CD_OP, PWTOPE.nu_vers_score_quantile
from <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_SCR_REC_NON_CAUT,
     <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.pwtope
where PITOPE_COT_SCR_REC_NON_CAUT.CD_OP=pwtope.CD_OP
and PITOPE_COT_SCR_REC_NON_CAUT.nu_vers_score_quantile='00000'
and PWTOPE.DD_VAL<=PITOPE_COT_SCR_REC_NON_CAUT.DJ_DATE_DEB
and PWTOPE.DF_VAL>PITOPE_COT_SCR_REC_NON_CAUT.DJ_DATE_DEB
)as req
where PITOPE_COT_SCR_REC_NON_CAUT.CD_OP=req.CD_OP

/* ============================================================================
   TACHE 2  -  PITOPE_COT_SCR_UPD_NULL
   ============================================================================ */
update <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_SCR_REC_NON_CAUT
set PITOPE_COT_SCR_REC_NON_CAUT.NU_VERS_SCORE_QUANTILE=SUBSTRING(PITOPE_COT_SCR_REC_NON_CAUT.CD_OP,2,4)+'1'
where nu_vers_score_quantile='00000'

/* ============================================================================
   TACHE 3  -  PITOPE_COT_SCR_PF_RGL (reduite)
   ============================================================================ */
update <?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.dbo.PITOPE_COT_SCR_REC_NON_CAUT
set DJ_PFREGLE_10=FORMAT(getDate(),'yyyyMMdd')
where DJ_PFREGLE_10='19000101'
