/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 24  -  MAPPING  IOM.MNI.PITOPE_COT_MOT_REC_NON_CAUT.Ins.V0_1

   APPEL DU MOTEUR DE COTATION (dbo.fCotationSQL)

   Duplique de    : IOM.MNI.PITOPE_COT_MOT_M.Ins.V0_2  (etape 38 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_MOT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REC_NON_CAUT                  (MSSQL_DWH)   <- structure dediee
     - PITOPE_COT_COMP_REC_NON_CAUT             (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   ATTENTION - CONTENU DE PITOPE_COT_COMP_REC_NON_CAUT
   Dans l'original, PITOPE_COT_COMP est alimentee par le mapping
   IOM.MNI.PITOPE_COT_PB_COMP.Ins (liste des mappings a ne pas utiliser) a
   partir de PDTOPE_COT. Ici elle est alimentee a l'etape 23 a partir de
   l'historique du perimetre (PDTOPE_COT_REC_NON_CAUT, arrete precedent).
   Elle contient une ligne par operation de PITOPE_COT_REC_NON_CAUT, meme
   sans historique : la jointure INTERNE d'origine est donc conservee sans
   perte de ligne.

   Version V0_2 de l'original : FL_OP_MEP est FORCE A '1' dans le buffer
   envoye au moteur (CCS 03/09/2026). C'est ce forcage qui fait calculer au
   moteur une vraie CHR (et non K) ; l'etape 26 range ensuite cette CHR en
   CD_CHR_PD_CIBLE et remet CD_CHR_PD a 'K' puisque FL_OP_MEP = 0.
   C'est exactement le comportement voulu pour la production recue.

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_MOT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_MOT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ, BUF, RES, CD_DER_CHR_LGD_DEF, CD_CHR_PD_PDT, DT_REF_CHR_PD, DT_REF_CHR_LGD, FL_DEF_PASS, DT_REF_CHR_PD_REENT, DT_REF_CHR_LGD_REENT, CD_CHR_PD_REENT, CD_CHR_LGD_REEENT, CD_CHR_LGD_PDT)
select  
	PITOPE_COT_REC_NON_CAUT.CD_OP,
	PITOPE_COT_REC_NON_CAUT.NO_SEQ,
	isnull(cast(PITOPE_COT_REC_NON_CAUT.CD_TRAIT as char(1)),' ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_OP_MEP as char(1)),'0')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_REL as char(1)),'0')+
' '+
isnull(right('000000'+'00'+cast(case when PITOPE_COT_REC_NON_CAUT.TX_LTV>=1 then 9900 when PITOPE_COT_REC_NON_CAUT.TX_LTV=-1 then 9900 else cast(PITOPE_COT_REC_NON_CAUT.TX_LTV*10000 as int) end as varchar(6)),6),'      ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_MEP_OP, 'yyyyMMdd'),'        ')+
case when NB_INT is null then '  '
     when len(nb_int)=1 then cast(NB_INT as varchar)+' '
	 else cast(NB_INT as varchar)
end+
' '+
isnull(cast(cast(PITOPE_COT_REC_NON_CAUT.NB_NOTE_ENCOURS*10000 as int) as char(6)),'      ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_DEF_OP as char(1)),' ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DD_DEB_DEF_1, 'yyyyMMdd'),'        ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DF_DEF_OP, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_DEC_DET as char(1)),'0')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_DEC_DET, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_SUR as char(1)),'0')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_SUR, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_EXE as char(1)),'0')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_EXE, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_COLL as char(1)),'0')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_COLL, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_103_104 as char(1)),'0')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_103_104, 'yyyyMMdd'),'        ')+
isnull(cast(PITOPE_COT_REC_NON_CAUT.CD_CHR_LGD_COUR as char(2)),'  ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DF_REL, 'yyyyMMdd'),'        ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_ANN_FIN_REL, 'yyyyMMdd'),'        ')+
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_REF_TRAIT, 'yyyyMMdd'),FORMAT(getDate(),'yyyyMMdd')),
	dbo.fCotationSQL(isnull(cast(PITOPE_COT_REC_NON_CAUT.CD_TRAIT as char(1)),' ')+ 
--isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_OP_MEP as char(1)),'0')+ /* forçage à 1 CCS 03092026 */ 
'1'+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_REL as char(1)),'0')+ 
' '+ 
isnull(right('000000'+'00'+cast(case when PITOPE_COT_REC_NON_CAUT.TX_LTV>=1 then 9900 when PITOPE_COT_REC_NON_CAUT.TX_LTV=-1 then 9900 else cast(PITOPE_COT_REC_NON_CAUT.TX_LTV*10000 as int) end as varchar(6)),6),'      ')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_MEP_OP, 'yyyyMMdd'),FORMAT(getDate(),'yyyyMMdd'))+ 
case when NB_INT is null then '  ' 
     when len(nb_int)=1 then cast(NB_INT as varchar)+' ' 
	 else cast(NB_INT as varchar) 
end+ 
' '+ 
--case when SUBSTRING(cast(PITOPE_COT_REC_NON_CAUT.NB_NOTE_ENCOURS as varchar),1,1)='-' then '-' else '+' end+ 
isnull(cast(cast(PITOPE_COT_REC_NON_CAUT.NB_NOTE_ENCOURS*10000 as int) as char(6)),'      ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_DEF_OP as char(1)),' ')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DD_DEB_DEF_1, 'yyyyMMdd'),FORMAT(getDate(),'yyyyMMdd'))+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DF_DEF_OP, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_DEC_DET as char(1)),'0')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_DEC_DET, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_SUR as char(1)),'0')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_SUR, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_EXE as char(1)),'0')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_EXE, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_PROC_COLL as char(1)),'0')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_PROC_COLL, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.FL_103_104 as char(1)),'0')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_103_104, 'yyyyMMdd'),'        ')+ 
isnull(cast(PITOPE_COT_REC_NON_CAUT.CD_CHR_LGD_COUR as char(2)),'  ')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DF_REL, 'yyyyMMdd'),'        ')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_ANN_FIN_REL, 'yyyyMMdd'),'        ')+ 
isnull(FORMAT(PITOPE_COT_REC_NON_CAUT.DT_REF_TRAIT, 'yyyyMMdd'),FORMAT(getDate(),'yyyyMMdd'))),
	PITOPE_COT_COMP_REC_NON_CAUT.CD_DER_CHR_LGD_DEF,
	PITOPE_COT_COMP_REC_NON_CAUT.CD_CHR_PD_PDT,
	PITOPE_COT_COMP_REC_NON_CAUT.DT_REF_CHR_PD,
	PITOPE_COT_COMP_REC_NON_CAUT.DT_REF_CHR_LGD,
	PITOPE_COT_COMP_REC_NON_CAUT.FL_DEF_PASS,
	PITOPE_COT_COMP_REC_NON_CAUT.DT_REF_CHR_PD_REENT,
	PITOPE_COT_COMP_REC_NON_CAUT.DT_REF_CHR_LGD_REENT,
	PITOPE_COT_COMP_REC_NON_CAUT.CD_CHR_PD_REENT,
	PITOPE_COT_COMP_REC_NON_CAUT.CD_CHR_LGD_REEENT,
	PITOPE_COT_COMP_REC_NON_CAUT.CD_CHR_LGD_PDT
from
<?= odiRef.getObjectName("L", "PITOPE_COT_COMP_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_COMP_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PITOPE_COT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REC_NON_CAUT  
    ON  PITOPE_COT_COMP_REC_NON_CAUT.CD_OP = PITOPE_COT_REC_NON_CAUT.CD_OP AND PITOPE_COT_COMP_REC_NON_CAUT.NO_SEQ = PITOPE_COT_REC_NON_CAUT.NO_SEQ
where	(1=1)
