/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 11  -  MAPPING  IOM.MNI.PWTOPE_CHA_SCR_INT_REC_NON_CAUT.Ins.V0_1

   Charges - detail

   Duplique de    : IOM.MNI.PWTOPE_CHA_SCR_INT.Ins.V0_2  (etape 11 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PWTOPE_CHA_SCR_INT_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_REF_OPE_REC_NON_CAUT          (MSSQL_DWH)   <- structure dediee
     - PWTOPE_CHA                               (MSSQL_DWH)
     - PWTOPE_CHA_REL                           (MSSQL_DWH)

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference de controle (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PWTOPE_CHA_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PWTOPE_CHA_SCR_INT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, CD_TYP_CHARGE, CD_PERIOD_CHARGE, MT_CHARGE, NO_SEQ_CHA, NU_INDICE_CHA, RANG)
select  
	PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP,
	CHA.CD_TYP_CHARGE,
	CHA.CD_PERIOD_CHARGE,
	CHA.MT_CHARGE,
	CHA.NO_SEQ_CHA,
	CHA.NU_INDICE_CHA,
	row_number () OVER (partition by PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP order by CHA.NO_SEQ_CHA,CHA.NU_INDICE_CHA)
from
(<?= odiRef.getObjectName("L", "PITOPE_COT_REF_OPE_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_REF_OPE_REC_NON_CAUT  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_CHA_REL", "MSSQL_DWH", "D") ?> as CHA_REL  
    ON  PITOPE_COT_REF_OPE_REC_NON_CAUT.NO_SEQ_OPE = CHA_REL.NO_SEQ_OPE AND PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = CHA_REL.CD_OP
     )  INNER JOIN  <?= odiRef.getObjectName("L", "PWTOPE_CHA", "MSSQL_DWH", "D") ?> as CHA  
    ON  (PITOPE_COT_REF_OPE_REC_NON_CAUT.CD_OP = CHA.CD_OP) and (CHA_REL.CD_OP = CHA.CD_OP AND CHA_REL.NO_SEQ_CHA = CHA.NO_SEQ_CHA   AND CHA_REL.NU_INDICE_CHA = CHA.NU_INDICE_CHA)
where	(1=1)
 and (PITOPE_COT_REF_OPE_REC_NON_CAUT.RANG=1)
