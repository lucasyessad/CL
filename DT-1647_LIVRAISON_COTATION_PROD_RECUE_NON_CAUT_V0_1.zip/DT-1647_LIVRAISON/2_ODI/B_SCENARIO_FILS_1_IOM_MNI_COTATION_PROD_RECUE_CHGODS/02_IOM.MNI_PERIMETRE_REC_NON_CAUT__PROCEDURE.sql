/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 02  -  PROCEDURE  IOM.MNI_PERIMETRE_REC_NON_CAUT   (NOUVELLE)

   Construit le perimetre de l'arrete calcule : les prets
     - RECUS par Credit Logement et NON REGLES : derniere version du pret
       a fin de mois a une etape CLA, EAU, EDI, PEC ou SIG ;
     - NON CAUTIONNES : absents de l'encours engage (EWTENC) ;
     - NON ENGAGES   : absents de l'encours non engage (EWTNEC) ;
     - d'une operation dont AUCUN pret n'est dans EWTENC ou EWTNEC
       (consigne du code fourni : "s'assurer que pour une meme operation
       tous les prets sont dans le meme statut de non cautionnes").

   Source : code perimetre fourni dans la carte
   (Perimetre_PROD_RECU_NON_CAUTIONNEE.sql, version CCS 16/10/2026).
   Commentaire de Cyril Costes du 16/10 : "le perimetre est mis a jour, il
   n'y a plus d'exclusion ; tout ce qui arrive a CL, pas cautionne et pas
   regle, doit etre score et cote." -> l'exclusion CD_STATUT ANN/REF
   reste desactivee, comme dans le code fourni (voir README, point ouvert 1).

   Schema logique des taches : MSSQL_DWH  -  Technologie : Microsoft SQL Server

   CORRECTIONS PAR RAPPORT AU CODE FOURNI
   --------------------------------------
   1. Le code ne s'executait pas : parenthese fermante orpheline apres le
      2e INSERT, cible "table de perimetre" non renseignee, alias PRT.*
      inexistant (la table est aliasee WPRT_1).
   2. Incoherence de noms : TRUNCATE de PITMAX_SEQ_HORS_ENC_NEC, INSERT dans
      PITMAX_SEQ_HORS_ENC, lecture de PITMAX_SEQ_HORS_ENC_NEC ; et
      PITMAX_SEQ_PWTPRT n'etait jamais videe (cumul d'un mois a l'autre,
      puis violation de cle ou doublons). Chaque table est maintenant videe
      puis rechargee a chaque execution.
   3. Comparaison de dates en TEXTE : CONVERT(CHAR(10), ID_TRACE, 103)
      <= CONVERT(CHAR(10), date, 103) compare des chaines 'jj/mm/aaaa'.
      L'ordre alphabetique n'est pas l'ordre chronologique : '01/08/2026' est
      "inferieur" a '31/07/2026'. Des versions posterieures a l'arrete
      etaient retenues et des versions anterieures ecartees.
      -> comparaison de dates typees, sargable (ID_TRACE < arrete + 1 jour).
   4. Trois variables differentes pour une meme date (#V_DateArrete_EAD_V0_1,
      #INEO.V155_FinIntCalcul_V0_1, LEFT(...,6)), venant d'autres chaines et
      non rafraichies dans ce scenario. Tout derive maintenant de
      #INEO.V040_DatDonATraiter_V0_1, comme dans le reste du scenario
      (meme calcul d'arrete que le mapping d'origine
      IOM.MNI.PITOPE_COT_REF_PRT_INT.Ins).
   5. Noms "en dur" (DWH.dbo..., DWH_ENCOURS.dbo..., DWH.ods...) remplaces
      par odiRef.getObjectName : le code suit les contextes ODI.
   6. Exclusion au niveau operation implementee (le code fourni la laissait
      en commentaire).
   ============================================================================ */


/* ============================================================================
   TACHE 1  -  Derniere version de chaque pret a image fin de mois
   ============================================================================ */
DECLARE @DT_DONNEES DATETIME = CONVERT(DATETIME, '#INEO.V040_DatDonATraiter_V0_1', 121);
DECLARE @DT_ARRETE  DATE     = DATEADD(DAY, -DAY(@DT_DONNEES), CAST(@DT_DONNEES AS DATE));
DECLARE @DT_LIMITE  DATETIME = DATEADD(DAY, 1, CAST(@DT_ARRETE AS DATETIME));   -- arrete inclus, jusqu'a 23:59:59.997

TRUNCATE TABLE <?=odiRef.getObjectName("L", "PITOPE_MAX_SEQ_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>;

INSERT INTO <?=odiRef.getObjectName("L", "PITOPE_MAX_SEQ_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
       (CD_PRET, NO_SEQ_PRT)
SELECT PRT.CD_PRET,
       MAX(PRT.NO_SEQ_PRT)
FROM   <?=odiRef.getObjectName("L", "PWTPRT", "MSSQL_DWH", "D") ?> AS PRT
WHERE  PRT.DJ_DATE_DEB < @DT_LIMITE
  AND  PRT.ID_TRACE    < @DT_LIMITE
GROUP BY PRT.CD_PRET;


/* ============================================================================
   TACHE 2  -  Table de perimetre
   ============================================================================ */
DECLARE @DT_DONNEES DATETIME = CONVERT(DATETIME, '#INEO.V040_DatDonATraiter_V0_1', 121);
DECLARE @DT_ARRETE  DATE     = DATEADD(DAY, -DAY(@DT_DONNEES), CAST(@DT_DONNEES AS DATE));
DECLARE @CD_DAT_ARR_AAM INT  = YEAR(@DT_ARRETE) * 100 + MONTH(@DT_ARRETE);

TRUNCATE TABLE <?=odiRef.getObjectName("L", "PITOPE_PERIMETRE_REC_NON_CAUT", "MSSQL_DWH", "D") ?>;

WITH DERNIERE_VERSION AS
(
    SELECT PRT.CD_OP, PRT.CD_PRET, PRT.NO_SEQ_PRT, PRT.CD_ETAP, PRT.CD_STATUT,
           PRT.CD_NATUR_PRET, PRT.DJ_DATE_DEB, PRT.MT_PRET_PFI
    FROM   <?=odiRef.getObjectName("L", "PITOPE_MAX_SEQ_PRT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> AS MAXSEQ
    INNER JOIN <?=odiRef.getObjectName("L", "PWTPRT", "MSSQL_DWH", "D") ?> AS PRT
            ON  PRT.CD_PRET    = MAXSEQ.CD_PRET
            AND PRT.NO_SEQ_PRT = MAXSEQ.NO_SEQ_PRT
),
/* Operations dont au moins un pret est cautionne (EWTENC) ou engage (EWTNEC)
   a l'arrete : l'operation entiere sort du perimetre. */
OPERATIONS_ENGAGEES AS
(
    SELECT DISTINCT DV.CD_OP
    FROM   DERNIERE_VERSION AS DV
    WHERE  EXISTS (SELECT 1
                   FROM   <?=odiRef.getObjectName("L", "EWTENC", "MSSQL_DWH_ENCOURS", "D") ?> AS ENC
                   WHERE  ENC.CD_PRET    = DV.CD_PRET
                     AND  ENC.DT_ENCOURS = @CD_DAT_ARR_AAM)
       OR  EXISTS (SELECT 1
                   FROM   <?=odiRef.getObjectName("L", "EWTNEC", "MSSQL_DWH_ENCOURS", "D") ?> AS NEC
                   WHERE  NEC.CD_PRET    = DV.CD_PRET
                     AND  NEC.DT_ENCOURS = @CD_DAT_ARR_AAM)
)
INSERT INTO <?=odiRef.getObjectName("L", "PITOPE_PERIMETRE_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
       (CD_DAT_ARR_AAM, CD_OP, CD_PRET, NO_SEQ_PRT, CD_ETAP, CD_STATUT,
        CD_NATUR_PRET, DJ_DATE_DEB, MT_PRET_PFI, DT_MAJ)
SELECT @CD_DAT_ARR_AAM,
       DV.CD_OP, DV.CD_PRET, DV.NO_SEQ_PRT, DV.CD_ETAP, DV.CD_STATUT,
       DV.CD_NATUR_PRET, DV.DJ_DATE_DEB, DV.MT_PRET_PFI, GETDATE()
FROM   DERNIERE_VERSION AS DV
WHERE  DV.CD_ETAP IN ('CLA', 'EAU', 'EDI', 'PEC', 'SIG')
--AND  DV.CD_STATUT NOT IN ('ANN', 'REF')      /* desactive par CCS le 16/10/2026 - voir README point ouvert 1 */
  AND  NOT EXISTS (SELECT 1 FROM OPERATIONS_ENGAGEES AS OE WHERE OE.CD_OP = DV.CD_OP);
