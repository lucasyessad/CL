/* ============================================================================
   DT-1647  -  SCENARIO FILS 1  IOM_MNI_COTATION_PROD_RECUE_CHGODS
   ETAPE 25  -  MAPPING  IOM.MNI.PITOPE_COT_MOT_RES_REC_NON_CAUT.Ins.V0_1

   Decodage du resultat du moteur de cotation

   Duplique de    : IOM.MNI.PITOPE_COT_MOT_RES.Ins.V0_1  (etape 39 du scenario
                    IOM_MNI_COTATION_PRUD_MENS_CHGODS version 0_3)
   Cible          : PITOPE_COT_MOT_RES_REC_NON_CAUT   (schema logique MSSQL_DWH)
   KM             : KIM ISO SQL Control Append, option TRUNCATE = true
   Sources        :
     - PITOPE_COT_MOT_REC_NON_CAUT              (MSSQL_DWH)   <- structure dediee

   SEULE MODIFICATION : les structures de travail sont remplacees par leur
   jumelle _REC_NON_CAUT. Logique, jointures, filtres et expressions sont
   STRICTEMENT identiques a l'original (code genere par le KM, extrait du
   scenario de production).

   Mode operatoire ODI : dupliquer le mapping d'origine, renommer, puis
   remplacer chaque datastore de travail par son jumeau _REC_NON_CAUT
   (clic droit > "Remplacer le datastore" conserve les mappings de colonnes).
   Ce fichier est le code que le mapping duplique doit generer : il sert de
   reference de controle (onglet "Code" de la session ODI).
   ============================================================================ */

/* --- Truncate target table ------------------------------------------------ */
truncate table <?= odiRef.getObjectName("L", "PITOPE_COT_MOT_RES_REC_NON_CAUT", "MSSQL_DWH", "D") ?>

/* --- Insert new lines ------------------------------------------------------ */
insert into <?= odiRef.getObjectName("L", "PITOPE_COT_MOT_RES_REC_NON_CAUT", "MSSQL_DWH", "D") ?>
(CD_OP, NO_SEQ, CD_DER_CHR_LGD_DEF, CD_CHR_PD_PDT, CD_CHR_LGD, CD_CHR_PD, DT_VAL_CHR, NU_VERS_CHR, DT_REF_CHR_PD, DT_REF_CHR_LGD, FL_DEF_PASS, DT_REF_CHR_PD_REENT, DT_REF_CHR_LGD_REENT, CD_CHR_PD_REENT, CD_CHR_LGD_REEENT, CD_CHR_LGD_PDT)
select  
	PITOPE_COT_MOT_REC_NON_CAUT.CD_OP,
	PITOPE_COT_MOT_REC_NON_CAUT.NO_SEQ,
	PITOPE_COT_MOT_REC_NON_CAUT.CD_DER_CHR_LGD_DEF,
	PITOPE_COT_MOT_REC_NON_CAUT.CD_CHR_PD_PDT,
	substring(PITOPE_COT_MOT_REC_NON_CAUT.RES,4,2),
	substring(PITOPE_COT_MOT_REC_NON_CAUT.RES,3,1),
	convert(date,substring(PITOPE_COT_MOT_REC_NON_CAUT.RES,6,8),121),
	substring(PITOPE_COT_MOT_REC_NON_CAUT.RES,14,6),
	PITOPE_COT_MOT_REC_NON_CAUT.DT_REF_CHR_PD,
	PITOPE_COT_MOT_REC_NON_CAUT.DT_REF_CHR_LGD,
	PITOPE_COT_MOT_REC_NON_CAUT.FL_DEF_PASS,
	PITOPE_COT_MOT_REC_NON_CAUT.DT_REF_CHR_PD_REENT,
	PITOPE_COT_MOT_REC_NON_CAUT.DT_REF_CHR_LGD_REENT,
	PITOPE_COT_MOT_REC_NON_CAUT.CD_CHR_PD_REENT,
	PITOPE_COT_MOT_REC_NON_CAUT.CD_CHR_LGD_REEENT,
	PITOPE_COT_MOT_REC_NON_CAUT.CD_CHR_LGD_PDT
from
<?= odiRef.getObjectName("L", "PITOPE_COT_MOT_REC_NON_CAUT", "MSSQL_DWH", "D") ?> as PITOPE_COT_MOT_REC_NON_CAUT
where	(1=1)
