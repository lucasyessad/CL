================================================================================
DT-1647  -  [RISQUE] COTATION PRODUCTION RECUE NON CAUTIONNEE
Livraison V0_1 - 16/10/2026 - Lounis YESSAD
================================================================================


A QUOI SERT CE TRAITEMENT
--------------------------------------------------------------------------------

Depuis la mise en place de l'API score d'octroi (11/07/2026), les
operations recues ont bien une cotation prudentielle K08, mais leur CHR PD
CIBLE reste a E dans le SIO : le score d'encours n'est plus interroge en
exploitation. Le probleme a ete corrige dans le SID pour les operations
cautionnees (version 0_3 du scenario IOM_MNI_COTATION_PRUD_MENS_CHGODS).

La DRM etudie la qualite de TOUTE la production recue. Il manquait donc un
perimetre : les operations recues, non cautionnees et non reglees.

Ce traitement, mensuel, calcule pour chaque arrete :
  - le perimetre de ces operations ;
  - les donnees d'entree du moteur de score, puis le score ;
  - la cotation prudentielle (CHR PD = K) et la CHR CIBLE calculee par le
    moteur de cotation (CD_CHR_PD_CIBLE) ;
et range le resultat dans DWH.dbo.PITOPE_COT_REC_NON_CAUT, d'ou le
scenario fils 2 (autre carte) l'historisera dans
DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT.


CONTENU DE LA LIVRAISON
--------------------------------------------------------------------------------

  README.txt                          ce document
  1_SQL/                              scripts base de donnees, a jouer dans l'ordre
    01_DWH_CREATE_TABLE_PITOPE_COT_REC_NON_CAUT.sql
    02_DTM_INEO_CREATE_TABLE_PDTOPE_COT_REC_NON_CAUT.sql
    03_DWH_CREATE_TABLES_PERIMETRE_ET_HISTO_CHR_REC_NON_CAUT.sql
    04_DWH_CLONE_TABLES_TRAVAIL_REC_NON_CAUT.sql
    05_DWH_INIT_PWTTRE_REC_NON_CAUT.sql
    06_RECETTE_COTATION_REC_NON_CAUT.sql        (lecture seule)
    99_ROLLBACK_REC_NON_CAUT.sql                (abandon uniquement)
  2_ODI/
    A_PACKAGE_PERE_IOM_MNI_COTATION_PROD_RECUE/
      00_ENCHAINEMENT_PACKAGE_PERE.txt          etapes, liens OK/KO
      01..04_*.sql                              code des procedures et variables
    B_SCENARIO_FILS_1_IOM_MNI_COTATION_PROD_RECUE_CHGODS/
      00_ENCHAINEMENT_SCENARIO_FILS_1.txt       etapes, origine de chacune
      00..28_*.sql                              un fichier par etape
  3_DOC/
    DT-1647_Schema_Traitements.mermaid          schema d'ensemble

Chaque fichier SQL de 2_ODI commence par un cartouche : objet ODI a creer,
objet d'origine duplique, schema logique, KM, et ce qui change par rapport
a l'original (avec la raison).

Les fichiers "DUPLIQUEE" ont ete generes a partir du code reel du scenario
de production fourni (export XML) : ce sont les instructions exactes
produites par le KM, au renommage des tables de travail pres. Ils servent
de reference de controle une fois les mappings dupliques dans le Studio.


LES SIX PRINCIPES A COMPRENDRE
--------------------------------------------------------------------------------

1. LE PERIMETRE SE DEFINIT PAR EXCLUSION, AU NIVEAU OPERATION

   Un pret entre dans le perimetre si sa derniere version a fin de mois est
   a l'etape CLA, EAU, EDI, PEC ou SIG (recu, non regle) et s'il n'est ni
   dans l'encours engage (EWTENC) ni dans l'encours non engage (EWTNEC) de
   l'arrete. L'operation entiere sort du perimetre des qu'UN de ses prets
   est cautionne ou engage : une operation n'est jamais coupee en deux.

2. ON REUTILISE LE CHEMIN "NON ENGAGE" DEJA EN PRODUCTION

   Le mapping d'entree du stock (PITOPE_COT_REF_PRT_INT) a deux branches :
   prets mis en paiement (FL_PER = 1) et prets non engages (FL_PER = 0).
   La table de perimetre alimente la meme structure au format FL_PER = 0.
   Tout ce qui suit (operations, postes de cout, apports, charges, prets,
   intervenants, score, cotation) est le code de production, inchange.
   "La logique de l'appel au score et a la cotation est la meme, ce n'est
   que les structures de donnees de travail qui changent" (carte).

3. DES STRUCTURES DE TRAVAIL DEDIEES

   Chaque table de travail XXX a une jumelle XXX_REC_NON_CAUT, creee par
   copie exacte de sa structure (script 04). Le traitement du stock et
   celui-ci peuvent tourner le meme soir sans s'ecraser.

4. K EN COTATION, LA VRAIE CHR EN CIBLE

   Le moteur de cotation recoit FL_OP_MEP force a 1 (evolution CCS du
   03/09/2026, reprise telle quelle) : il calcule donc une vraie CHR. La
   mise a jour finale range cette CHR dans CD_CHR_PD_CIBLE et remet
   CD_CHR_PD a 'K' puisque l'operation n'est pas mise en paiement.

5. LES DATES DE CHR NE BOUGENT PAS SI LA CHR NE BOUGE PAS

   Le fils 1 relit, pour chaque operation, la derniere cotation historisee
   sur un arrete ANTERIEUR (etape 23). Meme CHR cible qu'au mois precedent
   -> DT_REF_CHR_PD precedente conservee ; sinon -> arrete calcule.
   Le recalcul d'un arrete deja historise ne relit jamais sa propre version.

6. UNE BOUCLE D'ARRETES EN ANNULE ET REMPLACE

   Le package pere liste les arretes a calculer depuis la ligne PWTTRE du
   fils 1 (DA_DEB_DEL_TRT = dernier arrete calcule), et s'arrete au premier
   mois dont les encours ne sont pas charges. Pour recalculer, on recule
   DA_DEB_DEL_TRT ; chaque arrete est recalcule et remplace. Un incident
   arrete la boucle sans faire avancer PWTTRE : la relance reprend au bon
   mois, sans manipulation.

   Convention de date (celle de toute la cotation prudentielle) :
       date des donnees 2026-08-01  ->  arrete 2026-07-31  ->  CD_DAT_ARR_AAM 202607


ORDRE DE DEPLOIEMENT
--------------------------------------------------------------------------------

  Etape  Ou                 Quoi
  -----  -----------------  ----------------------------------------------------
   1     DWH                1_SQL/01  table finale PITOPE_COT_REC_NON_CAUT
   2     DTM_INEO           1_SQL/02  historique PDTOPE_COT_REC_NON_CAUT
   3     DWH                1_SQL/03  perimetre + reprise des dates de CHR
   4     DWH                1_SQL/04  19 tables de travail (copie de structure)
   5     DWH                1_SQL/05  lignes PWTTRE des deux fils
                                      (verifier le parametre @DA_DEB_DEL_TRT_INIT)
   6     ODI Studio         reverse des nouvelles tables dans les modeles
                            MSSQL_DWH et MSSQL_DTM1
   7     ODI Studio         scenario fils 1 (voir ci-dessous)
   8     ODI Studio         package pere (voir ci-dessous)
   9     ODI                generation des scenarios V0_1, execution en
                            recette sur 1 arrete (forcer DA_FIN_DEL_FOR)
  10     DWH                1_SQL/06  requetes de recette

Tous les scripts SQL sont rejouables : ils ne creent que ce qui manque et
ne modifient jamais un objet existant.


CONSTRUCTION ODI PAS A PAS
--------------------------------------------------------------------------------

Scenario fils 1 - IOM_MNI_COTATION_PROD_RECUE_CHGODS (package + scenario V0_1)
  1. Dupliquer le package IOM_MNI_COTATION_PRUD_MENS_CHGODS, le renommer.
  2. Supprimer les etapes listees "NON REPRISES" dans
     00_ENCHAINEMENT_SCENARIO_FILS_1.txt.
  3. Pour chaque mapping DUPLIQUEE : dupliquer le mapping, le renommer
     (nom indique dans le fichier), remplacer chaque datastore de travail
     par sa jumelle _REC_NON_CAUT. Comparer le code genere au fichier.
  4. Pour chaque mapping ADAPTEE : meme chose, puis appliquer la
     modification decrite dans le cartouche (branche retiree, source
     remplacee...). Le SQL du fichier est le code cible.
  5. Creer les objets NOUVELLE : procedures 02 et 27 (une tache par bloc
     "TACHE n"), mapping 23.
  6. Chainer les etapes dans l'ordre 00 -> 28 (OK -> suivante, KO -> fin).
  7. Generer le scenario V0_1.

  Alternative acceptable pour aller plus vite : les fichiers etant le code
  exact, chaque etape peut aussi etre creee comme tache de procedure ODI
  (technologie Microsoft SQL Server, schema logique MSSQL_DWH ; ajouter
  un TRUNCATE devant chaque INSERT). Le resultat est identique ; les
  mappings restent preferables pour le lignage et la maintenance.

Package pere - IOM_MNI_COTATION_PROD_RECUE (scenario V0_1)
  1. Dupliquer IOM_MNI_COTATION_PRUD V0_5 ou partir d'un package vide.
  2. Creer les 3 variables (02_VARIABLES_PACKAGE_PERE.sql) et les
     3 procedures (01, 03, 04).
  3. Monter les etapes P00 a P11 selon 00_ENCHAINEMENT_PACKAGE_PERE.txt.
  4. Etape P09 (fils 2) : a ajouter quand la carte d'insertion sera livree ;
     d'ici la, relier l'OK de P08 a P10.


ANOMALIES CORRIGEES DANS LES SOURCES FOURNIES
--------------------------------------------------------------------------------

Scripts de tables
  A1  SCRIPT_PITOPE_COT_REC_NON_CAUT.sql : contrainte nommee PK_PITOPE_COT,
      nom deja pris par PITOPE_COT dans DWH -> le CREATE TABLE echoue.
      Renommee PK_PITOPE_COT_REC_NON_CAUT.
  A2  SCRIPT_PDTOPE_COT_REC_NON_CAUT.sql : PK (CD_OP, NO_SEQ) sur une table
      historisee par arrete -> violation de cle des le 2e mois pour toute
      operation encore non cautionnee. PK portee a
      (CD_DAT_ARR_AAM, CD_OP, NO_SEQ), CD_DAT_ARR_AAM passe NOT NULL.
  A3  SCRIPT_PDTOPE_COT_REC_NON_CAUT.sql : CD_TRAIT encore present (NOT NULL)
      alors que la carte le declare inutile. Supprime.

Code perimetre (Perimetre_PROD_RECU_NON_CAUTIONNEE.sql)
  A4  Ne s'execute pas : parenthese orpheline, cible "table de perimetre"
      non renseignee, alias PRT.* inexistant.
  A5  Noms incoherents : TRUNCATE de PITMAX_SEQ_HORS_ENC_NEC, INSERT dans
      PITMAX_SEQ_HORS_ENC ; PITMAX_SEQ_PWTPRT jamais videe (cumul mensuel).
  A6  Dates comparees en texte au format jj/mm/aaaa (CONVERT style 103) :
      '01/08/2026' < '31/07/2026' en ordre alphabetique -> versions de pret
      mal retenues. Remplace par une comparaison de dates typees.
  A7  Trois variables differentes pour la meme date, issues d'autres
      chaines et non rafraichies ici. Tout derive de V040_DatDonATraiter.
  A8  Bases et schemas en dur (DWH.dbo, DWH_ENCOURS.dbo, DWH.ods) :
      remplaces par odiRef.getObjectName (le code suit les contextes).


ECARTS ASSUMES PAR RAPPORT A LA CARTE
--------------------------------------------------------------------------------

  E1  Colonnes annotees "pas necessaire" dans PITOPE_COT_REC_NON_CAUT :
      conservees. Elles composent le buffer positionnel du moteur de
      cotation (CD_TRAIT en tete). Les retirer imposerait de reecrire le
      buffer. Elles restent a NULL, converties en valeurs neutres.
  E2  Mapping PITOPE_COT_PB_M_FIN : en plus des LEFT JOIN CTX/DEFAUT
      demandes, sa table pivot PITOPE_COT_PER_M disparait (son mapping est
      dans la liste "defaut inutile"). Remplacee par PER0_M avec les
      valeurs que PER_M produit pour une operation sans defaut, non mise en
      paiement (detail dans le fichier 22).
  E3  PITOPE_COT_PB_COMP (liste "a ne pas utiliser") est requis par le
      moteur (jointure interne). Remplace par PITOPE_COT_COMP_REC_NON_CAUT,
      alimentee depuis l'historique du perimetre (etape 23). C'est ce qui
      met en oeuvre la regle "dates de CHR inchangees si CHR inchangee".
  E4  "Table de periode de reprise (un truc du genre)" : la table maison
      PITCOT_PERIODE_REPRISE est reutilisee, cloisonnee par
      LB_NOM_SCN_SUN = 'IOM_MNI_COTATION_PROD_RECUE'. Pas de nouvelle table.
  E5  Tables intermediaires du perimetre placees dans DWH.dbo (MSSQL_DWH)
      et non MSSQL_STAGING : un seul schema logique pour toute la chaine.
  E6  Etape 27 ajoutee : controle bloquant des regles metier avant T004.


POINTS OUVERTS A VALIDER
--------------------------------------------------------------------------------

  1. EXCLUSION ANN / REF  (Cyril COSTES)
     Le code perimetre du 16/10 desactive le filtre CD_STATUT NOT IN
     ('ANN','REF') ("il n'y a plus d'exclusion"), mais un critere
     d'acceptation dit "les operations annulees/refusees sont absentes".
     La livraison suit le code du 16/10. Section C de la recette pour
     mesurer l'impact ; reactiver = decommenter une ligne (etape 02).

  2. SCENARIO FILS 2  (carte a venir)
     Insertion de PITOPE_COT_REC_NON_CAUT dans PDTOPE_COT_REC_NON_CAUT en
     annule et remplace de l'arrete. Plusieurs colonnes de PDTOPE (AGE_OP,
     ANC_BANC_EMP*, MT_CHARGE_CSM_PFI...) sont alimentees dans le stock par
     IMM_MNI_COTATION_PRUD_MENS_CHGDTM, non fourni : leur regle de calcul
     est a decrire dans cette carte. Tant que le fils 2 n'existe pas,
     l'historique est vide et toutes les dates de reference de CHR valent
     l'arrete calcule.

  3. DATES DE CHR A LA PREMIERE COTATION
     Sur le chemin repris (FIN -> MOT -> MOT_RES -> PITOPE_COT.Upd), une
     operation non mise en paiement dont la CHR moteur est A..H avec une
     LGD 01, 02, 03 ou 08 recoit DT_VAL_CHR = DT_MEP_OP, donc NULL, et
     DT_REF_CHR_LGD idem a sa premiere cotation (DT_REF_CHR_PD, elle, vaut
     l'arrete calcule). CD_CHR_PD_CIBLE, seule exigee non nulle par la carte, est
     bien renseignee. Si ces dates sont attendues, deux options :
       a) DT_VAL_CHR / DT_REF_CHR_LGD = date rendue par le moteur (comme la
          branche "non engage" PITOPE_COT_PER_M_COT_SCR.Upd V0_2) ;
       b) DT_VAL_CHR / DT_REF_CHR_LGD = arrete calcule.
     Section E de la recette pour mesurer.

  4. DATE DU JOUR DANS LES ENTREES MOTEUR
     Comme dans le stock, plusieurs valeurs par defaut utilisent GETDATE()
     (date de MEP absente, date de premier reglement 19000101). Une reprise
     d'arretes anciens n'est donc pas strictement reproductible d'un jour
     a l'autre. Comportement conserve pour rester aligne sur le stock.

  5. PROFONDEUR DE REPRISE INITIALE
     Script 05 : premier arrete calcule = juillet 2026 (mise en place de
     l'API score). A confirmer avec la DRM.


RECETTE
--------------------------------------------------------------------------------

Jouer 1_SQL/06 en fixant @CD_DAT_ARR_AAM. Une section par critere :

  B  insertion du perimetre / tout le perimetre est cote   -> 0 non cotee
  C  terminees / annulees / refusees absentes              -> voir point 1
  D  cautionnees / engagees absentes                       -> 0 / 0
  E  repartition des classes homogenes (livrable DRM)      -> information
  F  dates de CHR stables si CHR stable                    -> 0 (apres fils 2)
  G  toute operation cotee au moins une fois               -> 0 (apres fils 2)

L'etape 27 du fils 1 applique deja B, D et "CHR_PD = K" a chaque arrete
et bloque le traitement en cas d'ecart (message avec 20 exemples de CD_OP).


RETOUR ARRIERE
--------------------------------------------------------------------------------

1_SQL/99 supprime tous les objets crees (tables _REC_NON_CAUT, lignes
PWTTRE et PITCOT_PERIODE_REPRISE des nouveaux scenarios). La suppression de
l'historique DTM_INEO est commentee : a decommenter volontairement.
Cote ODI : supprimer les scenarios V0_1, le package pere, le package fils
et les objets crees. Aucun objet du stock n'est modifie par cette livraison.


BONNES PRATIQUES POUR LA SUITE
--------------------------------------------------------------------------------

  - Ne jamais ecrire dans les tables de travail du stock depuis ce
    traitement (et inversement) : toute nouvelle etape cree sa jumelle
    _REC_NON_CAUT via le script 04 (ajouter une ligne a la liste).
  - Toute evolution d'un mapping du stock (ex. IOM.MNI.PITOPE_COT.Upd V0_4)
    doit etre reportee ici : les mappings DUPLIQUEE sont volontairement
    identiques, l'ecart se repere en comparant le code genere au fichier.
  - Garder le controle de l'etape 27 bloquant : un arrete faux mais "OK"
    se propage dans l'historique et fausse les dates de CHR des mois
    suivants (regle 5).
  - Recalcul d'arretes : toujours par la boucle du pere (reculer
    DA_DEB_DEL_TRT), jamais en lancant le fils seul sur un mois isole
    sans le fils 2 juste apres.
  - Versionner : V0_1 pour cette livraison ; toute correction donne une
    V0_2 du scenario concerne et une mise a jour de ce README.
  - Scripts SQL : rejouables, nommes NN_BASE_ACTION_OBJET, une base par
    script, controle de structure en commentaire en fin de fichier.
