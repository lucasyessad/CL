================================================================================
DT-1647  -  [RISQUE] COTATION PRODUCTION RECUE NON CAUTIONNEE
Livraison V0_1 - 16/10/2026 - Lounis YESSAD
================================================================================


OBJET
--------------------------------------------------------------------------------

Coter chaque mois les operations recues, non cautionnees et non reglees
(cotation prudentielle K et CHR PD CIBLE calculee par le moteur), comme
c'est deja fait pour le stock cautionne depuis la version 0_3 de
IOM_MNI_COTATION_PRUD_MENS_CHGODS.

Sortie du fils 1 : DWH.dbo.PITOPE_COT_REC_NON_CAUT (dernier arrete calcule).
Historique      : DTM_INEO.dbo.PDTOPE_COT_REC_NON_CAUT, alimente par le
                  fils 2 (autre carte).


CONTENU
--------------------------------------------------------------------------------

  1_SQL/
    01_DWH_CREATE_TABLE_PITOPE_COT_REC_NON_CAUT.sql
    02_DTM_INEO_CREATE_TABLE_PDTOPE_COT_REC_NON_CAUT.sql
    03_DWH_CREATE_TABLES_PERIMETRE_ET_HISTO_CHR_REC_NON_CAUT.sql
    04_DWH_CLONE_TABLES_TRAVAIL_REC_NON_CAUT.sql
    05_DWH_INIT_PWTTRE_REC_NON_CAUT.sql
    99_ROLLBACK_REC_NON_CAUT.sql
  2_ODI/
    A_PACKAGE_PERE_IOM_MNI_COTATION_PROD_RECUE/      enchainement + 4 fichiers
    B_SCENARIO_FILS_1_IOM_MNI_COTATION_PROD_RECUE_CHGODS/  enchainement + 1 fichier par etape
  3_DOC/DT-1647_Schema_Traitements.mermaid

Chaque fichier ODI commence par un cartouche : objet a creer, objet
d'origine, schema logique, KM, ce qui change et pourquoi. Les fichiers
"DUPLIQUEE" sont generes depuis le code reel du scenario de production
(export XML) : instructions exactes du KM, tables de travail renommees.


PRINCIPES
--------------------------------------------------------------------------------

1. Perimetre : prets dont la derniere version a fin de mois est a l'etape
   CLA, EAU, EDI, PEC ou SIG, d'une operation dont aucun pret n'est dans
   EWTENC ni dans EWTNEC de l'arrete.

2. La table de perimetre alimente PITOPE_COT_REF_PRT_INT au format "non
   engage" (FL_PER = 0). Toute la suite est le code de production : seules
   les structures de travail changent (jumelles _REC_NON_CAUT).

3. Le moteur recoit FL_OP_MEP force a 1 (evolution CCS du 03/09/2026) :
   CD_CHR_PD = 'K', CD_CHR_PD_CIBLE = CHR rendue par le moteur.

4. Dates de CHR : l'etape 23 relit la derniere cotation historisee sur un
   arrete anterieur ; meme CHR cible -> DT_REF_CHR_PD conservee.

5. Boucle mensuelle en annule et remplace pilotee par la ligne PWTTRE du
   pere (T003 / T004). Recalcul : reculer DA_DEB_DEL_TRT de la ligne
   IOM_MNI_COTATION_PROD_RECUE.
       date des donnees 2026-08-01 -> arrete 2026-07-31 -> CD_DAT_ARR_AAM 202607

6. Ordonnancement (exploitation) : pere lance en mensuel, apres les
   chargements EWTENC et EWTNEC.


OBJETS EXISTANTS REUTILISES / OBJETS MUTUALISABLES
--------------------------------------------------------------------------------

Reutilises tels quels
  IOR.T003.ref_inittracechgt.V0_1      pere et fils 1
  IOR.T004.ref_OKfintracechgt.V0_1     pere et fils 1
  INEO.V040_DatDonATraiter_V0_1        fils 1
  INEO.V_IOM_COT_N                     compteur de boucle du pere
  dbo.PITCOT_PERIODE_REPRISE           table de periode de reprise

Nouveaux, dynamiques (cle = nom de session), reutilisables par tout package
pere mensuel du meme genre sans modification
  IOM_COT_RECUP_ARRETES_REPRISE_DYN
  IOM_COT_MAJ_PWTTRE_FILS_DYN          option LB_SCN_FILS = liste des fils
  IOM_COT_MAJ_PERIODE_REPRISE_DYN
  INEO.V_IOM_COT_NB_ARR_DYN
  INEO.V_IOM_COT_DatDon_DYN

Les objets du pere d'origine (IOM_COT_RECUP_DATES_REPRISE_V2,
IOM_COT_MAJ_PWTTRE_V2, V_IOM_COT_NBJ...) ne sont pas reutilisables : ils
sont codes en dur sur IOM_MNI_COTATION_PRUD_CHGODS.


ORDRE DE DEPLOIEMENT
--------------------------------------------------------------------------------

   1  DWH        1_SQL/01
   2  DTM_INEO   1_SQL/02
   3  DWH        1_SQL/03, 1_SQL/04, 1_SQL/05
   4  ODI        reverse des nouvelles tables (modeles MSSQL_DWH, MSSQL_DTM1)
   5  ODI        scenario fils 1, puis package pere (voir ci-dessous)
   6  ODI        generation des scenarios V0_1


CONSTRUCTION ODI
--------------------------------------------------------------------------------

Fils 1 - IOM_MNI_COTATION_PROD_RECUE_CHGODS
  1. Dupliquer le package IOM_MNI_COTATION_PRUD_MENS_CHGODS.
  2. Supprimer les etapes "NON REPRISES" (00_ENCHAINEMENT_SCENARIO_FILS_1.txt).
  3. DUPLIQUEE : dupliquer le mapping, le renommer, remplacer chaque
     datastore de travail par sa jumelle _REC_NON_CAUT.
  4. ADAPTEE : idem, puis appliquer la modification du cartouche.
  5. NOUVELLE : procedure 02 (une tache par bloc TACHE n), mapping 23.
  6. Chainer 00 -> 27.

Pere - IOM_MNI_COTATION_PROD_RECUE
  1. Creer les 3 procedures et les 2 variables _DYN (si elles n'existent pas
     deja), ajouter l'option LB_SCN_FILS a IOM_COT_MAJ_PWTTRE_FILS_DYN.
  2. Monter P00 a P11 selon 00_ENCHAINEMENT_PACKAGE_PERE.txt.
  3. P08 (fils 2) : a ajouter avec la carte d'insertion ; d'ici la,
     OK de P07 -> P09.


CORRECTIONS DES SOURCES FOURNIES
--------------------------------------------------------------------------------

  - PITOPE_COT_REC_NON_CAUT : PK nommee PK_PITOPE_COT, deja prise par
    PITOPE_COT -> renommee PK_PITOPE_COT_REC_NON_CAUT.
  - PDTOPE_COT_REC_NON_CAUT : PK (CD_OP, NO_SEQ) sur une table historisee
    par arrete -> (CD_DAT_ARR_AAM, CD_OP, NO_SEQ) ; CD_TRAIT supprime.
  - Code perimetre : syntaxe (parenthese, cible, alias), noms de tables
    incoherents, table PITMAX non videe, dates comparees en texte jj/mm/aaaa,
    variables d'autres chaines, noms de bases en dur.


ECARTS PAR RAPPORT A LA CARTE
--------------------------------------------------------------------------------

  - Colonnes "pas necessaire" de PITOPE_COT_REC_NON_CAUT conservees : elles
    composent le buffer du moteur de cotation (CD_TRAIT en tete).
  - PB_M_FIN : sa table pivot PITOPE_COT_PER_M (mapping de la liste
    "defaut inutile") est remplacee par PER0_M (detail dans le fichier 22).
  - PITOPE_COT_PB_COMP (liste "a ne pas utiliser") est requis par le moteur :
    remplace par PITOPE_COT_COMP_REC_NON_CAUT alimentee depuis l'historique
    du perimetre (etape 23).
  - Tables du perimetre dans DWH.dbo (MSSQL_DWH) et non MSSQL_STAGING.


POINTS OUVERTS
--------------------------------------------------------------------------------

  1. Exclusion ANN / REF desactivee par CCS le 16/10 alors qu'un critere
     d'acceptation la demande. Livraison alignee sur le code du 16/10 ;
     une ligne a decommenter dans l'etape 02.
  2. Fils 2 (autre carte) : regles des colonnes de PDTOPE alimentees dans
     le stock par IMM_MNI_COTATION_PRUD_MENS_CHGDTM (non fourni).
  3. Premiere cotation, CHR A..H avec LGD 01/02/03/08 : DT_VAL_CHR et
     DT_REF_CHR_LGD = DT_MEP_OP, donc NULL (code d'origine repris).
     CD_CHR_PD_CIBLE est renseignee.
  4. Profondeur de reprise initiale : juillet 2026 (script 05).


BONNES PRATIQUES
--------------------------------------------------------------------------------

  - Ne jamais partager une table de travail avec le stock : toute nouvelle
    etape a sa jumelle _REC_NON_CAUT (ajouter une ligne au script 04).
  - Toute evolution d'un mapping du stock est a reporter ici : les mappings
    DUPLIQUEE restent identiques a l'original.
  - Recalcul uniquement par la boucle du pere, fils 2 dans la boucle.
  - Objets _DYN : ne rien coder en dur, tout passe par le nom de session ou
    une option de procedure, pour rester mutualisables.
  - Versionner : toute correction donne une V0_2 du scenario concerne.
