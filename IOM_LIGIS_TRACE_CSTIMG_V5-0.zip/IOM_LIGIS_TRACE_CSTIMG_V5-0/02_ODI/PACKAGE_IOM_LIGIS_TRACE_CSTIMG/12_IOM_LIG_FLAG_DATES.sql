/* ============================================================================
   [E] PROCEDURE ODI : IOM_LIG_FLAG_DATES
   Atteinte uniquement si IOM_LIG_CTRL_JOURNEE est OK. Ne touche que PITCOT :
   l'avancement de PWTTRE est assure par la procedure maison T004 en fin
   de package.. "<=" et non "=" :
   absorbe automatiquement les journees intermediaires d'une periode
   MULTI_JOURS (sans borne, jamais eligibles, mais dont les traces sont
   dans la fenetre elargie). Puis lien OK -> retour rafraichissement de
   V_IOM_LIG_DT_TRACES.
   ============================================================================ */
UPDATE <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND DT_CAL <= '#V_IOM_LIG_DT_TRACES'
  AND TRAITE = 0
