/* ============================================================================
   [D1] PROCEDURE ODI : IOM_LIG_FLAG_OIT
   Flague l'image de fin de journee (FL_FIN_JOURNEE = 1) dans les tables
   ods.OIT_xxx actives du parametrage, pour la journee #V_IOM_LIG_DT_TRACES.

   IDEMPOTENT : remise a 0 du flag sur toute la fenetre avant re-flag.
   Rejouable autant de fois que voulu, seul ou depuis le debut du package.

   ERREURS : une table en erreur est tracee en KO dans ORT_AUDIT_CHARGEMENT
   et n'est PAS traitee par les etapes suivantes (07/08) de la meme session ;
   l'etape ne leve pas d'erreur ici, c'est [D4] IOM_LIG_CTRL_JOURNEE qui
   conclut la journee. Seule une journee non bornee arrete immediatement.

   Schemas : recuperes par substitution ODI (getCatalogName / getSchemaName).
   Noms de tables : physiques, volontairement non variabilises.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';

/* Prefixes de schemas pour le SQL dynamique (substitution ODI) */
DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(500);

/* Fenetre de la journee : ] borne(J-1) ; borne(J) ] -------------------------- */
SELECT @dt_fin = DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR = @DT_TRACES;

SELECT @dt_deb = MAX(DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR < @DT_TRACES;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
             + N' (borne de la journee et/ou borne anterieure absente dans ORT_BORNE_JOURNEE).';
    THROW 50011, @msg, 1;
END

/* Boucle sur les tables actives du parametrage ------------------------------- */
DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200), @src NVARCHAR(400),
        @cle_ods NVARCHAR(MAX), @ordre NVARCHAR(MAX), @col_fen NVARCHAR(128),
        @filtre NVARCHAR(1000), @sql NVARCHAR(MAX),
        @nb INT, @dt_step DATETIME;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT LB_TABLE_ODS, MIN(LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
    WHERE FL_CLEF = 1 AND FL_CHARGEMENT = 1
    GROUP BY LB_TABLE_ODS
    ORDER BY LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);

        SELECT @cle_ods = NULL, @ordre = NULL, @col_fen = NULL, @filtre = NULL;

        SELECT @cle_ods = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1 AND LB_CHAMP_ODS IS NOT NULL;

        SELECT @ordre = STRING_AGG(QUOTENAME(LB_CHAMP_ODS) + N' DESC', N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL;

        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        SELECT @filtre = MAX(LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1;

        IF @cle_ods IS NULL OR @col_fen IS NULL
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods
                     + N' (cle FL_CLEF = 1 et/ou colonne FL_ORDRE_TRI = 1 manquante).';
            THROW 50032, @msg, 1;
        END

        SET @filtre = ISNULL(@filtre, N'');

        /* 1. Remise a zero du flag sur la fenetre (idempotence) */
        SET @sql = N'UPDATE ' + @src + N' SET FL_FIN_JOURNEE = 0' +
                   N' WHERE ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                   CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3)',
             @p_deb = @dt_deb, @p_fin = @dt_fin;

        /* 2. Flag de la derniere trace de la fenetre par cle fonctionnelle */
        SET @sql = N';WITH cte AS (' +
                   N'  SELECT FL_FIN_JOURNEE, ROW_NUMBER() OVER (PARTITION BY ' + @cle_ods +
                   N'    ORDER BY ' + @ordre + N') AS rn_ort' +
                   N'  FROM ' + @src +
                   N'  WHERE ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                   CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END +
                   N') UPDATE cte SET FL_FIN_JOURNEE = 1 WHERE rn_ort = 1;' +
                   N' SELECT @p_nb = @@ROWCOUNT;';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb OUTPUT;

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'FLAG OIT [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                @tbl_ods, @tbl_ods, @nb, N'OK',
                CASE WHEN @nb = 0
                     THEN N'AVERTISSEMENT: aucune trace sur la fenetre (BCPIN non charge ou journee sans mouvement) - cible non modifiee.'
                     ELSE NULL END,
                @dt_step, GETDATE());
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'FLAG OIT [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                @tbl_ods, @tbl_ods, 0, N'KO', ERROR_MESSAGE(), @dt_step, GETDATE());
        /* on continue avec la table suivante : bilan en [D4] */
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
