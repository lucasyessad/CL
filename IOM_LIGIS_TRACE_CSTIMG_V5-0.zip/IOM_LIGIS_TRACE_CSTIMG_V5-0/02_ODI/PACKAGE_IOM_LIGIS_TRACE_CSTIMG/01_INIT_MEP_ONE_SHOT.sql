/* ============================================================================
   INITIALISATION ONE-SHOT (mise en production) - a executer UNE fois,
   apres creation des tables (01_TABLES) et avant le premier lancement.
   Script MANUEL (SSMS) : les noms sont ecrits en clair, sans substitution.
   Completer les valeurs <...>.
   ============================================================================ */

-- 1. Ligne PWTTRE du scenario. LB_NOM_SCN_SUN doit valoir EXACTEMENT le
--    SESS_NAME du package, c'est-a-dire le nom du scenario genere :
--    'IOM_LIGIS_TRACE_CSTIMG'. C'est la cle utilisee par T003, T004 et par
--    nos etapes 03 / 05 / 12.
--    DA_DEB_DEL_TRT = veille ouvree du premier jour a traiter : les
--    journees generees sont STRICTEMENT superieures a cette date.
--    DA_DON_A_TRT et DA_FIN_DEL_FOR restent NULL : T003 et l'etape 03 les
--    positionnent a chaque execution.
--    Completer les autres colonnes selon la structure reelle de PWTTRE
--    (NO_SEQ, DA_DER_TRT, ID_DET_TRT_ALI... - s'aligner sur une ligne
--    existante, par exemple celle de IOM_MNI_COTATION_PRUD_CHGODS).
IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE
               WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
    INSERT INTO dbo.PWTTRE (LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_DON_A_TRT,
                            DA_FIN_DEL_FOR, NO_SEQ)
    VALUES ('IOM_LIGIS_TRACE_CSTIMG', '<AAAA-MM-JJ veille ouvree>', NULL,
            NULL, 1);

-- 2. Borne initiale : debut de la toute premiere fenetre (idealement la
--    derniere datetime extraite lue dans l'audit CDC a l'activation).
--    DT_JOUR doit etre COHERENT avec DA_DEB_DEL_TRT ci-dessus : meme jour.
INSERT INTO dbo.ORT_BORNE_JOURNEE
    (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
VALUES
    ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss.mmm>', 'INIT', 'MANUEL',
     'Borne initiale - demarrage historisation traces LIGIS');

-- 3. Suppression de la table de suivi devenue inutile (si une version
--    anterieure du livrable a ete deployee) : son contenu est desormais
--    porte par ORT_AUDIT_CHARGEMENT.
-- DROP TABLE dbo.ORT_SUIVI_JOUR_TABLE;

-- 4. VERIFICATION : PWTCHE ne doit contenir aucune ligne pour ce scenario
--    (notre traitement n'est pas alimente par fichier). Si c'est le cas,
--    la 3e tache de T003 inserera 0 ligne dans PWTSPF : comportement
--    attendu.
SELECT * FROM dbo.PWTCHE WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG';
