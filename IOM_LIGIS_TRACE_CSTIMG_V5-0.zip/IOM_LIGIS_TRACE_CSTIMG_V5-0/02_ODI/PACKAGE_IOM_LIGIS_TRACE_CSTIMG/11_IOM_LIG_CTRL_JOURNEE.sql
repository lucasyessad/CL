/* ============================================================================
   [D4] PROCEDURE ODI : IOM_LIG_CTRL_JOURNEE
   Conclut la journee #V_IOM_LIG_DT_TRACES :
      1. CONTROLE anti-doublon par table : une seule version courante
         (FL_VER_CRT = 1) par cle fonctionnelle dans dbo.OWT_xxx ;
      2. BILAN de la journee dans ORT_AUDIT_CHARGEMENT ;
      3. REMONTEE D'ERREUR : s'il existe au moins une ligne KO pour cette
         journee dans cette session, THROW -> l'etape ODI passe KO ->
         la date reste TRAITE = 0 dans PITCOT -> a la relance, le package
         reprend cette journee depuis [D1] et tout est recalcule.

   Etape en LECTURE SEULE sur les donnees (hors ecriture d'audit) : la
   rejouer ne modifie jamais les tables OIT / OWT.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';

DECLARE @PFX_DWH NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23),
        @msg NVARCHAR(500), @dt_deb_bilan DATETIME = GETDATE();

DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200), @tgt NVARCHAR(400),
        @cle_dwh NVARCHAR(MAX), @sql NVARCHAR(MAX), @nb_doublons INT,
        @dt_step DATETIME;

/* 1. Controle anti-doublon (tables non KO de cette session) ------------------ */
DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT P.LB_TABLE_ODS, MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
    WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
      AND NOT EXISTS (
            SELECT 1
            FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> A
            WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
              AND A.LB_PROJET = @LB_PROJET
              AND A.CD_STATUT = 'KO'
              AND A.LB_SOURCE = P.LB_TABLE_ODS
              AND CHARINDEX('[' + @jour + ']', A.LB_CHARGEMENT) > 0)
    GROUP BY P.LB_TABLE_ODS
    ORDER BY P.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb_doublons = 0;

    BEGIN TRY
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        SELECT @cle_dwh = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N',') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1 AND LB_CHAMP_DWH IS NOT NULL;

        SET @sql = N'SELECT @p_nb = COUNT(*) FROM (' +
                   N'  SELECT ' + @cle_dwh +
                   N'  FROM ' + @tgt +
                   N'  WHERE FL_VER_CRT = 1' +
                   N'  GROUP BY ' + @cle_dwh +
                   N'  HAVING COUNT(*) > 1) d;';
        EXEC sp_executesql @sql, N'@p_nb int OUTPUT', @p_nb = @nb_doublons OUTPUT;

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'CTRL DOUBLON [' + @jour + N']',
                @tbl_ods, @tbl_dwh, @nb_doublons,
                CASE WHEN @nb_doublons > 0 THEN N'KO' ELSE N'OK' END,
                CASE WHEN @nb_doublons > 0
                     THEN N'Cles fonctionnelles avec plusieurs versions courantes (FL_VER_CRT = 1).'
                     ELSE NULL END,
                @dt_step, GETDATE());
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'CTRL DOUBLON [' + @jour + N']',
                @tbl_ods, @tbl_dwh, 0, N'KO', ERROR_MESSAGE(), @dt_step, GETDATE());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;

/* 2. Bilan de la journee ----------------------------------------------------- */
DECLARE @nb_ok INT, @nb_ko INT, @nb_tbl_ko INT;

SELECT @nb_ok = SUM(CASE WHEN CD_STATUT = 'OK' THEN 1 ELSE 0 END),
       @nb_ko = SUM(CASE WHEN CD_STATUT = 'KO' THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
WHERE ISNULL(ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
  AND LB_PROJET = @LB_PROJET
  AND CHARINDEX('[' + @jour + ']', LB_CHARGEMENT) > 0
  AND LB_SOURCE <> '*TOUTES*';

SELECT @nb_tbl_ko = COUNT(DISTINCT LB_SOURCE)
FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
WHERE ISNULL(ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
  AND LB_PROJET = @LB_PROJET
  AND CD_STATUT = 'KO'
  AND CHARINDEX('[' + @jour + ']', LB_CHARGEMENT) > 0
  AND LB_SOURCE <> '*TOUTES*';

SET @nb_ok = ISNULL(@nb_ok, 0);
SET @nb_ko = ISNULL(@nb_ko, 0);
SET @nb_tbl_ko = ISNULL(@nb_tbl_ko, 0);

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'BILAN JOURNEE [' + @jour + N']',
        N'*TOUTES*', NULL, @nb_ok,
        CASE WHEN @nb_ko > 0 THEN N'KO' ELSE N'OK' END,
        CASE WHEN @nb_ko > 0
             THEN CAST(@nb_tbl_ko AS NVARCHAR(10)) + N' table(s) en KO, '
                  + CAST(@nb_ko AS NVARCHAR(10)) + N' etape(s) en echec.'
             ELSE NULL END,
        @dt_deb_bilan, GETDATE());

/* 3. Remontee d'erreur a ODI ------------------------------------------------- */
IF @nb_ko > 0
BEGIN
    SET @msg = N'IOM_LIG_CTRL_JOURNEE : ' + CAST(@nb_tbl_ko AS NVARCHAR(10))
             + N' table(s) en KO pour la journee ' + @jour
             + N'. Detail dans ORT_AUDIT_CHARGEMENT (LB_PROJET = ''LIGIS'').';
    THROW 50010, @msg, 1;
END
