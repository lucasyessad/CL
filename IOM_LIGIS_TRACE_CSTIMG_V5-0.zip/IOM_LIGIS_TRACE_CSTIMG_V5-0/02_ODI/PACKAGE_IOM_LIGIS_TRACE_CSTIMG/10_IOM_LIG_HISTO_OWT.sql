/* ============================================================================
   [D3] PROCEDURE ODI : IOM_LIG_HISTO_OWT
   Construit l'historique SCD2 dans dbo.OWT_xxx pour la journee
   #V_IOM_LIG_DT_TRACES, a partir des lignes flaguees en [D1] :
      1. FERMETURE des versions courantes des cles concernees
         (DF_VAL = jour, FL_VER_CRT = 0)
      2. INSERTION des nouvelles versions courantes
         (DD_VAL = jour, DF_VAL = 2400-01-01, FL_VER_CRT = 1)
         REGLE SUPPRESSION : une image de fin de journee qui est une
         suppression LIGIS (CD_CMD_TEC = 1) ferme la version courante sans
         en creer de nouvelle - la cle n'a alors plus de version courante.

   GARDE-FOUS : table en KO dans cette session (ignoree), source vide
   (ignoree), et journee DEJA historisee pour cette table - presence de
   lignes DD_VAL = jour dans la cible - (ignoree). Ce dernier point rend
   l'etape rejouable SEULE sans risque de doublon ; relancee depuis le
   debut du package, [D2] purge d'abord et l'historique est reconstruit.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';
DECLARE @DATE_INFINIE DATE        = '2400-01-01';

DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(500),
        @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

SELECT @dt_fin = DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR = @DT_TRACES;

SELECT @dt_deb = MAX(DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR < @DT_TRACES;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + @jour + N' (ORT_BORNE_JOURNEE).';
    THROW 50011, @msg, 1;
END

DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200),
        @src NVARCHAR(400), @tgt NVARCHAR(400),
        @cle_ods NVARCHAR(MAX), @join_cond NVARCHAR(MAX),
        @cols_dwh NVARCHAR(MAX), @vals_ods NVARCHAR(MAX),
        @col_fen NVARCHAR(128), @filtre NVARCHAR(1000),
        @sql NVARCHAR(MAX), @nb_flag INT, @nb_deja INT, @nb_ferm INT, @nb_ins INT,
        @dt_step DATETIME;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT P.LB_TABLE_ODS, MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
    WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
      AND NOT EXISTS (
            SELECT 1
            FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> A
            WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
              AND A.LB_PROJET = @LB_PROJET
              AND A.CD_STATUT = 'KO'
              AND A.LB_SOURCE = P.LB_TABLE_ODS
              AND CHARINDEX('[' + @jour + ']', A.LB_CHARGEMENT) > 0)
    GROUP BY P.LB_TABLE_ODS
    ORDER BY P.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb_flag = 0; SET @nb_deja = 0; SET @nb_ferm = 0; SET @nb_ins = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        SELECT @cle_ods = NULL, @join_cond = NULL, @cols_dwh = NULL,
               @vals_ods = NULL, @col_fen = NULL, @filtre = NULL;

        SELECT @cle_ods   = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
               @join_cond = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS) + N' = T.' + QUOTENAME(LB_CHAMP_DWH), N' AND ')
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT @cols_dwh = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
               @vals_ods = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        SELECT @filtre = MAX(LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1;

        IF @cle_ods IS NULL OR @cols_dwh IS NULL OR @col_fen IS NULL
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods
                     + N' (cle, mapping colonnes ou FL_ORDRE_TRI manquants).';
            THROW 50032, @msg, 1;
        END

        SET @filtre = ISNULL(@filtre, N'');

        /* Garde-fou 1 : source vide sur la fenetre */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src +
                   N' WHERE FL_FIN_JOURNEE = 1' +
                   N'   AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                   CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_flag OUTPUT;

        /* Garde-fou 2 : journee deja historisee pour cette table */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @tgt + N' WHERE DD_VAL = @p_dt;';
        EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
             @p_dt = @DT_TRACES, @p_nb = @nb_deja OUTPUT;

        IF @nb_flag = 0 OR @nb_deja > 0
        BEGIN
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO OWT [' + @jour + N']',
                    @tbl_ods, @tbl_dwh, 0, N'OK',
                    CASE WHEN @nb_flag = 0
                         THEN N'IGNORE: aucune ligne flaguee sur la fenetre - cible non modifiee.'
                         ELSE N'IGNORE: journee deja historisee (' + CAST(@nb_deja AS NVARCHAR(10))
                              + N' version(s) DD_VAL = ' + @jour + N') - relancer depuis [D2] pour recalculer.'
                    END,
                    @dt_step, GETDATE());
        END
        ELSE
        BEGIN
            /* 1. Fermeture des versions courantes concernees */
            SET @sql = N'UPDATE T SET DF_VAL = @p_dt, FL_VER_CRT = 0' +
                       N' FROM ' + @tgt + N' AS T' +
                       N' INNER JOIN (SELECT DISTINCT ' + @cle_ods +
                       N'             FROM ' + @src +
                       N'             WHERE FL_FIN_JOURNEE = 1' +
                       N'               AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                       CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END +
                       N'            ) AS S ON ' + @join_cond +
                       N' WHERE T.FL_VER_CRT = 1;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_dt date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ferm OUTPUT;

            /* 2. Insertion des nouvelles versions courantes */
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh + N', DD_VAL, DF_VAL, FL_VER_CRT)' +
                       N' SELECT ' + @vals_ods + N', @p_dt, @p_infini, 1' +
                       N' FROM ' + @src + N' AS S' +
                       N' WHERE S.FL_FIN_JOURNEE = 1' +
                       N'   AND ISNULL(S.CD_CMD_TEC, 0) <> 1' +
                       N'   AND S.' + QUOTENAME(@col_fen) + N' > @p_deb AND S.' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                       CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE,
                 @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ins OUTPUT;

            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO OWT [' + @jour + N']',
                    @tbl_ods, @tbl_dwh, @nb_ins, N'OK',
                    N'Versions fermees: ' + CAST(@nb_ferm AS NVARCHAR(10))
                    + N' / versions inserees: ' + CAST(@nb_ins AS NVARCHAR(10))
                    + N' (lignes flaguees: ' + CAST(@nb_flag AS NVARCHAR(10)) + N').',
                    @dt_step, GETDATE());
        END
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO OWT [' + @jour + N']',
                @tbl_ods, @tbl_dwh, 0, N'KO', ERROR_MESSAGE(), @dt_step, GETDATE());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
