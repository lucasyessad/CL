/* ============================================================================
   [B] VARIABLE ODI : V_IOM_LIG_DT_TRACES
   Type Alphanumerique, action Rafraichir, schema logique MSSQL_DWH.
   Seules les journees BORNEES sont eligibles : une journee sans borne
   (extraction non close / periode en accumulation) attend. Les journees
   intermediaires d'une periode MULTI_JOURS n'ont pas de borne : la
   variable saute a la derniere journee de la periode, [E] les absorbera.
   Renvoie NULL quand plus rien n'est eligible -> sortie via l'evaluation.
   ============================================================================ */
SELECT CONVERT(varchar(10), MIN(P.DT_CAL), 23)
FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B
              WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))
