/* ============================================================================
   03_CREATE_TABLE_DWH_OIT_HISTO
   A EXECUTER SUR LA BASE D'ARCHIVE (ODS_Traces).

   Ce fichier recoit la SORTIE du generateur HISTO (00_GENER_SCRIPT_LIGIS,
   deuxieme generateur). Coller ici le contenu de la colonne ScriptComplet, qui
   contient les CREATE TABLE de :
       ods.OIT_<table>_HISTO   archive des traces traitees, 13 mois

   Ne rien ecrire a la main.
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR HISTO <<<
