SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_PREPARATION_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT       = NULL,
    @CD_FORMAT  NVARCHAR(10) = N'BCP'
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @sql         NVARCHAR(MAX),
        @msg         NVARCHAR(2000),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @dwh_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @entree      NVARCHAR(10),
        @schema_ods  NVARCHAR(128),
        @table_audit NVARCHAR(128),
        @nb          BIGINT,
        @nb_flux     INT = 0,
        @nb_ko       INT = 0;

    IF @ID_TRT_ALI IS NULL
        SET @ID_TRT_ALI = CONVERT(BIGINT, FORMAT(SYSDATETIME(), N'yyyyMMddHHmmss'));

    /* Init pilotee par la borne : une borne INIT non traitee sur le projet
       signifie qu'une reprise est en cours. Toutes les tables sont alors
       preparees pour un rechargement complet. */
    DECLARE @FL_INIT BIT = 0;
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE LB_PROJET = @LB_PROJET AND TYPE_BORNE = N'INIT' AND FL_TRAITE = 0)
        SET @FL_INIT = 1;

    /* L'audit doit etre charge des lors qu'un flux DELTA est au programme :
       sans lui, aucune plage de LSN n'est connue. */
    IF @FL_INIT = 0
       AND EXISTS
       (
           SELECT 1 FROM dbo.ORT_PARAM_FLUX
           WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1
             AND CD_FORMAT = @CD_FORMAT
             AND CD_MODE_ENTREE = N'DELTA'
       )
    BEGIN
        SELECT TOP (1) @schema_ods = LB_SCHEMA_ODS, @table_audit = LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1 AND CD_MODE_ENTREE = N'DELTA';

        SET @nb = 0;
        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM '
                 + QUOTENAME(@schema_ods) + N'.' + QUOTENAME(@table_audit) + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        IF ISNULL(@nb, 0) = 0
        BEGIN
            SET @msg = N'PS_PREPARATION_ODS : ' + @schema_ods + N'.' + @table_audit
                     + N' est vide. Charger l''audit avant d''appeler cette procedure.';
            THROW 56000, @msg, 1;
        END;
    END;

    /* Un run repris repart d'une trace propre. */
    DELETE FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE ID_TRT_ALI = @ID_TRT_ALI
      AND LB_PROJET  = @LB_PROJET
      AND LB_CHARGEMENT = N'Chargement bcp -> ods';

    DECLARE cur_flux CURSOR LOCAL FAST_FORWARD FOR
        SELECT LB_TABLE_ODS,
               QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
               CASE WHEN LB_TABLE_DWH IS NULL THEN NULL
                    ELSE QUOTENAME(LB_SCHEMA_DWH) + N'.' + QUOTENAME(LB_TABLE_DWH) END,
               LB_SOURCE, CD_MODE_ENTREE, LB_SCHEMA_ODS, LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET
          AND FL_ACTIF  = 1
          AND CD_FORMAT = @CD_FORMAT
        ORDER BY NO_ORDRE, LB_TABLE_ODS;

    OPEN cur_flux;
    FETCH NEXT FROM cur_flux
    INTO @table_ods, @ods_complet, @dwh_complet, @source, @entree, @schema_ods, @table_audit;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @nb = NULL;

        BEGIN TRY
            /* Aucun blocage sur un historique deja alimente : une init peut etre
               relancee a tout moment. Elle se comporte alors comme un FULL et
               date les ecarts de la journee de reprise. */
            IF @FL_INIT = 1 OR @entree = N'FULL'
            BEGIN
                SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
                EXEC sp_executesql @sql;
                SET @nb = 0;
            END
            ELSE
            BEGIN
                SET @sql =
                      N'DELETE T'                                     + CHAR(13)
                    + N'FROM ' + @ods_complet + N' AS T'              + CHAR(13)
                    + N'INNER JOIN ' + QUOTENAME(@schema_ods) + N'.'
                                     + QUOTENAME(@table_audit) + N' AS A' + CHAR(13)
                    + N'        ON A.LB_INSTANCE = @p_source'         + CHAR(13)
                    + N'WHERE T.LB_LSN_COMMIT_TEC >  A.LB_DEB_LSN'    + CHAR(13)
                    + N'  AND T.LB_LSN_COMMIT_TEC <= A.LB_FIN_LSN;';
                EXEC sp_executesql @sql, N'@p_source nvarchar(260)', @p_source = @source;

                SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
                EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;
            END;

            /* La ligne de chargement est creee ici, statut vide. NB_LIGNE porte
               provisoirement la volumetrie AVANT chargement : le controle la
               remplacera par la volumetrie chargee et posera le statut. */
            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement bcp -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 @nb, NULL, NULL, @dt_debut, NULL);

            SET @nb_flux += 1;
        END TRY
        BEGIN CATCH
            SET @nb_ko += 1;
            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement bcp -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 0, N'KO', N'Preparation : ' + ERROR_MESSAGE(), @dt_debut, SYSDATETIME());
        END CATCH;

        FETCH NEXT FROM cur_flux
        INTO @table_ods, @ods_complet, @dwh_complet, @source, @entree, @schema_ods, @table_audit;
    END;

    CLOSE cur_flux;
    DEALLOCATE cur_flux;

    /* Une preparation en echec doit arreter le job : charger par-dessus une
       cible mal preparee produirait des doublons silencieux. */
    IF @nb_ko > 0
    BEGIN
        SET @msg = N'PS_PREPARATION_ODS : ' + CONVERT(NVARCHAR(10), @nb_ko)
                 + N' flux en echec. Detail dans ORT_AUDIT_CHARGEMENT pour'
                 + N' ID_TRT_ALI = ' + CONVERT(NVARCHAR(20), @ID_TRT_ALI) + N'.';
        THROW 56002, @msg, 1;
    END;

    SELECT ID_TRT_ALI = @ID_TRT_ALI, NB_FLUX = @nb_flux;
END;
GO


/* ============================================================================
   PS_CHARGEMENT_FICHIER_ODS

   Charge un fichier delimite dans sa table ODS. Le format vient du
   parametrage : delimiteur, ligne de debut, encodage.

   Le job liste les fichiers et appelle la procedure une fois par fichier :
   c'est lui qui parcourt le repertoire, ce qui evite xp_cmdshell, que
   l'exploitation n'autorise generalement pas.

   BULK INSERT lit le fichier depuis le MOTEUR SQL, pas depuis le poste qui
   lance la commande : le compte de service doit avoir acces au repertoire.
   ============================================================================ */
