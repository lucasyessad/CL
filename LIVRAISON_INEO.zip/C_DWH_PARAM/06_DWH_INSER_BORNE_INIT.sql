/* ============================================================================
   06_DWH_INSER_BORNE_INIT
   A EXECUTER SUR LE DWH, a la main, AVANT un traitement d'init, si l'on veut
   que les lignes creees portent une DATE DE REPRISE choisie plutot que la date
   du jour.

   Comportement de l'init :
     - s'il existe une borne TYPE_BORNE = 'INIT' et FL_TRAITE = 0 pour le
       projet, l'init date DD_VAL avec la plus ancienne de ces bornes, puis la
       passe a FL_TRAITE = 1 ;
     - sinon, l'init date DD_VAL du jour de traitement.

   On peut poser plusieurs bornes INIT dans le temps : chacune est consommee
   une fois. Une borne deja traitee n'est jamais reprise.

   DT_JOUR porte la date de reprise voulue. DT_BORNE est mise a la meme valeur :
   elle n'entre pas dans le calcul pour une borne INIT, seul DT_JOUR compte.
   ============================================================================ */

INSERT INTO dbo.ORT_BORNE_JOURNEE
    (LB_PROJET, DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, FL_TRAITE, DT_POSE, COMMENTAIRE)
VALUES
    (N'LIGIS', '1900-01-01', '1900-01-01', N'INIT', N'MANUEL', 0, SYSDATETIME(),
     N'Date de reprise pour l''initialisation');
GO
