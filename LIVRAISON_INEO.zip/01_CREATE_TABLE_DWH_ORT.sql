/* ============================================================================
   01_CREATE_TABLE_DWH_ORT
   A EXECUTER SUR LE DWH.
   Cree toutes les tables ORT, VIDES. PK et index uniquement.

     Parametrage :  ORT_PARAM_FLUX
                    ORT_PARAM_HISTORISATION_TRACES
     Technique   :  ORT_BORNE_JOURNEE
                    ORT_AUDIT_CHARGEMENT
                    ORT_PERIODE_REPRISE

   L'alimentation vient plus tard : le parametrage colonne est produit par
   00_GENER_SCRIPT et charge en 04. Les tables techniques se remplissent au
   fil du traitement.
   ============================================================================ */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* ----- ORT_PARAM_FLUX ----- */
CREATE TABLE dbo.ORT_PARAM_FLUX
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS    NVARCHAR(128)  NOT NULL,
    LB_TABLE_DWH    NVARCHAR(128)  NULL,
    LB_SOURCE       NVARCHAR(260)  NULL,

    CD_MODE_ENTREE  NVARCHAR(10)   NOT NULL,
    CD_FORMAT       NVARCHAR(10)   NOT NULL,
    CD_MODE_ALIM    NVARCHAR(10)   NOT NULL,

    FL_ACTIF        BIT            NOT NULL,
    FL_INIT         BIT            NOT NULL,
    NO_ORDRE        INT            NOT NULL,
    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    LB_SCHEMA_ODS   NVARCHAR(128)  NOT NULL,
    LB_SCHEMA_DWH   NVARCHAR(128)  NOT NULL,
    LB_TABLE_AUDIT  NVARCHAR(128)  NULL,
    HR_FRONTIERE    TIME(0)        NULL,

    LB_FICHIER      NVARCHAR(260)  NULL,
    LB_REPERTOIRE   NVARCHAR(260)  NULL,
    LB_DELIMITEUR   NVARCHAR(10)   NULL,
    NO_LIGNE_DEBUT  INT            NULL,
    LB_ENCODAGE     NVARCHAR(20)   NULL,

    DT_MAJ          DATETIME2(3)   NULL,
    CD_USR_MAJ      NVARCHAR(20)   NULL,
    LB_COMMENTAIRE  NVARCHAR(500)  NULL,

    CONSTRAINT PK_ORT_PARAM_FLUX PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_FLUX_ACTIFS
    ON dbo.ORT_PARAM_FLUX (LB_PROJET, FL_ACTIF, NO_ORDRE)
    INCLUDE (LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM);
GO

/* ----- ORT_PARAM_HISTORISATION_TRACES ----- */
CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET      NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS   NVARCHAR(128)  NOT NULL,
    NO_CHAMP       INT            NOT NULL,

    LB_SOURCE      NVARCHAR(260)  NULL,
    LB_TABLE_DWH   NVARCHAR(128)  NULL,
    LB_CHAMP_ODS   NVARCHAR(128)  NULL,
    LB_CHAMP_DWH   NVARCHAR(128)  NULL,
    LB_SCD         NVARCHAR(30)   NULL,

    FL_CLEF        BIT            NOT NULL,
    FL_CHARGEMENT  BIT            NOT NULL,
    FL_ORDRE_TRI   BIT            NOT NULL,

    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
        PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ROLES
    ON dbo.ORT_PARAM_HISTORISATION_TRACES (LB_PROJET, LB_TABLE_ODS, FL_CLEF, FL_CHARGEMENT)
    INCLUDE (NO_CHAMP, LB_CHAMP_ODS, LB_CHAMP_DWH, FL_ORDRE_TRI);
GO

/* ----- ORT_BORNE_JOURNEE ----- */
/* ============================================================================
   TABLE DES FRONTIERES DE JOURNEE  -  dbo.ORT_BORNE_JOURNEE

   Une journee de travail ne s'arrete pas necessairement a minuit.
   DT_JOUR identifie la journee fonctionnelle, normalisee a 00:00:00.000.
   DT_BORNE contient la frontiere effective avec l'heure et les millisecondes.

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

GO

GO

DROP TABLE IF EXISTS dbo.ORT_BORNE_JOURNEE;
GO

CREATE TABLE dbo.ORT_BORNE_JOURNEE
(
    LB_PROJET        nvarchar(50)  NOT NULL,
	DT_JOUR          datetime2(3)  NOT NULL,
    DT_BORNE         datetime2(3)  NOT NULL,
    TYPE_BORNE       nvarchar(15)  NOT NULL,
    ORIGINE_VALEUR   nvarchar(20)  NOT NULL,
    DT_POSE          datetime2(3)  NOT NULL,
    COMMENTAIRE      nvarchar(500) NULL,

    CONSTRAINT PK_ORT_BORNE_JOURNEE
        PRIMARY KEY CLUSTERED
        (
            LB_PROJET ASC,
            DT_JOUR ASC
        )
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_BORNE_JOURNEE_BORNE
    ON dbo.ORT_BORNE_JOURNEE
    (
        LB_PROJET ASC,
		DT_BORNE
    )
    INCLUDE
    (
        DT_JOUR,
        TYPE_BORNE,
        ORIGINE_VALEUR
    );
GO
GO

/* ----- ORT_AUDIT_CHARGEMENT ----- */
/* ============================================================================
   JOURNAL DU TRAITEMENT  -  dbo.ORT_AUDIT_CHARGEMENT

   Cette table conserve le detail des traitements, des volumes, des statuts
   et des erreurs. Elle constitue le premier point de controle en cas
   d'anomalie.

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

GO

GO

DROP TABLE IF EXISTS dbo.ORT_AUDIT_CHARGEMENT;
GO

CREATE TABLE dbo.ORT_AUDIT_CHARGEMENT
(
    LB_PROJET       nvarchar(50)   NULL,
    LB_CHARGEMENT   nvarchar(100)  NULL,
    LB_SOURCE       nvarchar(200)  NULL,
    LB_CIBLE        nvarchar(200)  NULL,
    NB_LIGNE        int            NULL,
    CD_STATUT       nvarchar(10)   NULL,
    LB_ERREUR       nvarchar(MAX)  NULL,
    DT_DEBUT        datetime2(3)   NULL,
    DT_FIN          datetime2(3)   NULL,
    CD_USR_MAJ      nvarchar(20)   NULL,
    ID_TRT_ALI      numeric        NULL

);
GO

CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_PROJET_DT
    ON dbo.ORT_AUDIT_CHARGEMENT
    (
        LB_PROJET,
        DT_DEBUT
    )
    INCLUDE
    (
        ID_TRT_ALI,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        DT_FIN
    );
GO

CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_SESSION
    ON dbo.ORT_AUDIT_CHARGEMENT
    (
        ID_TRT_ALI,
        LB_PROJET,
        CD_STATUT
    )
    INCLUDE
    (
        LB_SOURCE,
        LB_CIBLE,
        LB_CHARGEMENT,
        NB_LIGNE,
        DT_DEBUT,
        DT_FIN
    );
GO
GO

/* ----- ORT_PERIODE_REPRISE ----- */
/* ============================================================================
   01 - dbo.ORT_PERIODE_REPRISE

   File des journees a traiter, une ligne par journee et par scenario. Videe et
   reconstruite a chaque execution par l'etape ODI 003, marquee par l'etape 010.

   Cle par LB_PROJET comme toutes les tables du dispositif, en complement du
   nom de scenario qui distingue deja les projets.

   PK et index seulement.
   ============================================================================ */

GO
GO

IF OBJECT_ID(N'dbo.ORT_PERIODE_REPRISE', N'U') IS NOT NULL
    DROP TABLE dbo.ORT_PERIODE_REPRISE;
GO

CREATE TABLE dbo.ORT_PERIODE_REPRISE
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    DT_CAL          DATE           NOT NULL,
    NO_SEQ          INT            NOT NULL,
    TRAITE          BIT            NOT NULL,
    LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,

    CONSTRAINT PK_ORT_PERIODE_REPRISE PRIMARY KEY CLUSTERED (LB_PROJET, LB_NOM_SCN_SUN, DT_CAL)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PERIODE_REPRISE_A_TRAITER
    ON dbo.ORT_PERIODE_REPRISE (LB_NOM_SCN_SUN, TRAITE, DT_CAL);
GO
GO

