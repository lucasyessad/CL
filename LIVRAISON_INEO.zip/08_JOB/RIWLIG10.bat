@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG10 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Importation des fichiers CDC LigisV5 dans ODS INEO via BCP   #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 01/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : RHMEIW0                                                         #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  M.A.J. 01/09/26 : ajout de trois appels sqlcmd autour de la boucle BCP.      #
REM    - la table d'audit est chargee seule et en premier : elle porte les        #
REM      bornes LSN dont depend la preparation des autres tables ;                #
REM    - PS_PREPARATION_ODS supprime, dans chaque table, la plage que le fichier  #
REM      va recharger. Sans cela, les tables accumulent et toute relance          #
REM      charge en double ;                                                       #
REM    - PS_CONTROLE_ODS verifie que chaque table a bien recu des lignes et       #
REM      alimente ORT_AUDIT_CHARGEMENT.                                           #
REM  La boucle BCP est inchangee.                                                 #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set	SERVER=COOS
set	DBNAME=DWH
set SCHEMA=ods
set PROJET=LIGIS
set BCP="X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe"
set RUNID=%DATALIB%\riwlig10-runid.txt

setlocal enableDelayedExpansion

rem 1. Table d'audit : videe et rechargee seule, avant tout le reste
sqlcmd -S %SERVER% -d %DBNAME% -E -b -Q "TRUNCATE TABLE [%SCHEMA%].[OIT_TEC_AUDIT_CDC];"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

%BCP% "%DBNAME%.%SCHEMA%.[OIT_TEC_AUDIT_CDC]" in "%DATALIB%\ZBCP_LIGIS_TEC_AUDIT_CDC_V.bcp" -T -S %SERVER% -n
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 2. Preparation des tables : plage LSN supprimee, volumetrie relevee
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; DECLARE @id bigint = CONVERT(bigint, FORMAT(SYSDATETIME(),'yyyyMMddHHmmss')); EXEC dbo.PS_PREPARATION_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=@id, @CD_FORMAT='BCP';" ^
       -o "%RUNID%"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

for /F "usebackq tokens=1" %%r in ("%RUNID%") do (
    echo %%r | findstr /R "^[0-9][0-9]*$" >nul && set ID_TRT_ALI=%%r
)
if "!ID_TRT_ALI!"=="" (
    echo Identifiant d'execution introuvable.
    set RC=1
    goto :ERR
)

rem 3. Lancement des BCP_IN sur toutes les vues concernées
for %%i in (ADRESSE,
	BIEN,
	BIEN_HISTO,
	CLIENT,
	CONTRAT,
	CONTRAT_CAUTIONS,
	CONTRAT_EMPRUNTEURS,
	DECOMPTE,
	DECOMPTE_CONTRATS,
	DOSSIER,
	EMPLOYEUR,
	GARANTIE,
	GARANTIE_CONTRATS,
	IDJ,
	IMPUTATION,
	LIG_ECHEANCE,
	LIG_ECHEANCIER,
	LOTMOUVEMENT,
	MANDAT,
	MOUVEMENT,
	ORGANISATION,
	POSTE,
	RIB,
	SOLVABILITE_LIGNES,
	TIERS,
	UTILISATEUR,
	WRK_PROCESS,
	WRK_TASK,
	WRK_TASKPARAMETER) do (
	
	set	WKF01=ZBCP_LIGIS_%%i_V.bcp
	set	TABLE=OIT_%%i

 	%BCP% "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n
	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

rem 4. Controle : chaque table a-t-elle recu des lignes ?
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "EXEC dbo.PS_CONTROLE_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=!ID_TRT_ALI!;"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

endlocal
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0
