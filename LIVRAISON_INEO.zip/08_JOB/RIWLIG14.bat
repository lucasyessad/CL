@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG14 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Chargement des fichiers delimites dans ODS INEO              #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 01/09/26                              DATE M.A.J. : 01/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : RIWLIG10                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  Un appel de procedure par fichier. Le format du fichier (delimiteur,         #
REM  en-tete, encodage) vient du parametrage ORT_PARAM_FLUX : il n'est ecrit ni   #
REM  ici, ni dans la procedure.                                                   #
REM  A placer entre RIWLIG10 et RIWLIG11 dans la chaine.                          #
REM                                                                               #
REM  PREREQUIS : BULK INSERT lit le fichier depuis le moteur SQL. Le compte de    #
REM  service SQL Server doit avoir acces a %DATALIB%.                             #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set	SERVER=COOS
set	DBNAME=DWH
set PROJET=LIGIS

setlocal enableDelayedExpansion

rem Un appel par fichier delimite declare dans le parametrage
for %%i in (PITOPE_TABLEREF.csv) do (

	if not exist "%DATALIB%\%%i" (
		echo Fichier absent : %DATALIB%\%%i
		set RC=2
		goto :ERR
	)

	sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
	       -Q "EXEC dbo.PS_CHARGEMENT_FICHIER_ODS @LB_PROJET='%PROJET%', @LB_FICHIER='%%i';"
	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

endlocal
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0
