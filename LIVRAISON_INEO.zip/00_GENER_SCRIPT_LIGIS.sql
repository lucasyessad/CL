/* ============================================================================
   00_GENER_SCRIPT_LIGIS
   A EXECUTER SUR LA BASE SOURCE (LIGIS).
   Trois generateurs qui PRODUISENT du SQL a rejouer sur le DWH :
     1. tables OIT et OWT        -> a coller dans 02_CREATE_TABLE_DWH_OIT_OWT
     2. tables d'archive HISTO   -> a coller dans 03_CREATE_TABLE_DWH_OIT_HISTO
     3. parametrage colonne      -> a coller dans 04_INSER_LIGNE_ORT
   Lire les sorties dans les colonnes XML ScriptComplet.
   ============================================================================ */

GO

/* ============================================================================
   GENERATEUR : 03_Ligis5_DATA_GEN_TABLES_OIT_OWT
   ============================================================================ */
/* ============================================================================
   GENERATEUR DES TABLES OIT ET OWT DEPUIS LES VUES BCP

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 03, 04 ET 05
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Bloc technique ajoute aux tables OWT :
       NO_SEQ, DD_VAL, DF_VAL, FL_VER_CRT, FL_SUP,
       CD_DML_TEC, DT_COMMIT_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   REGLES DE GENERATION
   ----------------------------------------------------------------------------
   - la structure OIT reproduit la vue a l'identique : ordre, type, longueur,
     precision, echelle et nullabilite ;
   - le bloc metier OWT reprend les memes colonnes, hors colonnes techniques ;
   - les colonnes de la cle metier sont forcees NOT NULL dans OWT ;
   - les scripts generes suppriment et recreent les tables OIT et OWT.
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    TableNameCibleODS sysname       NOT NULL,
    TableNameCibleDWH sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NULL,
    CreateScriptODS   nvarchar(MAX) NULL,
    CreateScriptDWH   nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_TableListODS
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource   sysname = N'dbo';
DECLARE @SchemaVue      sysname = N'export_cdc';
DECLARE @SchemaCibleODS sysname = N'ods';
DECLARE @SchemaCibleDWH sysname = N'dbo';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. A 0, ces tables sont generees sans
   cle et signalees par le controle final. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   Tables sans cle primaire exploitable, dont la cle fonctionnelle est declaree
   ici.
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
---------------------------------------------------------------------------- */
INSERT INTO ##TableListODS
(
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name,
    N'OWT_' + T.name
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @TableNameCibleODS sysname,
    @TableNameCibleDWH sysname,
    @ViewObjectId      int,
    @SourceObjectId    int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @ColonnesCleTriees nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @ColsODS           nvarchar(MAX),
    @ColsDWH           nvarchar(MAX),
    @CreateODS         nvarchar(MAX),
    @CreateDWH         nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        TableNameSource,
        ViewNameSource,
        TableNameCibleODS,
        TableNameCibleDWH
    FROM ##TableListODS
    ORDER BY TableNameSource;

OPEN cur_tables;
FETCH NEXT FROM cur_tables
INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @ColsODS = NULL,
        @ColsDWH = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @ColonnesCleTriees = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL DEFAULT (0),
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal),
        @ColonnesCleTriees = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                QUOTENAME(name)
                + CASE WHEN is_desc = 1 THEN N' DESC' ELSE N' ASC' END
            ),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : OWT generee sans cle primaire.';

    /* ------------------------------------------------------------------------
       Table OIT : copie conforme de la vue.
    ------------------------------------------------------------------------ */
    SELECT
        @ColsODS = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                N'        ' + QuotedName + N' ' + TypeDefinition + NullClause
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    /* ------------------------------------------------------------------------
       Table OWT, bloc metier : la vue hors colonnes techniques.
       Les colonnes de la cle metier sont forcees NOT NULL.
    ------------------------------------------------------------------------ */
    SELECT
        @ColsDWH = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                N'        ' + VC.QuotedName + N' ' + VC.TypeDefinition
                + CASE
                      WHEN EXISTS
                      (
                          SELECT 1
                          FROM #KeyCols AS K
                          WHERE K.name COLLATE DATABASE_DEFAULT =
                                VC.ColumnName COLLATE DATABASE_DEFAULT
                      )
                      THEN N' NOT NULL'
                      ELSE VC.NullClause
                  END
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY VC.column_id)
    FROM #ViewCols AS VC
    WHERE VC.ColumnName NOT IN
    (
        N'ID_INSTANCE_TEC',
        N'NO_SEQUENCE_TEC',
        N'LB_SEQVAL_TEC',
        N'CD_DML_TEC',
        N'DT_COMMIT_TEC',
        N'LB_LSN_COMMIT_TEC',
        N'FL_FIN_JOURNEE'
    );

    /* ------------------------------------------------------------------------
       Script de creation de la table OIT.
    ------------------------------------------------------------------------ */
    SET @CreateODS =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N' ('
        + CHAR(13) + @ColsODS + CHAR(13) + N');' + CHAR(13)

        /* Recherche de la derniere trace par cle sur la fenetre de journee. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE NONCLUSTERED INDEX '
                     + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_CLE')
                     + N' ON '
                     + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
                     + N' (' + @ColonnesCleMetier + N', [DT_COMMIT_TEC]);' + CHAR(13)
              ELSE N''
          END

        /* Bornage de la fenetre de journee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_COMMIT')
        + N' ON '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
        + N' ([DT_COMMIT_TEC]);' + CHAR(13)

        /* Suppression de la plage rechargee par l'import. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_LSN')
        + N' ON '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
        + N' ([LB_LSN_COMMIT_TEC]);' + CHAR(13);

    /* ------------------------------------------------------------------------
       Script de creation de la table OWT.
       CD_DML_TEC appartient au bloc technique : le parametrage genere par le
       script 05 l'alimente, elle doit donc exister dans la cible.
    ------------------------------------------------------------------------ */
    SET @CreateDWH =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N' (' + CHAR(13)
        + N'        [NO_SEQ] int NULL,' + CHAR(13)
        + N'        [DD_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [DF_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [FL_VER_CRT] bit NOT NULL,' + CHAR(13)
        + N'        [FL_SUP] bit NOT NULL DEFAULT (0),' + CHAR(13)
        + N'        [CD_DML_TEC] int NULL,' + CHAR(13)
        + N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13)
        + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
        + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
        + N'        [ID_TRT_ALI] bigint NULL'
        + CASE
              WHEN @ColsDWH IS NOT NULL
                  THEN N',' + CHAR(13) + @ColsDWH
              ELSE N''
          END
        + CASE
              WHEN @ColonnesCleTriees IS NOT NULL
                  THEN N',' + CHAR(13)
                     + N'        CONSTRAINT ' + QUOTENAME(N'PK_' + @TableNameCibleDWH)
                     + N' PRIMARY KEY CLUSTERED (' + @ColonnesCleTriees + N', [DD_VAL] ASC)'
              ELSE N''
          END
        + CHAR(13) + N');' + CHAR(13)

        /* Une seule version courante par cle metier. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE UNIQUE NONCLUSTERED INDEX '
                     + QUOTENAME(N'UX_' + @TableNameCibleDWH + N'_VER_CRT')
                     + N' ON '
                     + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
                     + N' (' + @ColonnesCleMetier + N')'
                     + N' WHERE [FL_VER_CRT] = 1;' + CHAR(13)
              ELSE N''
          END

        /* Purge et reouverture d'une journee recalculee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DD_VAL')
        + N' ON '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DD_VAL]);' + CHAR(13)
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DF_VAL')
        + N' ON '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DF_VAL], [FL_VER_CRT]);' + CHAR(13);

    UPDATE ##TableListODS
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        CreateScriptODS = @CreateODS,
        CreateScriptDWH = @CreateDWH,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_tables
    INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;
GO

/* Script complet a executer sur le DWH. */
SELECT
    ScriptComplet =
    (
        SELECT
            CHAR(13) + CreateScriptODS + CHAR(13)
          + CreateScriptDWH + CHAR(13)
        FROM ##TableListODS
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail par table. */
SELECT
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    MessageControle,
    CreateScriptODS,
    CreateScriptDWH
FROM ##TableListODS
ORDER BY TableNameSource;

/* Tables sans cle metier exploitable. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListODS
WHERE MessageControle <> N'OK'
ORDER BY TableNameSource;
GO

GO

/* ============================================================================
   GENERATEUR : 04_Ligis5_DATA_GEN_TABLES_HISTO
   ============================================================================ */
/* ============================================================================
   GENERATEUR DES TABLES D'ARCHIVE

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur la base ODS_Traces.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 03, 04 ET 05
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   STRUCTURE DE L'ARCHIVE
   ----------------------------------------------------------------------------
   La table d'archive reproduit la table OIT a l'identique, colonne pour
   colonne et dans le meme ordre, ce qui permet une copie sans transformation.
   FL_FIN_JOURNEE est conservee : elle indique quelle trace a servi d'image.

   Quatre colonnes d'archivage sont ajoutees en fin :
       DT_JOUR_TEC   journee de rattachement de la trace
       DT_MAJ_TRT    date d'archivage
       CD_USR_MAJ    utilisateur ou traitement d'archivage
       ID_TRT_ALI    numero de session ODI

   Index generes :
       UX_..._TRACE       unique sur (LB_LSN_COMMIT_TEC, LB_SEQVAL_TEC),
                          le couple qui identifie une trace CDC ; rend la
                          copie rejouable
       IX_..._JOUR        consultation et purge par journee
       IX_..._CLE_METIER  consultation par cle metier, si une cle est resolue
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListHisto;
GO

CREATE TABLE ##TableListHisto
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    TableNameHisto    sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NOT NULL DEFAULT (0),
    CreateScript      nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_TableListHisto
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource sysname = N'dbo';
DECLARE @SchemaVue    sysname = N'export_cdc';
DECLARE @BaseHisto    sysname = N'ODS_Traces';   -- base sur laquelle executer la sortie
DECLARE @SchemaHisto  sysname = N'ods';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
---------------------------------------------------------------------------- */
INSERT INTO ##TableListHisto
(
    TableNameSource,
    ViewNameSource,
    TableNameHisto
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name + N'_HISTO'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

/* Colonnes d'archivage ajoutees en fin de table. */
DECLARE @TechColsArchive nvarchar(MAX) =
      N'[DT_JOUR_TEC] datetime2(3) NULL,' + CHAR(13)
    + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
    + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
    + N'        [ID_TRT_ALI] bigint NULL';

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @TableNameHisto    sysname,
    @ViewObjectId      int,
    @SourceObjectId    int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @ColsHisto         nvarchar(MAX),
    @Create            nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_histo CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        TableNameSource,
        ViewNameSource,
        TableNameHisto
    FROM ##TableListHisto
    ORDER BY TableNameSource;

OPEN cur_histo;
FETCH NEXT FROM cur_histo
INTO @TableNameSource, @ViewNameSource, @TableNameHisto;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @ColsHisto = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL DEFAULT (0),
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : archive sans index metier.';

    /* ------------------------------------------------------------------------
       Colonnes de l'archive : copie conforme de la vue, donc de la table OIT.
    ------------------------------------------------------------------------ */
    SELECT
        @ColsHisto = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                N'        ' + QuotedName + N' ' + TypeDefinition + NullClause
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    SET @Create =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N' (' + CHAR(13)
        + @ColsHisto + N',' + CHAR(13)
        + N'        ' + @TechColsArchive + CHAR(13)
        + N');' + CHAR(13)

        /* Anti-doublon : le couple LSN + sequence identifie une trace CDC.
           Le LSN seul ne suffit pas, une transaction pouvant porter plusieurs
           modifications. */
        + N'CREATE UNIQUE NONCLUSTERED INDEX '
        + QUOTENAME(N'UX_' + @TableNameHisto + N'_TRACE')
        + N' ON '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
        + N' ([LB_LSN_COMMIT_TEC], [LB_SEQVAL_TEC]);' + CHAR(13)

        /* Consultation et purge de retention par journee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameHisto + N'_JOUR')
        + N' ON '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
        + N' ([DT_JOUR_TEC]);' + CHAR(13)

        /* Consultation par cle metier, si une cle a pu etre resolue. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE NONCLUSTERED INDEX '
                     + QUOTENAME(N'IX_' + @TableNameHisto + N'_CLE_METIER')
                     + N' ON '
                     + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
                     + N' (' + @ColonnesCleMetier + N', [DT_COMMIT_TEC]);' + CHAR(13)
              ELSE N''
          END;

    UPDATE ##TableListHisto
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        CreateScript = @Create,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_histo
    INTO @TableNameSource, @ViewNameSource, @TableNameHisto;
END;

CLOSE cur_histo;
DEALLOCATE cur_histo;
GO

/* Script complet a executer sur la base ODS_Traces. */
SELECT
    ScriptComplet =
    (
        SELECT CHAR(13) + CreateScript + CHAR(13)
        FROM ##TableListHisto
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail et controle de la cle metier detectee. */
SELECT
    TableNameSource,
    ViewNameSource,
    TableNameHisto,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    MessageControle,
    CreateScript
FROM ##TableListHisto
ORDER BY TableNameSource;

/* Tables sans cle metier exploitable. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListHisto
WHERE SourceCleMetier IS NULL
ORDER BY TableNameSource;
GO

GO

/* ============================================================================
   GENERATEUR : 05_Ligis5_DATA_GEN_PARAMETRAGE
   ============================================================================ */
/* ============================================================================
   GENERATEUR DU PARAMETRAGE

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 03, 04 ET 05
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   LIGNES GENEREES, PAR TABLE
   ----------------------------------------------------------------------------
   groupe 1  colonnes de la cle metier        FL_CLEF = 1, FL_CHARGEMENT = 1
   groupe 2  DT_COMMIT_TEC                    FL_ORDRE_TRI = 1, chargee
             CD_DML_TEC                       chargee, sert au calcul de FL_SUP
   groupe 3  ID_INSTANCE_TEC, NO_SEQUENCE_TEC,
             LB_SEQVAL_TEC, LB_LSN_COMMIT_TEC  presentes en ODS, non chargees
   groupe 4  colonnes metier hors cle          chargees
   groupe 5  FL_FIN_JOURNEE et bloc technique DWH, pour documentation

   Toute colonne portant FL_CHARGEMENT = 1 avec un LB_CHAMP_DWH renseigne doit
   exister dans la table OWT generee par le script 03.

   LIRE LE RESULTAT DANS LA COLONNE XML ScriptComplet.
   ============================================================================ */

DROP TABLE IF EXISTS ##ParamHistoScript;
GO

CREATE TABLE ##ParamHistoScript
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NULL,
    NbLignesParam     int           NULL,
    InsertScript      nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_ParamHistoScript
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource sysname       = N'dbo';
DECLARE @SchemaVue    sysname       = N'export_cdc';
DECLARE @LB_PROJET    nvarchar(50)  = N'LIGIS';
DECLARE @TableParam   nvarchar(300) = N'dbo.ORT_PARAM_HISTORISATION_TRACES';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. A 0, ces tables restent sans cle et
   sont donc ignorees par le traitement ODI. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
---------------------------------------------------------------------------- */
INSERT INTO ##ParamHistoScript
(
    TableNameSource,
    ViewNameSource
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @SourceObjectId    int,
    @ViewObjectId      int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @Script            nvarchar(MAX),
    @ValuesScript      nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @NbLignes          int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_param CURSOR LOCAL FAST_FORWARD FOR
    SELECT TableNameSource, ViewNameSource
    FROM ##ParamHistoScript
    ORDER BY TableNameSource;

OPEN cur_param;
FETCH NEXT FROM cur_param
INTO @TableNameSource, @ViewNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @Script = NULL,
        @ValuesScript = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @NbLignes = 0,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL DEFAULT (0),
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : table ignoree par ODI.';

    /* ------------------------------------------------------------------------
       Construction des lignes de parametrage.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #Lignes;

    CREATE TABLE #Lignes
    (
        grp       int          NOT NULL,
        ord       int          NOT NULL,
        champ_ods sysname      NULL,
        champ_dwh sysname      NULL,
        scd       nvarchar(20) NULL,
        clef      bit          NOT NULL,
        chg       bit          NOT NULL,
        tri       bit          NOT NULL
    );

    /* 1. Colonnes de la cle metier. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT
        1, K.key_ordinal, K.name, K.name, N'TYPE 2', 1, 1, 0
    FROM #KeyCols AS K;

    /* 2. Colonnes techniques chargees dans la cible.
          DT_COMMIT_TEC ordonne les traces dans la journee.
          CD_DML_TEC sert au calcul de FL_SUP : la colonne doit exister dans la
          table OWT, ce que garantit le bloc technique du script 03. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT 2, 1, N'DT_COMMIT_TEC', N'DT_COMMIT_TEC', NULL, 0, 1, 1
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'DT_COMMIT_TEC'
    )
    UNION ALL
    SELECT 2, 2, N'CD_DML_TEC', N'CD_DML_TEC', NULL, 0, 1, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'CD_DML_TEC'
    );

    /* 3. Colonnes techniques presentes en ODS, non chargees dans la cible. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT 3, 1, N'ID_INSTANCE_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'ID_INSTANCE_TEC'
    )
    UNION ALL
    SELECT 3, 2, N'NO_SEQUENCE_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'NO_SEQUENCE_TEC'
    )
    UNION ALL
    SELECT 3, 3, N'LB_SEQVAL_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_SEQVAL_TEC'
    )
    UNION ALL
    SELECT 3, 4, N'LB_LSN_COMMIT_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_LSN_COMMIT_TEC'
    );

    /* 4. Colonnes metier hors cle. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT
        4, V.column_id, V.ColumnName, V.ColumnName, NULL, 0, 1, 0
    FROM #ViewCols AS V
    WHERE V.ColumnName NOT IN
    (
        N'ID_INSTANCE_TEC',
        N'NO_SEQUENCE_TEC',
        N'LB_SEQVAL_TEC',
        N'CD_DML_TEC',
        N'DT_COMMIT_TEC',
        N'LB_LSN_COMMIT_TEC',
        N'FL_FIN_JOURNEE'
    )
      AND NOT EXISTS
      (
          SELECT 1
          FROM #KeyCols AS K
          WHERE K.name COLLATE DATABASE_DEFAULT =
                V.ColumnName COLLATE DATABASE_DEFAULT
      );

    /* 5. Lignes documentaires : flag ODS et bloc technique DWH.
          Elles ne sont pas chargees, elles decrivent les colonnes alimentees
          par le traitement lui-meme. L'ordre suit celui du bloc technique
          genere par le script 03. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    VALUES
        (5,  1, N'FL_FIN_JOURNEE', NULL,           NULL, 0, 0, 0),
        (5,  2, NULL,              N'NO_SEQ',      NULL, 0, 0, 0),
        (5,  3, NULL,              N'DD_VAL',      NULL, 0, 0, 0),
        (5,  4, NULL,              N'DF_VAL',      NULL, 0, 0, 0),
        (5,  5, NULL,              N'FL_VER_CRT',  NULL, 0, 0, 0),
        (5,  6, NULL,              N'FL_SUP',      NULL, 0, 0, 0),
        (5,  7, NULL,              N'DT_MAJ_TRT',  NULL, 0, 0, 0),
        (5,  8, NULL,              N'CD_USR_MAJ',  NULL, 0, 0, 0),
        (5,  9, NULL,              N'ID_TRT_ALI',  NULL, 0, 0, 0);

    ;WITH numerotees AS
    (
        SELECT
            L.*,
            NO_CHAMP = ROW_NUMBER() OVER
            (
                ORDER BY L.grp, L.ord, L.champ_ods, L.champ_dwh
            )
        FROM #Lignes AS L
    )
    SELECT
        @ValuesScript = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                  N' (N''' + REPLACE(@LB_PROJET, N'''', N'''''')
                + N''',N''' + REPLACE(@SchemaSource, N'''', N'''''')
                + N'_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OWT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',' + CONVERT(nvarchar(10), NO_CHAMP) + N','
                + CASE WHEN champ_ods IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_ods, N'''', N'''''') + N'''' END + N','
                + CASE WHEN champ_dwh IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_dwh, N'''', N'''''') + N'''' END + N','
                + CASE WHEN scd IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(scd, N'''', N'''''') + N'''' END + N','
                + CONVERT(nvarchar(1), CONVERT(int, clef)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, chg)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, tri)) + N',NULL)'
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY NO_CHAMP),
        @NbLignes = COUNT(*)
    FROM numerotees;

    SET @Script =
          N'DELETE FROM ' + @TableParam
        + N' WHERE LB_PROJET = N''' + REPLACE(@LB_PROJET, N'''', N'''''') + N''''
        + N' AND LB_TABLE_ODS = N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''') + N''';'
        + CHAR(13)
        + N'INSERT INTO ' + @TableParam + CHAR(13)
        + N'    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,' + CHAR(13)
        + N'     LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF, FL_CHARGEMENT,' + CHAR(13)
        + N'     FL_ORDRE_TRI, LB_FILTRE_WHERE)' + CHAR(13)
        + N'VALUES' + CHAR(13)
        + @ValuesScript
        + N';';

    UPDATE ##ParamHistoScript
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        NbLignesParam = @NbLignes,
        InsertScript = @Script,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_param
    INTO @TableNameSource, @ViewNameSource;
END;

CLOSE cur_param;
DEALLOCATE cur_param;
GO

/* Script complet a executer sur le DWH. */
SELECT
    ScriptComplet =
    (
        SELECT CHAR(13) + InsertScript + CHAR(13)
        FROM ##ParamHistoScript
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail par table. */
SELECT
    TableNameSource,
    ViewNameSource,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    NbLignesParam,
    MessageControle,
    InsertScript
FROM ##ParamHistoScript
ORDER BY TableNameSource;

/* Tables sans cle metier : elles ne seront pas traitees par ODI. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##ParamHistoScript
WHERE SourceCleMetier IS NULL
ORDER BY TableNameSource;
GO

GO

