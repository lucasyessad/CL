/* ============================================================================
   00_INIT_LIVRAISON_LIGIS
   A EXECUTER SUR LA BASE SOURCE (LIGIS).
   Cree les tables et vues necessaires a la capture et a l'export :
     - table et vue d'audit CDC ;
     - vues d'export ZBCP_LIGIS_<table>_V ;
     - vues d'initialisation ZBCP_INIT_LIGIS_<table>_V.
   ============================================================================ */

GO

/* ----- 01_Ligis5_DATA_CREATE_TABLE_VUES_AUDIT_CDC_LIGIS ----- */
ï»¿----------------------------------------------------------
-- Creation de la table et vue audit CDC pour borner l extraction
-- Base de donnÃ©es : Migration_ligis
----------------------------------------------------------

DROP VIEW IF EXISTS export_cdc.ZBCP_LIGIS_TEC_AUDIT_CDC_V;
GO

DROP TABLE IF EXISTS export_cdc.TEC_AUDIT_CDC;
GO

CREATE TABLE export_cdc.TEC_AUDIT_CDC (
	LB_INSTANCE		VARCHAR(50) NOT NULL,
	LB_DEB_LSN		BINARY(10) NULL,
	LB_FIN_LSN		BINARY(10) NULL,
	DT_EXTRACT		DATETIME2(3) NULL,
	NO_SEQUENCE		BIGINT NOT NULL,
	CONSTRAINT PK_TEC_AUDIT_CDC PRIMARY KEY (LB_INSTANCE)
) WITH (DATA_COMPRESSION = ROW);

GO

-- initialisation de la table TEC_AUDIT_CDC
INSERT INTO export_cdc.TEC_AUDIT_CDC
VALUES
('dbo_CONTRAT',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_ADRESSE',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_BIEN',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_BIEN_HISTO',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_CLIENT',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_CONTRAT_CAUTIONS',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_CONTRAT_EMPRUNTEURS',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_DECOMPTE',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_DECOMPTE_CONTRATS',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_DOSSIER',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_EMPLOYEUR',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_GARANTIE',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_GARANTIE_CONTRATS',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_IDJ',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_IMPUTATION',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_LIG_ECHEANCE',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_LIG_ECHEANCIER',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_LOTMOUVEMENT',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_MANDAT',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_MOUVEMENT',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_ORGANISATION',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_POSTE',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_RIB',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_SOLVABILITE_LIGNES',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_TIERS',					0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_UTILISATEUR',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_wrk_process',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_wrk_task',				0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_wrk_taskparameter',			0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_HISTOGL',			  		0x00000000000000000000,0x00000000000000000000,NULL,0),
('dbo_HISTOBALANCE',				0x00000000000000000000,0x00000000000000000000,NULL,0);

GO

CREATE OR ALTER VIEW export_cdc.ZBCP_LIGIS_TEC_AUDIT_CDC_V
AS
SELECT
    CONVERT (binary(32),HASHBYTES('SHA2_256',CONCAT (LB_INSTANCE,LB_DEB_LSN,LB_FIN_LSN,DT_EXTRACT,NO_SEQUENCE))) AS ID_INSTANCE,
    LB_INSTANCE,
    LB_DEB_LSN,
    LB_FIN_LSN,
    ISNULL (CONVERT(datetime2(3),sys.fn_cdc_map_lsn_to_time(LB_DEB_LSN)),CONVERT(datetime2(3), '19900101')) AS DT_DEB_LSN,
    CONVERT (datetime2(3),sys.fn_cdc_map_lsn_to_time(LB_FIN_LSN)) AS DT_FIN_LSN,
    CONVERT(datetime2(3), DT_EXTRACT) AS DT_EXTRACT,
    NO_SEQUENCE
FROM export_cdc.TEC_AUDIT_CDC;

GO
GO

/* ----- 02_Ligis5_DATA_CREATE_VUES_CDC_ZBCP_xxx_V ----- */
/* ================================================================
   Création de la table de correspondance
   ================================================================ */
DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource sysname NOT NULL
);
GO

--  Données d'exemple
INSERT INTO ##TableListODS (TableNameSource )
SELECT 
    t.name AS TableNameSource
FROM sys.tables AS t
INNER JOIN sys.schemas AS s 
    ON s.schema_id = t.schema_id
INNER JOIN [export_cdc].[TEC_AUDIT_CDC] tm
    ON tm.LB_INSTANCE = N'dbo_' + t.name
WHERE s.name = N'dbo'
ORDER BY t.name;

/* ================================================================
   Génération automatique des vues CDC enrichies
   ================================================================ */

SET NOCOUNT ON;

DECLARE
    @SchemaSource       sysname = N'dbo',
    @SchemaCDC          sysname = N'cdc',
    @SchemaCDCExport    sysname = N'export_cdc',
    @TableNameSource    sysname,
    @DropSQL nvarchar(MAX),
    @CreateSQL nvarchar(MAX),
    @FullSQL nvarchar(MAX),
    @CDC_Table nvarchar(517),
    @CaptureInstance sysname;

DECLARE cur_view CURSOR LOCAL FAST_FORWARD FOR
SELECT TableNameSource
FROM ##TableListODS;

OPEN cur_view;
FETCH NEXT FROM cur_view INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @CaptureInstance = @SchemaSource + '_' + @TableNameSource;
    SET @CDC_Table = QUOTENAME(@SchemaCDC) + N'.' + QUOTENAME(@CaptureInstance + N'_CT');

    /* Sécurité */
    IF OBJECT_ID(@CDC_Table) IS NULL
    BEGIN
        PRINT 'Table CDC absente : ' + @CDC_Table;
        FETCH NEXT FROM cur_view INTO @TableNameSource;
        CONTINUE;
    END

    /* =====================================================
       1. Script DROP
       ===================================================== */
    SET @DropSQL =
        'DROP VIEW IF EXISTS ' 
        + QUOTENAME(@SchemaCDCExport) 
        + N'.' + QUOTENAME(N'ZBCP_LIGIS_' + @TableNameSource + N'_V') + N';';

    /* =====================================================
       2. Script CREATE
       ===================================================== */
    ;WITH cols AS (
        SELECT 
            c.name,
            c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@CDC_Table)
          AND c.name NOT LIKE '__$%'
    )
    SELECT @CreateSQL =
'CREATE VIEW ' + QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_LIGIS_' + @TableNameSource + N'_V') + N'
AS
    WITH CTE_AUDIT AS (
        SELECT
            ID_INSTANCE,
            LB_DEB_LSN,
            LB_FIN_LSN,
            DT_DEB_LSN,
            DT_FIN_LSN,
            DT_EXTRACT,
            NO_SEQUENCE
        FROM ' + QUOTENAME(@SchemaCDCExport) + '.ZBCP_LIGIS_TEC_AUDIT_CDC_V
        WHERE LB_INSTANCE = ''' + @CaptureInstance + '''
    )

    SELECT
        T.ID_INSTANCE  AS ID_INSTANCE_TEC,
        T.NO_SEQUENCE  AS NO_SEQUENCE_TEC,
        CONVERT(binary(10), C.__$seqval) AS LB_SEQVAL_TEC,
        C.__$operation AS CD_DML_TEC,
        CONVERT(DATETIME2(3), sys.fn_cdc_map_lsn_to_time(C.__$start_lsn)) AS DT_COMMIT_TEC,
        C.__$start_lsn AS LB_LSN_COMMIT_TEC,
        ' +
        STRING_AGG('C.' + QUOTENAME(name), ',' + CHAR(13) + '        ')
        WITHIN GROUP (ORDER BY column_id) + ',
        CONVERT(BIT, 0) AS FL_FIN_JOURNEE
    FROM ' + @CDC_Table + ' AS C
    CROSS JOIN CTE_AUDIT AS T
    WHERE
        C.__$operation IN (1,2,4)
        AND C.__$start_lsn > T.LB_DEB_LSN
        AND C.__$start_lsn <= T.LB_FIN_LSN;'
    FROM cols
	where name not like 'CS/_%' escape '/';

    /* =====================================================
       3. Exécution dans le bon ordre
       ===================================================== */
/* version print */
--    SET @FullSQL = @DropSQL + CHAR(13) + 'GO' + CHAR(13) + @CreateSQL + CHAR(13) + 'GO' + CHAR(13) + CHAR(13); 	Print @FullSQL;

/* version exec */    
    EXEC(@DropSQL); EXEC(@CreateSQL);
    FETCH NEXT FROM cur_view INTO @TableNameSource;
END

CLOSE cur_view;
DEALLOCATE cur_view;
GO
GO

/* ----- 02_bis_Ligis5_DATA_CREATE_VUES_CDC_ZBCP_INIT_LIGIS_xxx_V ----- */
/* ================================================================
   Création de la table de correspondance
   ================================================================ */
DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource sysname NOT NULL
);
GO

--  Données d'exemple
INSERT INTO ##TableListODS (TableNameSource )
SELECT 
    t.name AS TableNameSource
FROM sys.tables AS t
INNER JOIN sys.schemas AS s 
    ON s.schema_id = t.schema_id
INNER JOIN [export_cdc].[TEC_AUDIT_CDC] tm
    ON tm.LB_INSTANCE = N'dbo_' + t.name
WHERE s.name = N'dbo'
ORDER BY t.name;

/* ================================================================
   Génération automatique des vues CDC enrichies
   ================================================================ */

SET NOCOUNT ON;

DECLARE
    @SchemaSource       sysname = N'dbo',
    @SchemaCDC          sysname = N'dbo',
    @SchemaCDCExport    sysname = N'export_cdc',
    @TableNameSource    sysname,
    @DropSQL nvarchar(MAX),
    @CreateSQL nvarchar(MAX),
    @FullSQL nvarchar(MAX),
    @CDC_Table nvarchar(517),
    @CaptureInstance sysname;

DECLARE cur_view CURSOR LOCAL FAST_FORWARD FOR
SELECT TableNameSource
FROM ##TableListODS;

OPEN cur_view;
FETCH NEXT FROM cur_view INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @CaptureInstance = @TableNameSource;
    SET @CDC_Table = QUOTENAME(@SchemaCDC) + N'.' + QUOTENAME(@CaptureInstance );

    /* Sécurité */
    IF OBJECT_ID(@CDC_Table) IS NULL
    BEGIN
        PRINT 'Table CDC absente : ' + @CDC_Table;
        FETCH NEXT FROM cur_view INTO @TableNameSource;
        CONTINUE;
    END

    /* =====================================================
       1. Script DROP
       ===================================================== */
    SET @DropSQL =
        'DROP VIEW IF EXISTS ' 
        + QUOTENAME(@SchemaCDCExport) 
        + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N';';

    /* =====================================================
       2. Script CREATE
       ===================================================== */
    ;WITH cols AS (
        SELECT 
            c.name,
            c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@CDC_Table)
          AND c.name NOT LIKE '__$%'
    )
    SELECT @CreateSQL =
'CREATE VIEW ' + QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N'
AS
    WITH CTE_AUDIT AS (
        SELECT
            ID_INSTANCE,
            LB_DEB_LSN,
            LB_FIN_LSN,
            DT_DEB_LSN,
            DT_FIN_LSN,
            DT_EXTRACT,
            NO_SEQUENCE
        FROM ' + QUOTENAME(@SchemaCDCExport) + '.ZBCP_LIGIS_TEC_AUDIT_CDC_V
        WHERE LB_INSTANCE = ''' + @CaptureInstance + '''
    )

    SELECT
        T.ID_INSTANCE  AS ID_INSTANCE_TEC,
        T.NO_SEQUENCE  AS NO_SEQUENCE_TEC,
        CONVERT(binary(10), 1) AS LB_SEQVAL_TEC,
        4 AS CD_DML_TEC,
        CONVERT(DATETIME2(3), getdate()) AS DT_COMMIT_TEC,
        getdate() AS LB_LSN_COMMIT_TEC,
        ' +
        STRING_AGG('C.' + QUOTENAME(name), ',' + CHAR(13) + '        ')
        WITHIN GROUP (ORDER BY column_id) + ',
        CONVERT(BIT, 0) AS FL_FIN_JOURNEE
    FROM ' + @CDC_Table + ' AS C
    CROSS JOIN CTE_AUDIT AS T;'
    FROM cols
	where name not like 'CS/_%' escape '/';

    /* =====================================================
       3. Exécution dans le bon ordre
       ===================================================== */
/* version print */
    SET @FullSQL = @DropSQL + CHAR(13) + 'GO' + CHAR(13) + @CreateSQL + CHAR(13) + 'GO' + CHAR(13) + CHAR(13); 	Print @FullSQL;

/* version exec */    
--    EXEC(@DropSQL); EXEC(@CreateSQL);
    FETCH NEXT FROM cur_view INTO @TableNameSource;
END

CLOSE cur_view;
DEALLOCATE cur_view;
GO
GO

