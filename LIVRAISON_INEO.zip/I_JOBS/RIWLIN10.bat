@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIN1                                            JOB : RIWLIN10 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Initialisation des tables LigisV5 dans ODS INEO via BCP    #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 01/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                             URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : aucune                                                          #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  Reprise d'existant : charge l'etat complet de TOUTES les tables du projet.  #
REM  dans ORT_PARAM_FLUX, une fois, avant que le flux CDC prenne le relais.       #
REM  Meme deroulement que RIWLIG10, avec les fichiers ZBCP_INIT_LIGIS_*, et la    #
REM  liste des tables lue dans le parametrage plutot qu'ecrite ici.               #
REM  PS_PREPARATION_ODS refuse une table dont l'historique est deja alimente.     #
REM                                                                               #
REM  Enchainement : poser une borne INIT dans ORT_BORNE_JOURNEE, RIWLIN10,        #
REM  puis RIWLIN11. La borne INIT est consommee automatiquement.                  #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set	SERVER=COOS
set	DBNAME=DWH
set SCHEMA=ods
set PROJET=LIGIS
set BCP="X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe"
set RUNID=%DATALIB%\riwlin10-runid.txt

setlocal enableDelayedExpansion

rem 1. Table d'audit : videe et rechargee seule, avant tout le reste
sqlcmd -S %SERVER% -d %DBNAME% -E -b -Q "TRUNCATE TABLE [%SCHEMA%].[OIT_TEC_AUDIT_CDC];"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

%BCP% "%DBNAME%.%SCHEMA%.[OIT_TEC_AUDIT_CDC]" in "%DATALIB%\ZBCP_LIGIS_TEC_AUDIT_CDC_V.bcp" -T -S %SERVER% -n
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 2. Preparation des tables : plage LSN supprimee, volumetrie relevee
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; DECLARE @id bigint = CONVERT(bigint, FORMAT(SYSDATETIME(),'yyyyMMddHHmmss')); EXEC dbo.PS_PREPARATION_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=@id, @CD_FORMAT='BCP';" ^
       -o "%RUNID%"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

for /F "usebackq tokens=1" %%r in ("%RUNID%") do (
    echo %%r | findstr /R "^[0-9][0-9]*$" >nul && set ID_TRT_ALI=%%r
)
if "!ID_TRT_ALI!"=="" (
    echo Identifiant d'execution introuvable.
    set RC=1
    goto :ERR
)

rem 3. Lancement des BCP_IN sur les vues d'initialisation de toutes les tables
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; SELECT SUBSTRING(LB_TABLE_ODS, 5, 200) FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET='%PROJET%' AND FL_ACTIF=1 AND CD_FORMAT='BCP' AND LB_TABLE_ODS <> 'OIT_TEC_AUDIT_CDC' ORDER BY NO_ORDRE, LB_TABLE_ODS;" ^
       -o "%DATALIB%\riwlin10-tables.txt"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

for /F "usebackq tokens=1" %%i in ("%DATALIB%\riwlin10-tables.txt") do (
	
	set	WKF01=ZBCP_INIT_LIGIS_%%i_V.bcp
	set	TABLE=OIT_%%i

 	%BCP% "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n
	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

rem 4. Controle : chaque table a-t-elle recu des lignes ?
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "EXEC dbo.PS_CONTROLE_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=!ID_TRT_ALI!;"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

endlocal
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0
