/* ============================================================================
   02_CREATE_TABLE_DWH_OIT_OWT
   A EXECUTER SUR LE DWH.

   Ce fichier recoit la SORTIE du generateur OIT/OWT (00_GENER_SCRIPT_LIGIS,
   premier generateur). Coller ici le contenu de la colonne ScriptComplet, qui
   contient les CREATE TABLE de :
       ods.OIT_<table>   sas de reception
       dbo.OWT_<table>   historique SCD2

   Ne rien ecrire a la main : le contenu est genere depuis la structure reelle
   des tables source.
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR OIT/OWT <<<
