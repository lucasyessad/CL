/* ============================================================================
   06_INIT_MEP_DWH
   A EXECUTER SUR LE DWH, une seule fois a la mise en production.
   ============================================================================ */

/* ============================================================================
   INITIALISATION  -  a executer UNE SEULE FOIS, a la mise en production

   Deux choses a poser avant le premier lancement :

     1. la ligne de pilotage dans PWTTRE, qui indique a partir de quand
        commencer ;
     2. la premiere frontiere de journee, sans laquelle le traitement ne sait
        pas ou commence la premiere fenetre.

   Les deux doivent designer la MEME journee : la derniere deja couverte par
   les extractions. Le traitement demarrera a la journee suivante.

   Exemple, pour traiter les traces a partir du 29 juillet 2026 :
     PWTTRE.DA_DEB_DEL_TRT  = 2026-07-28
     ORT_BORNE_JOURNEE      = 2026-07-28 / 2026-07-29 07:45:00.000

   ============================================================================ */
USE [DWH];
GO

DECLARE @LB_NOM_SCN_SUN NVARCHAR(100) = N'IWI_LIGIS_TRACES_CSTIMG';
DECLARE @DT_JOUR_INITIAL DATETIME2(3) = '2026-06-01 00:00:00.000';
DECLARE @DT_BORNE_INITIALE DATETIME2(3) = '2026-06-01 07:45:00.000';


/* 1. Initialisation du pilotage --------------------------------------------- */

delete
    FROM dbo.PWTTRE
    WHERE LB_NOM_SCN_SUN = @LB_NOM_SCN_SUN ; 

    INSERT INTO dbo.PWTTRE
    (
        LB_NOM_SCN_SUN,
        LB_TRT,
        DA_DEB_DEL_TRT,
        DA_DON_A_TRT,
        DA_FIN_DEL_FOR,
        NO_SEQ,
        LB_DOMAINE,
        CD_FRQ_ALI,
        CD_TYP_SRC
    )
    VALUES
    (
        @LB_NOM_SCN_SUN,
		'Alimentation des tables OWT_* et OIT_*_HISTO depuis les tables OIT_* de Crealia',
        @DT_JOUR_INITIAL,
        NULL,
        NULL,
        1,
        N'Recouvrement',
        N'J',
        N'B'
    );



/* 2. Borne initiale --------------------------------------------------------- */

delete

    FROM dbo.ORT_BORNE_JOURNEE
    WHERE DT_JOUR = @DT_JOUR_INITIAL
    INSERT INTO dbo.ORT_BORNE_JOURNEE
    (
	    LB_PROJET,
        DT_JOUR,
        DT_BORNE,
        TYPE_BORNE,
        ORIGINE_VALEUR,
        DT_POSE,
        COMMENTAIRE
    )
    VALUES
    (
	    'LIGIS',
        @DT_JOUR_INITIAL,
        @DT_BORNE_INITIALE,
        N'INIT',
        N'MANUEL',
        CONVERT(DATETIME2(3), GETDATE()),
        N'Borne initiale - demarrage DT-1374'
    );

