/* ============================================================================
   04_INSER_LIGNE_ORT
   A EXECUTER SUR LE DWH, apres 01 (tables creees) et apres le generateur.

   Alimente le parametrage, en trois temps :

     A. ORT_PARAM_HISTORISATION_TRACES  -  une ligne par colonne
        Vient de la SORTIE du generateur de parametrage
        (00_GENER_SCRIPT_LIGIS, troisieme generateur). Coller sa colonne
        ScriptComplet dans la section A.

     B. ORT_PARAM_FLUX pour les flux CDC  -  une ligne par table
        Genere dynamiquement a partir des colonnes deja chargees en A.
        Aucune saisie : la section B se joue telle quelle.

     C. ORT_PARAM_FLUX pour les flux FICHIER  -  une ligne par fichier
        Saisie manuelle : les fichiers ne sont pas dans le CDC. Un modele
        commente est fourni en section C, avec un exemple renseigne.

   L'ordre A -> B -> C est imperatif : B lit ce que A a insere.
   ============================================================================ */


/* ============================================================================
   SECTION A  -  PARAMETRAGE COLONNE  (sortie du generateur)
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR DE PARAMETRAGE <<<


/* ============================================================================
   SECTION B  -  FLUX CDC  (dynamique, ne rien modifier)

   Une ligne DELTA + BCP + SCD2 par table decrite en section A, avec la cible
   et la source reprises de la ligne cle. Le mode d'alimentation par defaut
   est SCD2 ; ajuster ensuite par UPDATE si une table doit etre en SCD1,
   AJOUT ou AUCUNE.
   ============================================================================ */

INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, FL_INIT, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
SELECT
    S.LB_PROJET, S.LB_TABLE_ODS, S.LB_TABLE_DWH, S.LB_SOURCE,
    N'DELTA', N'BCP', N'SCD2',
    1, 0, 100 + (ROW_NUMBER() OVER (ORDER BY S.LB_TABLE_ODS)) * 10, S.LB_FILTRE_WHERE,
    N'ods', N'dbo', N'OIT_TEC_AUDIT_CDC', '07:45:00',
    SYSDATETIME(), N'INIT', N'Flux CDC cree depuis le parametrage colonne'
FROM
(
    SELECT T.LB_PROJET, T.LB_TABLE_ODS, T.LB_TABLE_DWH, T.LB_SOURCE, T.LB_FILTRE_WHERE,
           Rang = ROW_NUMBER() OVER
           (
               PARTITION BY T.LB_PROJET, T.LB_TABLE_ODS
               ORDER BY CASE WHEN T.FL_CLEF = 1 THEN 0 ELSE 1 END, T.NO_CHAMP
           )
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
) AS S
WHERE S.Rang = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
      WHERE F.LB_PROJET = S.LB_PROJET AND F.LB_TABLE_ODS = S.LB_TABLE_ODS
  );
GO


/* ============================================================================
   SECTION C  -  FLUX FICHIER  (saisie manuelle)

   Une ligne par fichier delimite. A dupliquer et renseigner. Les colonnes de
   ce flux doivent aussi etre declarees en section A (le generateur ne les
   connait pas : elles se saisissent a la main dans ORT_PARAM_HISTORISATION_TRACES).

   Exemple renseigne, a adapter puis decommenter :

INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, FL_INIT, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    LB_FICHIER, LB_REPERTOIRE, LB_DELIMITEUR, NO_LIGNE_DEBUT, LB_ENCODAGE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
VALUES
(
    N'LIGIS', N'OIT_PITOPE_TABLEREF', N'OWT_PITOPE_TABLEREF', NULL,
    N'FULL', N'CSV', N'SCD1',
    1, 0, 900, NULL,
    N'ods', N'dbo', NULL, NULL,
    N'PITOPE_TABLEREF.csv', N'\\kenya\dsi\datalib', N';', 2, N'65001',
    SYSDATETIME(), N'INIT', N'Referentiel livre en CSV, etat courant'
);
GO
   ============================================================================ */
