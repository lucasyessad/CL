-- schema logique : MSSQL_DWH
-- type : S

DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';

INSERT INTO <?=odiRef.getObjectName("L", "ORT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
       (LB_PROJET, DT_JOUR, NO_SEQ, FL_TRAITE, LB_NOM_SCN_SUN)
SELECT @LB_PROJET,
       T.DT_JOUR,
       (ROW_NUMBER() OVER (ORDER BY T.DT_JOUR)) AS SEQ,
       0 AS FL_TRAITE,
       '<?=odiRef.getSession("SESS_NAME") ?>' AS LB_NOM_SCN_SUN
FROM
(
    /* Journees ouvrables de la periode cadree (quotidien). */
    SELECT DISTINCT convert(date, DT_JOUR, 121) as DT_JOUR
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND convert(date, DT_JOUR, 121) >  (select convert(date, DA_DEB_DEL_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = @LB_PROJET)
      and convert(date, DT_JOUR, 121) <= (select convert(date, DA_DON_A_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = @LB_PROJET)

    UNION

    /* Journees des bornes d'initialisation non traitees : elles peuvent etre
       anterieures au calendrier courant (date de reprise choisie a la MEP),
       donc on les recupere directement depuis ORT_BORNE_JOURNEE. */
    SELECT DISTINCT convert(date, B.DT_JOUR, 121) as DT_JOUR
    FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
    WHERE B.LB_PROJET = @LB_PROJET
      AND B.TYPE_BORNE = N'INIT'
      AND B.FL_TRAITE = 0
) AS T
ORDER BY SEQ ASC
