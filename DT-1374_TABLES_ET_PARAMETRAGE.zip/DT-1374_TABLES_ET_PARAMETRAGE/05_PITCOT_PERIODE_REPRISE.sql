/* ============================================================================
   DT-1374 - dbo.PITCOT_PERIODE_REPRISE  (standard maison)
   File des journees a traiter, regeneree a chaque execution par l'etape
   IOM_LIG_RECUP_DATES et flaguee par IOM_LIG_FLAG_DATES.

   CETTE TABLE EXISTE TRES PROBABLEMENT DEJA : elle est partagee par les
   autres chaines du projet (ex IOM_MNI_COTATION_PRUD_CHGODS). Le script est
   donc volontairement NON DESTRUCTIF (creation seulement si absente) et ne
   modifie jamais une table existante.

   >>> A FAIRE AVANT DEPLOIEMENT : executer le bloc de controle en fin de
       fichier. Si la table existe deja avec des noms ou des types differents
       (TRAITE en CHAR(1), colonne SEQ au lieu de NO_SEQ...), NE PAS la
       recreer : aligner a la place les etapes 05 et 12 du package sur la
       structure reelle.

   Colonnes attendues par le package, dans cet ordre (l'INSERT de l'etape
   IOM_LIG_RECUP_DATES est positionnel, sans liste de colonnes) :
       DT_CAL, NO_SEQ, TRAITE, LB_NOM_SCN_SUN
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PITCOT_PERIODE_REPRISE
    (
        DT_CAL          DATE           NOT NULL,
        NO_SEQ          INT            NOT NULL,
        TRAITE          BIT            NOT NULL DEFAULT (0),
        LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,
        CONSTRAINT PK_PITCOT_PERIODE_REPRISE PRIMARY KEY (LB_NOM_SCN_SUN, DT_CAL)
    );

    -- Lecture de la variable ODI : plus ancienne date TRAITE = 0 du scenario.
    CREATE NONCLUSTERED INDEX IX_PITCOT_PERIODE_REPRISE_A_TRAITER
        ON dbo.PITCOT_PERIODE_REPRISE (LB_NOM_SCN_SUN, TRAITE, DT_CAL);
END
GO

/* ----------------------------------------------------------------------------
   CONTROLE DE STRUCTURE (a executer avant deploiement)
---------------------------------------------------------------------------- */
-- SELECT c.name AS colonne, t.name AS type, c.max_length, c.is_nullable
-- FROM sys.columns c
-- JOIN sys.types t ON t.user_type_id = c.user_type_id
-- WHERE c.object_id = OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE')
-- ORDER BY c.column_id;
--
-- -- Scenarios deja pilotes par cette table (modele a suivre) :
-- SELECT LB_NOM_SCN_SUN, COUNT(*) AS nb_dates, MIN(DT_CAL) AS du, MAX(DT_CAL) AS au
-- FROM dbo.PITCOT_PERIODE_REPRISE
-- GROUP BY LB_NOM_SCN_SUN ORDER BY LB_NOM_SCN_SUN;
