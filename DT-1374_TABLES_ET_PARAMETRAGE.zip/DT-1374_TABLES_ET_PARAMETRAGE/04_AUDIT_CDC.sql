/* ============================================================================
   DT-1374 - dbo.AUDIT_CDC  (base DWH INEO)
   Table de reception de la vue d'audit CDC exportee cote LIGIS
   (cdc.ZBCP_LIGIS_TEC_AUD_CDC_V), chargee par le BCPIN en meme temps que les
   traces. C'est la SEULE source de la borne de fin de journee : l'etape
   IOM_LIG_A0_POSE_BORNE y lit MIN(COALESCE(DT_FIN_LSN, DT_EXTRACT)) sur les
   instances du perimetre actif.

   Cette table n'est PAS generee par 06_GENERATION_OIT_OWT.sql : le perimetre
   de ce generateur est constitue des tables SOUS CDC (jointure sur
   cdc.TEC_AUD_CDC), or l'audit lui-meme n'est pas une table capturee.
   D'ou cette creation manuelle.

   ATTENTION - TYPE DE ID_INSTANCE A CONFIRMER : la capture consultee montre
   une valeur binaire longue (0xEDF4083E5884...). La longueur retenue ici
   (varbinary(128)) est une hypothese haute, sans risque pour un BULK INSERT
   mais A ALIGNER sur la source : executer le bloc "GENERATEUR" en fin de
   fichier cote base LIGIS pour obtenir la definition exacte.

   Chargement : TRUNCATE + BULK INSERT positionnel, comme les OIT_xxx.
   L'ordre des colonnes ci-dessous DOIT etre celui de la vue exportee.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.AUDIT_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.AUDIT_CDC
    (
        ID_INSTANCE   VARBINARY(128) NULL,   -- identifiant technique de l'instance de capture
        LB_INSTANCE   NVARCHAR(128)  NULL,   -- 'dbo_' + nom de la table source (ex 'dbo_CONTRAT')
        LB_DEB_LSN    BINARY(10)     NULL,   -- LSN de debut d'extraction (borne basse, exclue)
        LB_FIN_LSN    BINARY(10)     NULL,   -- LSN de fin d'extraction  (borne haute, incluse)
        DT_DEB_LSN    DATETIME2(3)   NULL,   -- datetime correspondant a LB_DEB_LSN
        DT_FIN_LSN    DATETIME2(3)   NULL,   -- datetime correspondant a LB_FIN_LSN  <- BORNE UTILISEE
        DT_EXTRACT    DATETIME2(3)   NULL    -- datetime de l'extraction  <- FALLBACK
    );

    -- L'etape A0 filtre sur LB_INSTANCE et agrege les datetimes.
    CREATE NONCLUSTERED INDEX IX_AUDIT_CDC_INSTANCE
        ON dbo.AUDIT_CDC (LB_INSTANCE) INCLUDE (DT_FIN_LSN, DT_EXTRACT);
END
GO

/* ----------------------------------------------------------------------------
   CONTROLE INDISPENSABLE AVANT RECETTE
   Les trois colonnes DT_ etaient NULL sur l'environnement consulte. Tant
   qu'elles ne sont pas alimentees par le traitement amont (DSI), l'etape A0
   loguera un avertissement dans ORT_AUDIT_CHARGEMENT et AUCUNE journee ne
   deviendra eligible (comportement volontairement sur, mais bloquant).
---------------------------------------------------------------------------- */
-- SELECT LB_INSTANCE, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
-- FROM dbo.AUDIT_CDC
-- ORDER BY LB_INSTANCE;

/* ----------------------------------------------------------------------------
   GENERATEUR (a executer sur la base LIGIS) : produit la definition EXACTE
   de la table de reception a partir de la vue d'audit reellement exportee.
   Comparer le resultat au CREATE TABLE ci-dessus et ajuster si necessaire.
---------------------------------------------------------------------------- */
-- SELECT 'CREATE TABLE dbo.AUDIT_CDC (' + CHAR(13) + '    ' +
--        STRING_AGG(
--            QUOTENAME(c.name) + ' ' +
--            CASE
--              WHEN t.name IN ('varchar','char','varbinary','binary')
--                   THEN t.name + '(' + CASE WHEN c.max_length = -1 THEN 'MAX'
--                                            ELSE CAST(c.max_length AS varchar(10)) END + ')'
--              WHEN t.name IN ('nvarchar','nchar')
--                   THEN t.name + '(' + CASE WHEN c.max_length = -1 THEN 'MAX'
--                                            ELSE CAST(c.max_length/2 AS varchar(10)) END + ')'
--              WHEN t.name IN ('decimal','numeric')
--                   THEN t.name + '(' + CAST(c.precision AS varchar(10)) + ',' + CAST(c.scale AS varchar(10)) + ')'
--              WHEN t.name IN ('datetime2','time','datetimeoffset')
--                   THEN t.name + '(' + CAST(c.scale AS varchar(10)) + ')'
--              ELSE t.name
--            END + ' NULL',
--            ',' + CHAR(13) + '    ') WITHIN GROUP (ORDER BY c.column_id)
--        + CHAR(13) + ');'
-- FROM sys.columns c
-- JOIN sys.types t ON t.user_type_id = c.user_type_id
-- WHERE c.object_id = OBJECT_ID('cdc.ZBCP_LIGIS_TEC_AUD_CDC_V');
