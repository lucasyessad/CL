/* ============================================================================
   DT-1374 - dbo.ORT_AUDIT_CHARGEMENT
   Audit au standard maison : structure IDENTIQUE a AUDIT_CHARGEMENT du
   projet CL_ESTIM (PS_CHARGEMENT_CSV_ODS / PS_CHARGEMENT_ODS_DWH), nom
   prefixe ORT pour l'harmonie avec les autres tables techniques du projet.

   Cette table porte TOUT le suivi detaille : une ligne par etape et par
   table, avec volumetrie (NB_LIGNE), statut, message et bornes de temps.
   C'est elle qui a permis de supprimer une table de suivi dediee.
   Elle est aussi LUE par le package : les etapes D2, D3 et D4 ecartent les
   tables deja en KO dans la meme session, d'ou les index ci-dessous.

   Conventions DT-1374 :
     - LB_PROJET     = 'LIGIS'
     - LB_CHARGEMENT = etape + journee entre crochets, ex 'HISTO OWT [2026-07-18]'
     - LB_SOURCE     = table OIT concernee ('*TOUTES*' pour le bilan de journee)
     - CD_STATUT     = 'OK' / 'KO' seulement ; les avertissements sont des 'OK'
                       avec LB_ERREUR renseigne ('AVERTISSEMENT: ...')
     - ID_TRT_ALI    = numero de session ODI (SESS_NO)
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_AUDIT_CHARGEMENT', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_AUDIT_CHARGEMENT
    (
        ID_TRT_ALI     INT             NULL,
        LB_PROJET      NVARCHAR(50)    NULL,
        LB_CHARGEMENT  NVARCHAR(100)   NULL,
        LB_SOURCE      NVARCHAR(200)   NULL,
        LB_CIBLE       NVARCHAR(200)   NULL,
        NB_LIGNE       INT             NULL,
        CD_STATUT      NVARCHAR(10)    NULL,
        LB_ERREUR      NVARCHAR(MAX)   NULL,
        DT_DEBUT       DATETIME        NULL,
        DT_FIN         DATETIME        NULL
    );

    -- Supervision (recette, exploitation).
    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_PROJET_DT
        ON dbo.ORT_AUDIT_CHARGEMENT (LB_PROJET, DT_DEBUT);

    -- Lecture par les etapes D2 / D3 / D4 : tables en KO de la session courante.
    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_SESSION
        ON dbo.ORT_AUDIT_CHARGEMENT (ID_TRT_ALI, LB_PROJET, CD_STATUT)
        INCLUDE (LB_SOURCE, LB_CHARGEMENT);
END
GO
