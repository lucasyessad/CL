/* ============================================================================
   DT-1374 - INITIALISATION ONE-SHOT (mise en production)
   A executer UNE fois, apres les scripts 01 a 07, avant le premier lancement
   du package. Script MANUEL (SSMS) : noms en clair, sans substitution ODI.
   Completer les valeurs <...>.
   ============================================================================ */

-- 1. Ligne PWTTRE du scenario. LB_NOM_SCN_SUN doit valoir EXACTEMENT le
--    SESS_NAME du package, c'est-a-dire le nom du scenario genere :
--    'IOM_LIGIS_TRACE_CSTIMG'. C'est la cle utilisee par les procedures
--    maison T003 / T004 et par les etapes 03, 05 et 12 du package.
--    DA_DEB_DEL_TRT = veille ouvree du premier jour a traiter : les journees
--    generees sont STRICTEMENT superieures a cette date.
--    DA_DON_A_TRT et DA_FIN_DEL_FOR restent NULL : T003 et l'etape de
--    cadrage les positionnent a chaque execution.
--    >>> Aligner les autres colonnes sur une ligne existante, par exemple
--        celle de IOM_MNI_COTATION_PRUD_CHGODS.
IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE
               WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
    INSERT INTO dbo.PWTTRE (LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_DON_A_TRT,
                            DA_FIN_DEL_FOR, NO_SEQ)
    VALUES ('IOM_LIGIS_TRACE_CSTIMG', '<AAAA-MM-JJ veille ouvree>', NULL,
            NULL, 1);

-- 2. Borne initiale : point de depart de la toute premiere fenetre.
--    DT_JOUR doit etre COHERENT avec DA_DEB_DEL_TRT ci-dessus (meme jour).
--    DT_BORNE = derniere datetime extraite connue au moment de l'activation
--    (idealement lue dans dbo.AUDIT_CDC juste avant le demarrage).
IF NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE TYPE_BORNE = 'INIT')
    INSERT INTO dbo.ORT_BORNE_JOURNEE
        (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
    VALUES
        ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss.mmm>', 'INIT', 'MANUEL',
         'Borne initiale - demarrage historisation traces LIGIS');

-- 3. Aide : valeur de borne initiale proposee par l'audit CDC deja charge.
--    (a executer AVANT le point 2 pour recuperer la datetime a y reporter)
-- SELECT borne_proposee = MIN(COALESCE(DT_FIN_LSN, DT_EXTRACT))
-- FROM dbo.AUDIT_CDC
-- WHERE LB_INSTANCE IN (SELECT DISTINCT 'dbo_' + SUBSTRING(LB_TABLE_ODS, 5, 200)
--                       FROM dbo.ORT_PARAM_HISTORISATION_TRACES
--                       WHERE LB_PROJET = 'LIGIS'
--                         AND FL_CLEF = 1 AND FL_CHARGEMENT = 1
--                         AND LB_TABLE_ODS LIKE 'OIT[_]%');

-- 4. Nettoyage d'un deploiement anterieur : la table de suivi jour x table a
--    ete supprimee du dispositif (son contenu est porte par
--    dbo.ORT_AUDIT_CHARGEMENT).
-- DROP TABLE dbo.ORT_SUIVI_JOUR_TABLE;

-- 5. Verification : PWTCHE ne doit contenir aucune ligne pour ce scenario
--    (le traitement n'est pas alimente par fichier). Si c'est le cas, la 3e
--    tache de T003 inserera 0 ligne dans PWTSPF : comportement attendu.
SELECT * FROM dbo.PWTCHE WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG';
