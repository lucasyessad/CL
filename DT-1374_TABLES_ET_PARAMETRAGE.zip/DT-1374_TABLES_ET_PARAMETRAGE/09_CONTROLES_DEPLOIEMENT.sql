/* ============================================================================
   DT-1374 - Controles a passer apres deploiement des tables (01 a 08)
   Toutes les requetes doivent renvoyer le resultat attendu indique.
   ============================================================================ */

/* 1. Les 5 tables du dispositif existent-elles ?  (attendu : 5 lignes 'OK') */
SELECT nom = t.nom,
       etat = CASE WHEN OBJECT_ID(t.nom, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END
FROM (VALUES ('dbo.ORT_PARAM_HISTORISATION_TRACES'),
             ('dbo.ORT_BORNE_JOURNEE'),
             ('dbo.ORT_AUDIT_CHARGEMENT'),
             ('dbo.AUDIT_CDC'),
             ('dbo.PITCOT_PERIODE_REPRISE')) t(nom);

/* 2. Tables maison utilisees par le package (attendu : 'OK' partout) */
SELECT nom = t.nom,
       etat = CASE WHEN OBJECT_ID(t.nom, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END
FROM (VALUES ('dbo.PWTTRE'), ('dbo.PWTSDC'), ('dbo.PWTSPF'),
             ('dbo.PWTCHE'), ('dbo.PRTCAL')) t(nom);

/* 3. Parametrage : tables actives du perimetre (attendu : la liste des
      tables a historiser, avec leur nombre de colonnes cle) */
SELECT LB_TABLE_ODS, LB_TABLE_DWH,
       nb_colonnes      = COUNT(*),
       nb_colonnes_cle  = SUM(CASE WHEN FL_CLEF = 1 THEN 1 ELSE 0 END),
       nb_colonnes_tri  = SUM(CASE WHEN FL_ORDRE_TRI = 1 THEN 1 ELSE 0 END),
       filtre           = MAX(LB_FILTRE_WHERE)
FROM dbo.ORT_PARAM_HISTORISATION_TRACES
WHERE LB_PROJET = 'LIGIS'
GROUP BY LB_TABLE_ODS, LB_TABLE_DWH
ORDER BY LB_TABLE_ODS;

/* 4. Parametrage incoherent (attendu : 0 ligne) */
SELECT LB_TABLE_ODS, probleme
FROM (
    SELECT LB_TABLE_ODS,
           probleme = CASE
             WHEN SUM(CASE WHEN FL_CLEF = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne cle (FL_CLEF = 1)'
             WHEN SUM(CASE WHEN FL_ORDRE_TRI = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne d''ordre (FL_ORDRE_TRI = 1)'
             WHEN SUM(CASE WHEN FL_CLEF = 1 AND (LB_CHAMP_ODS IS NULL OR LB_CHAMP_DWH IS NULL)
                           THEN 1 ELSE 0 END) > 0
                  THEN 'ligne cle avec mapping ODS/DWH incomplet'
             ELSE NULL END
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_PROJET = 'LIGIS'
    GROUP BY LB_TABLE_ODS
) c
WHERE probleme IS NOT NULL
ORDER BY LB_TABLE_ODS;

/* 5. Chaque table active a-t-elle bien sa table OIT et sa table OWT ?
      (attendu : 0 ligne) */
SELECT LB_TABLE_ODS, LB_TABLE_DWH,
       table_ods = CASE WHEN OBJECT_ID('ods.' + LB_TABLE_ODS, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END,
       table_dwh = CASE WHEN OBJECT_ID('dbo.' + LB_TABLE_DWH, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END
FROM (SELECT DISTINCT LB_TABLE_ODS, LB_TABLE_DWH
      FROM dbo.ORT_PARAM_HISTORISATION_TRACES
      WHERE LB_PROJET = 'LIGIS' AND FL_CLEF = 1 AND FL_CHARGEMENT = 1) p
WHERE OBJECT_ID('ods.' + LB_TABLE_ODS, 'U') IS NULL
   OR OBJECT_ID('dbo.' + LB_TABLE_DWH, 'U') IS NULL;

/* 6. Colonnes parametrees absentes des tables physiques (attendu : 0 ligne).
      Detecte les renommages oublies apres modification manuelle du mapping. */
SELECT p.LB_TABLE_ODS, p.NO_CHAMP, p.LB_CHAMP_ODS, p.LB_CHAMP_DWH,
       manquant = CASE WHEN co.name IS NULL THEN 'colonne ODS absente'
                       ELSE 'colonne DWH absente' END
FROM dbo.ORT_PARAM_HISTORISATION_TRACES p
LEFT JOIN sys.columns co ON co.object_id = OBJECT_ID('ods.' + p.LB_TABLE_ODS)
                        AND co.name = p.LB_CHAMP_ODS
LEFT JOIN sys.columns cd ON cd.object_id = OBJECT_ID('dbo.' + p.LB_TABLE_DWH)
                        AND cd.name = p.LB_CHAMP_DWH
WHERE p.LB_PROJET = 'LIGIS'
  AND p.LB_CHAMP_ODS IS NOT NULL AND p.LB_CHAMP_DWH IS NOT NULL
  AND (co.name IS NULL OR cd.name IS NULL)
ORDER BY p.LB_TABLE_ODS, p.NO_CHAMP;

/* 7. Audit CDC : les datetimes sont-elles alimentees par l'amont ?
      (attendu : aucune ligne avec DT_FIN_LSN ET DT_EXTRACT a NULL,
       sinon la pose de borne restera bloquee) */
SELECT LB_INSTANCE, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM dbo.AUDIT_CDC
ORDER BY LB_INSTANCE;

/* 8. Bornes posees et continuite des fenetres (attendu : 0 ligne au 2e SELECT) */
SELECT TOP (20) * FROM dbo.ORT_BORNE_JOURNEE ORDER BY DT_JOUR DESC;

SELECT b1.DT_JOUR, b1.DT_BORNE, b2.DT_JOUR AS jour_suivant, b2.DT_BORNE AS borne_suivante
FROM dbo.ORT_BORNE_JOURNEE b1
JOIN dbo.ORT_BORNE_JOURNEE b2 ON b2.DT_JOUR > b1.DT_JOUR
WHERE b2.DT_BORNE <= b1.DT_BORNE;   -- chainage incoherent
