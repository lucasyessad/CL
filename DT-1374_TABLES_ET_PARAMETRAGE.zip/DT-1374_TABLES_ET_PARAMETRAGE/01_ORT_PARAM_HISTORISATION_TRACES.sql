/* ============================================================================
   DT-1374 - dbo.ORT_PARAM_HISTORISATION_TRACES
   Parametrage GRAIN COLONNE, au format maison PARAM_CHARGEMENT : une ligne
   par champ (NO_CHAMP), mapping LB_CHAMP_ODS -> LB_CHAMP_DWH (les noms
   peuvent differer), cle fonctionnelle portee par FL_CLEF = 1, activation de
   la table par FL_CHARGEMENT = 1 sur la ligne cle.

   Extensions propres a l'historisation des traces :
     - FL_ORDRE_TRI    : 1 = colonne d'horodatage servant a la fois de borne
                         de fenetre (la 1ere au sens NO_CHAMP) et d'ordre
                         "derniere trace" (les suivantes departagent).
                         Valeurs generees : DT_COMMIT_TEC puis CD_SEQ_TEC.
     - LB_FILTRE_WHERE : filtre optionnel sur la source, porte par la ligne
                         cle (ex : MEM_TYPE = 'CNT').

   Colonnes techniques FIXES, non parametrees (jamais mappees par le
   package, presentes en lignes documentaires uniquement) :
     - ODS : FL_FIN_JOURNEE      - DWH : DD_VAL, DF_VAL, FL_VER_CRT

   REVISION : script rendu NON DESTRUCTIF (le DROP TABLE de la version
   precedente effacait tout le parametrage a chaque redeploiement) et cle
   primaire etendue a LB_PROJET, car l'alimentation supprime desormais par
   (LB_PROJET, LB_TABLE_ODS).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PARAM_HISTORISATION_TRACES', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
    (
        LB_PROJET        NVARCHAR(50)   NOT NULL DEFAULT ('LIGIS'),
        LB_SOURCE        NVARCHAR(200)  NULL,             -- instance CDC source, ex 'dbo_CONTRAT' (informatif)
        LB_TABLE_ODS     NVARCHAR(128)  NOT NULL,         -- ex 'OIT_CONTRAT'
        LB_TABLE_DWH     NVARCHAR(200)  NOT NULL,         -- ex 'OWT_CONTRAT'
        NO_CHAMP         INT            NOT NULL,
        LB_CHAMP_ODS     NVARCHAR(128)  NULL,
        LB_CHAMP_DWH     NVARCHAR(128)  NULL,
        LB_SCD           NVARCHAR(30)   NULL,             -- 'TYPE 2' sur la ligne cle (informatif)
        FL_CLEF          BIT            NOT NULL DEFAULT (0),
        FL_CHARGEMENT    BIT            NULL,             -- 1 sur la ligne cle = table active
        FL_ORDRE_TRI     BIT            NOT NULL DEFAULT (0),
        LB_FILTRE_WHERE  NVARCHAR(1000) NULL,
        CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
            PRIMARY KEY (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
    );

    -- Le package parcourt les tables actives : FL_CLEF = 1 ET FL_CHARGEMENT = 1.
    CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ACTIVES
        ON dbo.ORT_PARAM_HISTORISATION_TRACES (FL_CLEF, FL_CHARGEMENT)
        INCLUDE (LB_TABLE_ODS, LB_TABLE_DWH);
END
GO

/* ----------------------------------------------------------------------------
   MODELE D'ALIMENTATION (genere automatiquement par
   07_ALIMENTATION_PARAM_HISTORISATION.sql - exemple ici a titre de lecture)
-------------------------------------------------------------------------------
INSERT INTO dbo.ORT_PARAM_HISTORISATION_TRACES
    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,
     LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF, FL_CHARGEMENT,
     FL_ORDRE_TRI, LB_FILTRE_WHERE)
VALUES
 ('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',1,'NUM_CONTRAT','NUM_CONTRAT','TYPE 2',1,1,0,NULL)
-- fenetre + ordre "derniere trace" :
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',2,'DT_COMMIT_TEC','DT_COMMIT_TEC',NULL,0,NULL,1,NULL)
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',3,'CD_SEQ_TEC','CD_SEQ_TEC',NULL,0,NULL,1,NULL)
-- tracabilite CDC reprise dans OWT :
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',4,'ID_INSTANCE_TEC','ID_INSTANCE_TEC',NULL,0,NULL,0,NULL)
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',5,'CD_CMD_TEC','CD_CMD_TEC',NULL,0,NULL,0,NULL)
-- colonnes metier :
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',6,'CD_ETAT','CD_ETAT',NULL,0,NULL,0,NULL)
-- lignes documentaires (colonnes techniques, non mappees) :
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',7,'FL_FIN_JOURNEE',NULL,NULL,0,NULL,0,NULL)
,('LIGIS','dbo_CONTRAT','OIT_CONTRAT','OWT_CONTRAT',8,NULL,'DD_VAL',NULL,0,NULL,0,NULL);
---------------------------------------------------------------------------- */
