/* ============================================================================
   DT-1374 - dbo.ORT_BORNE_JOURNEE
   Bornes de fin de journee : referentiel des fenetres de traitement.
   La fenetre de la journee J est  ] borne(J-1) ; borne(J) ]  : les fenetres
   se touchent exactement, aucune modification n'est perdue, y compris celles
   faites apres la fin du quotidien (quotidien fini a 22h00, modifications de
   22h30 a 07h45 -> fenetre de la journee suivante, par construction).

   DEUX TYPES DE BORNE :
     - QUOTIDIEN   : cas nominal, une borne par journee ouvree ;
     - MULTI_JOURS : rattrapage (batch KO non repris, CDC couvrant plusieurs
                     jours) : UNE borne clot toute la periode, l'image
                     construite est celle de la DERNIERE journee ; les
                     journees intermediaires sont absorbees (aucune perte).
     - INIT        : borne initiale posee une fois a la mise en production.

   DT_BORNE = MIN(COALESCE(DT_FIN_LSN, DT_EXTRACT)) lu dans dbo.AUDIT_CDC sur
   les instances du perimetre actif : la table la moins avancee garantit la
   completude de toutes les autres. Type DATETIME2(3) = precision exacte de
   DT_COMMIT_TEC, donc aucune ambiguite a la milliseconde aux frontieres.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_BORNE_JOURNEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_BORNE_JOURNEE
    (
        DT_JOUR                 DATE           NOT NULL,  -- journee ouvree que cette borne CLOT
        DT_BORNE                DATETIME2(3)   NOT NULL,  -- derniere datetime extraite (audit CDC)
        TYPE_BORNE              NVARCHAR(15)   NOT NULL DEFAULT ('QUOTIDIEN'),
        ORIGINE_VALEUR          NVARCHAR(20)   NOT NULL DEFAULT ('AUDIT_CDC'),
        DT_JOUR_DEBUT_PERIODE   DATE           NULL,      -- MULTI_JOURS : premiere journee couverte
        DT_POSE                 DATETIME       NOT NULL DEFAULT (GETDATE()),
        COMMENTAIRE             NVARCHAR(500)  NULL,
        CONSTRAINT PK_ORT_BORNE_JOURNEE PRIMARY KEY (DT_JOUR),
        CONSTRAINT UQ_ORT_BORNE_JOURNEE_DT_BORNE UNIQUE (DT_BORNE),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_TYPE
            CHECK (TYPE_BORNE IN ('QUOTIDIEN','MULTI_JOURS','INIT')),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_ORIGINE
            CHECK (ORIGINE_VALEUR IN ('AUDIT_CDC','DEFAUT','MANUEL'))
    );
END
GO

/* La borne initiale (one-shot MEP) est posee par 08_INIT_MEP_ONE_SHOT.sql. */
