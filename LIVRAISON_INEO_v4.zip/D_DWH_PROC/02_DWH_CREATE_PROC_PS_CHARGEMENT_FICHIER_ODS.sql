/* ============================================================================
   PS_CHARGEMENT_FICHIER_ODS

   Charge un fichier délimité dans sa table ODS. Le format vient du
   paramétrage : délimiteur, ligne de début, encodage.

   Le job parcourt le répertoire et appelle la procédure une fois par
   fichier réel ; le répertoire est transmis par le job (%DATALIB%).

   Après chargement, la première colonne FL_ORDRE_TRI = 1 du flux reçoit la
   date d'extraction : celle de la ligne d'audit de LB_SOURCE si elle existe,
   sinon la date d'import. C'est elle qui rattache l'état complet à sa
   journée, comme DT_COMMIT_TEC pour un fichier bcp.

   BULK INSERT lit le fichier depuis le MOTEUR SQL : le compte de service
   doit avoir accès au répertoire.
   ============================================================================ */
USE [DWH];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_CHARGEMENT_FICHIER_ODS
(
    @LB_PROJET     NVARCHAR(50),
    @LB_FICHIER    NVARCHAR(260),
    @LB_REPERTOIRE NVARCHAR(260),
    @ID_TRT_ALI    BIGINT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @schema_ods  NVARCHAR(128),
        @table_audit NVARCHAR(128),
        @delimiteur  NVARCHAR(10),
        @ligne_debut INT,
        @encodage    NVARCHAR(20),
        @col_date    NVARCHAR(128),
        @dt_extract  DATETIME2(3),
        @chemin      NVARCHAR(520),
        @sql         NVARCHAR(MAX),
        @nb          BIGINT = 0,
        @msg         NVARCHAR(2000);

    IF @ID_TRT_ALI IS NULL
        SET @ID_TRT_ALI = CONVERT(BIGINT, FORMAT(SYSDATETIME(), N'yyyyMMddHHmmss'));

    /* Le job transmet le nom réel ; LB_FICHIER peut être un masque à
       suffixe libre (PREFIXE_*.csv). Le plus long masque gagne, pour qu'un
       nom exact prime sur un masque général. */
    SELECT TOP (1)
        @table_ods   = LB_TABLE_ODS,
        @ods_complet = QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
        @source      = LB_SOURCE,
        @schema_ods  = LB_SCHEMA_ODS,
        @table_audit = LB_TABLE_AUDIT,
        @delimiteur  = LB_DELIMITEUR,
        @ligne_debut = ISNULL(NO_LIGNE_DEBUT, 1),
        @encodage    = LB_ENCODAGE
    FROM dbo.ORT_PARAM_FLUX
    WHERE LB_PROJET  = @LB_PROJET
      AND FL_ACTIF   = 1
      AND CD_FORMAT  = N'CSV'
      AND LB_FICHIER IS NOT NULL
      AND @LB_FICHIER LIKE REPLACE(LB_FICHIER, N'*', N'%')
    ORDER BY LEN(LB_FICHIER) DESC;

    IF @table_ods IS NULL
    BEGIN
        SET @msg = N'Aucun flux paramétré pour le fichier ' + @LB_FICHIER
                 + N' (projet ' + @LB_PROJET + N').';
        THROW 56010, @msg, 1;
    END;

    IF ISNULL(@LB_REPERTOIRE, N'') = N''
    BEGIN
        SET @msg = N'Répertoire non transmis par le job : impossible de localiser '
                 + @LB_FICHIER + N'.';
        THROW 56011, @msg, 1;
    END;

    SET @chemin = @LB_REPERTOIRE
                + CASE WHEN RIGHT(@LB_REPERTOIRE, 1) = N'\' THEN N'' ELSE N'\' END
                + @LB_FICHIER;

    SELECT TOP (1) @col_date = LB_CHAMP_ODS
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_PROJET = @LB_PROJET AND LB_TABLE_ODS = @table_ods
      AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
    ORDER BY NO_CHAMP;

    BEGIN TRY
        /* Un fichier délimité porte un état complet : la cible est vidée. */
        SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
        EXEC sp_executesql @sql;

        SET @sql =
              N'BULK INSERT ' + @ods_complet                                       + CHAR(13)
            + N'FROM ''' + REPLACE(@chemin, N'''', N'''''') + N''''                + CHAR(13)
            + N'WITH ('                                                            + CHAR(13)
            + N'    FIELDTERMINATOR = ''' + REPLACE(@delimiteur, N'''', N'''''') + N''',' + CHAR(13)
            + N'    ROWTERMINATOR   = ''0x0a'','                                   + CHAR(13)
            + N'    FIRSTROW        = ' + CONVERT(NVARCHAR(10), @ligne_debut) + N',' + CHAR(13)
            + CASE WHEN @encodage IS NULL THEN N''
                   ELSE N'    CODEPAGE        = ''' + @encodage + N''',' + CHAR(13) END
            /* Une seule ligne mal formée fait échouer le chargement : une table
               de référence à moitié chargée serait pire qu'une table non
               chargée. La relance est toujours possible. */
            + N'    MAXERRORS       = 0,'                                          + CHAR(13)
            + N'    TABLOCK'                                                       + CHAR(13)
            + N');';
        EXEC sp_executesql @sql;

        /* Date de rattachement : audit de l'instance, sinon date d'import. */
        IF @col_date IS NOT NULL
        BEGIN
            IF @source IS NOT NULL AND @table_audit IS NOT NULL
            BEGIN
                SET @sql = N'SELECT @p_dt = MAX(DT_EXTRACT) FROM '
                         + QUOTENAME(@schema_ods) + N'.' + QUOTENAME(@table_audit)
                         + N' WHERE LB_INSTANCE = @p_source;';
                EXEC sp_executesql @sql, N'@p_source nvarchar(260), @p_dt datetime2(3) OUTPUT',
                     @p_source = @source, @p_dt = @dt_extract OUTPUT;
            END;
            SET @dt_extract = ISNULL(@dt_extract, SYSDATETIME());

            SET @sql = N'UPDATE ' + @ods_complet + N' SET ' + QUOTENAME(@col_date) + N' = @p_dt;';
            EXEC sp_executesql @sql, N'@p_dt datetime2(3)', @p_dt = @dt_extract;
        END;

        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, @nb, N'OK',
             CASE WHEN @col_date IS NULL THEN N'AVERTISSEMENT: aucune colonne FL_ORDRE_TRI, état non daté.'
                  ELSE N'Daté au ' + CONVERT(NVARCHAR(23), @dt_extract, 121) END,
             @dt_debut, SYSDATETIME());
    END TRY
    BEGIN CATCH
        SET @msg = ERROR_MESSAGE();

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, 0, N'KO', @msg, @dt_debut, SYSDATETIME());

        THROW;
    END CATCH;
END;
GO
