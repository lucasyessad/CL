USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_CONTROLE_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @nb_avant    BIGINT,
        @nb_apres    BIGINT,
        @dt_debut    DATETIME2(3),
        @sql         NVARCHAR(MAX),
        @msg         NVARCHAR(2000),
        @statut      NVARCHAR(10),
        @nb_ko       INT = 0,
        @nb_total    BIGINT = 0,
        @nb_charge   BIGINT;

    /* Vérification de l'existence des lignes créées par la préparation. */
    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.ORT_AUDIT_CHARGEMENT
        WHERE ID_TRT_ALI     = @ID_TRT_ALI
          AND LB_PROJET      = @LB_PROJET
          AND LB_CHARGEMENT  = N'Chargement bcp -> ods'
          AND CD_STATUT IS NULL
    )
    BEGIN
        SET @msg =
              N'PS_CONTROLE_ODS : aucune preparation tracee pour ID_TRT_ALI = '
            + CONVERT(NVARCHAR(20), @ID_TRT_ALI)
            + N'. La preparation a-t-elle bien tourne ?';

        THROW 56020, @msg, 1;
    END;

    /* Récupération des tables à contrôler. */
    DECLARE cur_ctrl CURSOR LOCAL FAST_FORWARD FOR
        SELECT
            A.LB_CIBLE,
            QUOTENAME(F.LB_SCHEMA_ODS)
                + N'.'
                + QUOTENAME(F.LB_TABLE_ODS),
            A.LB_SOURCE,
            A.NB_LIGNE,
            A.DT_DEBUT
        FROM dbo.ORT_AUDIT_CHARGEMENT AS A
        INNER JOIN dbo.ORT_PARAM_FLUX AS F
            ON F.LB_PROJET = A.LB_PROJET
           AND F.LB_TABLE_ODS = A.LB_CIBLE
        WHERE A.ID_TRT_ALI    = @ID_TRT_ALI
          AND A.LB_PROJET     = @LB_PROJET
          AND A.LB_CHARGEMENT = N'Chargement bcp -> ods'
          AND A.CD_STATUT IS NULL
        ORDER BY A.LB_CIBLE;

    OPEN cur_ctrl;

    FETCH NEXT FROM cur_ctrl
    INTO
        @table_ods,
        @ods_complet,
        @source,
        @nb_avant,
        @dt_debut;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @statut = N'OK';
        SET @msg = NULL;
        SET @nb_apres = NULL;
        SET @nb_charge = 0;

        BEGIN TRY
            /* Comptage de la volumétrie après le chargement BCP. */
            SET @sql =
                N'SELECT @p_nb = COUNT_BIG(*) FROM '
                + @ods_complet
                + N';';

            EXEC sys.sp_executesql
                @sql,
                N'@p_nb BIGINT OUTPUT',
                @p_nb = @nb_apres OUTPUT;

            SET @nb_charge =
                ISNULL(@nb_apres, 0) - ISNULL(@nb_avant, 0);

            /*
                Une volumétrie inchangée n'est pas une erreur.

                Le fichier peut être vide et le BCP peut s'être terminé
                correctement avec zéro ligne chargée.
            */
            IF @nb_charge = 0
            BEGIN
                SET @statut = N'OK';
                SET @msg = N'Aucune ligne a charger : fichier vide ou sans nouvelle donnee.';
            END;

            /*
                Une volumétrie négative est anormale, car le nombre de lignes
                après le BCP ne doit pas être inférieur au nombre relevé
                pendant la préparation.
            */
            IF @nb_charge < 0
            BEGIN
                SET @statut = N'KO';
                SET @msg =
                      N'Volumetrie incoherente : '
                    + CONVERT(NVARCHAR(20), ISNULL(@nb_avant, 0))
                    + N' ligne(s) avant et '
                    + CONVERT(NVARCHAR(20), ISNULL(@nb_apres, 0))
                    + N' ligne(s) apres le chargement.';
            END;
        END TRY
        BEGIN CATCH
            SET @statut = N'KO';
            SET @msg = ERROR_MESSAGE();
            SET @nb_charge = 0;
        END CATCH;

        /* Mise à jour de la ligne créée par PS_PREPARATION_ODS. */
        UPDATE dbo.ORT_AUDIT_CHARGEMENT
        SET
            NB_LIGNE  = @nb_charge,
            CD_STATUT = @statut,
            LB_ERREUR = @msg,
            DT_FIN    = SYSDATETIME()
        WHERE ID_TRT_ALI     = @ID_TRT_ALI
          AND LB_PROJET      = @LB_PROJET
          AND LB_CHARGEMENT  = N'Chargement bcp -> ods'
          AND LB_CIBLE       = @table_ods;

        IF @statut = N'KO'
        BEGIN
            SET @nb_ko += 1;
        END;

        SET @nb_total += @nb_charge;

        FETCH NEXT FROM cur_ctrl
        INTO
            @table_ods,
            @ods_complet,
            @source,
            @nb_avant,
            @dt_debut;
    END;

    CLOSE cur_ctrl;
    DEALLOCATE cur_ctrl;

    /*
        Une ligne de bilan est ajoutée uniquement lorsqu'au moins
        un flux est en erreur.
    */
    IF @nb_ko > 0
    BEGIN
        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (
            ID_TRT_ALI,
            LB_PROJET,
            LB_CHARGEMENT,
            LB_SOURCE,
            LB_CIBLE,
            NB_LIGNE,
            CD_STATUT,
            LB_ERREUR,
            DT_DEBUT,
            DT_FIN
        )
        VALUES
        (
            @ID_TRT_ALI,
            @LB_PROJET,
            N'Bilan chargement ods',
            N'*TOUTES*',
            NULL,
            @nb_total,
            N'KO',
            CONVERT(NVARCHAR(10), @nb_ko)
                + N' flux en echec.',
            SYSDATETIME(),
            SYSDATETIME()
        );
    END;

    /* Restitution du résultat des contrôles. */
    SELECT
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR
    FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE ID_TRT_ALI = @ID_TRT_ALI
      AND LB_PROJET  = @LB_PROJET
    ORDER BY
        CD_STATUT DESC,
        DT_DEBUT;

    /* Le traitement échoue uniquement en cas d'erreur réelle. */
    IF @nb_ko > 0
    BEGIN
        SET @msg =
              N'PS_CONTROLE_ODS : '
            + CONVERT(NVARCHAR(10), @nb_ko)
            + N' flux en echec. L''ODS est incomplet, le scenario ODI '
            + N'ne doit pas etre lance.';

        THROW 56021, @msg, 1;
    END;
END;
GO