----------------------------------------------------------
-- Mise à jour de l'audit avant un export.
-- Base de données : Migration_ligis
-- Copie en proclib sous le nom HMEIW00_Update_Ligis_TEC_AUDIT_CDC.sql.
-- Appel par sqlcmd :  -v TYPE=CDC   dhmeiw00, avant l'export quotidien
--                     -v TYPE=INIT  dhmein00, avant l'export d'état complet
--
-- CDC   : la plage devient ]ancien LB_FIN_LSN ; LSN max courant].
-- INIT  : la photo est prise au LSN max courant ; LB_DEB_LSN y est
--         aligné pour que la prochaine plage CDC commence après la
--         photo, sinon les traces antérieures seraient rejouées.
----------------------------------------------------------

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @TYPE        VARCHAR(10)  = '$(TYPE)';
DECLARE @DT_EXTRACT  DATETIME2(3) = SYSDATETIME();
DECLARE @LSN_MAX     BINARY(10)   = sys.fn_cdc_get_max_lsn();
DECLARE @NO_SEQUENCE BIGINT;

IF @TYPE NOT IN ('CDC', 'INIT')
BEGIN
    DECLARE @msg NVARCHAR(200) = N'TYPE attendu : CDC ou INIT, reçu : ' + ISNULL(@TYPE, N'(vide)');
    THROW 57000, @msg, 1;
END;

BEGIN TRY
    BEGIN TRANSACTION;

    SELECT @NO_SEQUENCE = ISNULL(MAX(NO_SEQUENCE), 0) + 1
    FROM export_cdc.TEC_AUDIT_CDC WITH (UPDLOCK, HOLDLOCK);

    UPDATE export_cdc.TEC_AUDIT_CDC
    SET LB_DEB_LSN      = CASE WHEN @TYPE = 'CDC' THEN LB_FIN_LSN ELSE @LSN_MAX END,
        LB_FIN_LSN      = @LSN_MAX,
        DT_EXTRACT      = @DT_EXTRACT,
        NO_SEQUENCE     = @NO_SEQUENCE,
        CD_TYPE_EXTRACT = @TYPE;

    COMMIT TRANSACTION;

    SELECT @TYPE AS CD_TYPE_EXTRACT, @DT_EXTRACT AS DT_EXTRACT,
           @NO_SEQUENCE AS NO_SEQUENCE, @LSN_MAX AS LB_FIN_LSN;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
GO
