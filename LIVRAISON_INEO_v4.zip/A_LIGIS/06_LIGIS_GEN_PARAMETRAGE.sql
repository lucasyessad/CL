/* ============================================================================
   GENERATEUR DU PARAMETRAGE

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 04, 05 ET 06
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   (la vue ZBCP_INIT_LIGIS_<TABLE>_V expose les memes colonnes)
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   LIGNES GENEREES, PAR TABLE
   ----------------------------------------------------------------------------
   groupe 1  colonnes de la cle metier        FL_CLEF = 1, FL_CHARGEMENT = 1
   groupe 2  DT_COMMIT_TEC + LB_SEQVAL_TEC    FL_ORDRE_TRI = 1 (ordre du tri)
   groupe 3  ID_INSTANCE_TEC, NO_SEQUENCE_TEC,
             LB_LSN_COMMIT_TEC, CD_DML_TEC    presentes en ODS, non chargees
   groupe 4  colonnes metier hors cle          chargees
   groupe 5  FL_FIN_JOURNEE et bloc technique DWH, pour documentation

   Une colonne FL_ORDRE_TRI = 1 est copiee dans la cible si FL_CHARGEMENT = 1
   mais n'entre jamais dans la comparaison de changement : elle date la trace,
   elle ne decrit pas la ligne. CD_DML_TEC est ecrite par l'etape
   d'historisation elle-meme, comme FL_SUP.

   Toute colonne portant FL_CHARGEMENT = 1 avec un LB_CHAMP_DWH renseigne doit
   exister dans la table OWT generee par le script 04.

   LIRE LE RESULTAT DANS LA COLONNE XML ScriptComplet.
   ============================================================================ */

DROP TABLE IF EXISTS ##ParamHistoScript;
GO

CREATE TABLE ##ParamHistoScript
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NULL,
    NbLignesParam     int           NULL,
    InsertScript      nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_ParamHistoScript
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource sysname       = N'dbo';
DECLARE @SchemaVue    sysname       = N'export_cdc';
DECLARE @LB_PROJET    nvarchar(50)  = N'LIGIS';
DECLARE @TableParam   nvarchar(300) = N'dbo.ORT_PARAM_HISTORISATION_TRACES';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. A 0, ces tables restent sans cle et
   sont donc ignorees par le traitement ODI. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 04, 05 ET 06.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 04, 05 ET 06.
---------------------------------------------------------------------------- */
INSERT INTO ##ParamHistoScript
(
    TableNameSource,
    ViewNameSource
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @SourceObjectId    int,
    @ViewObjectId      int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @Script            nvarchar(MAX),
    @ValuesScript      nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @NbLignes          int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_param CURSOR LOCAL FAST_FORWARD FOR
    SELECT TableNameSource, ViewNameSource
    FROM ##ParamHistoScript
    ORDER BY TableNameSource;

OPEN cur_param;
FETCH NEXT FROM cur_param
INTO @TableNameSource, @ViewNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @Script = NULL,
        @ValuesScript = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @NbLignes = 0,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 04, 05 ET 06.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 04, 05 ET 06.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL,
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : table ignoree par ODI.';

    /* ------------------------------------------------------------------------
       Construction des lignes de parametrage.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #Lignes;

    CREATE TABLE #Lignes
    (
        grp       int          NOT NULL,
        ord       int          NOT NULL,
        champ_ods sysname      NULL,
        champ_dwh sysname      NULL,
        clef      bit          NOT NULL,
        chg       bit          NOT NULL,
        tri       bit          NOT NULL
    );

    /* 1. Colonnes de la cle metier. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, clef, chg, tri)
    SELECT
        1, K.key_ordinal, K.name, K.name, 1, 1, 0
    FROM #KeyCols AS K;

    /* 2. Colonnes techniques d'ordre et de sens de modification.

          L'ordre des traces dans la journee se fait sur DEUX colonnes :
            DT_COMMIT_TEC   heure du commit, borne la fenetre de journee ;
            LB_SEQVAL_TEC   rang de l'operation dans la transaction, departage
                            deux modifications commitees dans la meme
                            milliseconde.
          Les deux portent donc FL_ORDRE_TRI = 1, dans cet ordre de NO_CHAMP.
          DT_COMMIT_TEC est aussi FL_CHARGEMENT = 1 : copiee dans la cible,
          exclue de la comparaison par son FL_ORDRE_TRI. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, clef, chg, tri)
    SELECT 2, 1, N'DT_COMMIT_TEC', N'DT_COMMIT_TEC', 0, 1, 1
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'DT_COMMIT_TEC'
    )
    UNION ALL
    SELECT 2, 2, N'LB_SEQVAL_TEC', NULL, 0, 0, 1
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_SEQVAL_TEC'
    );

    /* 3. Colonnes techniques presentes en ODS, non chargees dans la cible. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, clef, chg, tri)
    SELECT 3, 1, N'ID_INSTANCE_TEC', NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'ID_INSTANCE_TEC'
    )
    UNION ALL
    SELECT 3, 2, N'NO_SEQUENCE_TEC', NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'NO_SEQUENCE_TEC'
    )
    UNION ALL
    SELECT 3, 3, N'LB_LSN_COMMIT_TEC', NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_LSN_COMMIT_TEC'
    )
    UNION ALL
    SELECT 3, 4, N'CD_DML_TEC', NULL, 0, 0, 0
    WHERE EXISTS
    (
        SELECT 1 FROM #ViewCols WHERE ColumnName = N'CD_DML_TEC'
    );

    /* 4. Colonnes metier hors cle. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, clef, chg, tri)
    SELECT
        4, V.column_id, V.ColumnName, V.ColumnName, 0, 1, 0
    FROM #ViewCols AS V
    WHERE V.ColumnName NOT IN
    (
        N'ID_INSTANCE_TEC',
        N'NO_SEQUENCE_TEC',
        N'LB_SEQVAL_TEC',
        N'CD_DML_TEC',
        N'DT_COMMIT_TEC',
        N'LB_LSN_COMMIT_TEC',
        N'FL_FIN_JOURNEE'
    )
      AND NOT EXISTS
      (
          SELECT 1
          FROM #KeyCols AS K
          WHERE K.name COLLATE DATABASE_DEFAULT =
                V.ColumnName COLLATE DATABASE_DEFAULT
      );

    /* 5. Lignes documentaires : flag ODS et bloc technique DWH.
          Elles ne sont pas chargees, elles decrivent les colonnes alimentees
          par le traitement lui-meme. L'ordre suit celui du bloc technique
          genere par le script 04. */
    INSERT INTO #Lignes
        (grp, ord, champ_ods, champ_dwh, clef, chg, tri)
    VALUES
        (5,  1, N'FL_FIN_JOURNEE', NULL,           0, 0, 0),
        (5,  2, NULL,              N'NO_SEQ',      0, 0, 0),
        (5,  3, NULL,              N'DD_VAL',      0, 0, 0),
        (5,  4, NULL,              N'DF_VAL',      0, 0, 0),
        (5,  5, NULL,              N'FL_VER_CRT',  0, 0, 0),
        (5,  6, NULL,              N'FL_SUP',      0, 0, 0),
        (5,  7, NULL,              N'CD_DML_TEC',  0, 0, 0),
        (5,  8, NULL,              N'DT_MAJ_TRT',  0, 0, 0),
        (5,  9, NULL,              N'CD_USR_MAJ',  0, 0, 0),
        (5, 10, NULL,              N'ID_TRT_ALI',  0, 0, 0);

    ;WITH numerotees AS
    (
        SELECT
            L.*,
            NO_CHAMP = ROW_NUMBER() OVER
            (
                ORDER BY L.grp, L.ord, L.champ_ods, L.champ_dwh
            )
        FROM #Lignes AS L
    )
    SELECT
        @ValuesScript = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                  N' (N''' + REPLACE(@LB_PROJET, N'''', N'''''')
                + N''',N''' + REPLACE(@SchemaSource, N'''', N'''''')
                + N'_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OWT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',' + CONVERT(nvarchar(10), NO_CHAMP) + N','
                + CASE WHEN champ_ods IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_ods, N'''', N'''''') + N'''' END + N','
                + CASE WHEN champ_dwh IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_dwh, N'''', N'''''') + N'''' END + N','
                + CONVERT(nvarchar(1), CONVERT(int, clef)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, chg)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, tri)) + N')'
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY NO_CHAMP),
        @NbLignes = COUNT(*)
    FROM numerotees;

    SET @Script =
          N'DELETE FROM ' + @TableParam
        + N' WHERE LB_PROJET = N''' + REPLACE(@LB_PROJET, N'''', N'''''') + N''''
        + N' AND LB_TABLE_ODS = N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''') + N''';'
        + CHAR(13)
        + N'INSERT INTO ' + @TableParam + CHAR(13)
        + N'    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,' + CHAR(13)
        + N'     LB_CHAMP_ODS, LB_CHAMP_DWH, FL_CLEF, FL_CHARGEMENT, FL_ORDRE_TRI)' + CHAR(13)
        + N'VALUES' + CHAR(13)
        + @ValuesScript
        + N';';

    UPDATE ##ParamHistoScript
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        NbLignesParam = @NbLignes,
        InsertScript = @Script,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_param
    INTO @TableNameSource, @ViewNameSource;
END;

CLOSE cur_param;
DEALLOCATE cur_param;
GO

/* Script complet a executer sur le DWH. */
SELECT
    ScriptComplet =
    (
        SELECT CHAR(13) + InsertScript + CHAR(13)
        FROM ##ParamHistoScript
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail par table. */
SELECT
    TableNameSource,
    ViewNameSource,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    NbLignesParam,
    MessageControle,
    InsertScript
FROM ##ParamHistoScript
ORDER BY TableNameSource;

/* Tables sans cle metier : elles ne seront pas traitees par ODI. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##ParamHistoScript
WHERE SourceCleMetier IS NULL
ORDER BY TableNameSource;
GO
