/* ================================================================
   Vues d'état complet ZBCP_INIT_LIGIS_<TABLE>_V

   Une vue par table sous CDC, lue directement sur la table source.
   Elle sert à l'initialisation, et au quotidien pour une table
   déclarée CD_MODE_ENTREE = FULL.

   Mêmes colonnes techniques que la vue CDC, pour charger la même
   table OIT :
     LB_LSN_COMMIT_TEC  LSN de la photo (LB_FIN_LSN de l'audit)
     LB_SEQVAL_TEC      rang de la ligne ; le couple (LSN, rang)
                        identifie la ligne dans l'archive
     CD_DML_TEC         2 (insertion)
     DT_COMMIT_TEC      date d'extraction portée par l'audit
   La ligne d'audit de l'instance doit donc être mise à jour par le
   script 07 (type INIT ou FULL) avant l'export.
   ================================================================ */
DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource sysname NOT NULL
);
GO

INSERT INTO ##TableListODS (TableNameSource)
SELECT t.name
FROM sys.tables AS t
INNER JOIN sys.schemas AS s
    ON s.schema_id = t.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS tm
    ON tm.LB_INSTANCE = N'dbo_' + t.name
WHERE s.name = N'dbo'
ORDER BY t.name;

SET NOCOUNT ON;

DECLARE
    @SchemaSource    sysname = N'dbo',
    @SchemaCDCExport sysname = N'export_cdc',
    @TableNameSource sysname,
    @DropSQL         nvarchar(MAX),
    @CreateSQL       nvarchar(MAX),
    @SourceTable     nvarchar(517),
    @CaptureInstance sysname;

DECLARE cur_view CURSOR LOCAL FAST_FORWARD FOR
SELECT TableNameSource FROM ##TableListODS;

OPEN cur_view;
FETCH NEXT FROM cur_view INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    /* L'instance CDC porte le préfixe du schéma : c'est elle qui est
       dans TEC_AUDIT_CDC, pas le nom de table. */
    SET @CaptureInstance = @SchemaSource + N'_' + @TableNameSource;
    SET @SourceTable = QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource);

    IF OBJECT_ID(@SourceTable) IS NULL
    BEGIN
        PRINT 'Table source absente : ' + @SourceTable;
        FETCH NEXT FROM cur_view INTO @TableNameSource;
        CONTINUE;
    END

    SET @DropSQL =
        N'DROP VIEW IF EXISTS '
        + QUOTENAME(@SchemaCDCExport)
        + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N';';

    ;WITH cols AS (
        SELECT c.name, c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@SourceTable)
    )
    SELECT @CreateSQL =
N'CREATE VIEW ' + QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N'
AS
    WITH CTE_AUDIT AS (
        SELECT ID_INSTANCE, LB_FIN_LSN, DT_EXTRACT, NO_SEQUENCE
        FROM ' + QUOTENAME(@SchemaCDCExport) + N'.ZBCP_LIGIS_TEC_AUDIT_CDC_V
        WHERE LB_INSTANCE = ''' + @CaptureInstance + N'''
    )
    SELECT
        T.ID_INSTANCE  AS ID_INSTANCE_TEC,
        T.NO_SEQUENCE  AS NO_SEQUENCE_TEC,
        CONVERT(binary(10), ROW_NUMBER() OVER (ORDER BY (SELECT NULL))) AS LB_SEQVAL_TEC,
        2 AS CD_DML_TEC,
        T.DT_EXTRACT AS DT_COMMIT_TEC,
        T.LB_FIN_LSN AS LB_LSN_COMMIT_TEC,
        ' +
        STRING_AGG(N'C.' + QUOTENAME(name), N',' + CHAR(13) + N'        ')
        WITHIN GROUP (ORDER BY column_id) + N',
        CONVERT(BIT, 0) AS FL_FIN_JOURNEE
    FROM ' + @SourceTable + N' AS C
    CROSS JOIN CTE_AUDIT AS T;'
    FROM cols
    WHERE name NOT LIKE 'CS/_%' ESCAPE '/';

    EXEC(@DropSQL);
    EXEC(@CreateSQL);

    FETCH NEXT FROM cur_view INTO @TableNameSource;
END

CLOSE cur_view;
DEALLOCATE cur_view;
GO
