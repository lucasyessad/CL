-- schema logique : MSSQL_DWH
-- type : S

DECLARE @ID_TRT_ALI BIGINT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @CD_USR_MAJ NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';

DECLARE
    @dt_step     DATETIME2(3) = SYSDATETIME(),
    @dt_jour     DATE,
    @nb_ins      BIGINT = 0,
    @nb_total    BIGINT = 0,
    @nb_sans_lsn BIGINT = 0,
    @message     NVARCHAR(2000);

SELECT
    @dt_jour =
        MAX(CONVERT(DATE, B.DT_JOUR, 121))
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.LB_PROJET = @LB_PROJET;

/* Aucune journée bornée : aucun archivage */

IF @dt_jour IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'ARCHIVE AUDIT CDC',
        N'OIT_TEC_AUDIT_CDC',
        N'OWT_TEC_AUDIT_CDC',
        0,
        N'OK',
        N'IGNORE: aucune journee bornee pour le projet '
        + @LB_PROJET
        + N'. Aucun audit CDC archive.',
        @dt_step,
        SYSDATETIME()
    );

    RETURN;
END;

SELECT
    @nb_total =
        COUNT_BIG(*),

    @nb_sans_lsn =
        ISNULL(
            SUM(
                CASE
                    WHEN A.LB_FIN_LSN IS NULL THEN 1
                    ELSE 0
                END
            ),
            0
        )
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUDIT_CDC", "MSSQL_ODS", "D") ?> AS A;

BEGIN TRY
    INSERT INTO <?=odiRef.getObjectName("L", "OWT_TEC_AUDIT_CDC", "MSSQL_DWH", "D") ?>
    (
        LB_PROJET,
        NO_SEQUENCE,
        LB_INSTANCE,
        CD_TYPE_EXTRACT,
        DT_JOUR_TEC,
        DT_DEB_LSN,
        DT_FIN_LSN,
        DT_EXTRACT,
        ID_INSTANCE,
        LB_DEB_LSN,
        LB_FIN_LSN,
        DT_MAJ_TRT,
        CD_USR_MAJ,
        ID_TRT_ALI
    )
    SELECT
        @LB_PROJET,
        A.NO_SEQUENCE,
        A.LB_INSTANCE,
        A.CD_TYPE_EXTRACT,
        @dt_jour,
        A.DT_DEB_LSN,
        A.DT_FIN_LSN,
        A.DT_EXTRACT,
        A.ID_INSTANCE,
        A.LB_DEB_LSN,
        A.LB_FIN_LSN,
        SYSDATETIME(),
        @CD_USR_MAJ,
        @ID_TRT_ALI
    FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUDIT_CDC", "MSSQL_ODS", "D") ?> AS A
    WHERE A.LB_FIN_LSN IS NOT NULL
      AND A.LB_INSTANCE IN
      (
          SELECT F.LB_SOURCE
          FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
          WHERE F.LB_PROJET = @LB_PROJET AND F.LB_SOURCE IS NOT NULL
      )
      AND NOT EXISTS
      (
          SELECT 1
          FROM <?=odiRef.getObjectName("L", "OWT_TEC_AUDIT_CDC", "MSSQL_DWH", "D") ?> AS H
          WHERE H.LB_PROJET   = @LB_PROJET
            AND H.LB_INSTANCE = A.LB_INSTANCE
            AND H.NO_SEQUENCE = A.NO_SEQUENCE
      );

    SET @nb_ins =
        @@ROWCOUNT;

    SET @message =
        CASE
            WHEN @nb_total = 0
                THEN
                    N'AVERTISSEMENT: OIT_TEC_AUDIT_CDC est vide. '
                    + N'Verifier le BCP IN de la vue d''audit.'

            WHEN @nb_sans_lsn > 0
                THEN
                    N'AVERTISSEMENT: '
                    + CONVERT(NVARCHAR(20), @nb_sans_lsn)
                    + N' ligne(s) ecartee(s) faute de LB_FIN_LSN sur '
                    + CONVERT(NVARCHAR(20), @nb_total)
                    + N' ligne(s) presente(s).'

            WHEN @nb_ins = 0
                THEN
                    N'IGNORE: aucune nouvelle extraction CDC '
                    + N'depuis le dernier archivage.'

            ELSE
                    N'Extractions CDC archivees : '
                    + CONVERT(NVARCHAR(20), @nb_ins)
                    + N' sur '
                    + CONVERT(NVARCHAR(20), @nb_total)
                    + N' ligne(s) presente(s).'
        END;

    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'ARCHIVE AUDIT CDC ['
        + CONVERT(NVARCHAR(10), @dt_jour, 23)
        + N']',
        N'OIT_TEC_AUDIT_CDC',
        N'OWT_TEC_AUDIT_CDC',
        @nb_ins,
        N'OK',
        @message,
        @dt_step,
        SYSDATETIME()
    );
END TRY
BEGIN CATCH
    SET @message =
          N'ARCHIVE AUDIT CDC : '
        + ERROR_MESSAGE()
        + N' [erreur '
        + CONVERT(NVARCHAR(20), ERROR_NUMBER())
        + N', ligne '
        + CONVERT(NVARCHAR(20), ERROR_LINE())
        + N']';

    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'ARCHIVE AUDIT CDC',
        N'OIT_TEC_AUDIT_CDC',
        N'OWT_TEC_AUDIT_CDC',
        0,
        N'KO',
        @message,
        @dt_step,
        SYSDATETIME()
    );

    THROW;
END CATCH;
