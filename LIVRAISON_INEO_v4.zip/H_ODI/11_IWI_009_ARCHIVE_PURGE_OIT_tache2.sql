-- schema logique : MSSQL_ODS
-- type : S

/* ============================================================================
   IWI.009  -  ARCHIVAGE DU SAS ET PURGE DE RÉTENTION

   Après la boucle des journées :
     1. toute trace du sas datée au plus tard de la dernière journée traitée
        et absente de OIT_x_HISTO, ou archivée avec un autre FL_FIN_JOURNEE,
        y est copiée telle quelle. La copie supprime puis réinsère par le
        couple (LB_LSN_COMMIT_TEC, LB_SEQVAL_TEC) qui identifie une trace :
        rejouable, une journée recalculée remplace son archive, un archivage
        échoué est rattrapé à l'exécution suivante ;
     2. les traces plus anciennes que NB_MOIS_RETENTION (ORT_PARAM_FLUX) et
        déjà archivées sont retirées du sas. L'archive n'est jamais purgée.

   Ne concerne que les flux DELTA : un flux FULL est vidé à chaque livraison,
   il n'accumule rien. Les lignes d'un état INIT chargées dans un flux DELTA
   sont datées de leur extraction et archivées comme des traces.

   Le couple LSN + séquence et FL_FIN_JOURNEE sont le contrat technique des
   vues d'export (en-tête des générateurs) : ils sont nommés ici tels quels.
   La colonne de date vient du paramétrage (première FL_ORDRE_TRI).
   ============================================================================ */

DECLARE @ID_TRT_ALI BIGINT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @CD_USR_MAJ NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';

DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_HISTO NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS_TRACES", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS_TRACES", "D") ?>.';

DECLARE
    @jour_max  DATE,
    @fin       DATETIME2(3),
    @msg       NVARCHAR(2000),
    @nb_ko     INT = 0,
    @dt_step   DATETIME2(3);

/* Dernière journée traitée par cette exécution (FL_TRAITE posé par 008). */
SELECT @jour_max = MAX(P.DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> AS P
WHERE P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND P.LB_PROJET = @LB_PROJET
  AND P.FL_TRAITE = 1;

SELECT @fin = B.DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.LB_PROJET = @LB_PROJET AND B.DT_JOUR = @jour_max;

IF @jour_max IS NULL OR @fin IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT', N'*TOUTES*', NULL, 0, N'OK',
            CASE WHEN @jour_max IS NULL
                 THEN N'IGNORE: aucune journée traitée par cette exécution, rien à archiver.'
                 ELSE N'IGNORE: borne absente pour la journée ' + CONVERT(NVARCHAR(10), @jour_max, 23) + N', rien à archiver.' END,
            SYSDATETIME(), SYSDATETIME());
    RETURN;
END;

DECLARE
    @tbl_ods    NVARCHAR(128), @tbl_histo NVARCHAR(200),
    @src        NVARCHAR(400), @tgt       NVARCHAR(400),
    @col_fen    NVARCHAR(128), @retention INT, @limite DATETIME2(3),
    @cols       NVARCHAR(MAX), @cols_src  NVARCHAR(MAX),
    @fenetre    NVARCHAR(400), @jour_expr NVARCHAR(MAX),
    @sql        NVARCHAR(MAX),
    @nb_a_traiter BIGINT, @nb_supp_histo BIGINT, @nb_ins_histo BIGINT,
    @nb_absentes BIGINT, @nb_non_conformes BIGINT, @nb_purgees BIGINT;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.NB_MOIS_RETENTION
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ENTREE = N'DELTA'
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @retention;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SET @tbl_histo = @tbl_ods + N'_HISTO';
    SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
    SET @tgt = @PFX_HISTO + QUOTENAME(@tbl_histo);
    SELECT @cols = NULL, @cols_src = NULL, @col_fen = NULL,
           @nb_a_traiter = 0, @nb_supp_histo = 0, @nb_ins_histo = 0,
           @nb_absentes = 0, @nb_non_conformes = 0, @nb_purgees = 0;

    BEGIN TRY
        /* Colonnes du sas : toutes celles avec LB_CHAMP_ODS renseigné. */
        SELECT
            @cols     = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(P.LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @cols_src = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.' + QUOTENAME(P.LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY P.NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET AND P.LB_TABLE_ODS = @tbl_ods AND P.LB_CHAMP_ODS IS NOT NULL;

        SELECT TOP (1) @col_fen = P.LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_ORDRE_TRI = 1 AND P.LB_CHAMP_ODS IS NOT NULL
        ORDER BY P.NO_CHAMP;

        IF @cols IS NULL OR @col_fen IS NULL
        BEGIN
            SET @msg = N'Paramétrage incomplet pour ' + @tbl_ods + N' : colonnes ou colonne d''ordre absentes.';
            THROW 50040, @msg, 1;
        END;

        /* Traces à archiver : datées au plus tard de la frontière, pas encore
           dans l'archive ou archivées avec une autre image. */
        SET @fenetre = N' S.' + QUOTENAME(@col_fen) + N' <= @p_fin'
                     + N' AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS HX'
                     + N'   WHERE HX.LB_LSN_COMMIT_TEC = S.LB_LSN_COMMIT_TEC AND HX.LB_SEQVAL_TEC = S.LB_SEQVAL_TEC'
                     + N'     AND ISNULL(HX.FL_FIN_JOURNEE, 0) = ISNULL(S.FL_FIN_JOURNEE, 0))';

        /* Journée de rattachement : première borne >= date de la trace. */
        SET @jour_expr =
              N'(SELECT TOP (1) B.DT_JOUR'
            + N' FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B'
            + N' WHERE B.LB_PROJET = @p_projet AND B.DT_BORNE >= S.' + QUOTENAME(@col_fen)
            + N' ORDER BY B.DT_BORNE)';

        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @src + N' AS S WHERE' + @fenetre + N';';
        EXEC sp_executesql @sql, N'@p_fin datetime2(3), @p_nb bigint OUTPUT',
             @p_fin = @fin, @p_nb = @nb_a_traiter OUTPUT;

        BEGIN TRANSACTION;

        IF @nb_a_traiter > 0
        BEGIN
            /* 1. Anciennes images de ces traces. */
            SET @sql = N'DELETE H FROM ' + @tgt + N' AS H'
                     + N' INNER JOIN ' + @src + N' AS S'
                     + N'    ON H.LB_LSN_COMMIT_TEC = S.LB_LSN_COMMIT_TEC AND H.LB_SEQVAL_TEC = S.LB_SEQVAL_TEC'
                     + N' WHERE' + @fenetre + N';'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_fin datetime2(3), @p_nb bigint OUTPUT',
                 @p_fin = @fin, @p_nb = @nb_supp_histo OUTPUT;

            /* 2. Copie. */
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols + N', DT_JOUR_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                     + N' SELECT ' + @cols_src + N', ' + @jour_expr + N', SYSDATETIME(), @p_usr, @p_trt'
                     + N' FROM ' + @src + N' AS S WHERE' + @fenetre + N';'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_fin datetime2(3), @p_projet nvarchar(50), @p_usr nvarchar(20), @p_trt bigint, @p_nb bigint OUTPUT',
                 @p_fin = @fin, @p_projet = @LB_PROJET, @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_ins_histo OUTPUT;

            IF @nb_ins_histo <> @nb_a_traiter
            BEGIN
                SET @msg = N'Volumétrie incohérente pour ' + @tbl_histo + N' : '
                         + CONVERT(NVARCHAR(20), @nb_a_traiter) + N' attendue(s), '
                         + CONVERT(NVARCHAR(20), @nb_ins_histo) + N' réinsérée(s).';
                THROW 50041, @msg, 1;
            END;

            /* 3. Chaque trace datée jusqu'à la frontière est dans l'archive. */
            SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @src + N' AS S WHERE S.' + QUOTENAME(@col_fen) + N' <= @p_fin'
                     + N' AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS H'
                     + N'   WHERE H.LB_LSN_COMMIT_TEC = S.LB_LSN_COMMIT_TEC AND H.LB_SEQVAL_TEC = S.LB_SEQVAL_TEC);';
            EXEC sp_executesql @sql, N'@p_fin datetime2(3), @p_nb bigint OUTPUT',
                 @p_fin = @fin, @p_nb = @nb_absentes OUTPUT;

            IF @nb_absentes > 0
            BEGIN
                SET @msg = N'Réinsertion incomplète vers ' + @tbl_histo + N' : '
                         + CONVERT(NVARCHAR(20), @nb_absentes) + N' trace(s) absente(s).';
                THROW 50042, @msg, 1;
            END;

            /* 4. L'image archivée est celle du sas. */
            SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @src + N' AS S'
                     + N' INNER JOIN ' + @tgt + N' AS H'
                     + N'    ON H.LB_LSN_COMMIT_TEC = S.LB_LSN_COMMIT_TEC AND H.LB_SEQVAL_TEC = S.LB_SEQVAL_TEC'
                     + N' WHERE S.' + QUOTENAME(@col_fen) + N' <= @p_fin'
                     + N' AND ISNULL(H.FL_FIN_JOURNEE, 0) <> ISNULL(S.FL_FIN_JOURNEE, 0);';
            EXEC sp_executesql @sql, N'@p_fin datetime2(3), @p_nb bigint OUTPUT',
                 @p_fin = @fin, @p_nb = @nb_non_conformes OUTPUT;

            IF @nb_non_conformes > 0
            BEGIN
                SET @msg = N'Archive non conforme pour ' + @tbl_histo + N' : '
                         + CONVERT(NVARCHAR(20), @nb_non_conformes) + N' trace(s) avec un FL_FIN_JOURNEE différent.';
                THROW 50043, @msg, 1;
            END;
        END;

        /* 5. Rétention : traces plus anciennes que NB_MOIS_RETENTION, à
              condition d'être dans l'archive. */
        SET @sql = N'DELETE S FROM ' + @src + N' AS S'
                 + N' WHERE S.' + QUOTENAME(@col_fen) + N' < @p_limite'
                 + N'   AND EXISTS (SELECT 1 FROM ' + @tgt + N' AS H'
                 + N'   WHERE H.LB_LSN_COMMIT_TEC = S.LB_LSN_COMMIT_TEC AND H.LB_SEQVAL_TEC = S.LB_SEQVAL_TEC);'
                 + N' SELECT @p_nb = @@ROWCOUNT;';
        SET @limite = DATEADD(MONTH, -@retention, @fin);
        EXEC sp_executesql @sql, N'@p_limite datetime2(3), @p_nb bigint OUTPUT',
             @p_limite = @limite, @p_nb = @nb_purgees OUTPUT;

        COMMIT TRANSACTION;

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT [' + CONVERT(NVARCHAR(10), @jour_max, 23) + N']',
                @tbl_ods, @tbl_histo, @nb_a_traiter, N'OK',
                N'Archivées: ' + CONVERT(NVARCHAR(20), @nb_ins_histo)
                + N' (remplacées: ' + CONVERT(NVARCHAR(20), @nb_supp_histo) + N')'
                + N' / purgées du sas: ' + CONVERT(NVARCHAR(20), @nb_purgees)
                + N' / frontière ' + CONVERT(NVARCHAR(23), @fin, 121) + N'.',
                @dt_step, SYSDATETIME());
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        SET @nb_ko = @nb_ko + 1;
        SET @msg = ERROR_MESSAGE()
                 + N' [erreur ' + CONVERT(NVARCHAR(20), ERROR_NUMBER())
                 + N', ligne ' + CONVERT(NVARCHAR(20), ERROR_LINE()) + N']';
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT [' + CONVERT(NVARCHAR(10), @jour_max, 23) + N']',
                @tbl_ods, @tbl_histo, 0, N'KO', @msg, @dt_step, SYSDATETIME());
    END CATCH;

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @retention;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;

IF @nb_ko > 0
BEGIN
    SET @msg = N'IWI.009 ARCHIVE OIT : ' + CONVERT(NVARCHAR(10), @nb_ko)
             + N' table(s) non archivée(s), transactions annulées. Les traces restent'
             + N' dans le sas et seront reprises à la prochaine exécution.';
    THROW 50045, @msg, 1;
END;
