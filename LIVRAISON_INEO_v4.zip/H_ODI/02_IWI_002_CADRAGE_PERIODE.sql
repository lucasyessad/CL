-- schema logique : MSSQL_DWH
-- type : S

DECLARE @ID_TRT_ALI BIGINT       = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @LB_SCN     NVARCHAR(100) = N'<?=odiRef.getSession("SESS_NAME") ?>';

DECLARE @dt_step DATETIME = GETDATE(),
        @last_borne DATE, @deb_periode DATE, @fin_forcee DATE, @fin_retenue DATE;

/* Derniere journee bornee = derniere journee reellement traitable ------------ */
SELECT @last_borne = MAX(DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE LB_PROJET=@LB_PROJET;

SELECT @deb_periode = CONVERT(date, DA_DEB_DEL_TRT, 121),
       @fin_forcee  = CONVERT(date, DA_FIN_DEL_FOR, 121)
FROM <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
WHERE LB_NOM_SCN_SUN = @LB_SCN;

IF @deb_periode IS NULL
BEGIN
    DECLARE @msg NVARCHAR(500) =
        N'IWI.002 CADRAGE PERIODE : aucune ligne PWTTRE pour LB_NOM_SCN_SUN = '''
        + @LB_SCN + N''' - executer G_DWH_MEP/01_DWH_INIT_MEP.sql.';
    THROW 50023, @msg, 1;
END

/* Pas de borne -> periode vide (neutre) ; sinon min(forcage, derniere borne) - */
SET @fin_retenue = ISNULL(@last_borne, @deb_periode);

IF @fin_forcee IS NOT NULL AND @fin_forcee < @fin_retenue
    SET @fin_retenue = @fin_forcee;

UPDATE <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
SET DA_FIN_DEL_FOR = @fin_retenue
WHERE LB_NOM_SCN_SUN = @LB_SCN;

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'CADRAGE PERIODE',
        N'ORT_BORNE_JOURNEE', N'PWTTRE', 1, N'OK',
        N'Periode cadree : ] ' + CONVERT(NVARCHAR(10), @deb_periode, 23)
        + N' ; ' + CONVERT(NVARCHAR(10), @fin_retenue, 23) + N' ]'
        + CASE WHEN @last_borne IS NULL THEN N' - aucune borne posee, periode vide.'
               WHEN @fin_forcee IS NOT NULL AND @fin_forcee < @last_borne
                    THEN N' - reduite par forcage manuel DA_FIN_DEL_FOR.'
               ELSE N' - fin = derniere journee bornee.' END,
        @dt_step, GETDATE());
