-- schema logique : MSSQL_DWH
-- type : S

/* ============================================================================
   IWI.006  -  HISTORISATION DANS LE DWH

   Image du jour : les lignes FL_FIN_JOURNEE = 1 du sas DANS LA FENÊTRE de la
   journée. Les flags des journées précédentes restent en place pour
   l'archive, ils ne font pas partie de l'image. En journée INIT, l'image est
   tout le sas flagué (l'étape 004 a remis tous les flags à zéro avant).

   Colonnes, lues dans ORT_PARAM_HISTORISATION_TRACES :
     copiées    FL_CHARGEMENT = 1
     comparées  FL_CHARGEMENT = 1, hors clé, hors FL_ORDRE_TRI
     écrites par l'étape : NO_SEQ, DD_VAL, DF_VAL, FL_VER_CRT, FL_SUP,
                CD_DML_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI

   Deux natures d'image :
     partielle  DELTA en quotidien : seules les clés modifiées. Une clé
                absente n'est pas touchée. FL_SUP vient de CD_DML_TEC.
     complète   FULL, ou journée INIT quel que soit le flux : une clé absente
                est fermée avec une version FL_SUP = 1 ; une clé déjà
                supprimée et toujours absente reste telle quelle ; une image
                vide signifie "pas de livraison" et ne touche pas la cible.

     SCD2   ferme et réinsère ce qui a changé, insère les nouvelles clés.
     SCD1   met à jour sur place.
     AJOUT  insère l'image sans comparer.
   Journalise une ligne par table.
   ============================================================================ */

DECLARE @DT_TRACES    DATE         = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI   BIGINT       = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET    NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE         = '#INEO.V_DATE_INFINIE';
DECLARE @CD_USR_MAJ   NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';
DECLARE @PFX_ODS NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23),
        @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(2000),
        @fl_journee_init BIT = 0;

IF EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
           WHERE LB_PROJET = @LB_PROJET AND DT_JOUR = @DT_TRACES
             AND TYPE_BORNE = N'INIT' AND FL_TRAITE = 0)
    SET @fl_journee_init = 1;

IF @fl_journee_init = 0
BEGIN
    SELECT @dt_fin = DT_BORNE
    FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
    WHERE DT_JOUR = @DT_TRACES AND LB_PROJET = @LB_PROJET;

    SELECT @dt_deb = MAX(DT_BORNE)
    FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
    WHERE DT_JOUR < @DT_TRACES AND LB_PROJET = @LB_PROJET;

    IF @dt_fin IS NULL OR @dt_deb IS NULL
    BEGIN
        SET @msg = N'Fenêtre non définie pour le ' + @jour + N'.';
        THROW 50011, @msg, 1;
    END
END

DECLARE
    @tbl_ods   NVARCHAR(128), @tbl_dwh  NVARCHAR(200),
    @entree    NVARCHAR(10),  @alim     NVARCHAR(10), @img_complete BIT,
    @src NVARCHAR(400), @tgt NVARCHAR(400), @img NVARCHAR(MAX), @col_fen NVARCHAR(128),
    @cle1    NVARCHAR(128),      -- première colonne clé, nom ODS
    @join_st NVARCHAR(MAX),      -- S.[k] = T.[k]
    @join_mx NVARCHAR(MAX),      -- T2.[k] = S.[k]
    @join_tt NVARCHAR(MAX),      -- T3.[k] = T.[k]
    @cols    NVARCHAR(MAX),      -- [c]   colonnes copiées, clé incluse
    @vals_s  NVARCHAR(MAX),      -- S.[c]
    @vals_t  NVARCHAR(MAX),      -- T.[c]
    @set_s1  NVARCHAR(MAX),      -- T.[c] = S.[c]  hors clé
    @cmp_s   NVARCHAR(MAX), @cmp_t NVARCHAR(MAX),
    @sup_s   NVARCHAR(200),      -- FL_SUP porté par l'image
    @dml_s   NVARCHAR(200),      -- CD_DML_TEC porté par l'image
    @params  NVARCHAR(400) = N'@p_deb datetime2(3), @p_fin datetime2(3), @p_dt date, @p_inf date, @p_usr nvarchar(20), @p_trt bigint, @p_nb int OUTPUT',
    @sql NVARCHAR(MAX),
    @nb_img INT, @nb_ferm INT, @nb_ins INT, @nb_maj INT, @nb_sup INT, @dt_step DATETIME2(3);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH, F.CD_MODE_ENTREE, F.CD_MODE_ALIM
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ALIM <> N'AUCUNE'
      AND F.LB_TABLE_DWH IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
                  WHERE A.ID_TRT_ALI = @ID_TRT_ALI
                    AND A.LB_PROJET = @LB_PROJET AND A.CD_STATUT = N'KO'
                    AND A.LB_SOURCE = F.LB_TABLE_ODS
                    AND CHARINDEX(N'[' + @jour + N']', A.LB_CHARGEMENT) > 0)
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @entree, @alim;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SELECT @nb_img = 0, @nb_ferm = 0, @nb_ins = 0, @nb_maj = 0, @nb_sup = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);
        SET @img_complete = CASE WHEN @entree = N'FULL' OR @fl_journee_init = 1 THEN 1 ELSE 0 END;
        SELECT @cle1=NULL,@col_fen=NULL,@join_st=NULL,@join_mx=NULL,@join_tt=NULL,
               @cols=NULL,@vals_s=NULL,@vals_t=NULL,@set_s1=NULL,@cmp_s=NULL,@cmp_t=NULL;

        /* Clé */
        SELECT
            @join_st = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.'+QUOTENAME(LB_CHAMP_ODS)+N' = T.'+QUOTENAME(LB_CHAMP_DWH)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @join_mx = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T2.'+QUOTENAME(LB_CHAMP_DWH)+N' = S.'+QUOTENAME(LB_CHAMP_ODS)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @join_tt = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T3.'+QUOTENAME(LB_CHAMP_DWH)+N' = T.'+QUOTENAME(LB_CHAMP_DWH)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CLEF=1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT TOP (1) @cle1 = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CLEF=1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL
        ORDER BY NO_CHAMP;

        /* Colonne de fenêtre : première colonne d'ordre. */
        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_ORDRE_TRI=1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        /* Colonnes copiées */
        SELECT
            @cols   = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(LB_CHAMP_DWH)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @vals_s = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.'+QUOTENAME(LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @vals_t = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.'+QUOTENAME(LB_CHAMP_DWH)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CHARGEMENT=1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        /* Colonnes copiées hors clé : mise à jour SCD1 */
        SELECT
            @set_s1 = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.'+QUOTENAME(LB_CHAMP_DWH)+N' = S.'+QUOTENAME(LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CHARGEMENT=1 AND FL_CLEF=0
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        /* Colonnes comparées : hors clé, hors ordre */
        SELECT
            @cmp_s  = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), S.'+QUOTENAME(LB_CHAMP_ODS)+N'), N''<null>'')'), N' + N''|'' + ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @cmp_t  = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), T.'+QUOTENAME(LB_CHAMP_DWH)+N'), N''<null>'')'), N' + N''|'' + ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CHARGEMENT=1 AND FL_CLEF=0 AND FL_ORDRE_TRI=0
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SET @cmp_s = ISNULL(@cmp_s, N'N''''');
        SET @cmp_t = ISNULL(@cmp_t, N'N''''');

        /* Sens de la modification : porté par CD_DML_TEC quand le sas la
           déclare (traces CDC, y compris en journée INIT), sinon insertion. */
        IF @entree = N'DELTA' AND EXISTS
        (
            SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
            WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND LB_CHAMP_ODS = N'CD_DML_TEC'
        )
            SELECT @sup_s = N'CASE WHEN S.[CD_DML_TEC] = 1 THEN 1 ELSE 0 END', @dml_s = N'S.[CD_DML_TEC]';
        ELSE
            SELECT @sup_s = N'0', @dml_s = N'NULL';

        IF @join_st IS NULL OR @cols IS NULL OR @col_fen IS NULL
        BEGIN
            SET @msg = N'Paramétrage incomplet pour ' + @tbl_ods + N' (clé, colonnes ou colonne d''ordre).';
            THROW 50042, @msg, 1;
        END

        /* L'image : flags de la fenêtre, ou tout le sas flagué en journée INIT. */
        SET @img = N'(SELECT * FROM ' + @src + N' WHERE FL_FIN_JOURNEE = 1'
                 + CASE WHEN @fl_journee_init = 1 THEN N''
                        ELSE N' AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' END
                 + N')';

        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @img + N' AS S;';
        EXEC sp_executesql @sql, @params,
             @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_img OUTPUT;

        /* Image vide : rien à reporter. Pour une image complète, ce n'est pas
           "tout a été supprimé" mais "rien n'a été livré". */
        IF @nb_img = 0
        BEGIN
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'OK',
                    @entree + N' / ' + @alim + N' - image vide, cible non modifiée.', @dt_step, SYSDATETIME());
        END
        ELSE
        BEGIN
            BEGIN TRANSACTION;

            IF @alim = N'SCD2'
            BEGIN
                IF @img_complete = 0
                    /* Image partielle : clés de l'image dont la valeur ou le sens change. */
                    SET @sql = N'UPDATE T SET T.DF_VAL = @p_dt, T.FL_VER_CRT = 0'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' INNER JOIN ' + @img + N' AS S ON ' + @join_st
                             + N' WHERE T.FL_VER_CRT = 1'
                             + N'   AND (' + @cmp_t + N' <> ' + @cmp_s + N' OR T.FL_SUP <> ' + @sup_s + N');'
                             + N' SELECT @p_nb = @@ROWCOUNT;';
                ELSE
                    /* Image complète : clé disparue (encore vivante), ou présente et
                       différente, ou présente avec un autre sens. Une clé déjà
                       supprimée et toujours absente n'est pas touchée. */
                    SET @sql = N'UPDATE T SET T.DF_VAL = @p_dt, T.FL_VER_CRT = 0'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' LEFT JOIN ' + @img + N' AS S ON ' + @join_st
                             + N' WHERE T.FL_VER_CRT = 1'
                             + N'   AND ((S.' + QUOTENAME(@cle1) + N' IS NULL AND T.FL_SUP = 0)'
                             + N'     OR (S.' + QUOTENAME(@cle1) + N' IS NOT NULL'
                             + N'         AND (' + @cmp_t + N' <> ' + @cmp_s + N' OR T.FL_SUP <> ' + @sup_s + N')));'
                             + N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, @params,
                     @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_ferm OUTPUT;

                /* Insertion des clés de l'image sans version courante. */
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, CD_DML_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' SELECT ' + @vals_s
                         + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_mx + N'), 0) + 1'
                         + N', @p_dt, @p_inf, ' + @sup_s + N', 1, ' + @dml_s + N', SYSDATETIME(), @p_usr, @p_trt'
                         + N' FROM ' + @img + N' AS S'
                         + N' WHERE NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T WHERE ' + @join_st + N' AND T.FL_VER_CRT = 1);'
                         + N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, @params,
                     @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_ins OUTPUT;

                /* Image complète : clés disparues -> version FL_SUP = 1. */
                IF @img_complete = 1
                BEGIN
                    SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                             + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, CD_DML_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                             + N' SELECT ' + @vals_t
                             + N', T.NO_SEQ + 1, @p_dt, @p_inf, 1, 1, 1, SYSDATETIME(), @p_usr, @p_trt'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' WHERE T.DF_VAL = @p_dt AND T.FL_VER_CRT = 0 AND T.FL_SUP = 0'
                             + N'   AND NOT EXISTS (SELECT 1 FROM ' + @img + N' AS S WHERE ' + @join_st + N')'
                             + N'   AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T3 WHERE ' + @join_tt + N' AND T3.FL_VER_CRT = 1);'
                             + N' SELECT @p_nb = @@ROWCOUNT;';
                    EXEC sp_executesql @sql, @params,
                         @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_sup OUTPUT;
                END
            END
            ELSE IF @alim = N'SCD1'
            BEGIN
                SET @sql = N'MERGE ' + @tgt + N' AS T USING ' + @img + N' AS S ON ' + @join_st
                         + N' WHEN MATCHED AND (' + @cmp_t + N' <> ' + @cmp_s + N' OR T.FL_SUP <> ' + @sup_s + N')'
                         + N' THEN UPDATE SET '
                         + CASE WHEN @set_s1 IS NOT NULL THEN @set_s1 + N', ' ELSE N'' END
                         + N'T.FL_SUP = ' + @sup_s + N', T.CD_DML_TEC = ' + @dml_s
                         + N', T.NO_SEQ = T.NO_SEQ + 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                         + N' WHEN NOT MATCHED BY TARGET THEN INSERT (' + @cols
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, CD_DML_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' VALUES (' + @vals_s + N', 1, @p_dt, @p_inf, ' + @sup_s + N', 1, ' + @dml_s + N', SYSDATETIME(), @p_usr, @p_trt)'
                         + CASE WHEN @img_complete = 1
                                THEN N' WHEN NOT MATCHED BY SOURCE AND T.FL_SUP = 0 THEN UPDATE SET T.FL_SUP = 1, T.CD_DML_TEC = 1, T.NO_SEQ = T.NO_SEQ + 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                                ELSE N'' END
                         + N'; SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, @params,
                     @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_maj OUTPUT;
            END
            ELSE IF @alim = N'AJOUT'
            BEGIN
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, CD_DML_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' SELECT ' + @vals_s
                         + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_mx + N'), 0) + 1'
                         + N', @p_dt, @p_inf, ' + @sup_s + N', 1, ' + @dml_s + N', SYSDATETIME(), @p_usr, @p_trt'
                         + N' FROM ' + @img + N' AS S; SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, @params,
                     @p_deb=@dt_deb, @p_fin=@dt_fin, @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_ins OUTPUT;
            END

            COMMIT TRANSACTION;

            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh,
                    CASE WHEN @alim = N'SCD1' THEN @nb_maj ELSE @nb_ins + @nb_sup END, N'OK',
                    @entree + N' / ' + @alim + CASE WHEN @fl_journee_init = 1 THEN N' (INIT)' ELSE N'' END
                    + N' - image: ' + CONVERT(NVARCHAR(10), @nb_img)
                    + CASE WHEN @alim = N'SCD2' THEN N' / fermées: ' + CONVERT(NVARCHAR(10),@nb_ferm) + N' / insérées: ' + CONVERT(NVARCHAR(10),@nb_ins)
                                                     + CASE WHEN @nb_sup > 0 THEN N' / supprimées: ' + CONVERT(NVARCHAR(10),@nb_sup) ELSE N'' END
                           WHEN @alim = N'SCD1' THEN N' / lignes touchées: ' + CONVERT(NVARCHAR(10),@nb_maj)
                           ELSE N' / insérées: ' + CONVERT(NVARCHAR(10),@nb_ins) END,
                    @dt_step, SYSDATETIME());
        END
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'KO',
                N'HISTO ' + ISNULL(@alim, N'?') + N' : ' + ERROR_MESSAGE(), @dt_step, SYSDATETIME());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @entree, @alim;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
