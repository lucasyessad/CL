/* ============================================================================
   02_DWH_CREATE_TABLE_ORT_PARAM_HISTORISATION_TRACES
   A EXECUTER SUR LE DWH. Table de parametrage colonne, VIDE. PK et index.
   Alimentee ensuite par la sortie du generateur (06_LIGIS_GEN_PARAMETRAGE).

   Une ligne par colonne. Roles :
     FL_CLEF        identifie la ligne (implique FL_CHARGEMENT = 1)
     FL_CHARGEMENT  copiee dans la cible et comparee
     FL_ORDRE_TRI   ordonne les traces ; la premiere au sens NO_CHAMP borne
                    la fenetre de journee ; copiee si FL_CHARGEMENT = 1 mais
                    jamais comparee
   LB_CHAMP_ODS NULL : ligne documentaire du bloc technique DWH.
   ============================================================================ */
USE [DWH];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.ORT_PARAM_HISTORISATION_TRACES;
GO

CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET      NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS   NVARCHAR(128)  NOT NULL,
    NO_CHAMP       INT            NOT NULL,

    LB_SOURCE      NVARCHAR(260)  NULL,
    LB_TABLE_DWH   NVARCHAR(128)  NULL,
    LB_CHAMP_ODS   NVARCHAR(128)  NULL,
    LB_CHAMP_DWH   NVARCHAR(128)  NULL,

    FL_CLEF        BIT            NOT NULL,
    FL_CHARGEMENT  BIT            NOT NULL,
    FL_ORDRE_TRI   BIT            NOT NULL,

    CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
        PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ROLES
    ON dbo.ORT_PARAM_HISTORISATION_TRACES (LB_PROJET, LB_TABLE_ODS, FL_CLEF, FL_CHARGEMENT)
    INCLUDE (NO_CHAMP, LB_CHAMP_ODS, LB_CHAMP_DWH, FL_ORDRE_TRI);
GO
