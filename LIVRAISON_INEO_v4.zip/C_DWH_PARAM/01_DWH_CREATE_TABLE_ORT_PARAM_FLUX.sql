/* ============================================================================
   01_DWH_CREATE_TABLE_ORT_PARAM_FLUX
   A EXECUTER SUR LE DWH. Table de flux, VIDE. PK et index.

   Une ligne par table alimentee. Les trois axes sont independants :
     CD_MODE_ENTREE  DELTA | FULL     CD_FORMAT  BCP | CSV
     CD_MODE_ALIM    SCD2 | SCD1 | AJOUT | AUCUNE
   LB_FICHIER       fichier quotidien (nom exact ou masque PREFIXE_*.ext)
   LB_FICHIER_INIT  fichier d'etat complet charge par la chaine d'init (BCP)
   NB_MOIS_RETENTION  conservation des traces dans le sas ODS apres
                    archivage ; la purge ne touche jamais l'archive.
   Le repertoire vient de %DATALIB% dans les jobs, pas de la base.
   ============================================================================ */
USE [DWH];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.ORT_PARAM_FLUX;
GO

CREATE TABLE dbo.ORT_PARAM_FLUX
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS    NVARCHAR(128)  NOT NULL,
    LB_TABLE_DWH    NVARCHAR(128)  NULL,
    LB_SOURCE       NVARCHAR(260)  NULL,

    CD_MODE_ENTREE  NVARCHAR(10)   NOT NULL,
    CD_FORMAT       NVARCHAR(10)   NOT NULL,
    CD_MODE_ALIM    NVARCHAR(10)   NOT NULL,

    FL_ACTIF        BIT            NOT NULL,
    NO_ORDRE        INT            NOT NULL,
    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    LB_SCHEMA_ODS   NVARCHAR(128)  NOT NULL,
    LB_SCHEMA_DWH   NVARCHAR(128)  NOT NULL,
    LB_TABLE_AUDIT  NVARCHAR(128)  NULL,
    NB_MOIS_RETENTION INT          NOT NULL,

    LB_FICHIER      NVARCHAR(260)  NULL,
    LB_FICHIER_INIT NVARCHAR(260)  NULL,
    LB_DELIMITEUR   NVARCHAR(10)   NULL,
    NO_LIGNE_DEBUT  INT            NULL,
    LB_ENCODAGE     NVARCHAR(20)   NULL,

    DT_MAJ          DATETIME2(3)   NULL,
    CD_USR_MAJ      NVARCHAR(20)   NULL,
    LB_COMMENTAIRE  NVARCHAR(500)  NULL,

    CONSTRAINT PK_ORT_PARAM_FLUX PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_FLUX_ACTIFS
    ON dbo.ORT_PARAM_FLUX (LB_PROJET, FL_ACTIF, NO_ORDRE)
    INCLUDE (LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM);
GO
