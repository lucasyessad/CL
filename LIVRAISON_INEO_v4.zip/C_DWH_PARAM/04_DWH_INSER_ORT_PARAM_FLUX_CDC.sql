/* ============================================================================
   04_DWH_INSER_ORT_PARAM_FLUX_CDC
   A EXECUTER SUR LE DWH, apres 03 (parametrage colonne rempli).

   Cree une ligne DELTA + BCP + SCD2 par table decrite au grain colonne, avec
   la cible et la source reprises de la ligne cle. Se joue tel quel.
   Ajuster ensuite par UPDATE si une table doit etre en SCD1, AJOUT, AUCUNE
   ou FULL (LB_FICHIER prend alors le nom du fichier d'etat complet).

   Les noms de fichiers suivent le nommage des vues cote progiciel :
     ZBCP_LIGIS_<TABLE>_V.bcp        traces quotidiennes
     ZBCP_INIT_LIGIS_<TABLE>_V.bcp   etat complet
   Ce sont des donnees : modifiables ensuite sans toucher aux jobs.
   ============================================================================ */
USE [DWH];
GO

INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, NB_MOIS_RETENTION,
    LB_FICHIER, LB_FICHIER_INIT,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
SELECT
    S.LB_PROJET, S.LB_TABLE_ODS, S.LB_TABLE_DWH, S.LB_SOURCE,
    N'DELTA', N'BCP', N'SCD2',
    1, 100 + (ROW_NUMBER() OVER (ORDER BY S.LB_TABLE_ODS)) * 10, NULL,
    N'ods', N'dbo', N'OIT_TEC_AUDIT_CDC', 13,
    N'ZBCP_LIGIS_'      + SUBSTRING(S.LB_TABLE_ODS, 5, 200) + N'_V.bcp',
    N'ZBCP_INIT_LIGIS_' + SUBSTRING(S.LB_TABLE_ODS, 5, 200) + N'_V.bcp',
    SYSDATETIME(), N'INIT', N'Flux CDC cree depuis le parametrage colonne'
FROM
(
    SELECT T.LB_PROJET, T.LB_TABLE_ODS, T.LB_TABLE_DWH, T.LB_SOURCE,
           Rang = ROW_NUMBER() OVER
           (
               PARTITION BY T.LB_PROJET, T.LB_TABLE_ODS
               ORDER BY CASE WHEN T.FL_CLEF = 1 THEN 0 ELSE 1 END, T.NO_CHAMP
           )
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
) AS S
WHERE S.Rang = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
      WHERE F.LB_PROJET = S.LB_PROJET AND F.LB_TABLE_ODS = S.LB_TABLE_ODS
  );
GO
