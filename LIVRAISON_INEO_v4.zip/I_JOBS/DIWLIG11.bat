@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG11 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Chargement des fichiers delimites dans ODS INEO              #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 01/09/26                              DATE M.A.J. : 01/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : RIWLIG10                                               #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  Un appel de procedure par fichier. Le format du fichier (delimiteur,         #
REM  en-tete, encodage) vient du parametrage ORT_PARAM_FLUX : il n'est ecrit ni   #
REM  ici, ni dans la procedure.                                                   #
REM  Un masque sans fichier est un avertissement : le referentiel n'a pas ete    #
REM  livre, l'ODS garde son contenu.                                              #
REM                                                                               #
REM  PREREQUIS : BULK INSERT lit le fichier depuis le moteur SQL. Le compte de    #
REM  service SQL Server doit avoir acces a %DATALIB%.                             #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set	SERVER=ERM
set	DBNAME=DWH
set PROJET=%~1
if "%PROJET%"=="" set PROJET=LIGIS

setlocal enableDelayedExpansion

rem Un appel par fichier delimite declare dans le parametrage
set LISTE=%DATALIB%\riwlig11-fichiers.txt

rem Liste des masques de fichiers, lue dans le parametrage
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; SELECT LB_FICHIER FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET='%PROJET%' AND FL_ACTIF=1 AND CD_FORMAT='CSV' AND LB_FICHIER IS NOT NULL ORDER BY NO_ORDRE, LB_FICHIER;" ^
       -o "%LISTE%"
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem Chaque masque est resolu sur le repertoire. Un masque peut donner plusieurs
rem fichiers (suffixe date) ; chacun est charge. Le repertoire vient de
rem %DATALIB%, il n'est pas stocke en base.
for /F "usebackq tokens=1" %%m in ("%LISTE%") do (

	set TROUVE=0

	for %%f in ("%DATALIB%\%%m") do (

		set TROUVE=1
		echo    %%~nxf

		sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
		       -Q "EXEC dbo.PS_CHARGEMENT_FICHIER_ODS @LB_PROJET='%PROJET%', @LB_FICHIER='%%~nxf', @LB_REPERTOIRE='%DATALIB%';"
		set RC=!ERRORLEVEL!
		if !RC! NEQ 0 goto :ERR
	)

	if "!TROUVE!"=="0" echo AVERTISSEMENT : aucun fichier pour le masque %DATALIB%\%%m
)

endlocal
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0
