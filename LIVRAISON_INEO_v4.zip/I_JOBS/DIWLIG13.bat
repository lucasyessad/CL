@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG13 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : ZIP des fichiers ZBCP_* (quotidien et init)                  #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 01/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : RIWLIG12                                               #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  M.A.J. 01/09/26 : trois corrections.                                         #
REM    - setlocal enableDelayedExpansion etait absent alors que le script utilise #
REM      !ZIP_RUN! et !INZIP! : 7za recevait les noms litteraux ;                 #
REM    - %ERRORLVEL% corrige en %ERRORLEVEL% ;                                    #
REM    - "if %RC% NEQ 0 1 goto ERR" corrige, le 1 en trop rendait le test        #
REM      invalide et l'erreur n'etait jamais detectee.                            #
REM  Avec -sdel, un echec non detecte laissait les .bcp en place.                 #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

setlocal enableDelayedExpansion

set "ZIP_RUN=%DATALIB%\IOT_LIGISV5_DONNEE_CDC.zip"

set "INZIP=%DATALIB%\ZBCP_*.bcp"
echo %INZIP%
call %proclib%\7za.exe a -tzip !ZIP_RUN! !INZIP! -sdel	
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

Echo ZIP : %ZIP_RUN% - OK
endlocal
goto FIN

:ERR
exit /B 1
goto :EOF

:FIN
exit /B 0
