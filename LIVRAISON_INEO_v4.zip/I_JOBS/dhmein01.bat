@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIN0                                            JOB : RHMEIN01 #
REM                                                                               #
REM  PROJET   : CREALIA                                    APPLICATION : LIGISV5  #
REM                                                                               #
REM  TITRE SCRIPT  : Export etat complet LIGISV5 par BCP Out (init)               #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 25/08/26                              DATE M.A.J. : 25/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                             URGENCE :              #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

set DBNAME=Ligis5_Dev_Data
set SQL_SRVNAME=ASM

setlocal enableDelayedExpansion

rem Lancement des BCP_OUT sur les vues d'etat complet, plus la vue d'audit
rem (type INIT, mise a jour par dhmein00) attendue par le job d'import.
for /F "usebackq tokens=*" %%i in (`sqlcmd -S %SQL_SRVNAME% -d %DBNAME% -E -h -1 -W -Q "SET NOCOUNT ON; SELECT v.name FROM sys.views v INNER JOIN sys.schemas s ON s.schema_id = v.schema_id WHERE s.name = 'export_cdc' AND (v.name LIKE 'ZBCP_INIT_LIGIS[_]%%[_]V' OR v.name = 'ZBCP_LIGIS_TEC_AUDIT_CDC_V') ORDER BY v.name;"`) do (

	set WKF01=%%i.bcp
	set VIEW=%%i

	"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe" "%DBNAME%.export_cdc.[!VIEW!]" out "%DATALIB%\!WKF01!" -T -S %SQL_SRVNAME% -n

	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

endlocal

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0