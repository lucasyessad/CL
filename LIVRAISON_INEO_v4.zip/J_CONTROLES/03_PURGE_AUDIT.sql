/* ============================================================================
   PURGE DE RETENTION DU JOURNAL
   A planifier une fois par semaine. 13 mois pour les lignes normales,
   24 mois pour les echecs. Suppression par lots.
   ============================================================================ */
USE [DWH];
GO

SET NOCOUNT ON;
DECLARE @lot INT = 5000, @nb INT = 1, @total BIGINT = 0;

WHILE @nb > 0
BEGIN
    DELETE TOP (@lot) FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE (ISNULL(CD_STATUT, N'OK') <> N'KO' AND DT_DEBUT < DATEADD(MONTH, -13, GETDATE()))
       OR (CD_STATUT = N'KO' AND DT_DEBUT < DATEADD(MONTH, -24, GETDATE()));
    SET @nb = @@ROWCOUNT;
    SET @total += @nb;
END

PRINT N'Lignes purgees : ' + CONVERT(NVARCHAR(20), @total);
