/* ============================================================================
   CONTROLES DU PARAMETRAGE
   A passer apres toute modification. Chaque requete doit renvoyer zero ligne.
   Le controle 9 suppose les tables ODS dans la meme base que le DWH (schema
   ods) : il ne voit pas les tables d'archive, dans ODS_Traces.
   Filtrer sur @LB_PROJET pour un projet donne.
   ============================================================================ */
USE [DWH];
GO

DECLARE @LB_PROJET NVARCHAR(50) = N'LIGIS';

/* 1. Table decrite au grain colonne mais absente du grain flux. */
SELECT DISTINCT T.LB_TABLE_ODS, N'flux non declare dans ORT_PARAM_FLUX' AS Probleme
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
WHERE T.LB_PROJET = @LB_PROJET
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
                  WHERE F.LB_PROJET = T.LB_PROJET AND F.LB_TABLE_ODS = T.LB_TABLE_ODS);

/* 2. Flux sans aucune colonne. */
SELECT F.LB_TABLE_ODS, N'aucune colonne decrite' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND F.CD_MODE_ALIM <> N'AUCUNE'
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS);

/* 3. Flux sans colonne cle. */
SELECT F.LB_TABLE_ODS, N'aucune colonne cle' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND F.CD_MODE_ALIM <> N'AUCUNE'
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1);

/* 4. Flux sans colonne d'ordre : elle rattache les lignes a leur journee,
      en DELTA comme en FULL. */
SELECT F.LB_TABLE_ODS, N'aucune colonne d''ordre (FL_ORDRE_TRI)' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND F.CD_MODE_ALIM <> N'AUCUNE'
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_ORDRE_TRI = 1);

/* 5. Cible manquante alors que le flux alimente le DWH. */
SELECT F.LB_TABLE_ODS, N'LB_TABLE_DWH absent' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND F.CD_MODE_ALIM <> N'AUCUNE' AND F.LB_TABLE_DWH IS NULL;

/* 6. Valeurs de mode hors domaine. */
SELECT F.LB_TABLE_ODS, N'mode hors domaine' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET
  AND (F.CD_MODE_ENTREE NOT IN (N'DELTA', N'FULL')
    OR F.CD_FORMAT      NOT IN (N'BCP', N'CSV')
    OR F.CD_MODE_ALIM   NOT IN (N'SCD2', N'SCD1', N'AJOUT', N'AUCUNE'));

/* 7. Tables physiques absentes. */
SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH,
       CASE WHEN OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS)+N'.'+QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
            THEN N'table ODS absente' ELSE N'table DWH absente' END AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND (OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS)+N'.'+QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
    OR (F.LB_TABLE_DWH IS NOT NULL
        AND OBJECT_ID(QUOTENAME(F.LB_SCHEMA_DWH)+N'.'+QUOTENAME(F.LB_TABLE_DWH), N'U') IS NULL));

/* 8. Cle non chargee : une colonne cle doit etre FL_CHARGEMENT = 1. */
SELECT C.LB_TABLE_ODS, C.LB_CHAMP_ODS, N'colonne cle non chargee' AS Probleme
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
WHERE C.LB_PROJET = @LB_PROJET AND C.FL_CLEF = 1 AND C.FL_CHARGEMENT = 0;

/* 9. Colonne parametree absente de la table physique (ODS ou DWH). */
SELECT C.LB_TABLE_ODS, C.LB_CHAMP_ODS, N'colonne absente de la table ODS' AS Probleme
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
INNER JOIN dbo.ORT_PARAM_FLUX AS F
    ON F.LB_PROJET = C.LB_PROJET AND F.LB_TABLE_ODS = C.LB_TABLE_ODS
WHERE C.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1 AND C.LB_CHAMP_ODS IS NOT NULL
  AND COL_LENGTH(QUOTENAME(F.LB_SCHEMA_ODS) + N'.' + QUOTENAME(F.LB_TABLE_ODS), C.LB_CHAMP_ODS) IS NULL
UNION ALL
SELECT C.LB_TABLE_ODS, C.LB_CHAMP_DWH, N'colonne absente de la table DWH'
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
INNER JOIN dbo.ORT_PARAM_FLUX AS F
    ON F.LB_PROJET = C.LB_PROJET AND F.LB_TABLE_ODS = C.LB_TABLE_ODS
WHERE C.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1 AND F.LB_TABLE_DWH IS NOT NULL
  AND C.LB_CHAMP_DWH IS NOT NULL AND C.FL_CHARGEMENT = 1
  AND COL_LENGTH(QUOTENAME(F.LB_SCHEMA_DWH) + N'.' + QUOTENAME(F.LB_TABLE_DWH), C.LB_CHAMP_DWH) IS NULL;

/* 10. Fichier non declare pour un flux BCP. */
SELECT F.LB_TABLE_ODS, N'LB_FICHIER absent' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1 AND F.LB_FICHIER IS NULL;

/* 11. Desaccord entre les deux niveaux sur la cible ou la source. */
SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH AS Flux_Cible, C.LB_TABLE_DWH AS Colonne_Cible,
       N'desaccord flux / colonne' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
INNER JOIN dbo.ORT_PARAM_HISTORISATION_TRACES AS C
    ON C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1
WHERE F.LB_PROJET = @LB_PROJET
  AND (ISNULL(F.LB_TABLE_DWH,N'') <> ISNULL(C.LB_TABLE_DWH,N'')
    OR ISNULL(F.LB_SOURCE,N'')    <> ISNULL(C.LB_SOURCE,N''));
