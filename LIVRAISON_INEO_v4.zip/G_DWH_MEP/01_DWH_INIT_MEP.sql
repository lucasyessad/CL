/* ============================================================================
   MISE EN PRODUCTION  -  à exécuter une fois, avant la première chaîne

   Deux lignes à poser :
     1. le pilotage PWTTRE du scénario, clé par nom de scénario (un scénario
        sert un projet) ;
     2. la borne INIT du projet, à la date de reprise choisie.

   La première exécution est une initialisation : DIWLIN10 charge les
   fichiers d'état complet, DIWLIN11 crée les versions datées DD_VAL =
   @DT_REPRISE et consomme la borne (FL_TRAITE = 1). Les bornes
   quotidiennes sont ensuite posées à partir du lendemain de @DT_REPRISE.

   Rejouer une initialisation plus tard : poser une nouvelle borne INIT
   (bloc 2 seul) puis relancer DIWLIN10 / DIWLIN11. L'historique existant
   est conservé, seuls les écarts créent des versions.
   ============================================================================ */
USE [DWH];
GO

DECLARE @LB_PROJET      NVARCHAR(50)  = N'LIGIS';
DECLARE @LB_NOM_SCN_SUN NVARCHAR(100) = N'IWI_LIGIS_TRACES_CSTIMG';
DECLARE @DT_REPRISE     DATE          = '2026-06-01';

/* 1. Pilotage du scénario --------------------------------------------------- */
DELETE FROM dbo.PWTTRE
WHERE LB_NOM_SCN_SUN = @LB_NOM_SCN_SUN;

INSERT INTO dbo.PWTTRE
    (LB_NOM_SCN_SUN, LB_TRT, DA_DEB_DEL_TRT, DA_DON_A_TRT, DA_FIN_DEL_FOR,
     NO_SEQ, LB_DOMAINE, CD_FRQ_ALI, CD_TYP_SRC)
VALUES
    (@LB_NOM_SCN_SUN,
     N'Alimentation des tables OWT_* et OIT_*_HISTO depuis le sas OIT_* du projet ' + @LB_PROJET,
     CONVERT(DATETIME2(3), @DT_REPRISE), NULL, NULL,
     1, N'Recouvrement', N'J', N'B');

/* 2. Borne d'initialisation ------------------------------------------------- */
DELETE FROM dbo.ORT_BORNE_JOURNEE
WHERE LB_PROJET = @LB_PROJET
  AND DT_JOUR   = CONVERT(DATETIME2(3), @DT_REPRISE);

INSERT INTO dbo.ORT_BORNE_JOURNEE
    (LB_PROJET, DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, FL_TRAITE, DT_POSE, COMMENTAIRE)
VALUES
    (@LB_PROJET,
     CONVERT(DATETIME2(3), @DT_REPRISE),
     CONVERT(DATETIME2(3), @DT_REPRISE),
     N'INIT', N'MANUEL', 0, SYSDATETIME(),
     N'Date de reprise de l''initialisation');
GO
