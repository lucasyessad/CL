/* ============================================================================
   RECEPTION DE L'AUDIT CDC  -  ods.OIT_TEC_AUDIT_CDC

   A chaque extraction, le progiciel produit un fichier d'audit qui indique,
   pour chaque instance, les bornes LSN de l'extraction, les dates couvertes,
   le numero de sequence et le type d'extraction :
     CDC   plage de traces, seule a faire avancer les bornes de journee
     INIT  etat complet pris au LSN LB_FIN_LSN
     FULL  etat complet d'une table hors CDC

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS ods.OIT_TEC_AUDIT_CDC;
GO

CREATE TABLE ods.OIT_TEC_AUDIT_CDC
(
    ID_INSTANCE    binary(32)    NULL,
    LB_INSTANCE    varchar(50)   NOT NULL,
    LB_DEB_LSN     binary(10)    NULL,
    LB_FIN_LSN     binary(10)    NULL,
    DT_DEB_LSN     datetime2(3)  NOT NULL,
    DT_FIN_LSN     datetime2(3)  NULL,
    DT_EXTRACT     datetime2(3)  NULL,
    NO_SEQUENCE    bigint        NOT NULL,
    CD_TYPE_EXTRACT varchar(10)  NOT NULL
);
GO

CREATE NONCLUSTERED INDEX IX_OIT_TEC_AUDIT_CDC_INSTANCE
    ON ods.OIT_TEC_AUDIT_CDC
    (
        LB_INSTANCE
    )
    INCLUDE
    (
        LB_DEB_LSN,
        LB_FIN_LSN,
        DT_FIN_LSN,
        DT_EXTRACT,
        NO_SEQUENCE,
        CD_TYPE_EXTRACT
    );
GO

CREATE NONCLUSTERED INDEX IX_OIT_TEC_AUDIT_CDC_SEQUENCE
    ON ods.OIT_TEC_AUDIT_CDC
    (
        NO_SEQUENCE,
        LB_INSTANCE
    )
    INCLUDE
    (
        LB_DEB_LSN,
        LB_FIN_LSN,
        DT_DEB_LSN,
        DT_FIN_LSN,
        DT_EXTRACT
    );
GO
