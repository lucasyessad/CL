/* ============================================================================
   TABLE DES FRONTIERES DE JOURNEE  -  dbo.ORT_BORNE_JOURNEE

   Une journee de travail ne s'arrete pas necessairement a minuit.
   DT_JOUR identifie la journee fonctionnelle, normalisee a 00:00:00.000.
   DT_BORNE contient la frontiere effective avec l'heure et les millisecondes.

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.ORT_BORNE_JOURNEE;
GO

CREATE TABLE dbo.ORT_BORNE_JOURNEE
(
    LB_PROJET        nvarchar(50)  NOT NULL,
	DT_JOUR          datetime2(3)  NOT NULL,
    DT_BORNE         datetime2(3)  NOT NULL,
    TYPE_BORNE       nvarchar(15)  NOT NULL,
    ORIGINE_VALEUR   nvarchar(20)  NOT NULL,
    FL_TRAITE        bit           NOT NULL,
    DT_POSE          datetime2(3)  NOT NULL,
    COMMENTAIRE      nvarchar(500) NULL,

    CONSTRAINT PK_ORT_BORNE_JOURNEE
        PRIMARY KEY CLUSTERED
        (
            LB_PROJET ASC,
            DT_JOUR ASC
        )
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_BORNE_JOURNEE_BORNE
    ON dbo.ORT_BORNE_JOURNEE
    (
        LB_PROJET ASC,
		DT_BORNE
    )
    INCLUDE
    (
        DT_JOUR,
        TYPE_BORNE,
        ORIGINE_VALEUR
    );
GO
