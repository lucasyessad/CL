/* ============================================================================
   HISTORIQUE DES EXTRACTIONS  -  dbo.OWT_TEC_AUDIT_CDC

   La table ods.OIT_TEC_AUDIT_CDC est videe a chaque import. Cette table
   conserve donc l'historique des extractions CDC et permet notamment de :

     - justifier la fermeture d'une journee ;
     - suivre l'evolution des bornes d'extraction ;
     - detecter une rupture de capture entre deux LSN ;
     - detecter une rupture de sequence.

   Une extraction est un evenement immutable. Les nouvelles lignes sont
   ajoutees sans mise a jour des lignes deja archivees.

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Les colonnes techniques lisibles sont placees au debut.
   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */
   
USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.OWT_TEC_AUDIT_CDC;
GO

CREATE TABLE dbo.OWT_TEC_AUDIT_CDC
(
    LB_PROJET       nvarchar(50)  NOT NULL,
    NO_SEQUENCE     bigint        NOT NULL,
    LB_INSTANCE     varchar(50)   NOT NULL,
    CD_TYPE_EXTRACT varchar(10)   NOT NULL,
    DT_JOUR_TEC     datetime2(3)  NULL,
    DT_DEB_LSN      datetime2(3)  NULL,
    DT_FIN_LSN      datetime2(3)  NULL,
    DT_EXTRACT      datetime2(3)  NULL,
    ID_INSTANCE     binary(32)    NULL,
    LB_DEB_LSN      binary(10)    NULL,
    LB_FIN_LSN      binary(10)    NULL,
    DT_MAJ_TRT      datetime2(3)  NULL,
    CD_USR_MAJ      nvarchar(20)  NULL,
    ID_TRT_ALI      bigint        NULL
);
GO

CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUDIT_CDC_EXTRACTION
    ON dbo.OWT_TEC_AUDIT_CDC
    (
        LB_PROJET,
        LB_INSTANCE,
        NO_SEQUENCE
    );
GO

CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUDIT_CDC_JOUR
    ON dbo.OWT_TEC_AUDIT_CDC
    (
        DT_JOUR_TEC
    )
    INCLUDE
    (
        LB_INSTANCE,
        DT_FIN_LSN,
        NO_SEQUENCE,
        ID_TRT_ALI
    );
GO

CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUDIT_CDC_SEQUENCE
    ON dbo.OWT_TEC_AUDIT_CDC
    (
        NO_SEQUENCE
    )
    INCLUDE
    (
        LB_INSTANCE,
        DT_DEB_LSN,
        DT_FIN_LSN,
        DT_EXTRACT
    );
GO

CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUDIT_CDC_EXTRACTION_DATE
    ON dbo.OWT_TEC_AUDIT_CDC
    (
        DT_EXTRACT,
        LB_INSTANCE
    )
    INCLUDE
    (
        NO_SEQUENCE,
        DT_JOUR_TEC,
        DT_DEB_LSN,
        DT_FIN_LSN
    );
GO
