/* ============================================================================
   dbo.ORT_PERIODE_REPRISE

   File des journees a traiter, une ligne par journee et par scenario. Videe et
   reconstruite a chaque execution par l'etape ODI 003, marquee par l'etape 008.

   Un scenario sert un projet : LB_PROJET est porte comme dans toutes les
   tables du dispositif, le nom de scenario reste la cle de travail.

   PK et index seulement.
   ============================================================================ */
USE [DWH];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.ORT_PERIODE_REPRISE', N'U') IS NOT NULL
    DROP TABLE dbo.ORT_PERIODE_REPRISE;
GO

CREATE TABLE dbo.ORT_PERIODE_REPRISE
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    DT_JOUR          DATE           NOT NULL,
    NO_SEQ          INT            NOT NULL,
    FL_TRAITE          BIT            NOT NULL,
    LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,

    CONSTRAINT PK_ORT_PERIODE_REPRISE PRIMARY KEY CLUSTERED (LB_PROJET, LB_NOM_SCN_SUN, DT_JOUR)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PERIODE_REPRISE_A_TRAITER
    ON dbo.ORT_PERIODE_REPRISE (LB_NOM_SCN_SUN, FL_TRAITE, DT_JOUR);
GO
