-- schema logique : MSSQL_DWH
-- type : S

DECLARE @DT_TRACES DATE = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI INT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE = '2400-01-01';
DECLARE @CD_USR_MAJ NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';
DECLARE @PFX_ODS NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';
DECLARE
    @dt_deb DATETIME2(3),
    @dt_fin DATETIME2(3),
    @msg    NVARCHAR(2000),
    @jour   NVARCHAR(10) =
        CONVERT(NVARCHAR(10), @DT_TRACES, 23);

/* ============================================================================
   1. FENETRE ] BORNE PRECEDENTE ; BORNE DE LA JOURNEE ]
   ============================================================================ */

SELECT
    @dt_fin = B.DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR = @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

SELECT
    @dt_deb = MAX(B.DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR < @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg =
          N'Fenetre non definie pour le '
        + @jour
        + N' dans ORT_BORNE_JOURNEE pour le projet '
        + @LB_PROJET
        + N'.';

    THROW 50011, @msg, 1;
END;

/* ============================================================================
   2. VARIABLES DE TRAITEMENT
   ============================================================================ */

DECLARE
    @tbl_ods   NVARCHAR(128),
    @tbl_dwh   NVARCHAR(200),
    @src       NVARCHAR(400),
    @tgt       NVARCHAR(400),
    @cle_ods   NVARCHAR(MAX),
    @join_cond NVARCHAR(MAX),
    @join_max  NVARCHAR(MAX),
    @cols_dwh  NVARCHAR(MAX),
    @vals_ods  NVARCHAR(MAX),
    @col_fen   NVARCHAR(128),
    @filtre    NVARCHAR(1000),
    @sql       NVARCHAR(MAX),
    @nb_flag   INT,
    @nb_deja   INT,
    @nb_ferm   INT,
    @nb_ins    INT,
    @dt_step   DATETIME2(3);

/* ============================================================================
   3. LISTE DES TABLES ACTIVES
   ============================================================================ */

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        P.LB_TABLE_ODS,
        MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
    WHERE P.LB_PROJET = @LB_PROJET
      AND P.FL_CLEF = 1
      AND P.FL_CHARGEMENT = 1
      AND P.LB_TABLE_ODS LIKE N'OIT[_]%'
      AND NOT EXISTS
      (
          SELECT
              1
          FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
          WHERE ISNULL(A.ID_TRT_ALI, -1) =
                ISNULL(@ID_TRT_ALI, -1)
            AND A.LB_PROJET = @LB_PROJET
            AND A.CD_STATUT = N'KO'
            AND A.LB_SOURCE = P.LB_TABLE_ODS
            AND CHARINDEX
                (
                    N'[' + @jour + N']',
                    A.LB_CHARGEMENT
                ) > 0
      )
    GROUP BY
        P.LB_TABLE_ODS
    ORDER BY
        P.LB_TABLE_ODS;

OPEN cur_tables;

FETCH NEXT FROM cur_tables
INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SET @nb_flag = 0;
    SET @nb_deja = 0;
    SET @nb_ferm = 0;
    SET @nb_ins = 0;

    BEGIN TRY

        SET @src =
              @PFX_ODS
            + QUOTENAME(@tbl_ods);

        SET @tgt =
              @PFX_DWH
            + QUOTENAME(@tbl_dwh);

        SELECT
            @cle_ods   = NULL,
            @join_cond = NULL,
            @join_max  = NULL,
            @cols_dwh  = NULL,
            @vals_ods  = NULL,
            @col_fen   = NULL,
            @filtre    = NULL;

        /* ====================================================================
           4. CLE METIER ET CONDITIONS DE JOINTURE
           ==================================================================== */

        SELECT
            @cle_ods =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        QUOTENAME(P.LB_CHAMP_ODS)
                    ),
                    N','
                )
                WITHIN GROUP
                (
                    ORDER BY P.NO_CHAMP
                ),

            @join_cond =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        N'S.'
                        + QUOTENAME(P.LB_CHAMP_ODS)
                        + N' = T.'
                        + QUOTENAME(P.LB_CHAMP_DWH)
                    ),
                    N' AND '
                )
                WITHIN GROUP
                (
                    ORDER BY P.NO_CHAMP
                ),

            @join_max =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        N'T2.'
                        + QUOTENAME(P.LB_CHAMP_DWH)
                        + N' = S.'
                        + QUOTENAME(P.LB_CHAMP_ODS)
                    ),
                    N' AND '
                )
                WITHIN GROUP
                (
                    ORDER BY P.NO_CHAMP
                )
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CLEF = 1
          AND P.LB_CHAMP_ODS IS NOT NULL
          AND P.LB_CHAMP_DWH IS NOT NULL;

        /* ====================================================================
           5. COLONNES TRANSFEREES DE L'OIT VERS L'OWT
           ==================================================================== */

        SELECT
            @cols_dwh =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        QUOTENAME(P.LB_CHAMP_DWH)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY P.NO_CHAMP
                ),

            @vals_ods =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        N'S.' + QUOTENAME(P.LB_CHAMP_ODS)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY P.NO_CHAMP
                )
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.LB_CHAMP_ODS IS NOT NULL
          AND P.LB_CHAMP_DWH IS NOT NULL;

        /* ====================================================================
           6. COLONNE TEMPORELLE DE LA FENETRE
           ==================================================================== */

        SELECT TOP (1)
            @col_fen = P.LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_ORDRE_TRI = 1
          AND P.LB_CHAMP_ODS IS NOT NULL
        ORDER BY
            P.NO_CHAMP;

        /* ====================================================================
           7. FILTRE COMPLEMENTAIRE
           ==================================================================== */

        SELECT
            @filtre = MAX(P.LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CLEF = 1;

        /* ====================================================================
           8. CONTROLE DU PARAMETRAGE
           ==================================================================== */

        IF @cle_ods IS NULL
           OR @join_cond IS NULL
           OR @join_max IS NULL
           OR @cols_dwh IS NULL
           OR @vals_ods IS NULL
           OR @col_fen IS NULL
        BEGIN
            SET @msg =
                  N'Parametrage incomplet pour '
                + @tbl_ods
                + N' et le projet '
                + @LB_PROJET
                + N'.';

            THROW 50032, @msg, 1;
        END;

        SET @filtre =
            ISNULL(@filtre, N'');

        /* ====================================================================
           9. NOMBRE DE TRACES DE FIN DE JOURNEE
           ==================================================================== */

        SET @sql =
              N'SELECT @p_nb = COUNT(*)'
            + N' FROM ' + @src + N' AS S'
            + N' WHERE S.FL_FIN_JOURNEE = 1'
            + N'   AND S.' + QUOTENAME(@col_fen)
            + N' > @p_deb'
            + N'   AND S.' + QUOTENAME(@col_fen)
            + N' <= @p_fin'
            + CASE
                  WHEN @filtre <> N''
                      THEN N' AND ' + @filtre
                  ELSE N''
              END
            + N';';

        EXEC sys.sp_executesql
             @sql,
             N'@p_deb datetime2(3),
               @p_fin datetime2(3),
               @p_nb int OUTPUT',
             @p_deb = @dt_deb,
             @p_fin = @dt_fin,
             @p_nb = @nb_flag OUTPUT;

        /* ====================================================================
           10. CONTROLE D'UNE JOURNEE DEJA HISTORISEE
           ==================================================================== */

        SET @sql =
              N'SELECT @p_nb = COUNT(*)'
            + N' FROM ' + @tgt
            + N' WHERE DD_VAL = @p_dt;';

        EXEC sys.sp_executesql
             @sql,
             N'@p_dt date,
               @p_nb int OUTPUT',
             @p_dt = @DT_TRACES,
             @p_nb = @nb_deja OUTPUT;

        /* ====================================================================
           11. HISTORISATION UNIQUEMENT EN PRESENCE DE TRACES

           La condition est volontairement formulee avec @nb_flag > 0.

           Cela evite un bloc BEGIN/END vide suivi d'un ELSE, qui provoquait :
               Syntaxe incorrecte vers le mot cle ELSE.
           ==================================================================== */

        IF @nb_flag > 0
        BEGIN

            /* ================================================================
               11.1. JOURNEE DEJA HISTORISEE
               ================================================================ */

            IF @nb_deja > 0
            BEGIN
                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (
                    ID_TRT_ALI,
                    LB_PROJET,
                    LB_CHARGEMENT,
                    LB_SOURCE,
                    LB_CIBLE,
                    NB_LIGNE,
                    CD_STATUT,
                    LB_ERREUR,
                    DT_DEBUT,
                    DT_FIN
                )
                VALUES
                (
                    @ID_TRT_ALI,
                    @LB_PROJET,
                    N'TRACES [' + @jour + N']',
                    @tbl_ods,
                    @tbl_dwh,
                    0,
                    N'OK',
                    N'IGNORE: journee deja historisee ('
                    + CONVERT(NVARCHAR(10), @nb_deja)
                    + N' version(s)). Relancer depuis PURGE OWT '
                    + N'pour reconstruire la journee.',
                    @dt_step,
                    SYSDATETIME()
                );
            END
            ELSE
            BEGIN

                /*
                    La fermeture des versions courantes et l'insertion
                    des nouvelles versions sont executees dans une meme
                    transaction.
                */

                BEGIN TRANSACTION;

                /* ============================================================
                   11.2. FERMETURE DES VERSIONS COURANTES
                   ============================================================ */

                SET @sql =
                      N'UPDATE T'
                    + N' SET T.DF_VAL = @p_dt,'
                    + N'     T.FL_VER_CRT = 0'
                    + N' FROM ' + @tgt + N' AS T'
                    + N' INNER JOIN'
                    + N' ('
                    + N'     SELECT DISTINCT ' + @cle_ods
                    + N'     FROM ' + @src + N' AS S'
                    + N'     WHERE S.FL_FIN_JOURNEE = 1'
                    + N'       AND S.' + QUOTENAME(@col_fen)
                    + N' > @p_deb'
                    + N'       AND S.' + QUOTENAME(@col_fen)
                    + N' <= @p_fin'
                    + CASE
                          WHEN @filtre <> N''
                              THEN N' AND ' + @filtre
                          ELSE N''
                      END
                    + N' ) AS S'
                    + N'     ON ' + @join_cond
                    + N' WHERE T.FL_VER_CRT = 1;'
                    + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql
                     @sql,
                     N'@p_dt date,
                       @p_deb datetime2(3),
                       @p_fin datetime2(3),
                       @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES,
                     @p_deb = @dt_deb,
                     @p_fin = @dt_fin,
                     @p_nb = @nb_ferm OUTPUT;

                /* ============================================================
                   11.3. INSERTION DES NOUVELLES VERSIONS
                   ============================================================ */

                SET @sql =
                      N'INSERT INTO ' + @tgt
                    + N' ('
                    + @cols_dwh
                    + N', NO_SEQ'
                    + N', DD_VAL'
                    + N', DF_VAL'
                    + N', FL_SUP'
                    + N', FL_VER_CRT'
                    + N', DT_MAJ_TRT'
                    + N', CD_USR_MAJ'
                    + N', ID_TRT_ALI'
                    + N')'
                    + N' SELECT '
                    + @vals_ods
                    + N', ISNULL'
                    + N'  ('
                    + N'      ('
                    + N'          SELECT MAX(T2.NO_SEQ)'
                    + N'          FROM ' + @tgt + N' AS T2'
                    + N'          WHERE ' + @join_max
                    + N'      ),'
                    + N'      0'
                    + N'  ) + 1'
                    + N', @p_dt'
                    + N', @p_infini'
                    + N', CASE'
                    + N'      WHEN S.CD_DML_TEC = 1 THEN 1'
                    + N'      ELSE NULL'
                    + N'  END'
                    + N', 1'
                    + N', SYSDATETIME()'
                    + N', @p_usr'
                    + N', @p_trt'
                    + N' FROM ' + @src + N' AS S'
                    + N' WHERE S.FL_FIN_JOURNEE = 1'
                    + N'   AND S.' + QUOTENAME(@col_fen)
                    + N' > @p_deb'
                    + N'   AND S.' + QUOTENAME(@col_fen)
                    + N' <= @p_fin'
                    + CASE
                          WHEN @filtre <> N''
                              THEN N' AND ' + @filtre
                          ELSE N''
                      END
                    + N';'
                    + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql
                     @sql,
                     N'@p_dt date,
                       @p_infini date,
                       @p_deb datetime2(3),
                       @p_fin datetime2(3),
                       @p_usr nvarchar(20),
                       @p_trt int,
                       @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES,
                     @p_infini = @DATE_INFINIE,
                     @p_deb = @dt_deb,
                     @p_fin = @dt_fin,
                     @p_usr = @CD_USR_MAJ,
                     @p_trt = @ID_TRT_ALI,
                     @p_nb = @nb_ins OUTPUT;

                /* ============================================================
                   11.4. CONTROLE DE VOLUMETRIE
                   ============================================================ */

                IF @nb_ins <> @nb_flag
                BEGIN
                    SET @msg =
                          N'Historisation incomplete pour '
                        + @tbl_dwh
                        + N' : '
                        + CONVERT(NVARCHAR(10), @nb_flag)
                        + N' trace(s) flaguee(s), '
                        + CONVERT(NVARCHAR(10), @nb_ins)
                        + N' version(s) inseree(s).';

                    THROW 50033, @msg, 1;
                END;

                COMMIT TRANSACTION;

                /* ============================================================
                   11.5. JOURNALISATION DU SUCCES
                   ============================================================ */

                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (
                    ID_TRT_ALI,
                    LB_PROJET,
                    LB_CHARGEMENT,
                    LB_SOURCE,
                    LB_CIBLE,
                    NB_LIGNE,
                    CD_STATUT,
                    LB_ERREUR,
                    DT_DEBUT,
                    DT_FIN
                )
                VALUES
                (
                    @ID_TRT_ALI,
                    @LB_PROJET,
                    N'TRACES [' + @jour + N']',
                    @tbl_ods,
                    @tbl_dwh,
                    @nb_ins,
                    N'OK',
                    N'Flaguees: '
                    + CONVERT(NVARCHAR(10), @nb_flag)
                    + N' / fermees: '
                    + CONVERT(NVARCHAR(10), @nb_ferm)
                    + N' / inserees: '
                    + CONVERT(NVARCHAR(10), @nb_ins)
                    + N'.',
                    @dt_step,
                    SYSDATETIME()
                );
            END;
        END;
    END TRY
    BEGIN CATCH

        /* ====================================================================
           12. ROLLBACK ET JOURNALISATION DE L'ERREUR
           ==================================================================== */

        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        SET @msg =
              N'HISTO : '
            + ERROR_MESSAGE()
            + N' [erreur '
            + CONVERT(NVARCHAR(20), ERROR_NUMBER())
            + N', ligne '
            + CONVERT(NVARCHAR(20), ERROR_LINE())
            + N']';

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (
            ID_TRT_ALI,
            LB_PROJET,
            LB_CHARGEMENT,
            LB_SOURCE,
            LB_CIBLE,
            NB_LIGNE,
            CD_STATUT,
            LB_ERREUR,
            DT_DEBUT,
            DT_FIN
        )
        VALUES
        (
            @ID_TRT_ALI,
            @LB_PROJET,
            N'TRACES [' + @jour + N']',
            @tbl_ods,
            @tbl_dwh,
            0,
            N'KO',
            @msg,
            @dt_step,
            SYSDATETIME()
        );
    END CATCH;

    FETCH NEXT FROM cur_tables
    INTO @tbl_ods, @tbl_dwh;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;