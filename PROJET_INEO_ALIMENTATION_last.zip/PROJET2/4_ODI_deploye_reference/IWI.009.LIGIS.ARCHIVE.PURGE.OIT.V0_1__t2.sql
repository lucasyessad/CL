-- schema logique : MSSQL_ODS
-- type : S

DECLARE @ID_TRT_ALI INT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @CD_USR_MAJ NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';

/* Base ODS contenant les tables OIT_* */
DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.'
  + N'<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';

/* Base ODS_Traces contenant les tables OIT_*_HISTO */
DECLARE @PFX_HISTO NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS_TRACES", "D") ?>.'
  + N'<?=odiRef.getSchemaName("MSSQL_ODS_TRACES", "D") ?>.';

DECLARE
    @frontiere DATETIME2(3),
    @jour_max  DATE,
    @msg       NVARCHAR(2000),
    @nb_ko     INT = 0,
    @dt_step   DATETIME2(3);

/* ============================================================================
   1. DERNIERE JOURNEE CALCULEE OU RECALCULEE AVEC SUCCES

   PITCOT_PERIODE_REPRISE contient les journees de l'execution courante.

   IWI.008.LIGIS.FLAG.DATE positionne TRAITE = 1 uniquement apres
   le controle reussi de la journee.
   ============================================================================ */

SELECT
    @jour_max = MAX(CONVERT(DATE, P.DD_VAL, 121))
FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> AS P
WHERE P.LB_NOM_SCN_SUN =
      '<?=odiRef.getSession("SESS_NAME") ?>'
  AND P.TRAITE = 1;

/* ============================================================================
   2. BORNE CORRESPONDANT A LA DERNIERE JOURNEE TRAITEE

   ORT_BORNE_JOURNEE reste la source de la frontiere technique.
   ============================================================================ */

SELECT
    @frontiere = B.DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.LB_PROJET = @LB_PROJET
  AND CONVERT(DATE, B.DT_JOUR, 121) = @jour_max;

/* ============================================================================
   3. AUCUNE JOURNEE TRAITEE OU BORNE CORRESPONDANTE ABSENTE
   ============================================================================ */

IF @jour_max IS NULL OR @frontiere IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'ARCHIVE OIT',
        N'*TOUTES*',
        NULL,
        0,
        N'OK',
        CASE
            WHEN @jour_max IS NULL
                THEN
                    N'IGNORE: aucune journee calculee ou recalculee '
                    + N'avec succes pour cette execution. '
                    + N'Rien a archiver.'
            ELSE
                    N'IGNORE: borne absente dans ORT_BORNE_JOURNEE '
                    + N'pour le projet '
                    + @LB_PROJET
                    + N' et la journee '
                    + CONVERT(NVARCHAR(10), @jour_max, 23)
                    + N'. Rien a archiver.'
        END,
        SYSDATETIME(),
        SYSDATETIME()
    );

    RETURN;
END;

/* ============================================================================
   4. VARIABLES UTILISEES POUR CHAQUE TABLE
   ============================================================================ */

DECLARE
    @tbl_ods          NVARCHAR(128),
    @tbl_histo        NVARCHAR(200),
    @src              NVARCHAR(400),
    @tgt              NVARCHAR(400),
    @cols             NVARCHAR(MAX),
    @cols_src         NVARCHAR(MAX),
    @jour_expr        NVARCHAR(MAX),
    @sql              NVARCHAR(MAX),
    @nb_a_traiter     BIGINT,
    @nb_supp_histo    BIGINT,
    @nb_ins_histo     BIGINT,
    @nb_absentes      BIGINT,
    @nb_non_conformes BIGINT,
    @nb_purgees       BIGINT;

/* ============================================================================
   5. LISTE DES TABLES OIT ACTIVES DU PROJET
   ============================================================================ */

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        P.LB_TABLE_ODS
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
    WHERE P.LB_PROJET = @LB_PROJET
      AND P.FL_CLEF = 1
      AND P.FL_CHARGEMENT = 1
      AND P.LB_TABLE_ODS LIKE N'OIT[_]%'
    GROUP BY
        P.LB_TABLE_ODS
    ORDER BY
        P.LB_TABLE_ODS;

OPEN cur_tables;

FETCH NEXT FROM cur_tables
INTO @tbl_ods;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SET @tbl_histo = @tbl_ods + N'_HISTO';
    SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
    SET @tgt = @PFX_HISTO + QUOTENAME(@tbl_histo);

    SELECT
        @cols             = NULL,
        @cols_src         = NULL,
        @jour_expr        = NULL,
        @sql              = NULL,
        @nb_a_traiter     = 0,
        @nb_supp_histo    = 0,
        @nb_ins_histo     = 0,
        @nb_absentes      = 0,
        @nb_non_conformes = 0,
        @nb_purgees       = 0;

    BEGIN TRY

        /* ====================================================================
           6. CONSTRUCTION DES COLONNES DEPUIS LE PARAMETRAGE

           Toutes les colonnes avec LB_CHAMP_ODS renseigne sont reprises.

           Les colonnes propres a l'OWT ont LB_CHAMP_ODS = NULL et sont donc
           exclues automatiquement.

           L'ordre des colonnes est defini par NO_CHAMP.
           ==================================================================== */

        ;WITH ColonnesParametrees AS
        (
            SELECT
                P.LB_CHAMP_ODS,
                NO_CHAMP = MIN(P.NO_CHAMP)
            FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
            WHERE P.LB_PROJET = @LB_PROJET
              AND P.LB_TABLE_ODS = @tbl_ods
              AND P.LB_CHAMP_ODS IS NOT NULL
            GROUP BY
                P.LB_CHAMP_ODS
        )
        SELECT
            @cols =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        QUOTENAME(C.LB_CHAMP_ODS)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY C.NO_CHAMP
                ),

            @cols_src =
                STRING_AGG
                (
                    CONVERT
                    (
                        NVARCHAR(MAX),
                        N'S.' + QUOTENAME(C.LB_CHAMP_ODS)
                    ),
                    N', '
                )
                WITHIN GROUP
                (
                    ORDER BY C.NO_CHAMP
                )
        FROM ColonnesParametrees AS C;

        IF @cols IS NULL OR @cols_src IS NULL
        BEGIN
            SET @msg =
                  N'Aucune colonne OIT parametree pour '
                + @tbl_ods
                + N' et le projet '
                + @LB_PROJET
                + N'.';

            THROW 50040, @msg, 1;
        END;

        /* ====================================================================
           7. RATTACHEMENT A LA JOURNEE FONCTIONNELLE

           Une trace est rattachee a la premiere journee dont la borne est
           superieure ou egale a DT_COMMIT_TEC.
           ==================================================================== */

        SET @jour_expr =
              N'('
            + N'    SELECT TOP (1)'
            + N'        B.DT_JOUR'
            + N'    FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B'
            + N'    WHERE B.LB_PROJET = @p_projet'
            + N'      AND B.DT_BORNE >= S.DT_COMMIT_TEC'
            + N'    ORDER BY B.DT_BORNE'
            + N')';

        /* ====================================================================
           8. CALCUL DE LA VOLUMETRIE A TRAITER
           ==================================================================== */

        SET @sql =
              N'SELECT @p_nb = COUNT_BIG(*)'
            + N' FROM ' + @src + N' AS S'
            + N' WHERE S.DT_COMMIT_TEC <= @p_front;';

        EXEC sys.sp_executesql
             @sql,
             N'@p_front datetime2(3),
               @p_nb bigint OUTPUT',
             @p_front = @frontiere,
             @p_nb = @nb_a_traiter OUTPUT;

        IF @nb_a_traiter > 0
        BEGIN
            /*
                Toutes les operations de la table sont atomiques :

                - suppression des anciennes images HISTO ;
                - reinsertion des images recalculees ;
                - controles de coherence ;
                - purge des lignes OIT.
            */

            BEGIN TRANSACTION;

            /* ================================================================
               9. SUPPRESSION DES ANCIENNES IMAGES HISTO

               Une trace est identifiee par :

                   LB_LSN_COMMIT_TEC
                   LB_SEQVAL_TEC
               ================================================================ */

            SET @sql =
                  N'DELETE H'
                + N' FROM ' + @tgt + N' AS H'
                + N' INNER JOIN ' + @src + N' AS S'
                + N'     ON H.LB_LSN_COMMIT_TEC'
                + N'        = S.LB_LSN_COMMIT_TEC'
                + N'    AND H.LB_SEQVAL_TEC'
                + N'        = S.LB_SEQVAL_TEC'
                + N' WHERE S.DT_COMMIT_TEC <= @p_front;'
                + N' SELECT @p_nb = @@ROWCOUNT;';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_front datetime2(3),
                   @p_nb bigint OUTPUT',
                 @p_front = @frontiere,
                 @p_nb = @nb_supp_histo OUTPUT;

            /* ================================================================
               10. REINSERTION DES IMAGES RECALCULEES

               Toutes les colonnes OIT sont reinserees, notamment :

                   FL_FIN_JOURNEE
                   DT_COMMIT_TEC
                   LB_SEQVAL_TEC
                   LB_LSN_COMMIT_TEC
               ================================================================ */

            SET @sql =
                  N'INSERT INTO ' + @tgt
                + N' ('
                + @cols
                + N', DT_JOUR_TEC'
                + N', DT_MAJ_TRT'
                + N', CD_USR_MAJ'
                + N', ID_TRT_ALI'
                + N')'
                + N' SELECT '
                + @cols_src
                + N', ' + @jour_expr
                + N', SYSDATETIME()'
                + N', @p_usr'
                + N', @p_trt'
                + N' FROM ' + @src + N' AS S'
                + N' WHERE S.DT_COMMIT_TEC <= @p_front;'
                + N' SELECT @p_nb = @@ROWCOUNT;';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_front datetime2(3),
                   @p_projet nvarchar(50),
                   @p_usr nvarchar(20),
                   @p_trt bigint,
                   @p_nb bigint OUTPUT',
                 @p_front = @frontiere,
                 @p_projet = @LB_PROJET,
                 @p_usr = @CD_USR_MAJ,
                 @p_trt = @ID_TRT_ALI,
                 @p_nb = @nb_ins_histo OUTPUT;

            /* ================================================================
               11. CONTROLE DE VOLUMETRIE
               ================================================================ */

            IF @nb_ins_histo <> @nb_a_traiter
            BEGIN
                SET @msg =
                      N'Volumetrie incoherente pour '
                    + @tbl_histo
                    + N' : '
                    + CONVERT(NVARCHAR(20), @nb_a_traiter)
                    + N' trace(s) attendue(s), '
                    + CONVERT(NVARCHAR(20), @nb_ins_histo)
                    + N' trace(s) reinseree(s). '
                    + N'Purge annulee.';

                THROW 50041, @msg, 1;
            END;

            /* ================================================================
               12. CONTROLE DE PRESENCE DANS L'ARCHIVE
               ================================================================ */

            SET @sql =
                  N'SELECT @p_nb = COUNT_BIG(*)'
                + N' FROM ' + @src + N' AS S'
                + N' WHERE S.DT_COMMIT_TEC <= @p_front'
                + N'   AND NOT EXISTS'
                + N'       ('
                + N'           SELECT 1'
                + N'           FROM ' + @tgt + N' AS H'
                + N'           WHERE H.LB_LSN_COMMIT_TEC'
                + N'               = S.LB_LSN_COMMIT_TEC'
                + N'             AND H.LB_SEQVAL_TEC'
                + N'               = S.LB_SEQVAL_TEC'
                + N'       );';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_front datetime2(3),
                   @p_nb bigint OUTPUT',
                 @p_front = @frontiere,
                 @p_nb = @nb_absentes OUTPUT;

            IF @nb_absentes > 0
            BEGIN
                SET @msg =
                      N'Reinsertion incomplete vers '
                    + @tbl_histo
                    + N' : '
                    + CONVERT(NVARCHAR(20), @nb_absentes)
                    + N' trace(s) absente(s). '
                    + N'Purge annulee.';

                THROW 50042, @msg, 1;
            END;

            /* ================================================================
               13. CONTROLE DE FL_FIN_JOURNEE
               ================================================================ */

            SET @sql =
                  N'SELECT @p_nb = COUNT_BIG(*)'
                + N' FROM ' + @src + N' AS S'
                + N' INNER JOIN ' + @tgt + N' AS H'
                + N'     ON H.LB_LSN_COMMIT_TEC'
                + N'        = S.LB_LSN_COMMIT_TEC'
                + N'    AND H.LB_SEQVAL_TEC'
                + N'        = S.LB_SEQVAL_TEC'
                + N' WHERE S.DT_COMMIT_TEC <= @p_front'
                + N'   AND ISNULL(H.FL_FIN_JOURNEE, 0)'
                + N'       <> ISNULL(S.FL_FIN_JOURNEE, 0);';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_front datetime2(3),
                   @p_nb bigint OUTPUT',
                 @p_front = @frontiere,
                 @p_nb = @nb_non_conformes OUTPUT;

            IF @nb_non_conformes > 0
            BEGIN
                SET @msg =
                      N'Archive non conforme pour '
                    + @tbl_histo
                    + N' : '
                    + CONVERT(NVARCHAR(20), @nb_non_conformes)
                    + N' trace(s) avec un FL_FIN_JOURNEE different. '
                    + N'Purge annulee.';

                THROW 50043, @msg, 1;
            END;

            /* ================================================================
               14. PURGE DU SAS OIT
               ================================================================ */

            SET @sql =
                  N'DELETE S'
                + N' FROM ' + @src + N' AS S'
                + N' WHERE S.DT_COMMIT_TEC <= @p_front;'
                + N' SELECT @p_nb = @@ROWCOUNT;';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_front datetime2(3),
                   @p_nb bigint OUTPUT',
                 @p_front = @frontiere,
                 @p_nb = @nb_purgees OUTPUT;

            IF @nb_purgees <> @nb_a_traiter
            BEGIN
                SET @msg =
                      N'Purge incoherente pour '
                    + @tbl_ods
                    + N' : '
                    + CONVERT(NVARCHAR(20), @nb_a_traiter)
                    + N' trace(s) attendue(s), '
                    + CONVERT(NVARCHAR(20), @nb_purgees)
                    + N' trace(s) purgee(s).';

                THROW 50044, @msg, 1;
            END;

            COMMIT TRANSACTION;
        END;

        /* ====================================================================
           15. JOURNALISATION DU SUCCES
           ==================================================================== */

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (
            ID_TRT_ALI,
            LB_PROJET,
            LB_CHARGEMENT,
            LB_SOURCE,
            LB_CIBLE,
            NB_LIGNE,
            CD_STATUT,
            LB_ERREUR,
            DT_DEBUT,
            DT_FIN
        )
        VALUES
        (
            @ID_TRT_ALI,
            @LB_PROJET,
            N'ARCHIVE OIT ['
            + CONVERT(NVARCHAR(10), @jour_max, 23)
            + N']',
            @tbl_ods,
            @tbl_histo,
            @nb_a_traiter,
            N'OK',
            N'A traiter: '
            + CONVERT(NVARCHAR(20), @nb_a_traiter)
            + N' / anciennes images supprimees: '
            + CONVERT(NVARCHAR(20), @nb_supp_histo)
            + N' / images reinserees: '
            + CONVERT(NVARCHAR(20), @nb_ins_histo)
            + N' / absentes: '
            + CONVERT(NVARCHAR(20), @nb_absentes)
            + N' / FL_FIN_JOURNEE non conformes: '
            + CONVERT(NVARCHAR(20), @nb_non_conformes)
            + N' / purgees OIT: '
            + CONVERT(NVARCHAR(20), @nb_purgees)
            + N' (borne '
            + CONVERT(NVARCHAR(23), @frontiere, 121)
            + N').',
            @dt_step,
            SYSDATETIME()
        );
    END TRY
    BEGIN CATCH

        /* ====================================================================
           16. ROLLBACK DE LA TABLE COURANTE
           ==================================================================== */

        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        SET @nb_ko = @nb_ko + 1;

        SET @msg =
              ERROR_MESSAGE()
            + N' [erreur '
            + CONVERT(NVARCHAR(20), ERROR_NUMBER())
            + N', ligne '
            + CONVERT(NVARCHAR(20), ERROR_LINE())
            + N']';

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (
            ID_TRT_ALI,
            LB_PROJET,
            LB_CHARGEMENT,
            LB_SOURCE,
            LB_CIBLE,
            NB_LIGNE,
            CD_STATUT,
            LB_ERREUR,
            DT_DEBUT,
            DT_FIN
        )
        VALUES
        (
            @ID_TRT_ALI,
            @LB_PROJET,
            N'ARCHIVE OIT'
            + CASE
                  WHEN @jour_max IS NOT NULL
                      THEN
                          N' ['
                          + CONVERT(NVARCHAR(10), @jour_max, 23)
                          + N']'
                  ELSE N''
              END,
            @tbl_ods,
            @tbl_histo,
            0,
            N'KO',
            @msg,
            @dt_step,
            SYSDATETIME()
        );
    END CATCH;

    FETCH NEXT FROM cur_tables
    INTO @tbl_ods;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;

/* ============================================================================
   17. BILAN GLOBAL
   ============================================================================ */

IF @nb_ko > 0
BEGIN
    SET @msg =
          N'IWI.009.LIGIS.ARCHIVE.PURGE.OIT : '
        + CONVERT(NVARCHAR(10), @nb_ko)
        + N' table(s) non archivee(s). '
        + N'Les transactions correspondantes ont ete annulees. '
        + N'Les traces concernees restent dans les OIT et seront '
        + N'reprises lors de la prochaine execution.';

    THROW 50045, @msg, 1;
END;