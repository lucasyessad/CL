-- schema logique : MSSQL_DWH
-- type : S

DECLARE @DT_TRACES DATE = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI INT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE = '2400-01-01';
DECLARE @PFX_ODS NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg    NVARCHAR(2000), @jour   NVARCHAR(10) =  CONVERT(NVARCHAR(10), @DT_TRACES, 23);

/* Fenêtre ] borne précédente ; borne de la journée ] */

SELECT @dt_fin = B.DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR = @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

SELECT @dt_deb = MAX(B.DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR < @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg =
          N'Fenetre non definie pour le '
        + @jour
        + N' dans ORT_BORNE_JOURNEE pour le projet '
        + @LB_PROJET
        + N'.';

    THROW 50011, @msg, 1;
END;

DECLARE
    @tbl_ods NVARCHAR(128),
    @tbl_dwh NVARCHAR(200),
    @src     NVARCHAR(400),
    @tgt     NVARCHAR(400),
    @col_fen NVARCHAR(128),
    @filtre  NVARCHAR(1000),
    @sql     NVARCHAR(MAX),
    @nb_flag INT,
    @nb_supp INT,
    @nb_rouv INT,
    @dt_step DATETIME2(3);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        P.LB_TABLE_ODS,
        MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
    WHERE P.LB_PROJET = @LB_PROJET
      AND P.FL_CLEF = 1
      AND P.FL_CHARGEMENT = 1
      AND P.LB_TABLE_ODS LIKE N'OIT[_]%'
      AND NOT EXISTS
      (
          SELECT 1
          FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
          WHERE ISNULL(A.ID_TRT_ALI, -1) =
                ISNULL(@ID_TRT_ALI, -1)
            AND A.LB_PROJET = @LB_PROJET
            AND A.CD_STATUT = N'KO'
            AND A.LB_SOURCE = P.LB_TABLE_ODS
            AND CHARINDEX(
                    N'[' + @jour + N']',
                    A.LB_CHARGEMENT
                ) > 0
      )
    GROUP BY
        P.LB_TABLE_ODS
    ORDER BY
        P.LB_TABLE_ODS;

OPEN cur_tables;

FETCH NEXT FROM cur_tables
INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SET @nb_supp = 0;
    SET @nb_rouv = 0;
    SET @nb_flag = 0;

    BEGIN TRY
        SET @src =
              @PFX_ODS
            + QUOTENAME(@tbl_ods);

        SET @tgt =
              @PFX_DWH
            + QUOTENAME(@tbl_dwh);

        SET @col_fen = NULL;
        SET @filtre = NULL;

        SELECT TOP (1)
            @col_fen = P.LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_ORDRE_TRI = 1
          AND P.LB_CHAMP_ODS IS NOT NULL
        ORDER BY
            P.NO_CHAMP;

        SELECT
            @filtre = MAX(P.LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CLEF = 1;

        IF @col_fen IS NULL
        BEGIN
            SET @msg =
                  N'FL_ORDRE_TRI manquant pour '
                + @tbl_ods
                + N' et le projet '
                + @LB_PROJET
                + N'.';

            THROW 50031, @msg, 1;
        END;

        SET @filtre =
            ISNULL(@filtre, N'');

        /* Contrôle de présence de traces de fin de journée */

        SET @sql =
              N'SELECT @p_nb = COUNT(*)'
            + N' FROM ' + @src + N' AS S'
            + N' WHERE S.FL_FIN_JOURNEE = 1'
            + N'   AND S.' + QUOTENAME(@col_fen)
            + N' > @p_deb'
            + N'   AND S.' + QUOTENAME(@col_fen)
            + N' <= @p_fin'
            + CASE
                  WHEN @filtre <> N''
                      THEN N' AND ' + @filtre
                  ELSE N''
              END
            + N';';

        EXEC sys.sp_executesql
             @sql,
             N'@p_deb datetime2(3),
               @p_fin datetime2(3),
               @p_nb int OUTPUT',
             @p_deb = @dt_deb,
             @p_fin = @dt_fin,
             @p_nb = @nb_flag OUTPUT;

        IF @nb_flag > 0
        BEGIN
            BEGIN TRANSACTION;

            /* Suppression des versions à reconstruire */

            SET @sql =
                  N'DELETE FROM ' + @tgt
                + N' WHERE DD_VAL >= @p_dt;'
                + N' SELECT @p_nb = @@ROWCOUNT;';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_dt date,
                   @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES,
                 @p_nb = @nb_supp OUTPUT;

            /* Réouverture de la version précédant la journée rejouée */

            SET @sql =
                  N'UPDATE ' + @tgt
                + N' SET DF_VAL = @p_infini,'
                + N'     FL_VER_CRT = 1'
                + N' WHERE DF_VAL = @p_dt'
                + N'   AND FL_VER_CRT = 0;'
                + N' SELECT @p_nb = @@ROWCOUNT;';

            EXEC sys.sp_executesql
                 @sql,
                 N'@p_dt date,
                   @p_infini date,
                   @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES,
                 @p_infini = @DATE_INFINIE,
                 @p_nb = @nb_rouv OUTPUT;

            COMMIT TRANSACTION;

            IF @nb_supp > 0 OR @nb_rouv > 0
            BEGIN
                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (
                    ID_TRT_ALI,
                    LB_PROJET,
                    LB_CHARGEMENT,
                    LB_SOURCE,
                    LB_CIBLE,
                    NB_LIGNE,
                    CD_STATUT,
                    LB_ERREUR,
                    DT_DEBUT,
                    DT_FIN
                )
                VALUES
                (
                    @ID_TRT_ALI,
                    @LB_PROJET,
                    N'RECALCUL [' + @jour + N']',
                    @tbl_ods,
                    @tbl_dwh,
                    @nb_supp,
                    N'OK',
                    N'Journee deja traitee : '
                    + CONVERT(NVARCHAR(10), @nb_supp)
                    + N' version(s) supprimee(s), '
                    + CONVERT(NVARCHAR(10), @nb_rouv)
                    + N' version(s) rouverte(s) avant reconstruction.',
                    @dt_step,
                    SYSDATETIME()
                );
            END;
        END;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
        BEGIN
            ROLLBACK TRANSACTION;
        END;

        SET @msg =
              N'PURGE OWT : '
            + ERROR_MESSAGE()
            + N' [erreur '
            + CONVERT(NVARCHAR(20), ERROR_NUMBER())
            + N', ligne '
            + CONVERT(NVARCHAR(20), ERROR_LINE())
            + N']';

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (
            ID_TRT_ALI,
            LB_PROJET,
            LB_CHARGEMENT,
            LB_SOURCE,
            LB_CIBLE,
            NB_LIGNE,
            CD_STATUT,
            LB_ERREUR,
            DT_DEBUT,
            DT_FIN
        )
        VALUES
        (
            @ID_TRT_ALI,
            @LB_PROJET,
            N'TRACES [' + @jour + N']',
            @tbl_ods,
            @tbl_dwh,
            0,
            N'KO',
            @msg,
            @dt_step,
            SYSDATETIME()
        );
    END CATCH;

    FETCH NEXT FROM cur_tables
    INTO @tbl_ods, @tbl_dwh;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;