/* ============================================================================
   PARAMETRAGE AU GRAIN TABLE  -  dbo.ORT_PARAM_FLUX

   C'est la SEULE table nouvelle du dispositif. Tout le reste reutilise ce qui
   existe deja :

     dbo.ORT_PARAM_HISTORISATION_TRACES   le parametrage au grain colonne,
                                          inchange, avec ses 1406 lignes
     dbo.ORT_AUDIT_CHARGEMENT             le journal ET le suivi
     dbo.ORT_BORNE_JOURNEE                les frontieres de journee
     ods.OIT_TEC_AUDIT_CDC                l'audit de la capture
     dbo.PITCOT_PERIODE_REPRISE           la file des journees

   Les etapes ODI continuent de lire ORT_PARAM_HISTORISATION_TRACES pour les
   colonnes, et lisent ORT_PARAM_FLUX pour le mode de chaque table. Aucune
   migration de parametrage, aucune vue.

   ----------------------------------------------------------------------------
   POURQUOI UNE TABLE DE PLUS
   ----------------------------------------------------------------------------
   ORT_PARAM_HISTORISATION_TRACES decrit les colonnes : une ligne par champ.
   Elle ne peut pas porter ce qui est vrai pour la table entiere - le mode
   d'alimentation, le format du fichier, le schema d'atterrissage - sans que
   ces informations soient repetees sur chacune de ses lignes, donc maintenues
   des centaines de fois.

   ORT_PARAM_FLUX porte ces informations une fois par table. Les deux se
   completent : l'une dit COMMENT alimenter, l'autre dit QUOI mapper.

   ----------------------------------------------------------------------------
   LES TROIS AXES
   ----------------------------------------------------------------------------
   CD_MODE_ENTREE   ce que contient le fichier
       DELTA   des modifications, une ligne par changement. L'etat de fin de
               journee doit etre reconstitue en retenant, pour chaque cle, la
               derniere modification.
       ETAT    l'etat complet de la table. Rien a reconstituer.

   CD_FORMAT        comment le fichier est ecrit
       BCP     format binaire natif, charge par bcp depuis un job
       CSV     fichier delimite, charge par BULK INSERT depuis une procedure

   CD_MODE_ALIM     ce qu'on fait de la donnee dans le DWH
       SCD2    historisation par periodes de validite
       SCD1    etat courant seulement, sans conserver le passe
       AJOUT   insertion pure, pour des donnees evenementielles
       AUCUNE  le flux s'arrete a l'ODS

   Les trois sont independants : le traitement ne deduit jamais l'un des
   autres.

       DELTA + BCP + SCD2    traces CDC LIGIS, cas actuel
       ETAT  + BCP + SCD2    referentiel livre en entier, dont on veut l'histoire
       ETAT  + CSV + SCD1    referentiel simple, etat courant
       ETAT  + CSV + AUCUNE  fichier charge en ODS pour un autre usage

   FL_INIT n'est pas un quatrieme mode : c'est une phase de demarrage. Une
   table marquee FL_INIT = 1 est chargee en entier une fois, puis repasse en
   alimentation normale.
   ============================================================================ */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.ORT_PARAM_FLUX', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_PARAM_FLUX
    (
        /* Cle, identique a celle de ORT_PARAM_HISTORISATION_TRACES. */
        LB_PROJET       NVARCHAR(50)   NOT NULL,
        LB_TABLE_ODS    NVARCHAR(128)  NOT NULL,

        /* Cible, source et filtre : ce sont des proprietes de la table, elles
           sont donc portees ici, une fois. ORT_PARAM_HISTORISATION_TRACES les
           repete sur chaque ligne de colonne ; le controle 8 verifie que les
           deux restent d'accord. */
        LB_TABLE_DWH    NVARCHAR(128)  NULL,
        LB_SOURCE       NVARCHAR(260)  NULL,
        LB_FILTRE_WHERE NVARCHAR(1000) NULL,

        /* Les trois axes. */
        CD_MODE_ENTREE  NVARCHAR(10)   NOT NULL,
        CD_FORMAT       NVARCHAR(10)   NOT NULL,
        CD_MODE_ALIM    NVARCHAR(10)   NOT NULL,

        FL_ACTIF        BIT            NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_ACTIF DEFAULT (1),
        FL_INIT         BIT            NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_INIT  DEFAULT (0),
        NO_ORDRE        INT            NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_ORDRE DEFAULT (100),

        /* Ou atterrit et ou va la donnee. Repete par flux plutot que porte par
           une troisieme table : trente lignes se maintiennent sans peine, et
           un projet peut ainsi avoir des flux dans des schemas differents. */
        LB_SCHEMA_ODS   NVARCHAR(128)  NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_SODS DEFAULT (N'ods'),
        LB_SCHEMA_DWH   NVARCHAR(128)  NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_SDWH DEFAULT (N'dbo'),

        /* Nom du fichier attendu. En BCP il se deduit de la convention et
           peut rester NULL ; en CSV il est obligatoire. */
        LB_FICHIER      NVARCHAR(260)  NULL,
        LB_REPERTOIRE   NVARCHAR(260)  NULL,

        /* Format du fichier, renseigne uniquement si CD_FORMAT = CSV. */
        LB_DELIMITEUR   NVARCHAR(10)   NULL,
        NO_LIGNE_DEBUT  INT            NULL,
        LB_ENCODAGE     NVARCHAR(20)   NULL,

        /* Table portant les bornes de la capture, pour les flux DELTA. */
        LB_TABLE_AUDIT  NVARCHAR(128)  NULL,

        /* Heure de frontiere de journee, exprimee comme une heure et non
           comme un nombre de minutes : ce qui est lu doit rester lisible. */
        HR_FRONTIERE    TIME(0)        NULL CONSTRAINT DF_ORT_PARAM_FLUX_FRONT DEFAULT ('07:45:00'),

        DT_MAJ          DATETIME2(3)   NOT NULL CONSTRAINT DF_ORT_PARAM_FLUX_DTMAJ DEFAULT (SYSDATETIME()),
        CD_USR_MAJ      NVARCHAR(20)   NULL,
        LB_COMMENTAIRE  NVARCHAR(500)  NULL,

        CONSTRAINT PK_ORT_PARAM_FLUX
            PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS),

        CONSTRAINT CK_ORT_PARAM_FLUX_ENTREE
            CHECK (CD_MODE_ENTREE IN (N'DELTA', N'ETAT')),
        CONSTRAINT CK_ORT_PARAM_FLUX_FORMAT
            CHECK (CD_FORMAT IN (N'BCP', N'CSV')),
        CONSTRAINT CK_ORT_PARAM_FLUX_ALIM
            CHECK (CD_MODE_ALIM IN (N'SCD2', N'SCD1', N'AJOUT', N'AUCUNE')),

        /* Le format de fichier n'a de sens qu'en CSV, et il y est obligatoire :
           sans delimiteur ni nom de fichier, le chargement ne peut pas tourner. */
        CONSTRAINT CK_ORT_PARAM_FLUX_CSV
            CHECK
            (
                (CD_FORMAT =  N'CSV' AND LB_DELIMITEUR IS NOT NULL
                                     AND LB_FICHIER    IS NOT NULL
                                     AND LB_REPERTOIRE IS NOT NULL)
             OR (CD_FORMAT <> N'CSV' AND LB_DELIMITEUR  IS NULL
                                     AND NO_LIGNE_DEBUT IS NULL
                                     AND LB_ENCODAGE    IS NULL)
            ),

        /* Un flux DELTA a besoin des bornes de la capture. */
        CONSTRAINT CK_ORT_PARAM_FLUX_AUDIT
            CHECK (CD_MODE_ENTREE <> N'DELTA' OR LB_TABLE_AUDIT IS NOT NULL)
    );

    CREATE NONCLUSTERED INDEX IX_ORT_PARAM_FLUX_ACTIFS
        ON dbo.ORT_PARAM_FLUX (LB_PROJET, FL_ACTIF, NO_ORDRE)
        INCLUDE (LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM);
END;
GO


/* ============================================================================
   ALIMENTATION INITIALE

   Cree une ligne de flux pour chaque table deja decrite dans le parametrage
   colonne, en mode DELTA + BCP + SCD2, qui est le comportement actuel. Les
   autres modes se declarent ensuite au cas par cas.

   Rejouable : ne cree que ce qui manque.
   ============================================================================ */
INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE, LB_FILTRE_WHERE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT,
    CD_USR_MAJ, LB_COMMENTAIRE
)
SELECT
    S.LB_PROJET, S.LB_TABLE_ODS, S.LB_TABLE_DWH, S.LB_SOURCE, S.LB_FILTRE_WHERE,
    N'DELTA', N'BCP', N'SCD2',
    N'ods', N'dbo', N'OIT_TEC_AUDIT_CDC',
    N'INIT',
    N'Cree a partir de ORT_PARAM_HISTORISATION_TRACES'
FROM
(
    /* La ligne cle de plus petit NO_CHAMP porte la cible et la source. */
    SELECT T.LB_PROJET, T.LB_TABLE_ODS, T.LB_TABLE_DWH, T.LB_SOURCE, T.LB_FILTRE_WHERE,
           Rang = ROW_NUMBER() OVER
           (
               PARTITION BY T.LB_PROJET, T.LB_TABLE_ODS
               ORDER BY CASE WHEN T.FL_CLEF = 1 THEN 0 ELSE 1 END, T.NO_CHAMP
           )
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
) AS S
WHERE S.Rang = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
      WHERE F.LB_PROJET = S.LB_PROJET AND F.LB_TABLE_ODS = S.LB_TABLE_ODS
  );

PRINT N'Flux crees : ' + CONVERT(NVARCHAR(10), @@ROWCOUNT);
GO


/* ============================================================================
   CONTROLES DE COHERENCE
   A passer apres toute modification du parametrage.
   Chaque requete doit renvoyer zero ligne.
   ============================================================================ */

/* 1. Table decrite au grain colonne mais absente du grain flux. */
SELECT DISTINCT
    T.LB_PROJET, T.LB_TABLE_ODS, Probleme = N'flux non declare dans ORT_PARAM_FLUX'
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
WHERE NOT EXISTS
(
    SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
    WHERE F.LB_PROJET = T.LB_PROJET AND F.LB_TABLE_ODS = T.LB_TABLE_ODS
);

/* 2. Flux declare sans aucune colonne. */
SELECT F.LB_TABLE_ODS, Probleme = N'aucune colonne decrite'
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.FL_ACTIF = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
      WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS
  );

/* 3. Flux sans colonne cle : il serait ignore par le traitement. */
SELECT F.LB_TABLE_ODS, Probleme = N'aucune colonne cle'
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.FL_ACTIF = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
      WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1
  );

/* 4. Mode DELTA sans colonne d'ordre. */
SELECT F.LB_TABLE_ODS, Probleme = N'mode DELTA sans colonne d''ordre'
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.FL_ACTIF = 1 AND F.CD_MODE_ENTREE = N'DELTA'
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
      WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_ORDRE_TRI = 1
  );

/* 5. Colonne d'ordre en mode ETAT : sans effet, donc probablement une erreur. */
SELECT F.LB_TABLE_ODS, C.LB_CHAMP_ODS, Probleme = N'colonne d''ordre inutile en mode ETAT'
FROM dbo.ORT_PARAM_FLUX AS F
INNER JOIN dbo.ORT_PARAM_HISTORISATION_TRACES AS C
    ON C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS
WHERE F.FL_ACTIF = 1 AND F.CD_MODE_ENTREE = N'ETAT' AND C.FL_ORDRE_TRI = 1;

/* 6. Cible manquante alors que le flux alimente le DWH. */
SELECT F.LB_TABLE_ODS, Probleme = N'LB_TABLE_DWH absent'
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.FL_ACTIF = 1 AND F.CD_MODE_ALIM <> N'AUCUNE' AND F.LB_TABLE_DWH IS NULL;

/* 7. Tables physiques absentes. */
SELECT
    F.LB_TABLE_ODS, F.LB_TABLE_DWH,
    Probleme = CASE WHEN OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS) + N'.' + QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
                    THEN N'table ODS absente' ELSE N'table DWH absente' END
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.FL_ACTIF = 1
  AND
  (
      OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS) + N'.' + QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
   OR (F.LB_TABLE_DWH IS NOT NULL
       AND OBJECT_ID(QUOTENAME(F.LB_SCHEMA_DWH) + N'.' + QUOTENAME(F.LB_TABLE_DWH), N'U') IS NULL)
  );

/* 8. Les deux niveaux ne disent pas la meme chose sur la cible ou la source. */
SELECT F.LB_TABLE_ODS,
       Flux_Cible = F.LB_TABLE_DWH, Colonne_Cible = C.LB_TABLE_DWH,
       Flux_Source = F.LB_SOURCE,   Colonne_Source = C.LB_SOURCE,
       Probleme = N'desaccord entre ORT_PARAM_FLUX et ORT_PARAM_HISTORISATION_TRACES'
FROM dbo.ORT_PARAM_FLUX AS F
INNER JOIN dbo.ORT_PARAM_HISTORISATION_TRACES AS C
    ON C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1
WHERE ISNULL(F.LB_TABLE_DWH, N'') <> ISNULL(C.LB_TABLE_DWH, N'')
   OR ISNULL(F.LB_SOURCE,    N'') <> ISNULL(C.LB_SOURCE,    N'');
GO


/* ============================================================================
   EXEMPLES

-- Referentiel recu en entier chaque jour, dont on veut l'historique
INSERT INTO dbo.ORT_PARAM_FLUX
    (LB_PROJET, LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM, NO_ORDRE)
VALUES
    (N'LIGIS', N'OIT_TAUX', N'ETAT', N'BCP', N'SCD2', 200);

-- Fichier delimite, etat courant seulement
INSERT INTO dbo.ORT_PARAM_FLUX
    (LB_PROJET, LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM, NO_ORDRE,
     LB_FICHIER, LB_REPERTOIRE, LB_DELIMITEUR, NO_LIGNE_DEBUT, LB_ENCODAGE)
VALUES
    (N'LIGIS', N'OIT_PITOPE_TABLEREF', N'ETAT', N'CSV', N'SCD1', 300,
     N'PITOPE_TABLEREF.csv', N'\\kenya\dsi\datalib', N';', 2, N'65001');

-- Retirer une table du perimetre, sans rien supprimer
UPDATE dbo.ORT_PARAM_FLUX SET FL_ACTIF = 0
WHERE LB_PROJET = N'LIGIS' AND LB_TABLE_ODS = N'OIT_WRK_TASK';

   ============================================================================ */
