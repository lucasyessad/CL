-- schema logique : MSSQL_DWH
-- type : S

UPDATE <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND DD_VAL <= '#INEO.V_IWI_LIGIS_DT_TRACES'
  AND TRAITE = 0
