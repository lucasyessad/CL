-- schema logique : MSSQL_DWH
-- type : S

INSERT INTO <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SELECT T.DT_CAL,
       (ROW_NUMBER() OVER (ORDER BY T.DT_CAL)) AS SEQ,
       0 AS TRAITE,
       '<?=odiRef.getSession("SESS_NAME") ?>' AS LB_NOM_SCN_SUN
FROM
(
    SELECT DISTINCT convert(date, DT_CAL, 121) as DT_CAL
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND convert(date, DT_CAL, 121) >  (select convert(date, DA_DEB_DEL_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
      and convert(date, DT_CAL, 121) <= (select convert(date, DA_DON_A_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
) AS T
ORDER BY SEQ ASC