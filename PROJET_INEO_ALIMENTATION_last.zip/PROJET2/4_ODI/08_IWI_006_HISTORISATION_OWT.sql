-- schema logique : MSSQL_DWH
-- type : S

/* ============================================================================
   IWI.006.LIGIS.HISTORISATION.OWT_xxx  -  version multi-mode

   Alimente le DWH pour la journee #V_IWI_LIGIS_DT_TRACES, selon le mode
   declare pour chaque flux dans ORT_PARAM_FLUX.

   ----------------------------------------------------------------------------
   CE QUI CHANGE PAR RAPPORT A LA VERSION DEPLOYEE
   ----------------------------------------------------------------------------
   1. La liste des flux et leurs deux modes viennent de ORT_PARAM_FLUX.
   2. Les colonnes chargees dans le DWH sont filtrees sur FL_CHARGEMENT = 1.
      Auparavant toute colonne ayant un LB_CHAMP_DWH etait chargee, meme a 0.
   3. FL_SUP vaut 0 par defaut et 1 sur suppression, au lieu de NULL et 1.
   4. Quatre comportements selon CD_MODE_ENTREE x CD_MODE_ALIM.

   ----------------------------------------------------------------------------
   CD_MODE_ENTREE : D'OU VIENT L'IMAGE
   ----------------------------------------------------------------------------
   DELTA   les lignes marquees FL_FIN_JOURNEE = 1 dans la fenetre de la
           journee, comme aujourd'hui.
   ETAT    tout le contenu de l'ODS : le fichier est deja l'image. Comme il ne
           dit pas ce qui a change, on compare chaque cle a sa version courante
           dans le DWH, colonne par colonne, sur les colonnes chargees.
           Un flux ETAT n'est traite que sur la DERNIERE journee de la boucle :
           son contenu est l'etat a l'extraction, pas celui de chaque journee
           intermediaire d'un rattrapage.

   ----------------------------------------------------------------------------
   CD_MODE_ALIM : CE QU'ON EN FAIT
   ----------------------------------------------------------------------------
   SCD2    fermeture de la version courante, insertion de la nouvelle.
           En ETAT, une cle absente du fichier est fermee et recoit une version
           FL_SUP = 1 : elle garde une version courante, marquee supprimee.
   SCD1    la ligne existante est mise a jour sur place, sans version. En ETAT,
           une cle absente est marquee FL_SUP = 1.
   AJOUT   insertion pure, sans fermeture ni comparaison.
   AUCUNE  le flux n'est pas traite ici.

   ----------------------------------------------------------------------------
   GARDE-FOUS
   ----------------------------------------------------------------------------
   - un flux en KO dans la session est ecarte ;
   - une source vide n'est pas traitee ; en ETAT, un fichier vide fermerait
     toutes les cles, le flux est ignore avec avertissement ;
   - une journee deja presente dans la cible est refusee, sauf en SCD1 dont la
     mise a jour est naturellement rejouable.
   ============================================================================ */

DECLARE @DT_TRACES    DATE         = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI   INT          = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET    NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE         = '2400-01-01';
DECLARE @CD_USR_MAJ   NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';
DECLARE @PFX_ODS NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.' + N'<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE
    @dt_deb      DATETIME2(3),
    @dt_fin      DATETIME2(3),
    @fl_derniere BIT = 0,
    @msg         NVARCHAR(2000),
    @jour        NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

/* ============================================================================
   1. FENETRE DE LA JOURNEE  ] BORNE PRECEDENTE ; BORNE DE LA JOURNEE ]
   ============================================================================ */

SELECT @dt_fin = B.DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR = @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

SELECT @dt_deb = MAX(B.DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> AS B
WHERE B.DT_JOUR < @DT_TRACES
  AND B.LB_PROJET = @LB_PROJET;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + @jour
             + N' dans ORT_BORNE_JOURNEE pour le projet ' + @LB_PROJET + N'.';
    THROW 50011, @msg, 1;
END;

/* Les flux ETAT ne sont traites que sur la derniere journee a traiter. */
IF NOT EXISTS
(
    SELECT 1
    FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> AS P
    WHERE P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
      AND P.TRAITE = 0
      AND P.DT_CAL > @DT_TRACES
)
    SET @fl_derniere = 1;

/* ============================================================================
   2. VARIABLES DE TRAITEMENT
   ============================================================================ */

DECLARE
    @tbl_ods     NVARCHAR(128),
    @tbl_dwh     NVARCHAR(200),
    @mode_entree NVARCHAR(10),
    @mode_alim   NVARCHAR(10),
    @src         NVARCHAR(400),
    @tgt         NVARCHAR(400),
    @cle_ods     NVARCHAR(MAX),   -- [K1], [K2]                     noms ODS
    @cle1_ods    NVARCHAR(128),   -- premiere colonne de cle, nom ODS
    @join_cond   NVARCHAR(MAX),   -- S.[k] = T.[k] AND ...
    @join_max    NVARCHAR(MAX),   -- T2.[k] = S.[k] AND ...
    @join_tt     NVARCHAR(MAX),   -- T3.[k] = T.[k] AND ...
    @cols_dwh    NVARCHAR(MAX),   -- [c1], [c2]      colonnes chargees, cle incluse
    @vals_ods    NVARCHAR(MAX),   -- S.[c1], S.[c2]
    @vals_dwh    NVARCHAR(MAX),   -- T.[c1], T.[c2]
    @set_scd1    NVARCHAR(MAX),   -- T.[c] = S.[c], ...   hors cle
    @cmp_s       NVARCHAR(MAX),   -- expression de comparaison cote source
    @cmp_t       NVARCHAR(MAX),   -- expression de comparaison cote cible
    @col_fen     NVARCHAR(128),
    @filtre      NVARCHAR(1000),
    @where_src   NVARCHAR(MAX),
    @sql         NVARCHAR(MAX),
    @nb_src      INT,
    @nb_deja     INT,
    @nb_ferm     INT,
    @nb_ins      INT,
    @nb_maj      INT,
    @nb_sup      INT,
    @dt_step     DATETIME2(3);

/* ============================================================================
   3. LISTE DES FLUX A TRAITER
   ============================================================================ */

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH, F.CD_MODE_ENTREE, F.CD_MODE_ALIM
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ALIM <> N'AUCUNE'
      AND F.LB_TABLE_DWH IS NOT NULL
      AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS C WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1)
      AND (F.CD_MODE_ENTREE = N'DELTA' OR @fl_derniere = 1)
      AND NOT EXISTS
      (
          SELECT 1
          FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
          WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
            AND A.LB_PROJET = @LB_PROJET
            AND A.CD_STATUT = N'KO'
            AND A.LB_SOURCE = F.LB_TABLE_ODS
            AND CHARINDEX(N'[' + @jour + N']', A.LB_CHARGEMENT) > 0
      )
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @mode_entree, @mode_alim;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SELECT @nb_src = 0, @nb_deja = 0, @nb_ferm = 0, @nb_ins = 0, @nb_maj = 0, @nb_sup = 0;

    BEGIN TRY

        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        SELECT @cle_ods = NULL, @cle1_ods = NULL, @join_cond = NULL, @join_max = NULL,
               @join_tt = NULL, @cols_dwh = NULL, @vals_ods = NULL, @vals_dwh = NULL,
               @set_scd1 = NULL, @cmp_s = NULL, @cmp_t = NULL, @col_fen = NULL, @filtre = NULL;

        /* ------------------------------------------------------------------
           4. CLE FONCTIONNELLE
        ------------------------------------------------------------------ */
        SELECT
            @cle_ods   = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(P.LB_CHAMP_ODS)), N', ')
                         WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @join_cond = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.' + QUOTENAME(P.LB_CHAMP_ODS) + N' = T.' + QUOTENAME(P.LB_CHAMP_DWH)), N' AND ')
                         WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @join_max  = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T2.' + QUOTENAME(P.LB_CHAMP_DWH) + N' = S.' + QUOTENAME(P.LB_CHAMP_ODS)), N' AND ')
                         WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @join_tt   = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T3.' + QUOTENAME(P.LB_CHAMP_DWH) + N' = T.' + QUOTENAME(P.LB_CHAMP_DWH)), N' AND ')
                         WITHIN GROUP (ORDER BY P.NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CLEF = 1
          AND P.LB_CHAMP_ODS IS NOT NULL
          AND P.LB_CHAMP_DWH IS NOT NULL;

        SELECT TOP (1) @cle1_ods = P.LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET AND P.LB_TABLE_ODS = @tbl_ods AND P.FL_CLEF = 1
        ORDER BY P.NO_CHAMP;

        /* ------------------------------------------------------------------
           5. COLONNES CHARGEES  -  FL_CHARGEMENT = 1 UNIQUEMENT
           Une colonne a 0 reste dans l'ODS et n'est pas reprise dans le DWH.
        ------------------------------------------------------------------ */
        SELECT
            @cols_dwh = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(P.LB_CHAMP_DWH)), N', ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @vals_ods = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.' + QUOTENAME(P.LB_CHAMP_ODS)), N', ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @vals_dwh = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.' + QUOTENAME(P.LB_CHAMP_DWH)), N', ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CHARGEMENT = 1
          AND P.LB_CHAMP_ODS IS NOT NULL
          AND P.LB_CHAMP_DWH IS NOT NULL;

        /* Colonnes hors cle : mise a jour SCD1 et comparaison ETAT.
           La comparaison concatene les valeurs converties en texte, NULL
           remplace par un marqueur : deux lignes sont identiques si et
           seulement si leurs colonnes chargees le sont. */
        SELECT
            @set_scd1 = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.' + QUOTENAME(P.LB_CHAMP_DWH) + N' = S.' + QUOTENAME(P.LB_CHAMP_ODS)), N', ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @cmp_s    = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), S.' + QUOTENAME(P.LB_CHAMP_ODS) + N'), N''<null>'')'), N' + N''|'' + ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP),
            @cmp_t    = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), T.' + QUOTENAME(P.LB_CHAMP_DWH) + N'), N''<null>'')'), N' + N''|'' + ')
                        WITHIN GROUP (ORDER BY P.NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_CHARGEMENT = 1
          AND P.FL_CLEF = 0
          AND P.LB_CHAMP_ODS IS NOT NULL
          AND P.LB_CHAMP_DWH IS NOT NULL;

        /* Sans colonne hors cle, deux lignes de meme cle sont identiques. */
        SET @cmp_s = ISNULL(@cmp_s, N'N''''');
        SET @cmp_t = ISNULL(@cmp_t, N'N''''');

        /* ------------------------------------------------------------------
           6. FENETRE ET FILTRE
        ------------------------------------------------------------------ */
        SELECT TOP (1) @col_fen = P.LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS P
        WHERE P.LB_PROJET = @LB_PROJET AND P.LB_TABLE_ODS = @tbl_ods
          AND P.FL_ORDRE_TRI = 1 AND P.LB_CHAMP_ODS IS NOT NULL
        ORDER BY P.NO_CHAMP;

        SELECT @filtre = ISNULL(F.LB_FILTRE_WHERE, N'')
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
        WHERE F.LB_PROJET = @LB_PROJET AND F.LB_TABLE_ODS = @tbl_ods;

        IF @cle_ods IS NULL OR @join_cond IS NULL OR @cols_dwh IS NULL
           OR (@mode_entree = N'DELTA' AND @col_fen IS NULL)
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods + N' et le projet ' + @LB_PROJET + N'.';
            THROW 50032, @msg, 1;
        END;

        /* Predicat de source, selon le mode d'entree. */
        IF @mode_entree = N'DELTA'
            SET @where_src = N'S.FL_FIN_JOURNEE = 1'
                           + N' AND S.' + QUOTENAME(@col_fen) + N' > @p_deb'
                           + N' AND S.' + QUOTENAME(@col_fen) + N' <= @p_fin';
        ELSE
            SET @where_src = N'1 = 1';

        IF @filtre <> N''
            SET @where_src = @where_src + N' AND (' + @filtre + N')';

        /* ------------------------------------------------------------------
           7. VOLUMETRIE SOURCE ET JOURNEE DEJA PRESENTE
        ------------------------------------------------------------------ */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src + N' AS S WHERE ' + @where_src + N';';
        EXEC sys.sp_executesql @sql,
             N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_src OUTPUT;

        IF @mode_alim IN (N'SCD2', N'AJOUT')
        BEGIN
            SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @tgt + N' WHERE DD_VAL = @p_dt;';
            EXEC sys.sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_nb = @nb_deja OUTPUT;
        END;

        IF @nb_src = 0
        BEGIN
            /* En DELTA, l'absence de trace est deja signalee par FLAG.
               En ETAT, un fichier vide fermerait toutes les cles : on refuse. */
            IF @mode_entree = N'ETAT'
                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'OK',
                        N'AVERTISSEMENT: source vide en mode ETAT - cible non modifiee, aucune cle fermee.',
                        @dt_step, SYSDATETIME());
        END
        ELSE IF @nb_deja > 0
        BEGIN
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'OK',
                    N'IGNORE: journee deja historisee (' + CONVERT(NVARCHAR(10), @nb_deja)
                    + N' version(s)). Relancer depuis PURGE OWT pour reconstruire la journee.',
                    @dt_step, SYSDATETIME());
        END
        ELSE
        BEGIN
            BEGIN TRANSACTION;

            /* ==============================================================
               8. SCD2
            ============================================================== */
            IF @mode_alim = N'SCD2'
            BEGIN
                /* 8.1 Fermeture des versions courantes concernees.
                       DELTA : toute cle presente dans la fenetre.
                       ETAT  : cle absente du fichier, ou presente et differente,
                               ou precedemment supprimee et de retour. */
                IF @mode_entree = N'DELTA'
                    SET @sql = N'UPDATE T SET T.DF_VAL = @p_dt, T.FL_VER_CRT = 0'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' INNER JOIN (SELECT DISTINCT ' + @cle_ods + N' FROM ' + @src + N' AS S WHERE ' + @where_src + N') AS S'
                             + N'    ON ' + @join_cond
                             + N' WHERE T.FL_VER_CRT = 1;'
                             + N' SELECT @p_nb = @@ROWCOUNT;';
                ELSE
                    SET @sql = N'UPDATE T SET T.DF_VAL = @p_dt, T.FL_VER_CRT = 0'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' LEFT JOIN (SELECT * FROM ' + @src + N' AS S WHERE ' + @where_src + N') AS S'
                             + N'    ON ' + @join_cond
                             + N' WHERE T.FL_VER_CRT = 1'
                             + N'   AND (S.' + QUOTENAME(@cle1_ods) + N' IS NULL'
                             + N'        OR T.FL_SUP = 1'
                             + N'        OR ' + @cmp_t + N' <> ' + @cmp_s + N');'
                             + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql @sql,
                     N'@p_dt date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ferm OUTPUT;

                /* 8.2 Insertion des nouvelles versions.
                       DELTA : toutes les lignes de la fenetre.
                       ETAT  : toute cle du fichier sans version courante,
                               c'est-a-dire nouvelle ou fermee a l'instant. */
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' SELECT ' + @vals_ods
                         + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_max + N'), 0) + 1'
                         + N', @p_dt, @p_infini'
                         + CASE WHEN @mode_entree = N'DELTA'
                                THEN N', CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END'
                                ELSE N', 0' END
                         + N', 1, SYSDATETIME(), @p_usr, @p_trt'
                         + N' FROM ' + @src + N' AS S'
                         + N' WHERE ' + @where_src
                         + CASE WHEN @mode_entree = N'ETAT'
                                THEN N' AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T WHERE ' + @join_cond + N' AND T.FL_VER_CRT = 1)'
                                ELSE N'' END
                         + N';'
                         + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql @sql,
                     N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_deb = @dt_deb, @p_fin = @dt_fin,
                     @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_ins OUTPUT;

                /* 8.3 ETAT seulement : les cles fermees a l'instant et absentes du
                       fichier ont disparu de la source. Elles recoivent une version
                       FL_SUP = 1 recopiee de leur derniere version. */
                IF @mode_entree = N'ETAT'
                BEGIN
                    SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh
                             + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                             + N' SELECT ' + @vals_dwh
                             + N', T.NO_SEQ + 1, @p_dt, @p_infini, 1, 1, SYSDATETIME(), @p_usr, @p_trt'
                             + N' FROM ' + @tgt + N' AS T'
                             + N' WHERE T.DF_VAL = @p_dt AND T.FL_VER_CRT = 0 AND T.FL_SUP = 0'
                             + N'   AND NOT EXISTS (SELECT 1 FROM ' + @src + N' AS S WHERE ' + @where_src + N' AND ' + @join_cond + N')'
                             + N'   AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T3 WHERE ' + @join_tt + N' AND T3.FL_VER_CRT = 1);'
                             + N' SELECT @p_nb = @@ROWCOUNT;';

                    EXEC sys.sp_executesql @sql,
                         N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                         @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_deb = @dt_deb, @p_fin = @dt_fin,
                         @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_sup OUTPUT;
                END;

                /* 8.4 Controle de volumetrie, en DELTA seulement : chaque trace
                       flaguee doit avoir produit une version. En ETAT, insere =
                       nouvelles + changees, sans rapport avec le nombre recu. */
                IF @mode_entree = N'DELTA' AND @nb_ins <> @nb_src
                BEGIN
                    SET @msg = N'Historisation incomplete pour ' + @tbl_dwh + N' : '
                             + CONVERT(NVARCHAR(10), @nb_src) + N' trace(s) flaguee(s), '
                             + CONVERT(NVARCHAR(10), @nb_ins) + N' version(s) inseree(s).';
                    THROW 50033, @msg, 1;
                END;
            END

            /* ==============================================================
               9. SCD1  -  mise a jour sur place
            ============================================================== */
            ELSE IF @mode_alim = N'SCD1'
            BEGIN
                SET @sql = N'MERGE ' + @tgt + N' AS T'
                         + N' USING (SELECT * FROM ' + @src + N' AS S WHERE ' + @where_src + N') AS S'
                         + N'    ON ' + @join_cond
                         + N' WHEN MATCHED AND (' + @cmp_t + N' <> ' + @cmp_s
                         + CASE WHEN @mode_entree = N'DELTA'
                                THEN N' OR T.FL_SUP <> CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END'
                                ELSE N' OR T.FL_SUP = 1' END
                         + N') THEN UPDATE SET '
                         + CASE WHEN @set_scd1 IS NOT NULL THEN @set_scd1 + N', ' ELSE N'' END
                         + N'T.FL_SUP = ' + CASE WHEN @mode_entree = N'DELTA' THEN N'CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END' ELSE N'0' END
                         + N', T.NO_SEQ = T.NO_SEQ + 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                         + N' WHEN NOT MATCHED BY TARGET THEN INSERT (' + @cols_dwh
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' VALUES (' + @vals_ods + N', 1, @p_dt, @p_infini, '
                         + CASE WHEN @mode_entree = N'DELTA' THEN N'CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END' ELSE N'0' END
                         + N', 1, SYSDATETIME(), @p_usr, @p_trt)'
                         + CASE WHEN @mode_entree = N'ETAT'
                                THEN N' WHEN NOT MATCHED BY SOURCE AND T.FL_SUP = 0 THEN UPDATE SET T.FL_SUP = 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                                ELSE N'' END
                         + N';'
                         + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql @sql,
                     N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_deb = @dt_deb, @p_fin = @dt_fin,
                     @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_maj OUTPUT;
            END

            /* ==============================================================
               10. AJOUT  -  insertion pure
            ============================================================== */
            ELSE IF @mode_alim = N'AJOUT'
            BEGIN
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' SELECT ' + @vals_ods
                         + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_max + N'), 0) + 1'
                         + N', @p_dt, @p_infini'
                         + CASE WHEN @mode_entree = N'DELTA' THEN N', CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END' ELSE N', 0' END
                         + N', 1, SYSDATETIME(), @p_usr, @p_trt'
                         + N' FROM ' + @src + N' AS S WHERE ' + @where_src + N';'
                         + N' SELECT @p_nb = @@ROWCOUNT;';

                EXEC sys.sp_executesql @sql,
                     N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_deb = @dt_deb, @p_fin = @dt_fin,
                     @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_ins OUTPUT;
            END;

            COMMIT TRANSACTION;

            /* ==============================================================
               11. JOURNALISATION  -  une ligne par flux
            ============================================================== */
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh,
                    CASE WHEN @mode_alim = N'SCD1' THEN @nb_maj ELSE @nb_ins + @nb_sup END,
                    N'OK',
                    @mode_entree + N' / ' + @mode_alim
                    + N' - recues: ' + CONVERT(NVARCHAR(10), @nb_src)
                    + CASE WHEN @mode_alim = N'SCD2'
                           THEN N' / fermees: ' + CONVERT(NVARCHAR(10), @nb_ferm)
                              + N' / inserees: ' + CONVERT(NVARCHAR(10), @nb_ins)
                              + CASE WHEN @nb_sup > 0 THEN N' / supprimees: ' + CONVERT(NVARCHAR(10), @nb_sup) ELSE N'' END
                           WHEN @mode_alim = N'SCD1'
                           THEN N' / lignes touchees: ' + CONVERT(NVARCHAR(10), @nb_maj)
                           ELSE N' / inserees: ' + CONVERT(NVARCHAR(10), @nb_ins) END
                    + N'.',
                    @dt_step, SYSDATETIME());
        END;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'KO',
                N'HISTORISATION ' + ISNULL(@mode_entree, N'?') + N'/' + ISNULL(@mode_alim, N'?') + N' : ' + ERROR_MESSAGE(),
                @dt_step, SYSDATETIME());
    END CATCH;

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @mode_entree, @mode_alim;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;
