/* ============================================================================
   MIGRATION  -  FL_SUP a 0 par defaut sur les tables OWT existantes

   FL_SUP valait 1 sur suppression et NULL sinon. Un indicateur ne doit avoir
   que deux etats : il vaut desormais 0 par defaut. Ce script aligne les tables
   deja creees, le generateur produisant directement la bonne definition pour
   les suivantes.

   Rejouable. Ne touche que les tables OWT du perimetre actif dont FL_SUP est
   encore nullable.
   ============================================================================ */

SET NOCOUNT ON;

DECLARE @tbl NVARCHAR(300), @sql NVARCHAR(MAX);

DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT DISTINCT QUOTENAME(F.LB_SCHEMA_DWH) + N'.' + QUOTENAME(F.LB_TABLE_DWH)
    FROM dbo.ORT_PARAM_FLUX AS F
    INNER JOIN sys.columns AS C
        ON C.object_id = OBJECT_ID(QUOTENAME(F.LB_SCHEMA_DWH) + N'.' + QUOTENAME(F.LB_TABLE_DWH))
       AND C.name = N'FL_SUP'
       AND C.is_nullable = 1
    WHERE F.FL_ACTIF = 1 AND F.LB_TABLE_DWH IS NOT NULL;

OPEN cur;
FETCH NEXT FROM cur INTO @tbl;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @sql = N'UPDATE ' + @tbl + N' SET FL_SUP = 0 WHERE FL_SUP IS NULL;'
             + N' ALTER TABLE ' + @tbl + N' ALTER COLUMN FL_SUP BIT NOT NULL;'
             + N' ALTER TABLE ' + @tbl + N' ADD CONSTRAINT '
             + QUOTENAME(N'DF_' + PARSENAME(@tbl, 1) + N'_FL_SUP')
             + N' DEFAULT (0) FOR FL_SUP;';
    EXEC sp_executesql @sql;
    PRINT N'FL_SUP aligne : ' + @tbl;

    FETCH NEXT FROM cur INTO @tbl;
END;

CLOSE cur;
DEALLOCATE cur;

/* Controle : plus aucune FL_SUP nullable dans le perimetre. */
SELECT F.LB_TABLE_DWH, Probleme = N'FL_SUP encore nullable'
FROM dbo.ORT_PARAM_FLUX AS F
INNER JOIN sys.columns AS C
    ON C.object_id = OBJECT_ID(QUOTENAME(F.LB_SCHEMA_DWH) + N'.' + QUOTENAME(F.LB_TABLE_DWH))
   AND C.name = N'FL_SUP' AND C.is_nullable = 1
WHERE F.FL_ACTIF = 1;
