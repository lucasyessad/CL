/* ============================================================================
   TABLE DE PARAMETRAGE  -  dbo.ORT_PARAM_HISTORISATION_TRACES

   Cette table indique au traitement quelles tables historiser et comment.
   Une ligne est creee par colonne parametree.

   FL_CHARGEMENT = 1  : table incluse dans le perimetre
   FL_CLEF = 1        : colonne appartenant a la cle fonctionnelle
   FL_ORDRE_TRI = 1   : colonne utilisee pour ordonner les traces
   LB_FILTRE_WHERE    : filtre SQL optionnel

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.ORT_PARAM_HISTORISATION_TRACES;
GO

CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET         nvarchar(50)   NOT NULL,
    LB_SOURCE         nvarchar(200)  NULL,
    LB_TABLE_ODS      nvarchar(128)  NOT NULL,
    LB_TABLE_DWH      nvarchar(200)  NOT NULL,
    NO_CHAMP          int            NOT NULL,
    LB_CHAMP_ODS      nvarchar(128)  NULL,
    LB_CHAMP_DWH      nvarchar(128)  NULL,
    LB_SCD            nvarchar(30)   NULL,
    FL_CLEF           bit            NOT NULL,
    FL_CHARGEMENT     bit            NULL,
    FL_ORDRE_TRI      bit            NOT NULL,
    LB_FILTRE_WHERE   nvarchar(1000) NULL,

    CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
        PRIMARY KEY CLUSTERED
        (
            LB_PROJET ASC,
            LB_TABLE_ODS ASC,
            NO_CHAMP ASC
        )
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ACTIVES
    ON dbo.ORT_PARAM_HISTORISATION_TRACES
    (
        FL_CLEF,
        FL_CHARGEMENT
    )
    INCLUDE
    (
        LB_PROJET,
        LB_TABLE_ODS,
        LB_TABLE_DWH,
        NO_CHAMP,
        LB_CHAMP_ODS,
        LB_CHAMP_DWH,
        FL_ORDRE_TRI
    );
GO
