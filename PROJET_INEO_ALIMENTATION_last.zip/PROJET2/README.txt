================================================================================
INEO  -  ALIMENTATION DU DWH DEPUIS LES PROGICIELS SOURCES
================================================================================


CE QUE CONTIENT CETTE LIVRAISON
--------------------------------------------------------------------------------

Le projet complet, construit sur ce qui est DEPLOYE : vos scripts de tables,
vos generateurs, le SQL reel extrait de votre scenario ODI. Ce qui est nouveau
ou modifie est signale ; le reste est repris tel quel.

  1_PARAMETRAGE      NOUVEAU    la table de flux et les procedures de chargement
  2_TABLES           EXISTANT   vos scripts de tables, plus une migration
  3_GENERATEURS      EXISTANT   vos generateurs, harmonises
  4_ODI              MODIFIE    le SQL des etapes, en scripts numerotes
  4_ODI_deploye_ref  REFERENCE  le SQL en production, pour comparaison
  5_EXPLOITATION     NOUVEAU    jobs generiques, le projet en parametre


REPONSES AUX QUESTIONS POSEES
--------------------------------------------------------------------------------

Les procedures ecrivent-elles dans ORT_AUDIT_CHARGEMENT ?
    Oui. PS_PREPARATION_ODS cree la ligne 'Chargement bcp -> ods' de chaque
    table, PS_CONTROLE_ODS la complete, PS_CHARGEMENT_FICHIER_ODS ecrit
    'Chargement csv -> ods', PS_CLOTURE_INIT_ODS ecrit la cloture. Les dix
    colonnes ecrites existent dans votre table.

Une colonne a FL_CHARGEMENT = 0 est-elle chargee ?
    Non - mais elle l'ETAIT dans la version deployee. L'etape 006 construisait
    la liste des colonnes sans filtrer sur FL_CHARGEMENT : toute colonne ayant
    un LB_CHAMP_DWH etait chargee. Corrige dans 4_ODI/08.

FL_SUP peut-il valoir 0 ?
    Il le doit. Il valait 1 sur suppression et NULL sinon, trois etats pour un
    indicateur. Il vaut desormais 0 par defaut : generateur corrige, etape 006
    corrigee, et 2_TABLES/08 aligne les OWT existantes.


LE PARAMETRAGE
--------------------------------------------------------------------------------

Une seule table est nouvelle : ORT_PARAM_FLUX, une ligne par table alimentee.
Elle porte ce qui est vrai pour la table entiere et que le parametrage colonne
ne pouvait pas porter sans le repeter sur ses 1406 lignes :

  CD_MODE_ENTREE   ce que contient le fichier
      DELTA   des modifications, une ligne par changement
      ETAT    l'etat complet de la table

  CD_FORMAT        comment le fichier est ecrit
      BCP     format binaire natif
      CSV     fichier delimite

  CD_MODE_ALIM     ce qu'on en fait dans le DWH
      SCD2    historisation par periodes de validite
      SCD1    etat courant seulement
      AJOUT   insertion pure
      AUCUNE  le flux s'arrete a l'ODS

Les trois se croisent librement : le traitement ne deduit jamais l'un des
autres. L'initialisation est un indicateur a part, FL_INIT, pas un mode.

ORT_PARAM_HISTORISATION_TRACES reste inchangee : ses 1406 lignes ne bougent
pas, et le script d'installation cree une ligne de flux par table deja
decrite, en DELTA + BCP + SCD2. Rien a migrer, rien a saisir.

Il n'y a pas de vue : les etapes ODI et les procedures lisent directement
ORT_PARAM_FLUX pour le mode et ORT_PARAM_HISTORISATION_TRACES pour les
colonnes. Le controle 8 de 01_ORT_PARAM_FLUX.sql verifie que les deux niveaux
restent d'accord sur la cible et la source de chaque table.


ORDRE DE DEPLOIEMENT
--------------------------------------------------------------------------------

  1. 1_PARAMETRAGE/01_ORT_PARAM_FLUX.sql
       cree la table, une ligne de flux par table existante, et passe les huit
       controles de coherence
  2. 1_PARAMETRAGE/02_PROCEDURES_ODS.sql
  3. 2_TABLES/08_MIGRATION_FL_SUP.sql
  4. 3_GENERATEURS/03 puis 05, pour les tables a venir seulement : les tables
     existantes ne sont pas a regenerer
  5. 4_ODI : coller chaque script dans la tache ODI correspondante, regenerer
     le scenario
  6. 5_EXPLOITATION : installer les trois jobs

Les etapes ODI non modifiees sont livrees pour completude : elles n'ont pas a
etre recollees.


LES JOBS
--------------------------------------------------------------------------------

Trois jobs, le projet en parametre. Aucun ne connait de table, de schema ni de
fichier : tout est lu dans le parametrage.

  RIWALI10.bat LIGIS          chargement des fichiers BCP
  RIWALI11.bat LIGIS          chargement des fichiers delimites
  RIWALI12.bat LIGIS          scenario ODI

  RIWALI10.bat LIGIS INIT     reprise d'existant

Un second projet se planifie avec les memes jobs, en changeant le parametre.

DEROULEMENT DE RIWALI10 : la table d'audit est chargee seule et en premier
car elle porte les bornes ; PS_PREPARATION_ODS nettoie chaque cible selon son
mode et photographie sa volumetrie ; la boucle bcp charge les fichiers, liste
lue dans le parametrage ; PS_CONTROLE_ODS mesure ce qui a ete charge et sort
en erreur si une table n'a rien recu.


LE JOURNAL
--------------------------------------------------------------------------------

Tout est dans ORT_AUDIT_CHARGEMENT. Par jour et par table, deux lignes :
'Chargement bcp -> ods' et 'TRACES [jour]'. Les autres etapes n'ecrivent qu'en
cas d'anomalie. Une ligne de chargement dont CD_STATUT est reste vide signale
un job arrete entre la preparation et le controle.


DONNEES DATEES DANS LE FUTUR
--------------------------------------------------------------------------------

Une trace dont la date de commit est dans le futur - horloge source dereglee
ou saisie manuelle - reste dans le sas jusqu'a ce que sa journee soit reellement
atteinte : c'est le comportement voulu.

Ce qu'il ne faut pas, c'est qu'elle entraine les autres. L'etape 001 plafonne
donc la couverture d'extraction a l'instant present :

    IF @fin_extraction > SYSDATETIME() SET @fin_extraction = SYSDATETIME();

Sans ce plafond, une seule trace au futur tirait la couverture au-dela
d'aujourd'hui, posait des bornes sur des journees pas encore arrivees, et le
quotidien ne trouvait plus de journee normale a traiter. Avec, les journees
passees se traitent comme d'habitude et la trace au futur patiente.


CE QUI A ETE VERIFIE
--------------------------------------------------------------------------------

  - equilibrage BEGIN/CASE/END, TRY/CATCH, transactions et curseurs de chaque
    script ODI et de chaque procedure ;
  - coherence des noms de colonnes techniques entre le generateur, le
    parametrage, les etapes ODI et le socle : DD_VAL, DF_VAL, DT_MAJ_TRT,
    LB_LSN_COMMIT_TEC, CD_DML_TEC, aucun nom d'une version anterieure ;
  - les dix colonnes ecrites dans ORT_AUDIT_CHARGEMENT existent dans la table ;
  - les colonnes de OIT_TEC_AUDIT_CDC lues par les procedures existent ;
  - parametres de chaque sp_executesql declares et passes ;
  - jobs : expansion retardee, labels, codes retour.

Ce qui ne peut pas etre verifie ici : aucun script n'a ete execute. La recette
etape par etape dans SSMS, avec une table active, reste le passage oblige. Le
SQL dynamique de l'etape 006 en particulier merite d'etre teste sur un flux de
chaque mode.
================================================================================
