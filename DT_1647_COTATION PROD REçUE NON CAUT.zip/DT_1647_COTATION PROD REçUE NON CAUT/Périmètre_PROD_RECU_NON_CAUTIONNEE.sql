/* détermination de la dernière version du prêt à image fin de mois de l'arrêté calculé */
/* CHANGER le nom de la table et créer un index sur le prêt séquence */

INSERT INTO <?= odiRef.getObjectName("L", "PITMAX_SEQ_PWTPRT", "MSSQL_STAGING", "D") ?>
select cd_pret,MAX(no_seq_prt) from <?= odiRef.getObjectName("L", "PWTPRT", "MSSQL_DWH", "D") ?> 
where   1=1
       AND DJ_DATE_DEB  <= convert(datetime,'#V_DateArrete_EAD_V0_1')
       AND CONVERT(CHAR(10), ID_TRACE, 103)<= CONVERT(CHAR(10),CONVERT(DATE,'#V_DateArrete_EAD_V0_1'))
group by CD_PRET


/* Création du périmètre des prêts hors encours engagé */ 
truncate table <?= odiRef.getObjectName("L", "PITMAX_SEQ_HORS_ENC_NEC", "MSSQL_STAGING", "D") ?>

INSERT INTO <?= odiRef.getObjectName("L", "PITMAX_SEQ_HORS_ENC", "MSSQL_STAGING", "D") ?> 
select cd_pret,no_seq_prt from <?= odiRef.getObjectName("L", "PITMAX_SEQ_PWTPRT", "MSSQL_STAGING", "D") ?>
 EAD
where   1=1
    
       AND NOT EXISTS 
                     (SELECT * 
                      from  <?= odiRef.getObjectName("L", "EWTENC", "MSSQL_DWH_ENCOURS", "D") ?>  ENC
                      WHERE  EAD.CD_PRET = ENC.CD_PRET
                      AND DT_ENCOURS=LEFT('#V_DateArrete_EAD_V0_1',6))


)
/* alimentation de la table périmètre PROD recue non cautionné contenant les données prêts exclusion du non engagé */

INSERT INTO "table de périmètre"

SELECT PRT.*
from
DWH.dbo.PWTPRT as WPRT_1  INNER JOIN  DWH.ods.PITMAX_SEQ_HORS_ENC_NEC as PITMAX_SEQ_PDTEAD_PRT_1  
    ON  WPRT_1.CD_PRET = PITMAX_SEQ_PDTEAD_PRT_1.CD_PRET AND WPRT_1.NO_SEQ_PRT = PITMAX_SEQ_PDTEAD_PRT_1.NO_SEQ_PRT  
AND (WPRT_1.CD_ETAP IN ('CLA','EAU','EDI','PEC','SIG') )
-- AND WPRT_1.CD_STATUT NOT IN ('ANN','REF')) /* CCS 16102026 */
where	(1=1)
 and (NOT EXISTS
 (SELECT * 
  FROM DWH_ENCOURS.dbo.EWTNEC as CAUTIONNE_NEC
  WHERE CAUTIONNE_NEC.CD_PRET =  PITMAX_SEQ_PDTEAD_PRT_1.CD_PRET
  AND CAUTIONNE_NEC.DT_ENCOURS = '#INEO.V155_FinIntCalcul_V0_1'))

/* Il faut s'assurer que pour une m^me opération tous les prêts sont dans le même statut de non cuationnés */



