USE [DWH]
GO

/****** Object:  Table [dbo].[PITOPE_COT_REC_NON_CAUT]    Script Date: 08/10/2026 15:09:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PITOPE_COT_REC_NON_CAUT](
	[NO_SEQ] [int] NOT NULL,
	[CD_TRAIT] [char](1) NOT NULL, -- pas nécessaire 
	[CD_OP] [char](10) NOT NULL,
	[FL_OP_MEP] [tinyint] NULL,
	[FL_REL] [tinyint] NULL,
	[TX_LTV] [numeric](6, 4) NULL,
	[DT_MEP_OP] [datetime] NULL,
	[NB_INT] [int] NULL,
	[FL_DEF_OP] [tinyint] NULL,        -- pas nécessaire 
	[DD_DEF_OP] [datetime] NULL,		-- pas nécessaire   		
	[DF_DEF_OP] [datetime] NULL,		-- pas nécessaire
	[FL_DEC_DET] [tinyint] NULL,		-- pas nécessaire
	[DT_DEC_DET] [datetime] NULL,		-- pas nécessaire
	[FL_PROC_SUR] [tinyint] NULL,		-- pas nécessaire
	[DT_PROC_SUR] [datetime] NULL,		-- pas nécessaire
	[FL_PROC_EXE] [tinyint] NULL,		-- pas nécessaire
	[DT_PROC_EXE] [datetime] NULL,		-- pas nécessaire
	[FL_PROC_COLL] [tinyint] NULL,		-- pas nécessaire
	[DT_PROC_COLL] [datetime] NULL,		-- pas nécessaire
	[FL_103_104] [tinyint] NULL,		-- pas nécessaire
	[DT_103_104] [datetime] NULL,		-- pas nécessaire
	[CD_CHR_LGD_COUR] [char](2) NULL,
	[DF_REL] [datetime] NULL,
	[DT_ANN_FIN_REL] [datetime] NULL,
	[DT_REF] [datetime] NULL,
	[CD_CHR_PD] [char](1) NULL,
	[CD_CHR_LGD] [char](2) NULL,
	[DT_VAL_CHR] [datetime] NULL,
	[NU_VERS_CHR] [numeric](5, 2) NULL,
	[CD_COTE_ENCOURS] [char](2) NULL,
	[NB_NOTE_ENCOURS] [numeric](6, 4) NULL,
	[NU_VERS_ENCOURS] [numeric](5, 2) NULL,
	[NB_PASS_HIST_LGD] [int] NULL,
	[DD_VAL] [datetime] NULL,
	[DF_VAL] [datetime] NULL,
	[DT_MAJ] [datetime] NULL,
	[RES] [varchar](19) NULL,
	[FL_VER_CRT] [tinyint] NULL,
	[CD_USR_MAJ] [char](8) NULL,
	[CD_CHR_PD_CIBLE] [varchar](1) NULL,
	[DT_REF_TRAIT] [datetime] NULL,
	[DT_REF_CHR_PD] [datetime] NULL,
	[DT_REF_CHR_LGD] [datetime] NULL,
	[FL_DEF_PASS] [tinyint] NULL,
	[DD_DEB_DEF_1] [datetime] NULL,
 CONSTRAINT [PK_PITOPE_COT] PRIMARY KEY CLUSTERED 
(
	[CD_OP] ASC,
	[NO_SEQ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


