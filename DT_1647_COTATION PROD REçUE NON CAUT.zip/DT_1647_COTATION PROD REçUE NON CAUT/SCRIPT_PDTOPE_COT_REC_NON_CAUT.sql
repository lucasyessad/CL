USE [DTM_INEO]
GO

/****** Object:  Table [dbo].[PDTOPE_COT_REC_NON_CAUT]    Script Date: 08/10/2026 15:18:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PDTOPE_COT_REC_NON_CAUT](
	[NO_SEQ] [int] NOT NULL,
	[CD_TRAIT] [char](1) NOT NULL,
	[CD_OP] [char](10) NOT NULL,
	[FL_OP_MEP] [tinyint] NULL,
	[FL_REL] [tinyint] NULL,
	[TX_LTV] [numeric](6, 4) NULL,
	[DT_MEP_OP] [datetime] NULL,
	[NB_INT] [int] NULL,
	[FL_DEF_OP] [tinyint] NULL,
	[DD_DEF_OP] [datetime] NULL,
	[DF_DEF_OP] [datetime] NULL,
	[FL_DEF_PASS] [tinyint] NULL,
	[NB_PASS_HIST_LGD] [int] NULL,
	[FL_DEC_DET] [tinyint] NULL,
	[DT_DEC_DET] [datetime] NULL,
	[FL_PROC_SUR] [tinyint] NULL,
	[DT_PROC_SUR] [datetime] NULL,
	[FL_PROC_EXE] [tinyint] NULL,
	[DT_PROC_EXE] [datetime] NULL,
	[FL_PROC_COLL] [tinyint] NULL,
	[DT_PROC_COLL] [datetime] NULL,
	[FL_103_104] [tinyint] NULL,
	[DT_103_104] [datetime] NULL,
	[CD_DER_CHR_LGD_DEF] [char](2) NULL,
	[DT_FIN_REL] [datetime] NULL,
	[DT_ANN_FIN_REL] [datetime] NULL,
	[CD_CHR_PD] [char](1) NULL,
	[CD_CHR_LGD] [char](2) NULL,
	[NU_VERS_CHR] [numeric](5, 2) NULL,
	[CD_COTE_ENCOURS] [char](2) NULL,
	[NB_NOTE_ENCOURS] [numeric](6, 4) NULL,
	[NU_VERS_ENCOURS] [numeric](5, 2) NULL,
	[CD_USER_MAJ] [char](8) NULL,
	[FL_VER_CRT] [tinyint] NULL,
	[DD_VAL] [datetime] NULL,
	[DF_VAL] [datetime] NULL,
	[DT_MAJ] [datetime] NULL,
--	[DT_REF_TRAIT] [datetime] NOT NULL, -- à supprimer
	[DT_REF_CHR_PD] [datetime] NULL,
	[DT_REF_CHR_LGD] [datetime] NULL,
	[CD_CHR_PD_CIBLE] [char](1) NULL,
	[FL_DADP_ACTIF] [bit] NULL,
	[FL_DEJA_DADP] [bit] NULL,
	[FL_IMP] [bit] NULL,
	[FL_DEF] [bit] NULL,
	[FL_CTX] [bit] NULL,
	[FL_CTX_MOTIF_5XX] [bit] NULL,
	[FL_STOCK_DEF] [bit] NULL,
	[FL_OPE_VIVANTE] [bit] NULL,
	[NB_DUR_DEF] [int] NULL,
	[CD_DNE_CHR_LGD_SAIN] [varchar](2) NULL,
	[AGE_OP] [int] NULL,
	[ANC_BANC_EMP1_EVO] [int] NULL,
	[ANC_BANC_EMP2_EVO] [int] NULL,
	[MT_CHARGE_CSM_PFI] [float] NULL,
	[MT_REV_PFI] [float] NULL,
	[FL_REL_VIV] [bit] NULL,
	[LL_RGP_2] [varchar](38) NULL,
	[MT_APPOR_PFI] [float] NULL,
	[MT_PATRIM_MOB] [float] NULL,
	[CD_CSP_EMP1] [varchar](6) NULL,
	[CD_ETAT_CIVIL] [varchar](6) NULL,
	[NB_DUR] [int] NULL,
	[CD_NATUR_OP_PFI] [varchar](3) NULL,
	[CD_NAT_EMP1] [varchar](6) NULL,
	[CD_NAT_EMP2] [varchar](6) NULL,
	[CD_NIV_TAUX] [varchar](4) NULL,
	[DT_EVT] [datetime2](3) NULL,
	[CD_DAT_ARR_AAM] [numeric](6, 0) NULL,
	[DT_ARR_AMJ] [datetime2](7) NULL,
	[MT_EAD_OBS] [numeric](15, 2) NULL,
	[PRES_PATR_HORS_OP] [int] NULL,
	[DT_DERN_DEF] [datetime2](3) NULL,
 CONSTRAINT [PK_PDTOPE_COT_REC_NON_CAUT] PRIMARY KEY CLUSTERED 
(
	[CD_OP] ASC,
	[NO_SEQ] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 100, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PDTOPE_COT_REC_NON_CAUT] ADD  DEFAULT ((0)) FOR [FL_OP_MEP]
GO

ALTER TABLE [dbo].[PDTOPE_COT_REC_NON_CAUT] ADD  DEFAULT ((0)) FOR [FL_103_104]
GO

--ALTER TABLE [dbo].[PDTOPE_COT_REC_NON_CAUT] ADD  DEFAULT (CONVERT([date],'19000101')) FOR [DT_REF_TRAIT]
--GO


