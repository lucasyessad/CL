/* ============================================================================
   01 - dbo.ORT_PERIODE_REPRISE

   File des journees a traiter, une ligne par journee et par scenario. Videe et
   reconstruite a chaque execution par l'etape ODI 003, marquee par l'etape 010.

   Cle par LB_PROJET comme toutes les tables du dispositif, en complement du
   nom de scenario qui distingue deja les projets.

   PK et index seulement.
   ============================================================================ */
USE [DWH];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE if exists dbo.ORT_PERIODE_REPRISE;


CREATE TABLE dbo.ORT_PERIODE_REPRISE
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    DT_JOUR          DATE           NOT NULL,
    NO_SEQ          INT            NOT NULL,
    FL_TRAITE          BIT            NOT NULL,
    LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,

    CONSTRAINT PK_ORT_PERIODE_REPRISE PRIMARY KEY CLUSTERED (LB_PROJET, LB_NOM_SCN_SUN, DT_JOUR)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PERIODE_REPRISE_A_TRAITER
    ON dbo.ORT_PERIODE_REPRISE (LB_NOM_SCN_SUN, FL_TRAITE, DT_JOUR);
GO
