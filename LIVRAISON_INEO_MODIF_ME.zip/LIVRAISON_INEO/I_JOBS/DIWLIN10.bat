@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIN1                                            JOB : RIWLIN10 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Initialisation des tables LigisV5 dans ODS INEO via BCP      #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 04/09/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                             URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : aucune                                                          #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  Reprise d'existant : charge l'etat complet de TOUTES les tables du projet.   #
REM  dans ORT_PARAM_FLUX, une fois, avant que le flux CDC prenne le relais.        #
REM  Meme deroulement que RIWLIG10, avec les fichiers ZBCP_INIT_LIGIS_*, et la    #
REM  liste des tables lue dans le parametrage plutot qu'ecrite ici.               #
REM  PS_PREPARATION_ODS refuse une table dont l'historique est deja alimente.     #
REM                                                                               #
REM  Enchainement : poser une borne INIT dans ORT_BORNE_JOURNEE, RIWLIN10,        #
REM  puis RIWLIN11. La borne INIT est consommee automatiquement.                  #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set SERVER=ERM
set DBNAME=DWH
set SCHEMA=ods
set PROJET=LIGIS
set BCP="X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe"
set RUNID=%DATALIB%\riwlin10-runid.txt

setlocal enableDelayedExpansion

rem 1. Table d'audit : videe et rechargee seule, avant tout le reste
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "TRUNCATE TABLE [%SCHEMA%].[OIT_TEC_AUDIT_CDC];"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

%BCP% "%DBNAME%.%SCHEMA%.[OIT_TEC_AUDIT_CDC]" in "%DATALIB%\ZBCP_LIGIS_TEC_AUDIT_CDC_V.bcp" -T -S %SERVER% -n

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 2. Preparation des tables : volumetrie relevee
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; DECLARE @id bigint = CONVERT(bigint, FORMAT(SYSDATETIME(),'yyyyMMddHHmmss')); EXEC dbo.PS_PREPARATION_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=@id, @CD_FORMAT='BCP'; SELECT 'ID_TRT_ALI=' + CONVERT(varchar(20), @id);" ^
       -o "%RUNID%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem Recuperation de l'identifiant retourne par SQL Server
set ID_TRT_ALI=

for /F "usebackq tokens=1,2 delims==" %%a in ("%RUNID%") do (
    if /I "%%a"=="ID_TRT_ALI" set ID_TRT_ALI=%%b
)

if "!ID_TRT_ALI!"=="" (
    echo Identifiant d'execution introuvable.
    set RC=1
    goto :ERR
)

echo Identifiant d'execution : !ID_TRT_ALI!

rem 3. Liste des tables BCP d'initialisation, lue dans le parametrage
set LISTE=%DATALIB%\riwlin10-tables.txt

sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; SELECT SUBSTRING(LB_TABLE_ODS, 5, 200) FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET='%PROJET%' AND FL_ACTIF=1 AND CD_FORMAT='BCP' AND LB_TABLE_ODS <> 'OIT_TEC_AUDIT_CDC' ORDER BY NO_ORDRE, LB_TABLE_ODS;" ^
       -o "%LISTE%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 4. Lancement des BCP_IN sur les fichiers d'initialisation
for /F "usebackq tokens=1" %%i in ("%LISTE%") do (

    set WKF01=ZBCP_INIT_LIGIS_%%i_V.bcp
    set TABLE=OIT_%%i

    %BCP% "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n

    set RC=!ERRORLEVEL!
    if !RC! NEQ 0 goto :ERR
)

rem 5. Controle du chargement des tables ODS
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "EXEC dbo.PS_CONTROLE_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=!ID_TRT_ALI!;"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

endlocal
goto :FIN

:ERR
exit /B %RC%

:FIN
exit /B 0