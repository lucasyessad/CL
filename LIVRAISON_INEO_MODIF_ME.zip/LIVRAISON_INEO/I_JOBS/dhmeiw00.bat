@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIW0                                            JOB : RHMEIW00 #
REM                                                                               #
REM  PROJET   : CREALIA                                    APPLICATION : LIGISV5  #
REM                                                                               #
REM  TITRE SCRIPT  : Mise à jour de la table audit CDC pour extraction LIGISV5    #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 25/08/26                              DATE M.A.J. : 25/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                              URGENCE :              #
REM                                                                               #
REM                                                                               #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0


rem - recuperation date et heure pour constitution nom fichier
set tsp=%date:~6,4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set tsp=%tsp: =0%

rem A renseigner
set	DBNAME=Ligis5_Dev_Data
set	SERVER=ASM

"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE" -S %SERVER% -d %DBNAME% -M -E -b -i %proclib%\HMEIW00_Update_Ligis_TEC_AUDIT_CDC.sql -f o:1252
endlocal

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0