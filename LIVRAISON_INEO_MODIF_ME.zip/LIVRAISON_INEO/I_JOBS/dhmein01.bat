@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIW0                                            JOB : RHMEIW01 #
REM                                                                               #
REM  PROJET   : CREALIA                                    APPLICATION : LIGISV5  #
REM                                                                               #
REM  TITRE SCRIPT  : Export CDC des donn�es LIGISV5 par BCP Out                   #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 25/08/26                              DATE M.A.J. : 25/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                              URGENCE :              #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

set DBNAME=Ligis5_Dev_Data
set SQL_SRVNAME=ASM

setlocal enableDelayedExpansion

rem Lancement des BCP_OUT sur toutes les vues du schema export_cdc
for /F "usebackq tokens=*" %%i in (`sqlcmd -S %SQL_SRVNAME% -d %DBNAME% -E -h -1 -W -Q "SET NOCOUNT ON; SELECT v.name FROM sys.views v INNER JOIN sys.schemas s ON s.schema_id = v.schema_id WHERE s.name = 'export_cdc' AND v.name LIKE 'ZBCP_INIT_LIGIS[_]%%[_]V' ORDER BY v.name;"`) do (

	set WKF01=%%i.bcp
	set VIEW=%%i

	"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe" "%DBNAME%.export_cdc.[!VIEW!]" out "%DATALIB%\!WKF01!" -T -S %SQL_SRVNAME% -n

	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

endlocal

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0