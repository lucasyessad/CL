@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIW0                                            JOB : RHMEIW02 #
REM                                                                               #
REM  PROJET   : CREALIA                                    APPLICATION : LIGISV5  #
REM                                                                               #
REM  TITRE SCRIPT  : Move des fichiers ZBCP_LIGIS_* sur INEO                      #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 25/08/26                              DATE M.A.J. : 25/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                              URGENCE :              #
REM                                                                               #
REM                                                                               #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************


@call E:\dsi\exploit\parmlib\chemin.bat


set	REP_SOURCE=%DATALIB%
set	REP_DESTINATION=\\Kenya\dsi\exploit\datalib\dt1374

move /Y %REP_SOURCE%\ZBCP_LIGIS_*.bcp %REP_DESTINATION%
