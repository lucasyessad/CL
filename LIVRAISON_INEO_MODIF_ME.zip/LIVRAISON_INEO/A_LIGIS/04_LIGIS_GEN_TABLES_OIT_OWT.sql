/* ============================================================================
   GENERATEUR DES TABLES OIT ET OWT DEPUIS LES VUES BCP

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 03, 04 ET 05
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Bloc technique ajoute aux tables OWT :
       NO_SEQ, DD_VAL, DF_VAL, FL_VER_CRT, FL_SUP,
       CD_DML_TEC, DT_COMMIT_TEC, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   REGLES DE GENERATION
   ----------------------------------------------------------------------------
   - la structure OIT reproduit la vue a l'identique : ordre, type, longueur,
     precision, echelle et nullabilite ;
   - le bloc metier OWT reprend les memes colonnes, hors colonnes techniques ;
   - les colonnes de la cle metier sont forcees NOT NULL dans OWT ;
   - les scripts generes suppriment et recreent les tables OIT et OWT.
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    TableNameCibleODS sysname       NOT NULL,
    TableNameCibleDWH sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NULL,
    CreateScriptODS   nvarchar(MAX) NULL,
    CreateScriptDWH   nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_TableListODS
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource   sysname = N'dbo';
DECLARE @SchemaVue      sysname = N'export_cdc';
DECLARE @SchemaCibleODS sysname = N'ods';
DECLARE @SchemaCibleDWH sysname = N'dbo';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. A 0, ces tables sont generees sans
   cle et signalees par le controle final. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   Tables sans cle primaire exploitable, dont la cle fonctionnelle est declaree
   ici.
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
---------------------------------------------------------------------------- */
INSERT INTO ##TableListODS
(
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name,
    N'OWT_' + T.name
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @TableNameCibleODS sysname,
    @TableNameCibleDWH sysname,
    @ViewObjectId      int,
    @SourceObjectId    int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @ColonnesCleTriees nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @ColsODS           nvarchar(MAX),
    @ColsDWH           nvarchar(MAX),
    @CreateODS         nvarchar(MAX),
    @CreateDWH         nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        TableNameSource,
        ViewNameSource,
        TableNameCibleODS,
        TableNameCibleDWH
    FROM ##TableListODS
    ORDER BY TableNameSource;

OPEN cur_tables;
FETCH NEXT FROM cur_tables
INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @ColsODS = NULL,
        @ColsDWH = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @ColonnesCleTriees = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL DEFAULT (0),
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal),
        @ColonnesCleTriees = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                QUOTENAME(name)
                + CASE WHEN is_desc = 1 THEN N' DESC' ELSE N' ASC' END
            ),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : OWT generee sans cle primaire.';

    /* ------------------------------------------------------------------------
       Table OIT : copie conforme de la vue.
    ------------------------------------------------------------------------ */
    SELECT
        @ColsODS = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                N'        ' + QuotedName + N' ' + TypeDefinition + NullClause
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    /* ------------------------------------------------------------------------
       Table OWT, bloc metier : la vue hors colonnes techniques.
       Les colonnes de la cle metier sont forcees NOT NULL.
    ------------------------------------------------------------------------ */
    /* L'appartenance a la cle est resolue AVANT l'agregation : SQL Server
       n'accepte pas de sous-requete dans l'expression d'un STRING_AGG. */
    ;WITH ColonnesMetier AS
    (
        SELECT
            VC.column_id,
            Definition =
                N'        ' + VC.QuotedName + N' ' + VC.TypeDefinition
                + CASE
                      WHEN K.name IS NOT NULL THEN N' NOT NULL'
                      ELSE VC.NullClause
                  END
        FROM #ViewCols AS VC
        LEFT JOIN #KeyCols AS K
            ON K.name COLLATE DATABASE_DEFAULT =
               VC.ColumnName COLLATE DATABASE_DEFAULT
        WHERE VC.ColumnName NOT IN
        (
            N'ID_INSTANCE_TEC',
            N'NO_SEQUENCE_TEC',
            N'LB_SEQVAL_TEC',
            N'CD_DML_TEC',
            N'DT_COMMIT_TEC',
            N'LB_LSN_COMMIT_TEC',
            N'FL_FIN_JOURNEE'
        )
    )
    SELECT
        @ColsDWH = STRING_AGG(CONVERT(nvarchar(MAX), Definition), N',' + CHAR(13))
                   WITHIN GROUP (ORDER BY column_id)
    FROM ColonnesMetier;

    /* ------------------------------------------------------------------------
       Script de creation de la table OIT.
    ------------------------------------------------------------------------ */
    SET @CreateODS =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N' ('
        + CHAR(13) + @ColsODS + CHAR(13) + N');' + CHAR(13)

        /* Recherche de la derniere trace par cle sur la fenetre de journee.
           L'ordre du tri est DT_COMMIT_TEC puis LB_SEQVAL_TEC : les deux
           colonnes sont dans l'index, sinon le ROW_NUMBER trie a chaque
           execution. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE NONCLUSTERED INDEX '
                     + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_CLE')
                     + N' ON '
                     + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
                     + N' (' + @ColonnesCleMetier + N', [DT_COMMIT_TEC], [LB_SEQVAL_TEC]);' + CHAR(13)
              ELSE N''
          END

        /* Bornage de la fenetre de journee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_COMMIT')
        + N' ON '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
        + N' ([DT_COMMIT_TEC]);' + CHAR(13)

        /* Suppression de la plage rechargee par l'import. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_LSN')
        + N' ON '
        + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
        + N' ([LB_LSN_COMMIT_TEC]);' + CHAR(13);

    /* ------------------------------------------------------------------------
       Script de creation de la table OWT.
       CD_DML_TEC appartient au bloc technique : le parametrage genere par le
       script 05 l'alimente, elle doit donc exister dans la cible.
    ------------------------------------------------------------------------ */
    SET @CreateDWH =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N' (' + CHAR(13)
        + N'        [NO_SEQ] int NULL,' + CHAR(13)
        + N'        [DD_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [DF_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [FL_VER_CRT] bit NOT NULL,' + CHAR(13)
        + N'        [FL_SUP] bit NOT NULL,' + CHAR(13)
        + N'        [CD_DML_TEC] int NULL,' + CHAR(13)
        + N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13)
        + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
        + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
        + N'        [ID_TRT_ALI] bigint NULL'
        + CASE
              WHEN @ColsDWH IS NOT NULL
                  THEN N',' + CHAR(13) + @ColsDWH
              ELSE N''
          END
        + CASE
              WHEN @ColonnesCleTriees IS NOT NULL
                  THEN N',' + CHAR(13)
                     + N'        CONSTRAINT ' + QUOTENAME(N'PK_' + @TableNameCibleDWH)
                     + N' PRIMARY KEY CLUSTERED (' + @ColonnesCleTriees + N', [DD_VAL] ASC)'
              ELSE N''
          END
        + CHAR(13) + N');' + CHAR(13)

        /* Une seule version courante par cle metier. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE UNIQUE NONCLUSTERED INDEX '
                     + QUOTENAME(N'UX_' + @TableNameCibleDWH + N'_VER_CRT')
                     + N' ON '
                     + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
                     + N' (' + @ColonnesCleMetier + N')'
                     + N' WHERE [FL_VER_CRT] = 1;' + CHAR(13)
              ELSE N''
          END

        /* Purge et reouverture d'une journee recalculee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DD_VAL')
        + N' ON '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DD_VAL]);' + CHAR(13)
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DF_VAL')
        + N' ON '
        + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DF_VAL], [FL_VER_CRT]);' + CHAR(13);

    UPDATE ##TableListODS
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        CreateScriptODS = @CreateODS,
        CreateScriptDWH = @CreateDWH,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_tables
    INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;
GO

/* Script complet a executer sur le DWH. */
SELECT
    ScriptComplet =
    (
        SELECT
            CHAR(13) + CreateScriptODS + CHAR(13)
          + CreateScriptDWH + CHAR(13)
        FROM ##TableListODS
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail par table. */
SELECT
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    MessageControle,
    CreateScriptODS,
    CreateScriptDWH
FROM ##TableListODS
ORDER BY TableNameSource;

/* Tables sans cle metier exploitable. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListODS
WHERE MessageControle <> N'OK'
ORDER BY TableNameSource;
GO
