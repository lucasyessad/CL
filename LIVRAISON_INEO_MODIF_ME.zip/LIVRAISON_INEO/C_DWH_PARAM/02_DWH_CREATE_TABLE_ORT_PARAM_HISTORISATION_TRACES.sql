/* ============================================================================
   02_DWH_CREATE_TABLE_ORT_PARAM_HISTORISATION_TRACES
   A EXECUTER SUR LE DWH. Table de parametrage colonne, VIDE. PK et index.
   Alimentee ensuite par la sortie du generateur (06_LIGIS_GEN_PARAMETRAGE).
   ============================================================================ */
USE [DWH];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

Drop table if exists dbo.ORT_PARAM_HISTORISATION_TRACES; 

CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET      NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS   NVARCHAR(128)  NOT NULL,
    NO_CHAMP       INT            NOT NULL,

    LB_SOURCE      NVARCHAR(260)  NULL,
    LB_TABLE_DWH   NVARCHAR(128)  NULL,
    LB_CHAMP_ODS   NVARCHAR(128)  NULL,
    LB_CHAMP_DWH   NVARCHAR(128)  NULL,
    LB_SCD         NVARCHAR(30)   NULL,

    FL_CLEF        BIT            NOT NULL,
    FL_CHARGEMENT  BIT            NOT NULL,
    FL_ORDRE_TRI   BIT            NOT NULL,

    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
        PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ROLES
    ON dbo.ORT_PARAM_HISTORISATION_TRACES (LB_PROJET, LB_TABLE_ODS, FL_CLEF, FL_CHARGEMENT)
    INCLUDE (NO_CHAMP, LB_CHAMP_ODS, LB_CHAMP_DWH, FL_ORDRE_TRI);
GO
