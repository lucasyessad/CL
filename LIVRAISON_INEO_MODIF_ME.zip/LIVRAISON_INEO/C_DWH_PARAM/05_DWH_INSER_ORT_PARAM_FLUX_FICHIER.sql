/* ============================================================================
   05_DWH_INSER_ORT_PARAM_FLUX_FICHIER
   A EXECUTER SUR LE DWH. Saisie MANUELLE, une ligne par fichier delimite.

   Les fichiers ne sont pas dans le CDC : ils se declarent a la main. Les
   colonnes de ces flux doivent aussi etre saisies dans
   ORT_PARAM_HISTORISATION_TRACES (le generateur ne les connait pas), sauf si
   CD_MODE_ALIM = 'AUCUNE' : le flux s'arrete a l'ODS, rien a mapper.

   LB_FICHIER accepte un nom exact ou un masque a suffixe variable :
       PITOPE_TABLEREF.csv       nom exact
       PITOPE_TABLEREF_*.csv     prefixe stable, suffixe libre (date...)
   Le repertoire n'est PAS stocke ici : il vient de %DATALIB% dans le job.

   Exemple renseigne, a adapter puis decommenter.
   ============================================================================ */
USE [DWH];
GO

DELETE FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET = N'LIGIS' and LB_TABLE_ODS = N'PITLIG_TABLEREF';

INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    LB_FICHIER, LB_DELIMITEUR, NO_LIGNE_DEBUT, LB_ENCODAGE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
VALUES
(
    N'LIGIS', N'PITLIG_TABLEREF', NULL, NULL,
    N'FULL', N'CSV', N'AUCUNE',
    1, 900, NULL,
    N'ods', N'dbo', NULL, NULL,
    N'ZBCP_LIGIS_TABLEREF_*.csv', N';', 2, N'65001',
    SYSDATETIME(), N'INIT', N'Ficher charge en ODS, pas d''historisation'
);
GO
