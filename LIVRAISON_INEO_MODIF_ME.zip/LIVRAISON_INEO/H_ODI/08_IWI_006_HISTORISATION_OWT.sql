/* ============================================================================
   IWI.006  -  HISTORISATION DANS LE DWH

   Part de l'image du jour - les lignes FL_FIN_JOURNEE = 1 du sas, posees par
   l'etape 004 - et la reporte dans la cible selon CD_MODE_ALIM.

   L'etape ne connait pas le mode d'entree : DELTA et FULL ont deja converge
   vers une image, une ligne par cle. La comparaison a la cible se fait sur
   les colonnes FL_CHARGEMENT = 1.

     SCD2   compare l'image a la version courante. Ferme et reinsere ce qui a
            change, insere les nouvelles cles, marque FL_SUP = 1 les cles
            disparues (absentes de l'image mais courantes dans la cible).
     SCD1   met a jour l'image sur place, sans conserver le passe.
     AJOUT  insere l'image sans comparer.
     AUCUNE non traite ici.

   Une suppression a la source :
     DELTA  derniere trace CD_DML_TEC = 1  ->  FL_SUP = 1
     FULL   cle absente de l'image        ->  FL_SUP = 1

   Journalise une ligne par table. Aucun controle de volumetrie : on trace,
   on ne fait pas echouer sur un ecart attendu (insere = ce qui a change).
   ============================================================================ */

DECLARE @DT_TRACES    DATE         = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI   INT          = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET    NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE         = '2400-01-01';
DECLARE @CD_USR_MAJ   NVARCHAR(20) = N'<?=odiRef.getSession("ODI_USER_NAME") ?>';
DECLARE @PFX_ODS NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) = N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

DECLARE
    @tbl_ods   NVARCHAR(128), @tbl_dwh  NVARCHAR(200),
    @entree    NVARCHAR(10),  @alim     NVARCHAR(10),
    @src NVARCHAR(400), @tgt NVARCHAR(400),
    @cle_ods NVARCHAR(MAX),      -- [K]                    noms ODS
    @cle1    NVARCHAR(128),      -- premiere colonne cle, nom ODS
    @join_st NVARCHAR(MAX),      -- S.[k] = T.[k]
    @join_mx NVARCHAR(MAX),      -- T2.[k] = S.[k]
    @join_tt NVARCHAR(MAX),      -- T3.[k] = T.[k]
    @cols    NVARCHAR(MAX),      -- [c]      colonnes chargees (cle incluse)
    @vals_s  NVARCHAR(MAX),      -- S.[c]
    @vals_t  NVARCHAR(MAX),      -- T.[c]
    @set_s1  NVARCHAR(MAX),      -- T.[c] = S.[c]   hors cle
    @cmp_s   NVARCHAR(MAX), @cmp_t NVARCHAR(MAX),
    @sql NVARCHAR(MAX), @msg NVARCHAR(2000),
    @nb_ferm INT, @nb_ins INT, @nb_maj INT, @nb_sup INT, @dt_step DATETIME2(3);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH, F.CD_MODE_ENTREE, F.CD_MODE_ALIM
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ALIM <> N'AUCUNE'
      AND F.LB_TABLE_DWH IS NOT NULL
      AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1)
      AND NOT EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
                  WHERE ISNULL(A.ID_TRT_ALI,-1) = ISNULL(@ID_TRT_ALI,-1)
                    AND A.LB_PROJET = @LB_PROJET AND A.CD_STATUT = N'KO'
                    AND A.LB_SOURCE = F.LB_TABLE_ODS
                    AND CHARINDEX(N'[' + @jour + N']', A.LB_CHARGEMENT) > 0)
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @entree, @alim;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SELECT @nb_ferm = 0, @nb_ins = 0, @nb_maj = 0, @nb_sup = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);
        SELECT @cle_ods=NULL,@cle1=NULL,@join_st=NULL,@join_mx=NULL,@join_tt=NULL,
               @cols=NULL,@vals_s=NULL,@vals_t=NULL,@set_s1=NULL,@cmp_s=NULL,@cmp_t=NULL;

        /* Cle */
        SELECT
            @cle_ods = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @join_st = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.'+QUOTENAME(LB_CHAMP_ODS)+N' = T.'+QUOTENAME(LB_CHAMP_DWH)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @join_mx = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T2.'+QUOTENAME(LB_CHAMP_DWH)+N' = S.'+QUOTENAME(LB_CHAMP_ODS)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @join_tt = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T3.'+QUOTENAME(LB_CHAMP_DWH)+N' = T.'+QUOTENAME(LB_CHAMP_DWH)), N' AND ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CLEF=1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT TOP (1) @cle1 = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CLEF=1 ORDER BY NO_CHAMP;

        /* Colonnes chargees */
        SELECT
            @cols   = STRING_AGG(CONVERT(NVARCHAR(MAX), QUOTENAME(LB_CHAMP_DWH)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @vals_s = STRING_AGG(CONVERT(NVARCHAR(MAX), N'S.'+QUOTENAME(LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @vals_t = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.'+QUOTENAME(LB_CHAMP_DWH)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CHARGEMENT=1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        /* Colonnes chargees hors cle : mise a jour SCD1 et comparaison */
        SELECT
            @set_s1 = STRING_AGG(CONVERT(NVARCHAR(MAX), N'T.'+QUOTENAME(LB_CHAMP_DWH)+N' = S.'+QUOTENAME(LB_CHAMP_ODS)), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @cmp_s  = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), S.'+QUOTENAME(LB_CHAMP_ODS)+N'), N''<null>'')'), N' + N''|'' + ') WITHIN GROUP (ORDER BY NO_CHAMP),
            @cmp_t  = STRING_AGG(CONVERT(NVARCHAR(MAX), N'ISNULL(CONVERT(NVARCHAR(MAX), T.'+QUOTENAME(LB_CHAMP_DWH)+N'), N''<null>'')'), N' + N''|'' + ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET=@LB_PROJET AND LB_TABLE_ODS=@tbl_ods AND FL_CHARGEMENT=1 AND FL_CLEF=0
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SET @cmp_s = ISNULL(@cmp_s, N'N''''');
        SET @cmp_t = ISNULL(@cmp_t, N'N''''');

        IF @cle_ods IS NULL OR @cols IS NULL
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods + N'.';
            THROW 50042, @msg, 1;
        END

        BEGIN TRANSACTION;

        /* L'image du jour : les lignes flaguees du sas. */
        DECLARE @img NVARCHAR(MAX) =
            N'(SELECT * FROM ' + @src + N' WHERE FL_FIN_JOURNEE = 1)';

        IF @alim = N'SCD2'
        BEGIN
            /* Fermeture : cle de l'image absente, differente, ou de retour. */
            SET @sql = N'UPDATE T SET T.DF_VAL = @p_dt, T.FL_VER_CRT = 0'
                     + N' FROM ' + @tgt + N' AS T'
                     + N' LEFT JOIN ' + @img + N' AS S ON ' + @join_st
                     + N' WHERE T.FL_VER_CRT = 1'
                     + N'   AND (S.' + QUOTENAME(@cle1) + N' IS NULL'
                     + N'        OR T.FL_SUP = 1 OR ' + @cmp_t + N' <> ' + @cmp_s + N');'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT', @p_dt=@DT_TRACES, @p_nb=@nb_ferm OUTPUT;

            /* Insertion des cles de l'image sans version courante. */
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                     + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                     + N' SELECT ' + @vals_s
                     + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_mx + N'), 0) + 1'
                     + N', @p_dt, @p_inf'
                     + CASE WHEN @entree = N'DELTA' THEN N', CASE WHEN S.CD_DML_TEC = 1 THEN 1 ELSE 0 END' ELSE N', 0' END
                     + N', 1, SYSDATETIME(), @p_usr, @p_trt'
                     + N' FROM ' + @img + N' AS S'
                     + N' WHERE NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T WHERE ' + @join_st + N' AND T.FL_VER_CRT = 1);'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_dt date, @p_inf date, @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                 @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_ins OUTPUT;

            /* FULL : cles disparues de l'image -> version FL_SUP = 1. */
            IF @entree = N'FULL'
            BEGIN
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                         + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                         + N' SELECT ' + @vals_t
                         + N', T.NO_SEQ + 1, @p_dt, @p_inf, 1, 1, SYSDATETIME(), @p_usr, @p_trt'
                         + N' FROM ' + @tgt + N' AS T'
                         + N' WHERE T.DF_VAL = @p_dt AND T.FL_VER_CRT = 0 AND T.FL_SUP = 0'
                         + N'   AND NOT EXISTS (SELECT 1 FROM ' + @img + N' AS S WHERE ' + @join_st + N')'
                         + N'   AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS T3 WHERE ' + @join_tt + N' AND T3.FL_VER_CRT = 1);'
                         + N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql,
                     N'@p_dt date, @p_inf date, @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                     @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_sup OUTPUT;
            END
        END
        ELSE IF @alim = N'SCD1'
        BEGIN
            SET @sql = N'MERGE ' + @tgt + N' AS T USING ' + @img + N' AS S ON ' + @join_st
                     + N' WHEN MATCHED AND (' + @cmp_t + N' <> ' + @cmp_s
                     + CASE WHEN @entree = N'DELTA' THEN N' OR T.FL_SUP <> CASE WHEN S.CD_DML_TEC=1 THEN 1 ELSE 0 END' ELSE N' OR T.FL_SUP = 1' END
                     + N') THEN UPDATE SET '
                     + CASE WHEN @set_s1 IS NOT NULL THEN @set_s1 + N', ' ELSE N'' END
                     + N'T.FL_SUP = ' + CASE WHEN @entree=N'DELTA' THEN N'CASE WHEN S.CD_DML_TEC=1 THEN 1 ELSE 0 END' ELSE N'0' END
                     + N', T.NO_SEQ = T.NO_SEQ + 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                     + N' WHEN NOT MATCHED BY TARGET THEN INSERT (' + @cols
                     + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                     + N' VALUES (' + @vals_s + N', 1, @p_dt, @p_inf, '
                     + CASE WHEN @entree=N'DELTA' THEN N'CASE WHEN S.CD_DML_TEC=1 THEN 1 ELSE 0 END' ELSE N'0' END
                     + N', 1, SYSDATETIME(), @p_usr, @p_trt)'
                     + CASE WHEN @entree = N'FULL'
                            THEN N' WHEN NOT MATCHED BY SOURCE AND T.FL_SUP = 0 THEN UPDATE SET T.FL_SUP = 1, T.DT_MAJ_TRT = SYSDATETIME(), T.CD_USR_MAJ = @p_usr, T.ID_TRT_ALI = @p_trt'
                            ELSE N'' END
                     + N'; SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_dt date, @p_inf date, @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                 @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_maj OUTPUT;
        END
        ELSE IF @alim = N'AJOUT'
        BEGIN
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols
                     + N', NO_SEQ, DD_VAL, DF_VAL, FL_SUP, FL_VER_CRT, DT_MAJ_TRT, CD_USR_MAJ, ID_TRT_ALI)'
                     + N' SELECT ' + @vals_s
                     + N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2 WHERE ' + @join_mx + N'), 0) + 1'
                     + N', @p_dt, @p_inf'
                     + CASE WHEN @entree=N'DELTA' THEN N', CASE WHEN S.CD_DML_TEC=1 THEN 1 ELSE 0 END' ELSE N', 0' END
                     + N', 1, SYSDATETIME(), @p_usr, @p_trt'
                     + N' FROM ' + @img + N' AS S; SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_dt date, @p_inf date, @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                 @p_dt=@DT_TRACES, @p_inf=@DATE_INFINIE, @p_usr=@CD_USR_MAJ, @p_trt=@ID_TRT_ALI, @p_nb=@nb_ins OUTPUT;
        END

        COMMIT TRANSACTION;

        /* Journal : une ligne par table. */
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh,
                CASE WHEN @alim = N'SCD1' THEN @nb_maj ELSE @nb_ins + @nb_sup END, N'OK',
                @entree + N' / ' + @alim
                + CASE WHEN @alim = N'SCD2' THEN N' - fermees: ' + CONVERT(NVARCHAR(10),@nb_ferm) + N' / inserees: ' + CONVERT(NVARCHAR(10),@nb_ins) + CASE WHEN @nb_sup>0 THEN N' / supprimees: ' + CONVERT(NVARCHAR(10),@nb_sup) ELSE N'' END
                       WHEN @alim = N'SCD1' THEN N' - lignes touchees: ' + CONVERT(NVARCHAR(10),@nb_maj)
                       ELSE N' - inserees: ' + CONVERT(NVARCHAR(10),@nb_ins) END,
                @dt_step, SYSDATETIME());
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'KO',
                N'HISTO ' + ISNULL(@alim,N'?') + N' : ' + ERROR_MESSAGE(), @dt_step, SYSDATETIME());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh, @entree, @alim;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
