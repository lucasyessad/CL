/* ================================================================
   Création de la table de correspondance
   ================================================================ */
DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource sysname NOT NULL
);
GO

--  Données d'exemple
INSERT INTO ##TableListODS (TableNameSource )
SELECT 
    t.name AS TableNameSource
FROM sys.tables AS t
INNER JOIN sys.schemas AS s 
    ON s.schema_id = t.schema_id
INNER JOIN [export_cdc].[TEC_AUDIT_CDC] tm
    ON tm.LB_INSTANCE = N'dbo_' + t.name
WHERE s.name = N'dbo'
ORDER BY t.name;

/* ================================================================
   Génération automatique des vues CDC enrichies
   ================================================================ */

SET NOCOUNT ON;

DECLARE
    @SchemaSource       sysname = N'dbo',
    @SchemaCDC          sysname = N'cdc',
    @SchemaCDCExport    sysname = N'export_cdc',
    @TableNameSource    sysname,
    @DropSQL nvarchar(MAX),
    @CreateSQL nvarchar(MAX),
    @FullSQL nvarchar(MAX),
    @CDC_Table nvarchar(517),
    @CaptureInstance sysname;

DECLARE cur_view CURSOR LOCAL FAST_FORWARD FOR
SELECT TableNameSource
FROM ##TableListODS;

OPEN cur_view;
FETCH NEXT FROM cur_view INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @CaptureInstance = @SchemaSource + '_' + @TableNameSource;
    SET @CDC_Table = QUOTENAME(@SchemaCDC) + N'.' + QUOTENAME(@CaptureInstance + N'_CT');

    /* Sécurité */
    IF OBJECT_ID(@CDC_Table) IS NULL
    BEGIN
        PRINT 'Table CDC absente : ' + @CDC_Table;
        FETCH NEXT FROM cur_view INTO @TableNameSource;
        CONTINUE;
    END

    /* =====================================================
       1. Script DROP
       ===================================================== */
    SET @DropSQL =
        'DROP VIEW IF EXISTS ' 
        + QUOTENAME(@SchemaCDCExport) 
        + N'.' + QUOTENAME(N'ZBCP_LIGIS_' + @TableNameSource + N'_V') + N';';

    /* =====================================================
       2. Script CREATE
       ===================================================== */
    ;WITH cols AS (
        SELECT 
            c.name,
            c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@CDC_Table)
          AND c.name NOT LIKE '__$%'
    )
    SELECT @CreateSQL =
'CREATE VIEW ' + QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_LIGIS_' + @TableNameSource + N'_V') + N'
AS
    /* Contrat de nullabilité, identique à la vue ZBCP_INIT_LIGIS_<TABLE>_V :
       bloc technique NOT NULL sauf DT_COMMIT_TEC, colonnes métier toutes NULL
       (jointure externe). bcp -n écrit le fichier d''après la nullabilité de
       la vue et le relit d''après celle de la table OIT, générée depuis cette
       vue : les trois doivent coïncider. */
    WITH CTE_AUDIT AS (
        SELECT
            ID_INSTANCE,
            LB_DEB_LSN,
            LB_FIN_LSN,
            DT_DEB_LSN,
            DT_FIN_LSN,
            DT_EXTRACT,
            NO_SEQUENCE
        FROM ' + QUOTENAME(@SchemaCDCExport) + '.ZBCP_LIGIS_TEC_AUDIT_CDC_V
        WHERE LB_INSTANCE = ''' + @CaptureInstance + '''
    )

    SELECT
        ISNULL(T.ID_INSTANCE, CONVERT(binary(32), 0))                                AS ID_INSTANCE_TEC,
        ISNULL(T.NO_SEQUENCE, 0)                                                     AS NO_SEQUENCE_TEC,
        ISNULL(CONVERT(binary(10), C.__$seqval), 0x00000000000000000000)             AS LB_SEQVAL_TEC,
        ISNULL(C.__$operation, 0)                                                    AS CD_DML_TEC,
        CONVERT(DATETIME2(3), sys.fn_cdc_map_lsn_to_time(C.__$start_lsn))            AS DT_COMMIT_TEC,
        ISNULL(C.__$start_lsn, 0x00000000000000000000)                               AS LB_LSN_COMMIT_TEC,
        ' +
        STRING_AGG('C.' + QUOTENAME(name), ',' + CHAR(13) + '        ')
        WITHIN GROUP (ORDER BY column_id) + ',
        ISNULL(CONVERT(BIT, 0), 0) AS FL_FIN_JOURNEE
    FROM CTE_AUDIT AS T
    LEFT JOIN (SELECT 1 AS ORT_LIGNE, * FROM ' + @CDC_Table + ') AS C
           ON C.__$operation IN (1,2,4)
          AND C.__$start_lsn > T.LB_DEB_LSN
          AND C.__$start_lsn <= T.LB_FIN_LSN
    WHERE C.ORT_LIGNE = 1;'
    FROM cols
	where name not like 'CS/_%' escape '/';

    /* =====================================================
       3. Exécution dans le bon ordre
       ===================================================== */
/* version print */
--    SET @FullSQL = @DropSQL + CHAR(13) + 'GO' + CHAR(13) + @CreateSQL + CHAR(13) + 'GO' + CHAR(13) + CHAR(13); 	Print @FullSQL;

/* version exec */    
    EXEC(@DropSQL); EXEC(@CreateSQL);
    FETCH NEXT FROM cur_view INTO @TableNameSource;
END

CLOSE cur_view;
DEALLOCATE cur_view;
GO