/* ============================================================================
   CONTRÔLE DES VUES D'EXPORT  -  À EXÉCUTER SUR LA BASE SOURCE (Migration_ligis)

   Pour chaque table de l'audit, la vue CDC et la vue d'état complet doivent
   être identiques colonne pour colonne : nom, rang, type, longueur, précision,
   échelle, nullabilité. bcp -n écrit le fichier d'après la vue et le relit
   d'après la table OIT, générée depuis la vue CDC : tout écart casse l'import
   des fichiers d'état complet.

   À passer après A_LIGIS/02 et 03, et après tout changement de structure.
   Chaque requête doit renvoyer zéro ligne.
   ============================================================================ */
USE [Migration_ligis];
GO

DECLARE @SchemaCDCExport sysname = N'export_cdc';

/* 1. Vue d'état complet sans vue CDC, ou l'inverse, pour une table sous CDC. */
SELECT A.LB_INSTANCE, N'vue CDC absente' AS Probleme
FROM export_cdc.TEC_AUDIT_CDC AS A
WHERE OBJECT_ID(N'cdc.' + QUOTENAME(A.LB_INSTANCE + N'_CT')) IS NOT NULL
  AND OBJECT_ID(QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_LIGIS_' + STUFF(A.LB_INSTANCE, 1, 4, N'') + N'_V')) IS NULL
UNION ALL
SELECT A.LB_INSTANCE, N'vue d''etat complet absente'
FROM export_cdc.TEC_AUDIT_CDC AS A
WHERE OBJECT_ID(QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + STUFF(A.LB_INSTANCE, 1, 4, N'') + N'_V')) IS NULL;

/* 2. Écart de structure entre la vue CDC et la vue d'état complet. */
;WITH V AS
(
    SELECT
        tbl = CASE WHEN v.name LIKE N'ZBCP_INIT_LIGIS[_]%' THEN SUBSTRING(v.name, 17, LEN(v.name) - 18)
                   ELSE SUBSTRING(v.name, 12, LEN(v.name) - 13) END,
        genre = CASE WHEN v.name LIKE N'ZBCP_INIT_LIGIS[_]%' THEN N'INIT' ELSE N'CDC' END,
        c.column_id, c.name AS colonne, ty.name AS type_sql,
        c.max_length, c.precision, c.scale, c.is_nullable
    FROM sys.views AS v
    INNER JOIN sys.schemas AS s ON s.schema_id = v.schema_id
    INNER JOIN sys.columns AS c ON c.object_id = v.object_id
    INNER JOIN sys.types AS ty ON ty.user_type_id = c.user_type_id
    WHERE s.name = @SchemaCDCExport
      AND (v.name LIKE N'ZBCP_LIGIS[_]%[_]V' OR v.name LIKE N'ZBCP_INIT_LIGIS[_]%[_]V')
      AND v.name <> N'ZBCP_LIGIS_TEC_AUDIT_CDC_V'
)
SELECT
    ISNULL(C.tbl, I.tbl)         AS tbl,
    ISNULL(C.column_id, I.column_id) AS rang,
    C.colonne     AS colonne_cdc,   I.colonne     AS colonne_init,
    C.type_sql    AS type_cdc,      I.type_sql    AS type_init,
    C.max_length  AS lg_cdc,        I.max_length  AS lg_init,
    C.precision   AS prec_cdc,      I.precision   AS prec_init,
    C.scale       AS ech_cdc,       I.scale       AS ech_init,
    C.is_nullable AS null_cdc,      I.is_nullable AS null_init,
    CASE
        WHEN C.colonne IS NULL THEN N'colonne en trop dans la vue INIT'
        WHEN I.colonne IS NULL THEN N'colonne en trop dans la vue CDC'
        WHEN C.colonne <> I.colonne THEN N'ordre des colonnes'
        WHEN C.type_sql <> I.type_sql OR C.max_length <> I.max_length
          OR C.precision <> I.precision OR C.scale <> I.scale THEN N'type'
        WHEN C.is_nullable <> I.is_nullable THEN N'nullabilite'
    END AS Probleme
FROM (SELECT * FROM V WHERE genre = N'CDC')  AS C
FULL OUTER JOIN (SELECT * FROM V WHERE genre = N'INIT') AS I
    ON I.tbl = C.tbl AND I.column_id = C.column_id
WHERE EXISTS (SELECT 1 FROM V AS X WHERE X.tbl = ISNULL(C.tbl, I.tbl) AND X.genre = N'CDC')
  AND (C.colonne IS NULL OR I.colonne IS NULL
       OR C.colonne <> I.colonne
       OR C.type_sql <> I.type_sql OR C.max_length <> I.max_length
       OR C.precision <> I.precision OR C.scale <> I.scale
       OR C.is_nullable <> I.is_nullable)
ORDER BY tbl, rang;
GO
