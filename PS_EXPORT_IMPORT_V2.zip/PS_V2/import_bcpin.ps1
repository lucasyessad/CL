#-----------------------------------------------------------------------------#
# SCHEDULE : quotidien, apres l'export BCP                                    #
# PROJET   : EXPORT / IMPORT BCP                                              #
# TITRE    : Import des fichiers BCP dans les tables ODS                      #
#-----------------------------------------------------------------------------#
# CODES RETOUR : 0 = OK ; 1 = configuration/connexion SQL ; 2 = table en echec#
#                3 = ecart entre le nombre de lignes exporte et charge        #
#-----------------------------------------------------------------------------#

[CmdletBinding()]
param(
    [string]$ConfigFile = 'import-parameters.json',
    [string]$CheminBat = 'E:\dsi\exploit\parmlib\Chemin.bat'
)

$ErrorActionPreference = 'Stop'
$code = 0
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$workDir = $null
$logDir = $null
$recapFile = $null
$erreur = ''
$dateExtraction = 'INCONNUE'
$sequence = 'INCONNUE'
$archiveNom = ''
$recapLines = [System.Collections.Generic.List[string]]::new()

$logRepli = Join-Path $env:TEMP "IMPORT_$stamp.log"
Start-Transcript -Path $logRepli | Out-Null
$transcriptStarted = $true

function Import-BatEnvironment {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Chemin.bat introuvable : $Path"
    }

    $command = 'call "' + $Path + '" >nul && set'
    $lines = & $env:ComSpec /d /s /c $command
    if ($LASTEXITCODE -ne 0) {
        throw "Echec du chargement de Chemin.bat (code $LASTEXITCODE)."
    }

    foreach ($line in $lines) {
        if ($line -match '^([^=]+)=(.*)$') {
            [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process')
        }
    }
}

function Get-BcpRowCount {
    param([Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Sortie)

    $m = $Sortie |
         Select-String -Pattern '^\s*(\d+)\s+(rows copied|lignes copi)' |
         Select-Object -First 1

    if ($m) { return [long]$m.Matches[0].Groups[1].Value }
    return [long]-1
}

# Ecrit une ligne dans le journal du DWH, celui-la meme qu'utilise le package
# ODI. Toute la chaine devient ainsi consultable par une seule requete, au
# lieu d'aller lire des fichiers sur deux serveurs.
function Write-JournalDwh {
    param(
        [Parameter(Mandatory)][object]$Config,
        [Parameter(Mandatory)][string]$Chargement,
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Cible,
        [Parameter(Mandatory)][long]$NbLignes,
        [Parameter(Mandatory)][string]$Statut,
        [string]$Message = '',
        [Parameter(Mandatory)][datetime]$Debut
    )

    if (-not $Config.JournalTable) { return }

    $e = { param($s) ([string]$s).Replace("'", "''") }
    $sql = @"
INSERT INTO [$($Config.JournalSchema)].[$($Config.JournalTable)]
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
     NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES
    (NULL, N'$(& $e $Config.LbProjet)', N'$(& $e $Chargement)',
     N'$(& $e $Source)', N'$(& $e $Cible)', $NbLignes, N'$Statut',
     $(if ($Message) { "N'" + (& $e $Message) + "'" } else { 'NULL' }),
     CONVERT(datetime, '$($Debut.ToString('yyyy-MM-dd HH:mm:ss'))', 120),
     GETDATE());
"@

    # Un echec d'ecriture du journal ne doit pas faire echouer l'import.
    try {
        & sqlcmd.exe -S $Config.Server -d $Config.Database -E -b -Q $sql | Out-Null
    } catch {
        Write-Host "Journal DWH non alimente : $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

try {
    Import-BatEnvironment -Path $CheminBat

    $configPath = if ([IO.Path]::IsPathRooted($ConfigFile)) {
        $ConfigFile
    } else {
        Join-Path $env:parmlib $ConfigFile
    }

    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "Fichier de configuration introuvable : $configPath"
    }

    $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 |
           ConvertFrom-Json -ErrorAction Stop

    $inputDir = $env:datalib
    $logDir = $env:loglib
    $workRoot = Join-Path $inputDir 'work'

    if ([string]::IsNullOrWhiteSpace($inputDir)) { throw 'Variable datalib non definie par Chemin.bat.' }
    if ([string]::IsNullOrWhiteSpace($logDir))   { throw 'Variable loglib non definie par Chemin.bat.' }

    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    New-Item -ItemType Directory -Path $workRoot -Force | Out-Null

    Stop-Transcript | Out-Null
    $logFile = Join-Path $logDir "IMPORT_$stamp.log"
    Get-Content -LiteralPath $logRepli | Set-Content -LiteralPath $logFile -Encoding UTF8
    Remove-Item -LiteralPath $logRepli -Force -ErrorAction SilentlyContinue
    Start-Transcript -Path $logFile -Append | Out-Null

    foreach ($identifier in @($cfg.TableSchema, $cfg.TablePrefix, $cfg.AuditTable)) {
        if ([string]$identifier -notmatch '^[A-Za-z0-9_]+$') {
            throw "Identifiant SQL non autorise : $identifier"
        }
    }

    $archive = Get-ChildItem -LiteralPath $inputDir -Filter "$($cfg.ZipPrefix)_*.zip" -File |
               Sort-Object Name |
               Select-Object -First 1

    if (-not $archive) {
        throw "Aucune archive $($cfg.ZipPrefix)_*.zip a importer."
    }
    $archiveNom = $archive.Name

    if ($archive.BaseName -notmatch '^.+_(\d{8})_(\d{10})$') {
        throw "Nom d'archive invalide : $($archive.Name)"
    }

    $dateExtraction = $matches[1]
    $sequence = $matches[2]
    $workDir = Join-Path $workRoot "${dateExtraction}_${sequence}"

    if (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $workDir -Force | Out-Null

    Expand-Archive -LiteralPath $archive.FullName -DestinationPath $workDir -Force

    $listFile = Join-Path $workDir $cfg.ListFileName
    if (-not (Test-Path -LiteralPath $listFile)) {
        throw "Fichier de liste absent de l'archive : $($cfg.ListFileName)"
    }

    $listContent = @(
        Get-Content -LiteralPath $listFile -Encoding UTF8 |
        ForEach-Object { $_.Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )

    $dateExtraction = (($listContent | Where-Object { $_ -like '#DATE_EXTRACTION=*' } | Select-Object -First 1) -replace '^#DATE_EXTRACTION=', '')
    $sequence = (($listContent | Where-Object { $_ -like '#SEQUENCE=*' } | Select-Object -First 1) -replace '^#SEQUENCE=', '')
    $tables = @($listContent | Where-Object { -not $_.StartsWith('#') })

    if ($tables.Count -eq 0) {
        throw "Liste vide : $listFile"
    }

    # Volumetries annoncees par l'export, lues dans le recap de l'archive.
    $attendu = @{}
    $recapExport = Join-Path $workDir 'recap-export.txt'
    if (Test-Path -LiteralPath $recapExport) {
        Get-Content -LiteralPath $recapExport -Encoding UTF8 |
            Where-Object { $_ -match '^([A-Za-z0-9_]+)\|(\d+)\|' } |
            ForEach-Object {
                if ($_ -match '^([A-Za-z0-9_]+)\|(\d+)\|') {
                    $attendu[$matches[1]] = [long]$matches[2]
                }
            }
        Write-Host "Volumetries d'export lues : $($attendu.Count) table(s)." -ForegroundColor Cyan
    } else {
        Write-Host 'Recap d export absent de l archive : controle de volumetrie desactive.' -ForegroundColor Yellow
    }

    Write-Host "Date d'extraction : $dateExtraction" -ForegroundColor Cyan
    Write-Host "Sequence          : $sequence" -ForegroundColor Cyan
    Write-Host "Repertoire travail: $workDir" -ForegroundColor Cyan

    $recapFile = Join-Path $logDir "RECAP_IMPORT_${dateExtraction}_${sequence}.txt"
    $libelleChargement = "IMPORT [${dateExtraction}_${sequence}]"
    $totalRows = [long]0

    foreach ($table in $tables) {
        if ($table -notmatch '^[A-Za-z0-9_]+$') {
            throw "Nom de table non autorise : $table"
        }

        $debutTable = Get-Date
        $targetTable = "$($cfg.TablePrefix)$table"
        $file = Join-Path $workDir "$table.bcp"

        if (-not (Test-Path -LiteralPath $file)) {
            $recapLines.Add("$targetTable|0|0|FICHIER_ABSENT|")
            Write-JournalDwh -Config $cfg -Chargement $libelleChargement -Source $table `
                             -Cible $targetTable -NbLignes 0 -Statut 'KO' `
                             -Message "Fichier .bcp absent de l'archive" -Debut $debutTable
            $code = 2
            throw "Fichier absent dans l'archive : $file"
        }

        if ($targetTable -eq [string]$cfg.AuditTable) {
            # Photo de la derniere extraction : rechargee en entier.
            $query = "TRUNCATE TABLE [$($cfg.TableSchema)].[$targetTable];"
        } else {
            # Table de traces : alimentee en ajout, jamais videe, pour ne pas
            # detruire les traces pas encore traitees. On supprime uniquement
            # la plage de LSN que ce fichier va recharger, ce qui rend une
            # relance sans effet de bord.
            $tableSql = $table.Replace("'", "''")
            $query = @"
DELETE T
FROM [$($cfg.TableSchema)].[$targetTable] AS T
INNER JOIN [$($cfg.TableSchema)].[$($cfg.AuditTable)] AS A
        ON A.LB_INSTANCE = N'dbo_$tableSql'
WHERE T.CD_LSN_TEC > A.LB_DEB_LSN
  AND T.CD_LSN_TEC <= A.LB_FIN_LSN;
"@
        }

        & sqlcmd.exe -S $cfg.Server -d $cfg.Database -E -b -Q $query
        $sqlExitCode = $LASTEXITCODE
        if ($sqlExitCode -ne 0) {
            $recapLines.Add("$targetTable|0|0|ECHEC_PREPARATION|")
            Write-JournalDwh -Config $cfg -Chargement $libelleChargement -Source $table `
                             -Cible $targetTable -NbLignes 0 -Statut 'KO' `
                             -Message "Preparation SQL en echec (code $sqlExitCode)" -Debut $debutTable
            $code = 2
            throw "Traitement SQL en echec pour $targetTable (code $sqlExitCode)."
        }

        $target = "$($cfg.Database).$($cfg.TableSchema).$targetTable"
        $errorFile = Join-Path $logDir "${targetTable}_REJETS_${dateExtraction}_${sequence}.log"

        Write-Host "Import de $file vers $target" -ForegroundColor Cyan
        $bcpOutput = @(& bcp.exe $target in $file -n -S $cfg.Server -T -m 1 -e $errorFile 2>&1)
        $bcpExitCode = $LASTEXITCODE
        $bcpOutput | ForEach-Object { Write-Host $_ }

        $bcpHasError = @(
            $bcpOutput | Where-Object {
                [string]$_ -match 'SQLState\s*=' -or [string]$_ -match 'Error\s*='
            }
        ).Count -gt 0

        if ($bcpExitCode -ne 0 -or $bcpHasError) {
            $recapLines.Add("$targetTable|0|0|ECHEC_BCP|$errorFile")
            Write-JournalDwh -Config $cfg -Chargement $libelleChargement -Source $table `
                             -Cible $targetTable -NbLignes 0 -Statut 'KO' `
                             -Message "BCP IN en echec (code $bcpExitCode), rejets dans $errorFile" -Debut $debutTable
            $code = 2
            throw "BCP IN en echec pour $targetTable. Code=$bcpExitCode. Rejets=$errorFile"
        }

        # Nombre de lignes reellement chargees par CET import. Un COUNT sur la
        # table donnerait le total accumule, traces des jours precedents
        # comprises, ce qui ne renseigne pas sur le chargement.
        $rowsCopied = Get-BcpRowCount -Sortie $bcpOutput

        # Comparaison avec ce que l'export annonce avoir ecrit dans le fichier.
        $nbAttendu = if ($attendu.ContainsKey($table)) { $attendu[$table] } else { [long]-1 }
        if ($nbAttendu -ge 0 -and $rowsCopied -ge 0 -and $rowsCopied -ne $nbAttendu) {
            $recapLines.Add("$targetTable|$nbAttendu|$rowsCopied|ECART_VOLUMETRIE|")
            Write-JournalDwh -Config $cfg -Chargement $libelleChargement -Source $table `
                             -Cible $targetTable -NbLignes $rowsCopied -Statut 'KO' `
                             -Message "Ecart : $nbAttendu ligne(s) exportee(s), $rowsCopied chargee(s)" -Debut $debutTable
            $code = 3
            throw "Ecart de volumetrie pour $targetTable : $nbAttendu exportee(s), $rowsCopied chargee(s)."
        }

        if (Test-Path -LiteralPath $errorFile) {
            if ((Get-Item -LiteralPath $errorFile).Length -eq 0) {
                Remove-Item -LiteralPath $errorFile -Force
            }
        }

        if ($rowsCopied -gt 0) { $totalRows += $rowsCopied }
        $recapLines.Add("$targetTable|$nbAttendu|$rowsCopied|OK|")
        Write-JournalDwh -Config $cfg -Chargement $libelleChargement -Source $table `
                         -Cible $targetTable -NbLignes $rowsCopied -Statut 'OK' `
                         -Debut $debutTable
    }

    # L'archive n'est marquee traitee qu'une fois TOUTES les tables chargees.
    $donePath = [IO.Path]::ChangeExtension($archive.FullName, '.done')
    Move-Item -LiteralPath $archive.FullName -Destination $donePath -Force

    Remove-Item -LiteralPath $workDir -Recurse -Force
    $workDir = $null

    Write-Host "Import termine : $archiveNom, $($tables.Count) table(s), $totalRows ligne(s)." -ForegroundColor Green
}
catch {
    if ($code -eq 0) { $code = 1 }
    $erreur = $_.Exception.Message
    Write-Host "*** IMPORT EN ECHEC (code $code) : $erreur" -ForegroundColor Red
    Write-Host '*** L ODS EST INCOMPLET : NE PAS LANCER LE PACKAGE ODI.' -ForegroundColor Red
    if ($workDir) {
        Write-Host "Repertoire de travail conserve : $workDir" -ForegroundColor Yellow
    }
}
finally {
    if ($logDir) {
        if (-not $recapFile) {
            $recapFile = Join-Path $logDir "RECAP_IMPORT_${stamp}_ECHEC.txt"
        }
        $entete = @(
            "DATE_EXTRACTION=$dateExtraction"
            "SEQUENCE=$sequence"
            "ARCHIVE=$archiveNom"
            "DATE_FIN=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "STATUT_GLOBAL=$(if ($code -eq 0) { 'OK' } else { 'KO' })"
            "CODE_RETOUR=$code"
            "ERREUR=$erreur"
            ''
            'TABLE|NB_LIGNES_EXPORT|NB_LIGNES_CHARGEES|STATUT|FICHIER_REJETS'
        )
        Set-Content -LiteralPath $recapFile -Value ($entete + $recapLines) -Encoding UTF8

        $jours = if ($cfg -and $cfg.RetentionJours) { [int]$cfg.RetentionJours } else { 30 }
        if ($jours -gt 0) {
            $limite = (Get-Date).AddDays(-$jours)
            Get-ChildItem -LiteralPath $logDir -File -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.LastWriteTime -lt $limite -and
                    ($_.Name -like 'IMPORT_*' -or $_.Name -like 'RECAP_IMPORT_*' -or $_.Name -like '*_REJETS_*')
                } |
                Remove-Item -Force -ErrorAction SilentlyContinue
            if ($env:datalib) {
                Get-ChildItem -LiteralPath $env:datalib -File -Filter '*.done' -ErrorAction SilentlyContinue |
                    Where-Object { $_.LastWriteTime -lt $limite } |
                    Remove-Item -Force -ErrorAction SilentlyContinue
            }
        }
    }
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}

exit $code
