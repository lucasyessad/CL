USE [DWH];
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @LB_PROJET nvarchar(50) = N'LIGIS';

/*
    1 = vider les tables OIT avant le rechargement
    0 = ajouter les lignes sans vider les tables OIT
*/
DECLARE @ViderCible bit = 1;

DECLARE @PFX_ODS nvarchar(300) =
    N'DWH.ods.';

DECLARE @PFX_HISTO nvarchar(300) =
    N'ODS_Traces.ods.';

DECLARE @CAT_ODS nvarchar(200) =
    N'DWH.';

DECLARE @CAT_HISTO nvarchar(200) =
    N'ODS_Traces.';

DECLARE @SCHEMA_ODS sysname =
    N'ods';

DECLARE @SCHEMA_HISTO sysname =
    N'ods';

DECLARE
    @tbl_ods       nvarchar(128),
    @tbl_histo     nvarchar(200),
    @src           nvarchar(400),
    @tgt           nvarchar(400),
    @cols          nvarchar(MAX),
    @cols_src      nvarchar(MAX),
    @sql           nvarchar(MAX),
    @nb_lignes     bigint,
    @nb_total      bigint = 0,
    @msg           nvarchar(2000);

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
        SELECT
            P.LB_TABLE_ODS
        FROM DWH.dbo.ORT_PARAM_HISTORISATION_TRACES AS P
        WHERE P.LB_PROJET = @LB_PROJET
          AND P.FL_CLEF = 1
          AND P.FL_CHARGEMENT = 1
          AND P.LB_TABLE_ODS LIKE N'OIT[_]%'
        GROUP BY
            P.LB_TABLE_ODS
        ORDER BY
            P.LB_TABLE_ODS;

    OPEN cur_tables;

    FETCH NEXT FROM cur_tables
    INTO @tbl_ods;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @tbl_histo =
              @tbl_ods
            + N'_HISTO';

        SET @src =
              @PFX_HISTO
            + QUOTENAME(@tbl_histo);

        SET @tgt =
              @PFX_ODS
            + QUOTENAME(@tbl_ods);

        SET @cols = NULL;
        SET @cols_src = NULL;
        SET @sql = NULL;
        SET @nb_lignes = 0;

        /*
            Construction de la liste des colonnes communes entre
            la table OIT cible et la table OIT_HISTO source.

            L'ordre des colonnes est celui de la table OIT cible.
        */
        SET @sql =
              N'SELECT'
            + N'    @p_cols = STRING_AGG'
            + N'    ('
            + N'        CONVERT'
            + N'        ('
            + N'            nvarchar(max),'
            + N'            QUOTENAME(OC.name)'
            + N'        ),'
            + N'        N'', '''
            + N'    ) WITHIN GROUP'
            + N'    ('
            + N'        ORDER BY OC.column_id'
            + N'    ),'
            + N'    @p_cols_src = STRING_AGG'
            + N'    ('
            + N'        CONVERT'
            + N'        ('
            + N'            nvarchar(max),'
            + N'            N''H.'' + QUOTENAME(OC.name)'
            + N'        ),'
            + N'        N'', '''
            + N'    ) WITHIN GROUP'
            + N'    ('
            + N'        ORDER BY OC.column_id'
            + N'    )'
            + N' FROM ' + @CAT_ODS + N'sys.columns AS OC'
            + N' INNER JOIN ' + @CAT_ODS + N'sys.tables AS OT'
            + N'     ON OT.object_id = OC.object_id'
            + N' INNER JOIN ' + @CAT_ODS + N'sys.schemas AS OS'
            + N'     ON OS.schema_id = OT.schema_id'
            + N' WHERE OS.name = @p_schema_ods'
            + N'   AND OT.name = @p_table_ods'
            + N'   AND OC.is_computed = 0'
            + N'   AND EXISTS'
            + N'       ('
            + N'           SELECT 1'
            + N'           FROM ' + @CAT_HISTO
            + N'sys.columns AS HC'
            + N'           INNER JOIN ' + @CAT_HISTO
            + N'sys.tables AS HT'
            + N'               ON HT.object_id = HC.object_id'
            + N'           INNER JOIN ' + @CAT_HISTO
            + N'sys.schemas AS HS'
            + N'               ON HS.schema_id = HT.schema_id'
            + N'           WHERE HS.name = @p_schema_histo'
            + N'             AND HT.name = @p_table_histo'
            + N'             AND HC.name COLLATE DATABASE_DEFAULT'
            + N'                 = OC.name COLLATE DATABASE_DEFAULT'
            + N'       );';

        EXEC sys.sp_executesql
             @sql,
             N'@p_schema_ods sysname,
               @p_table_ods sysname,
               @p_schema_histo sysname,
               @p_table_histo sysname,
               @p_cols nvarchar(max) OUTPUT,
               @p_cols_src nvarchar(max) OUTPUT',
             @p_schema_ods = @SCHEMA_ODS,
             @p_table_ods = @tbl_ods,
             @p_schema_histo = @SCHEMA_HISTO,
             @p_table_histo = @tbl_histo,
             @p_cols = @cols OUTPUT,
             @p_cols_src = @cols_src OUTPUT;

        IF @cols IS NULL
           OR @cols_src IS NULL
        BEGIN
            SET @msg =
                  N'Aucune colonne commune entre '
                + @src
                + N' et '
                + @tgt
                + N'.';

            RAISERROR(@msg, 16, 1);
        END;

        SET @sql = N'';

        IF @ViderCible = 1
        BEGIN
            SET @sql =
                  N'TRUNCATE TABLE '
                + @tgt
                + N';'
                + CHAR(13);
        END;

        SET @sql =
              @sql
            + N'INSERT INTO '
            + @tgt
            + N' ('
            + @cols
            + N')'
            + CHAR(13)
            + N'SELECT '
            + @cols_src
            + CHAR(13)
            + N'FROM '
            + @src
            + N' AS H;'
            + CHAR(13)
            + N'SET @p_nb = @@ROWCOUNT;'
            + CHAR(13)
            + N'UPDATE '
            + @tgt
            + N' SET FL_FIN_JOURNEE = 0;';

        EXEC sys.sp_executesql
             @sql,
             N'@p_nb bigint OUTPUT',
             @p_nb = @nb_lignes OUTPUT;

        SET @nb_total =
              @nb_total
            + @nb_lignes;

        PRINT
              N'OK : '
            + @src
            + N' vers '
            + @tgt
            + N' : '
            + CONVERT(nvarchar(30), @nb_lignes)
            + N' ligne(s) inseree(s), '
            + N'FL_FIN_JOURNEE remis a 0.';

        FETCH NEXT FROM cur_tables
        INTO @tbl_ods;
    END;

    CLOSE cur_tables;
    DEALLOCATE cur_tables;

    COMMIT TRANSACTION;

    SELECT
        N'OK' AS STATUT,
        @nb_total AS NB_LIGNES_TOTAL;
END TRY
BEGIN CATCH
    IF CURSOR_STATUS(N'local', N'cur_tables') >= 0
    BEGIN
        CLOSE cur_tables;
    END;

    IF CURSOR_STATUS(N'local', N'cur_tables') > -3
    BEGIN
        DEALLOCATE cur_tables;
    END;

    IF XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    SELECT
        N'KO' AS STATUT,
        @tbl_ods AS TABLE_EN_ERREUR,
        ERROR_NUMBER() AS NUMERO_ERREUR,
        ERROR_LINE() AS LIGNE_ERREUR,
        ERROR_MESSAGE() AS MESSAGE_ERREUR;

    SET @msg =
          N'Echec du rechargement HISTO vers OIT'
        + CASE
              WHEN @tbl_ods IS NOT NULL
                  THEN N' pour ' + @tbl_ods
              ELSE N''
          END
        + N' : '
        + ERROR_MESSAGE();

    RAISERROR(@msg, 16, 1);
END CATCH;
GO