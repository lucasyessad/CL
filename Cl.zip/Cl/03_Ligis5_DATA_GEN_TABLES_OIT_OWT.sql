﻿/* ============================================================================
   GENERATEUR DES TABLES OIT ET OWT DEPUIS LES VUES BCP

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   Regles :
   - la structure OIT est lue directement dans export_cdc.ZBCP_LIGIS_<TABLE>_V ;
   - l'ordre, le type, la longueur, la precision, l'echelle et la nullabilite
     des colonnes OIT sont strictement ceux de la vue BCP ;
   - les colonnes OWT metier sont lues dans la meme vue ;
   - les colonnes techniques CDC et FL_FIN_JOURNEE sont exclues du bloc metier OWT ;
   - la cle primaire source est utilisee pour la cle OWT si toutes ses colonnes
     existent dans la vue BCP ;
   - les scripts generes suppriment et recreent les tables OIT et OWT.
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    TableNameCibleODS sysname       NOT NULL,
    TableNameCibleDWH sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    NbColonnesCle     int           NULL,
    CreateScriptODS   nvarchar(MAX) NULL,
    CreateScriptDWH   nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL
);
GO

SET NOCOUNT ON;

DECLARE @SchemaSource   sysname = N'dbo';
DECLARE @SchemaVue      sysname = N'export_cdc';
DECLARE @SchemaCibleODS sysname = N'ods';
DECLARE @SchemaCibleDWH sysname = N'dbo';

INSERT INTO ##TableListODS
(
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH
)
SELECT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name,
    N'OWT_' + T.name
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (N'dbo_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @TableNameCibleODS sysname,
    @TableNameCibleDWH sysname,
    @ViewObjectId      int,
    @TableObjectId     int,
    @CreateODS         nvarchar(MAX),
    @CreateDWH         nvarchar(MAX),
    @ColsODS           nvarchar(MAX),
    @ColsDWH           nvarchar(MAX),
    @PKSorted          nvarchar(MAX),
    @PKPlain           nvarchar(MAX),
    @NbColonnesVue     int,
    @NbCle             int,
    @NbCleDansVue      int,
    @Message           nvarchar(500);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        TableNameSource,
        ViewNameSource,
        TableNameCibleODS,
        TableNameCibleDWH
    FROM ##TableListODS
    ORDER BY TableNameSource;

OPEN cur_tables;
FETCH NEXT FROM cur_tables
INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;

WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT
        @ViewObjectId = V.object_id
    FROM sys.views AS V
    INNER JOIN sys.schemas AS S
        ON S.schema_id = V.schema_id
    WHERE S.name = @SchemaVue
      AND V.name = @ViewNameSource;

    SELECT
        @TableObjectId = T.object_id
    FROM sys.tables AS T
    INNER JOIN sys.schemas AS S
        ON S.schema_id = T.schema_id
    WHERE S.name = @SchemaSource
      AND T.name = @TableNameSource;

    SET @ColsODS = NULL;
    SET @ColsDWH = NULL;
    SET @PKSorted = NULL;
    SET @PKPlain = NULL;
    SET @NbColonnesVue = 0;
    SET @NbCle = 0;
    SET @NbCleDansVue = 0;
    SET @Message = NULL;

    IF OBJECT_ID(N'tempdb..#ViewCols') IS NOT NULL
        DROP TABLE #ViewCols;

    SELECT
        C.column_id,
        C.name AS ColumnName,
        QUOTENAME(C.name) AS QuotedName,
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE WHEN C.max_length = -1
                              THEN N'MAX'
                              ELSE CONVERT(nvarchar(10), C.max_length)
                         END + N')'
                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE WHEN C.max_length = -1
                              THEN N'MAX'
                              ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END + N')'
                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'
                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'
                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'
                ELSE TY.name
            END,
        NullClause = CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    SELECT
        @ColsODS = STRING_AGG
        (
            CAST(N'        ' + QuotedName + N' ' + TypeDefinition + NullClause AS nvarchar(MAX)),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    SELECT
        @ColsDWH = STRING_AGG
        (
            CAST
            (
                N'        ' + VC.QuotedName + N' ' + VC.TypeDefinition
                + CASE WHEN PK.ColumnName IS NOT NULL THEN N' NOT NULL' ELSE VC.NullClause END
                AS nvarchar(MAX)
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY VC.column_id)
    FROM #ViewCols AS VC
    LEFT JOIN
    (
        SELECT C.name AS ColumnName
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @TableObjectId
          AND KC.type = N'PK'
    ) AS PK
        ON PK.ColumnName COLLATE DATABASE_DEFAULT =
           VC.ColumnName COLLATE DATABASE_DEFAULT
    WHERE VC.ColumnName NOT IN
    (
        N'ID_INSTANCE_TEC',
        N'NO_SEQUENCE_TEC',
        N'LB_SEQVAL_TEC',
        N'CD_DML_TEC',
        N'DT_COMMIT_TEC',
        N'LB_LSN_COMMIT_TEC',
        N'FL_FIN_JOURNEE'
    );

    SELECT
        @NbCle = COUNT(*),
        @PKSorted = STRING_AGG
        (
            CAST
            (
                QUOTENAME(C.name)
                + CASE WHEN IC.is_descending_key = 1 THEN N' DESC' ELSE N' ASC' END
                AS nvarchar(MAX)
            ),
            N', '
        ) WITHIN GROUP (ORDER BY IC.key_ordinal),
        @PKPlain = STRING_AGG
        (
            CAST(QUOTENAME(C.name) AS nvarchar(MAX)),
            N', '
        ) WITHIN GROUP (ORDER BY IC.key_ordinal)
    FROM sys.key_constraints AS KC
    INNER JOIN sys.index_columns AS IC
        ON IC.object_id = KC.parent_object_id
       AND IC.index_id = KC.unique_index_id
    INNER JOIN sys.columns AS C
        ON C.object_id = IC.object_id
       AND C.column_id = IC.column_id
    WHERE KC.parent_object_id = @TableObjectId
      AND KC.type = N'PK';

    SELECT
        @NbCleDansVue = COUNT(*)
    FROM sys.key_constraints AS KC
    INNER JOIN sys.index_columns AS IC
        ON IC.object_id = KC.parent_object_id
       AND IC.index_id = KC.unique_index_id
    INNER JOIN sys.columns AS C
        ON C.object_id = IC.object_id
       AND C.column_id = IC.column_id
    WHERE KC.parent_object_id = @TableObjectId
      AND KC.type = N'PK'
      AND EXISTS
      (
          SELECT 1
          FROM #ViewCols AS VC
          WHERE VC.ColumnName COLLATE DATABASE_DEFAULT =
                C.name COLLATE DATABASE_DEFAULT
      );

    IF @NbCle = 0
    BEGIN
        SET @PKSorted = NULL;
        SET @PKPlain = NULL;
        SET @Message = N'Aucune cle primaire source : OWT generee sans cle primaire.';
    END
    ELSE IF @NbCleDansVue <> @NbCle
    BEGIN
        SET @PKSorted = NULL;
        SET @PKPlain = NULL;
        SET @Message = N'Cle primaire source non entierement presente dans la vue BCP : OWT generee sans cle primaire.';
    END
    ELSE
    BEGIN
        SET @Message = N'OK';
    END;

    SET @CreateODS =
          N'DROP TABLE IF EXISTS ' + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE ' + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS) + N' ('
        + CHAR(13) + @ColsODS + CHAR(13) + N');' + CHAR(13)
        + CASE
              WHEN @PKPlain IS NOT NULL
                  THEN N'CREATE NONCLUSTERED INDEX '
                     + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_CLE')
                     + N' ON ' + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
                     + N' (' + @PKPlain + N', [DT_COMMIT_TEC]);' + CHAR(13)
              ELSE N'CREATE NONCLUSTERED INDEX '
                 + QUOTENAME(N'IX_' + @TableNameCibleODS + N'_COMMIT')
                 + N' ON ' + QUOTENAME(@SchemaCibleODS) + N'.' + QUOTENAME(@TableNameCibleODS)
                 + N' ([DT_COMMIT_TEC]);' + CHAR(13)
          END;

    SET @CreateDWH =
          N'DROP TABLE IF EXISTS ' + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE ' + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH) + N' (' + CHAR(13)
        + N'        [NO_SEQ] int NULL,' + CHAR(13)
        + N'        [DD_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [DF_VAL] datetime2(3) NOT NULL,' + CHAR(13)
        + N'        [FL_VER_CRT] bit NOT NULL,' + CHAR(13)
        + N'        [FL_SUP] bit NULL,' + CHAR(13)
        + N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13)
        + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
        + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
        + N'        [ID_TRT_ALI] int NULL'
        + CASE WHEN @ColsDWH IS NOT NULL THEN N',' + CHAR(13) + @ColsDWH ELSE N'' END
        + CASE
              WHEN @PKSorted IS NOT NULL
                  THEN N',' + CHAR(13)
                     + N'        CONSTRAINT ' + QUOTENAME(N'PK_' + @TableNameCibleDWH)
                     + N' PRIMARY KEY CLUSTERED (' + @PKSorted + N', [DD_VAL] ASC)'
              ELSE N''
          END
        + CHAR(13) + N');' + CHAR(13)
        + CASE
              WHEN @PKPlain IS NOT NULL
                  THEN N'CREATE UNIQUE NONCLUSTERED INDEX '
                     + QUOTENAME(N'UX_' + @TableNameCibleDWH + N'_VER_CRT')
                     + N' ON ' + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
                     + N' (' + @PKPlain + N', [DD_VAL]);' + CHAR(13)
              ELSE N''
          END
        + N'CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DD_VAL')
        + N' ON ' + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DD_VAL]);' + CHAR(13)
        + N'CREATE NONCLUSTERED INDEX ' + QUOTENAME(N'IX_' + @TableNameCibleDWH + N'_DF_VAL')
        + N' ON ' + QUOTENAME(@SchemaCibleDWH) + N'.' + QUOTENAME(@TableNameCibleDWH)
        + N' ([DF_VAL], [FL_VER_CRT]);' + CHAR(13);

    UPDATE ##TableListODS
    SET
        NbColonnesVue = @NbColonnesVue,
        NbColonnesCle = @NbCle,
        CreateScriptODS = @CreateODS,
        CreateScriptDWH = @CreateDWH,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_tables
    INTO @TableNameSource, @ViewNameSource, @TableNameCibleODS, @TableNameCibleDWH;
END;

CLOSE cur_tables;
DEALLOCATE cur_tables;
GO

SELECT
    ScriptComplet =
    (
        SELECT
            CHAR(13) + CreateScriptODS + CHAR(13)
          + CreateScriptDWH + CHAR(13)
        FROM ##TableListODS
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

SELECT
    TableNameSource,
    ViewNameSource,
    TableNameCibleODS,
    TableNameCibleDWH,
    NbColonnesVue,
    NbColonnesCle,
    MessageControle,
    CreateScriptODS,
    CreateScriptDWH
FROM ##TableListODS
ORDER BY TableNameSource;

SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListODS
WHERE MessageControle <> N'OK'
ORDER BY TableNameSource;
