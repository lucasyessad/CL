﻿/* ============================================================================
   GENERATEUR DU PARAMETRAGE

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur le DWH.

   Le generateur :
     - lit les colonnes dans export_cdc.ZBCP_LIGIS_<TABLE>_V ;
     - reprend la PK source si elle est entierement exposee dans la vue ;
     - utilise les cles manuelles declarees pour les tables sans PK ;
     - positionne DT_COMMIT_TEC comme colonne de tri ;
     - utilise les noms techniques CDC actuels ;
     - genere les DELETE et INSERT dans ORT_PARAM_HISTORISATION_TRACES.

   LIRE LE RESULTAT DANS LA COLONNE XML ScriptComplet.
   ============================================================================ */

DROP TABLE IF EXISTS ##ParamHistoScript;
GO

CREATE TABLE ##ParamHistoScript
(
    TableNameSource sysname       NOT NULL,
    ViewNameSource  sysname       NOT NULL,
    SourceCle       nvarchar(30)  NULL,
    ColonnesCle     nvarchar(MAX) NULL,
    NbColonnesCle   int           NULL,
    NbLignesParam   int           NULL,
    InsertScript    nvarchar(MAX) NULL,
    MessageControle nvarchar(500) NULL
);
GO

SET NOCOUNT ON;

DECLARE @SchemaSource sysname       = N'dbo';
DECLARE @SchemaVue    sysname       = N'export_cdc';
DECLARE @LB_PROJET    nvarchar(50)  = N'LIGIS';
DECLARE @TableParam   nvarchar(300) = N'dbo.ORT_PARAM_HISTORISATION_TRACES';

DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID', 2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID', 2);

INSERT INTO ##ParamHistoScript
(
    TableNameSource,
    ViewNameSource
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (N'dbo_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource sysname,
    @ViewNameSource  sysname,
    @SourceObjectId  int,
    @ViewObjectId    int,
    @Script          nvarchar(MAX),
    @ValuesScript    nvarchar(MAX),
    @NbCle           int,
    @NbLignes        int,
    @SourceCle       nvarchar(30),
    @ColonnesCle     nvarchar(MAX),
    @Message         nvarchar(500);

DECLARE cur_param CURSOR LOCAL FAST_FORWARD FOR
    SELECT TableNameSource, ViewNameSource
    FROM ##ParamHistoScript
    ORDER BY TableNameSource;

OPEN cur_param;
FETCH NEXT FROM cur_param
INTO @TableNameSource, @ViewNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT @ViewObjectId = V.object_id
    FROM sys.views AS V
    INNER JOIN sys.schemas AS S
        ON S.schema_id = V.schema_id
    WHERE S.name = @SchemaVue
      AND V.name = @ViewNameSource;

    SELECT
        @Script = NULL,
        @ValuesScript = NULL,
        @NbCle = 0,
        @NbLignes = 0,
        @SourceCle = NULL,
        @ColonnesCle = NULL,
        @Message = N'OK';

    DROP TABLE IF EXISTS #view_cols;
    CREATE TABLE #view_cols
    (
        column_id int NOT NULL,
        name sysname COLLATE DATABASE_DEFAULT NOT NULL,
        PRIMARY KEY (column_id)
    );

    INSERT INTO #view_cols (column_id, name)
    SELECT C.column_id, C.name
    FROM sys.columns AS C
    WHERE C.object_id = @ViewObjectId;

    DROP TABLE IF EXISTS #key_cols;
    CREATE TABLE #key_cols
    (
        name sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        PRIMARY KEY (name)
    );

    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #view_cols AS V
              WHERE V.name COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #key_cols (name, key_ordinal)
        SELECT C.name, IC.key_ordinal
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCle = N'PRIMARY KEY';
    END;

    IF NOT EXISTS (SELECT 1 FROM #key_cols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #view_cols AS V
                 WHERE V.name COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #key_cols (name, key_ordinal)
        SELECT M.ColumnName, M.KeyOrdinal
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCle = N'CLE MANUELLE';
    END;

    SELECT
        @NbCle = COUNT(*),
        @ColonnesCle = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #key_cols;

    IF @NbCle = 0
        SET @Message = N'Aucune cle exploitable : table ignoree par ODI.';

    DROP TABLE IF EXISTS #lignes;
    CREATE TABLE #lignes
    (
        grp int NOT NULL,
        ord int NOT NULL,
        champ_ods sysname NULL,
        champ_dwh sysname NULL,
        scd nvarchar(20) NULL,
        clef bit NOT NULL,
        chg bit NOT NULL,
        tri bit NOT NULL
    );

    INSERT INTO #lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT
        1, K.key_ordinal, K.name, K.name, N'TYPE 2', 1, 1, 0
    FROM #key_cols AS K;

    INSERT INTO #lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT 2, 1, N'DT_COMMIT_TEC', N'DT_COMMIT_TEC', NULL, 0, 1, 1
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'DT_COMMIT_TEC')
    UNION ALL
    SELECT 3, 5, N'CD_DML_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'CD_DML_TEC');

    INSERT INTO #lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT 3, 1, N'ID_INSTANCE_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'ID_INSTANCE_TEC')
    UNION ALL
    SELECT 3, 2, N'NO_SEQUENCE_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'NO_SEQUENCE_TEC')
    UNION ALL
    SELECT 3, 3, N'LB_SEQVAL_TEC', NULL, NULL, 0, 0, 1
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'LB_SEQVAL_TEC')
    UNION ALL
    SELECT 3, 4, N'LB_LSN_COMMIT_TEC', NULL, NULL, 0, 0, 0
    WHERE EXISTS (SELECT 1 FROM #view_cols WHERE name = N'LB_LSN_COMMIT_TEC');

    INSERT INTO #lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    SELECT
        4, V.column_id, V.name, V.name, NULL, 0, 1, 0
    FROM #view_cols AS V
    WHERE V.name NOT IN
    (
        N'ID_INSTANCE_TEC',
        N'NO_SEQUENCE_TEC',
        N'LB_SEQVAL_TEC',
        N'CD_DML_TEC',
        N'DT_COMMIT_TEC',
        N'LB_LSN_COMMIT_TEC',
        N'FL_FIN_JOURNEE'
    )
      AND NOT EXISTS
      (
          SELECT 1
          FROM #key_cols AS K
          WHERE K.name COLLATE DATABASE_DEFAULT =
                V.name COLLATE DATABASE_DEFAULT
      );

    INSERT INTO #lignes
        (grp, ord, champ_ods, champ_dwh, scd, clef, chg, tri)
    VALUES
        (5, 1, N'FL_FIN_JOURNEE', NULL,          NULL, 0, 0, 0),
        (5, 2, NULL, N'NO_SEQ',                   NULL, 0, 0, 0),
        (5, 3, NULL, N'DD_VAL',                   NULL, 0, 0, 0),
        (5, 4, NULL, N'DF_VAL',                   NULL, 0, 0, 0),
        (5, 5, NULL, N'FL_SUP',                   NULL, 0, 0, 0),
        (5, 6, NULL, N'FL_VER_CRT',               NULL, 0, 0, 0),
        (5, 7, NULL, N'DT_MAJ_TRT',               NULL, 0, 0, 0),
        (5, 8, NULL, N'CD_USR_MAJ',               NULL, 0, 0, 0),
        (5, 9, NULL, N'ID_TRT_ALI',               NULL, 0, 0, 0);

    ;WITH numerotees AS
    (
        SELECT
            L.*,
            NO_CHAMP = ROW_NUMBER() OVER
            (
                ORDER BY L.grp, L.ord, L.champ_ods, L.champ_dwh
            )
        FROM #lignes AS L
    )
    SELECT
        @ValuesScript = STRING_AGG
        (
            CAST
            (
                  N' (N''' + REPLACE(@LB_PROJET, N'''', N'''''')
                + N''',N''dbo_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',N''OWT_' + REPLACE(@TableNameSource, N'''', N'''''')
                + N''',' + CONVERT(nvarchar(10), NO_CHAMP) + N','
                + CASE WHEN champ_ods IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_ods, N'''', N'''''') + N'''' END + N','
                + CASE WHEN champ_dwh IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(champ_dwh, N'''', N'''''') + N'''' END + N','
                + CASE WHEN scd IS NULL THEN N'NULL'
                       ELSE N'N''' + REPLACE(scd, N'''', N'''''') + N'''' END + N','
                + CONVERT(nvarchar(1), CONVERT(int, clef)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, chg)) + N','
                + CONVERT(nvarchar(1), CONVERT(int, tri)) + N',NULL)'
                AS nvarchar(MAX)
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY NO_CHAMP),
        @NbLignes = COUNT(*)
    FROM numerotees;

    SET @Script =
          N'DELETE FROM ' + @TableParam
        + N' WHERE LB_PROJET = N''' + REPLACE(@LB_PROJET, N'''', N'''''') + N''''
        + N' AND LB_TABLE_ODS = N''OIT_' + REPLACE(@TableNameSource, N'''', N'''''') + N''';'
        + CHAR(13)
        + N'INSERT INTO ' + @TableParam + CHAR(13)
        + N'    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,' + CHAR(13)
        + N'     LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF, FL_CHARGEMENT,' + CHAR(13)
        + N'     FL_ORDRE_TRI, LB_FILTRE_WHERE)' + CHAR(13)
        + N'VALUES' + CHAR(13)
        + @ValuesScript
        + N';';

    UPDATE ##ParamHistoScript
    SET
        SourceCle = @SourceCle,
        ColonnesCle = @ColonnesCle,
        NbColonnesCle = @NbCle,
        NbLignesParam = @NbLignes,
        InsertScript = @Script,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_param
    INTO @TableNameSource, @ViewNameSource;
END;

CLOSE cur_param;
DEALLOCATE cur_param;
GO


SELECT
    TableNameSource,
    ViewNameSource,
    SourceCle,
    ColonnesCle,
    NbColonnesCle,
    NbLignesParam,
    MessageControle,
    InsertScript
FROM ##ParamHistoScript
ORDER BY TableNameSource;

SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##ParamHistoScript
WHERE ISNULL(NbColonnesCle, 0) = 0
ORDER BY TableNameSource;

