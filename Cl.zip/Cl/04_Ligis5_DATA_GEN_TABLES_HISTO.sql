/* ============================================================================
   GENERATEUR DES TABLES OIT_*_HISTO

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur ODS_Traces.

   Contrat commun avec le generateur OIT/OWT :
   - la vue export_cdc.ZBCP_LIGIS_<TABLE>_V est la reference de structure ;
   - toutes les colonnes de la vue sont reprises dans le meme ordre,
     avec les memes types et la meme nullabilite ;
   - les colonnes d'archivage sont ajoutees en fin de table ;
   - l'unicite d'une trace CDC repose sur :
       LB_LSN_COMMIT_TEC + LB_SEQVAL_TEC + CD_DML_TEC.
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListHisto;
GO

CREATE TABLE ##TableListHisto
(
    TableNameSource  sysname       NOT NULL,
    ViewNameSource   sysname       NOT NULL,
    TableNameHisto   sysname       NOT NULL,
    NbColonnesVue    int           NULL,
    CreateScript     nvarchar(MAX) NULL,
    MessageControle  nvarchar(500) NULL
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource sysname = N'dbo';
DECLARE @SchemaVue    sysname = N'export_cdc';
DECLARE @SchemaHisto  sysname = N'ods';

INSERT INTO ##TableListHisto
(
    TableNameSource,
    ViewNameSource,
    TableNameHisto
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name + N'_HISTO'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (N'dbo_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

DECLARE
    @TableNameSource sysname,
    @ViewNameSource  sysname,
    @TableNameHisto  sysname,
    @ViewObjectId    int,
    @NbColonnesVue   int,
    @ColsVue         nvarchar(MAX),
    @Create           nvarchar(MAX),
    @Message          nvarchar(500);

DECLARE cur_histo CURSOR LOCAL FAST_FORWARD FOR
    SELECT TableNameSource, ViewNameSource, TableNameHisto
    FROM ##TableListHisto
    ORDER BY TableNameSource;

OPEN cur_histo;
FETCH NEXT FROM cur_histo
INTO @TableNameSource, @ViewNameSource, @TableNameHisto;

WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @ViewObjectId = V.object_id
    FROM sys.views AS V
    INNER JOIN sys.schemas AS S
        ON S.schema_id = V.schema_id
    WHERE S.name = @SchemaVue
      AND V.name = @ViewNameSource;

    SET @ColsVue = NULL;
    SET @NbColonnesVue = 0;
    SET @Message = N'OK';

    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        C.name AS ColumnName,
        QUOTENAME(C.name) AS QuotedName,
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE WHEN C.max_length = -1 THEN N'MAX'
                              ELSE CONVERT(nvarchar(10), C.max_length) END + N')'
                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE WHEN C.max_length = -1 THEN N'MAX'
                              ELSE CONVERT(nvarchar(10), C.max_length / 2) END + N')'
                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'(' + CONVERT(nvarchar(10), C.precision)
                       + N',' + CONVERT(nvarchar(10), C.scale) + N')'
                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'(' + CONVERT(nvarchar(10), C.scale) + N')'
                WHEN TY.name = N'float'
                    THEN TY.name + N'(' + CONVERT(nvarchar(10), C.precision) + N')'
                ELSE TY.name
            END,
        NullClause = CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT
        @NbColonnesVue = COUNT(*),
        @ColsVue = STRING_AGG
        (
            CAST(N'        ' + QuotedName + N' ' + TypeDefinition + NullClause AS nvarchar(MAX)),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    IF NOT EXISTS (SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_LSN_COMMIT_TEC')
       OR NOT EXISTS (SELECT 1 FROM #ViewCols WHERE ColumnName = N'LB_SEQVAL_TEC')
       OR NOT EXISTS (SELECT 1 FROM #ViewCols WHERE ColumnName = N'CD_DML_TEC')
    BEGIN
        SET @Message = N'Colonnes techniques de l''index de trace absentes.';
        SET @Create = NULL;
    END
    ELSE
    BEGIN
        SET @Create =
              N'DROP TABLE IF EXISTS ' + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N';'
            + CHAR(13) + CHAR(13)
            + N'CREATE TABLE ' + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N' (' + CHAR(13)
            + @ColsVue + N',' + CHAR(13)
            + N'        [DT_JOUR_TEC] datetime2(3) NULL,' + CHAR(13)
            + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
            + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
            + N'        [ID_TRT_ALI] bigint NULL' + CHAR(13)
            + N');' + CHAR(13)
            + N'CREATE UNIQUE NONCLUSTERED INDEX '
            + QUOTENAME(N'UX_' + @TableNameHisto + N'_TRACE')
            + N' ON ' + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
            + N' ([LB_LSN_COMMIT_TEC], [LB_SEQVAL_TEC], [CD_DML_TEC]);' + CHAR(13)
            + N'CREATE NONCLUSTERED INDEX '
            + QUOTENAME(N'IX_' + @TableNameHisto + N'_JOUR')
            + N' ON ' + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
            + N' ([DT_JOUR_TEC]);' + CHAR(13)
            + N'CREATE NONCLUSTERED INDEX '
            + QUOTENAME(N'IX_' + @TableNameHisto + N'_COMMIT')
            + N' ON ' + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
            + N' ([DT_COMMIT_TEC]);' + CHAR(13);
    END;

    UPDATE ##TableListHisto
    SET NbColonnesVue = @NbColonnesVue,
        CreateScript = @Create,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_histo
    INTO @TableNameSource, @ViewNameSource, @TableNameHisto;
END;

CLOSE cur_histo;
DEALLOCATE cur_histo;
GO

SELECT ScriptComplet =
(
    SELECT CHAR(13) + CreateScript + CHAR(13)
    FROM ##TableListHisto
    WHERE CreateScript IS NOT NULL
    ORDER BY TableNameSource
    FOR XML PATH(N''), TYPE
);

SELECT
    TableNameSource,
    ViewNameSource,
    TableNameHisto,
    NbColonnesVue,
    MessageControle,
    CreateScript
FROM ##TableListHisto
ORDER BY TableNameSource;

SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListHisto
WHERE MessageControle <> N'OK'
ORDER BY TableNameSource;
GO
