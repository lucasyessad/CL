----------------------------------------------------------
-- Mise a jour de la table d Audit
-- Base de donn�es : Migration_ligis
-- Script : Update_Ligis_TEC_AUDIT_CDC.sql
----------------------------------------------------------

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @DT_EXTRACT	DATETIME2(3);
DECLARE @LB_FIN_LSN	BINARY(10);
DECLARE @NO_SEQUENCE	BIGINT;

SET @DT_EXTRACT = SYSDATETIME();
SET @LB_FIN_LSN = sys.fn_cdc_get_max_lsn();

BEGIN TRY

	BEGIN TRANSACTION;

	SELECT
		@NO_SEQUENCE = ISNULL(MAX(NO_SEQUENCE), 0) + 1
	FROM export_cdc.TEC_AUDIT_CDC
	WITH (UPDLOCK, HOLDLOCK);

	UPDATE export_cdc.TEC_AUDIT_CDC
	SET
		LB_DEB_LSN		= LB_FIN_LSN,
		LB_FIN_LSN		= @LB_FIN_LSN,
		DT_EXTRACT		= @DT_EXTRACT,
		NO_SEQUENCE		= @NO_SEQUENCE;

	COMMIT TRANSACTION;

	SELECT
		@DT_EXTRACT		AS DT_EXTRACT,
		@NO_SEQUENCE		AS NO_SEQUENCE,
		@LB_FIN_LSN		AS LB_FIN_LSN;

END TRY
BEGIN CATCH

	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	THROW;

END CATCH;
GO