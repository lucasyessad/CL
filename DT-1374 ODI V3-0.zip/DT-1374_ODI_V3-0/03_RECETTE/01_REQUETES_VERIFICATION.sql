/* ============================================================================
   DT-1374 - Requetes de verification (recette)
   V2.3 - 21/07/2026 - Fenetres par bornes, parametrage grain colonne, audit maison
   Alignees sur la strategie de recette du ticket :
     cas 1 = integration jour par jour ; cas 2 = recalcul d'une date deja
     traitee (verifications anti-doublon).
   Remplacer les valeurs entre <...> avant execution.
   ============================================================================ */

DECLARE @jour DATE = '<AAAA-MM-JJ>';

-- Fenetre de la journee : ] @deb ; @fin ]
DECLARE @fin DATETIME2(3) = (SELECT DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @jour);
DECLARE @deb DATETIME2(3) = (SELECT MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @jour);
SELECT @jour AS jour, @deb AS borne_debut_exclue, @fin AS borne_fin_incluse;

------------------------------------------------------------------------------
-- 0. Supervision globale
------------------------------------------------------------------------------
SELECT * FROM dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = 'DT1374_HISTO_TRACES_FIN_JOURNEE' AND DT_CAL = @jour;
SELECT * FROM dbo.ORT_SUIVI_JOUR_TABLE     WHERE DT_JOUR = @jour ORDER BY ID_PARAM;
SELECT * FROM ods.AUDIT_CHARGEMENT WHERE LB_PROJET = 'INEO_TRACES' AND LB_CHARGEMENT LIKE '%' + CONVERT(varchar(10), @jour, 23) + '%'

------------------------------------------------------------------------------
-- 0bis. Controle du chainage des bornes (attendu : 0 ligne)
--       Les bornes doivent etre strictement croissantes avec les journees.
------------------------------------------------------------------------------
SELECT b1.DT_JOUR, b1.DT_BORNE
FROM dbo.ORT_BORNE_JOURNEE b1
WHERE EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE b0
              WHERE b0.DT_JOUR < b1.DT_JOUR AND b0.DT_BORNE >= b1.DT_BORNE);

------------------------------------------------------------------------------
-- 1. Verification du flag fin de journee (source OIT)
--    Attendu : dans la fenetre, exactement 1 ligne flaguee a 1 par cle
--    fonctionnelle, et cette ligne porte la plus grande valeur d'ordre.
--    (exemple sur ods.OIT_CONTRAT / cle NUM_CONTRAT / ordre DT_COMMIT_TEC)
------------------------------------------------------------------------------
-- a) doublons de flag par cle (attendu : 0 ligne)
SELECT NUM_CONTRAT, COUNT(*) AS nb_flaguees
FROM ods.OIT_CONTRAT
WHERE DT_COMMIT_TEC > @deb AND DT_COMMIT_TEC <= @fin AND FL_FIN_JOURNEE = 1
GROUP BY NUM_CONTRAT
HAVING COUNT(*) > 1;

-- b) cles sans aucune ligne flaguee (attendu : 0 ligne)
SELECT NUM_CONTRAT
FROM ods.OIT_CONTRAT
WHERE DT_COMMIT_TEC > @deb AND DT_COMMIT_TEC <= @fin
GROUP BY NUM_CONTRAT
HAVING MAX(CASE WHEN FL_FIN_JOURNEE = 1 THEN 1 ELSE 0 END) = 0;

-- c) la ligne flaguee est bien la derniere de la fenetre (attendu : 0 ligne)
SELECT s.NUM_CONTRAT
FROM ods.OIT_CONTRAT s
WHERE s.DT_COMMIT_TEC > @deb AND s.DT_COMMIT_TEC <= @fin AND s.FL_FIN_JOURNEE = 1
  AND EXISTS (SELECT 1 FROM ods.OIT_CONTRAT s2
              WHERE s2.NUM_CONTRAT = s.NUM_CONTRAT
                AND s2.DT_COMMIT_TEC > @deb AND s2.DT_COMMIT_TEC <= @fin
                AND s2.DT_COMMIT_TEC > s.DT_COMMIT_TEC);

------------------------------------------------------------------------------
-- 2. Verification de l'alimentation de la cible (OWT/IWT)
------------------------------------------------------------------------------
-- a) nb de lignes inserees pour la journee = nb de lignes flaguees en source
SELECT
  (SELECT COUNT(*) FROM ods.OIT_CONTRAT
   WHERE DT_COMMIT_TEC > @deb AND DT_COMMIT_TEC <= @fin
     AND FL_FIN_JOURNEE = 1)                                        AS nb_flaguees_source,
  (SELECT COUNT(*) FROM dbo.OWT_CONTRAT WHERE DD_VAL = @jour)       AS nb_inserees_cible;

-- b) anti-doublon : 1 seule version courante par cle (attendu : 0 ligne)
SELECT NUM_CONTRAT, COUNT(*) AS nb_versions_courantes
FROM dbo.OWT_CONTRAT
WHERE FL_VER_CRT = 1
GROUP BY NUM_CONTRAT
HAVING COUNT(*) > 1;

-- c) coherence SCD2 : la version courante porte DF_VAL = 2400-01-01 (attendu : 0 ligne)
SELECT *
FROM dbo.OWT_CONTRAT
WHERE FL_VER_CRT = 1 AND DF_VAL <> '2400-01-01';

-- d) coherence SCD2 : pas de version historique "ouverte" (attendu : 0 ligne)
SELECT *
FROM dbo.OWT_CONTRAT
WHERE FL_VER_CRT = 0 AND DF_VAL = '2400-01-01';

-- e) chainage : pour une cle, la version fermee a DF_VAL = DD_VAL de la
--    version suivante (borne exclusive) (attendu : 0 ligne)
SELECT h.NUM_CONTRAT, h.DD_VAL, h.DF_VAL
FROM dbo.OWT_CONTRAT h
WHERE h.FL_VER_CRT = 0
  AND NOT EXISTS (SELECT 1 FROM dbo.OWT_CONTRAT n
                  WHERE n.NUM_CONTRAT = h.NUM_CONTRAT
                    AND n.DD_VAL = h.DF_VAL);

------------------------------------------------------------------------------
-- 3. Test de recalcul (cas 2 de la strategie de recette)
--    Rejouer une date deja calculee :
--        EXEC dbo.ORT_PRC_TRAITEMENT_JOUR @DT_TRACES = @jour, @FORCER = 1;
--    (les bornes sont conservees : memes fenetres, resultats identiques)
--    Puis re-derouler les controles 0bis, 1 et 2 : aucun doublon,
--    memes volumetries qu'avant recalcul.
------------------------------------------------------------------------------

-- Volumetrie de reference a relever AVANT et APRES recalcul :
SELECT COUNT(*) AS nb_total, SUM(CASE WHEN FL_VER_CRT = 1 THEN 1 ELSE 0 END) AS nb_courantes
FROM dbo.OWT_CONTRAT;

------------------------------------------------------------------------------
-- 4. Cas d'exploitation a recetter specifiquement
------------------------------------------------------------------------------
-- a) Quotidien normal (ex : fini a 22h00) : verifier la borne du jour
--    (TYPE_BORNE = 'QUOTIDIEN', ORIGINE_VALEUR = 'AUDIT_CDC' de preference)
SELECT * FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @jour;

--    ... et qu'aucune modification "de nuit" n'a ete perdue : toute trace
--    doit appartenir a exactement une fenetre (attendu : 0 ligne).
--    C'est la preuve que les modifications entre la fin du quotidien
--    (22h30) et 07h45 partent bien dans la journee suivante.
SELECT COUNT(*) AS nb_traces_orphelines
FROM ods.OIT_CONTRAT t
WHERE t.DT_COMMIT_TEC <= (SELECT MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE)
  AND NOT EXISTS (SELECT 1
                  FROM dbo.ORT_BORNE_JOURNEE b
                  WHERE t.DT_COMMIT_TEC <= b.DT_BORNE
                    AND t.DT_COMMIT_TEC > ISNULL((SELECT MAX(b0.DT_BORNE)
                                                  FROM dbo.ORT_BORNE_JOURNEE b0
                                                  WHERE b0.DT_JOUR < b.DT_JOUR), '1900-01-01'));

-- b) Periode MULTI_JOURS (ex : KO vendredi, retabli lundi) : verifier
--    la borne (TYPE_BORNE = 'MULTI_JOURS', DT_JOUR_DEBUT_PERIODE renseigne),
--    que les journees intermediaires sont bien absorbees (TRAITE = 1 sans
--    image propre), et que l'image de la derniere journee couvre toute la
--    fenetre elargie.
SELECT * FROM dbo.ORT_BORNE_JOURNEE WHERE TYPE_BORNE = 'MULTI_JOURS';

SELECT P.DT_CAL, P.TRAITE
FROM dbo.PITCOT_PERIODE_REPRISE P
WHERE P.LB_NOM_SCN_SUN = 'DT1374_HISTO_TRACES_FIN_JOURNEE'
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE B
                  WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))
ORDER BY P.DT_CAL;   -- journees sans borne : TRAITE = 1 attendu apres absorption
