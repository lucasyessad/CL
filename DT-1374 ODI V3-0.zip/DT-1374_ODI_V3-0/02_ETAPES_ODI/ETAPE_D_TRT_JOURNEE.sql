/* ============================================================================
   ETAPE ODI [D] - TRT_JOURNEE  (SQL INLINE, sans procedure stockee)
   Traitement complet d'UNE journee : garde-fou bornes, puis boucle interne
   sur les tables actives du parametrage, et pour chaque table :
      a) FLAG image fin de journee dans ods.OIT_x (fenetre par bornes)
      b) PURGE cible : DELETE DD_VAL = jour (recalcul idempotent)
      c) REOUVERTURE des versions fermees par ce jour
      d) FERMETURE SCD2 des versions courantes concernees
      e) INSERTION des nouvelles versions (hors suppressions CD_CMD_TEC = 1)
      f) CONTROLE anti-doublon (1 seule version courante par cle)
   Suivi dans ORT_SUIVI_JOUR_TABLE (reprise fine), audit ods.AUDIT_CHARGEMENT.
   Une table en erreur ne bloque pas les suivantes ; bilan final : si au
   moins une table KO -> THROW -> l'etape ODI passe KO -> la date reste
   TRAITE = 0 dans PITCOT -> reprise a la relance (seules tables non-OK).
   Comment : procedure ODI, commande sur la cible, SQL Server, schema DWH.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <%=snpRef.getSession("SESS_NO")%>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'INEO_TRACES';
DECLARE @FORCER     BIT           = 0;   -- 1 = retraiter aussi les tables deja OK (rejeu)

DECLARE @DATE_INFINIE DATE = '2400-01-01';
DECLARE @msg NVARCHAR(500), @dt_deb_jour DATETIME = GETDATE();

/* Garde-fou : borne de la journee + borne anterieure obligatoires ------------ */
IF NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES)
   OR NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES)
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
             + N' (borne de la journee et/ou borne anterieure absente).';
    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO JOURNEE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            N'*TOUTES*', NULL, 0, N'KO', @msg, @dt_deb_jour, GETDATE());
    THROW 50011, @msg, 1;
END

/* Fenetre de la journee : ] borne(J-1) ; borne(J) ] -------------------------- */
DECLARE @dt_fin DATETIME2(3) = (SELECT DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES);
DECLARE @dt_deb DATETIME2(3) = (SELECT MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES);

/* Boucle sur les tables actives du parametrage ------------------------------- */
DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200), @src NVARCHAR(300), @tgt NVARCHAR(300),
        @cle_ods NVARCHAR(MAX), @cle_dwh NVARCHAR(MAX), @join_cond NVARCHAR(MAX),
        @cols_dwh NVARCHAR(MAX), @vals_ods NVARCHAR(MAX),
        @col_fenetre NVARCHAR(128), @ordre NVARCHAR(MAX),
        @filtre NVARCHAR(1000), @where_supp NVARCHAR(1000),
        @sql NVARCHAR(MAX), @dt_step DATETIME, @statut NVARCHAR(20),
        @nb_flag INT, @nb_supp INT, @nb_rouv INT, @nb_ferm INT, @nb_ins INT, @nb_doublons INT;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT LB_TABLE_ODS, MIN(LB_TABLE_DWH)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE FL_CLEF = 1 AND FL_CHARGEMENT = 1
    GROUP BY LB_TABLE_ODS
    ORDER BY LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF @FORCER = 0 AND EXISTS (
        SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
        WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods
          AND CD_STATUT IN ('OK','OK_VIDE'))
    BEGIN
        INSERT INTO ods.AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                @tbl_ods, @tbl_dwh, NULL, N'OK',
                N'IGNORE: table deja OK pour cette journee (reprise fine).', GETDATE(), GETDATE());
    END
    ELSE
    BEGIN
        IF EXISTS (SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
                   WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods)
            UPDATE dbo.ORT_SUIVI_JOUR_TABLE
            SET CD_STATUT = 'EN_COURS', DT_DEBUT = GETDATE(), DT_FIN = NULL,
                NB_LIGNE_FLAG = NULL, NB_LIGNE_SUP = NULL, NB_LIGNE_INS = NULL,
                LB_ERREUR = NULL, ID_TRT_ALI = @ID_TRT_ALI, LB_TABLE_DWH = @tbl_dwh
            WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;
        ELSE
            INSERT INTO dbo.ORT_SUIVI_JOUR_TABLE
                (DT_JOUR, LB_TABLE_ODS, LB_TABLE_DWH, CD_STATUT, DT_DEBUT, ID_TRT_ALI)
            VALUES (@DT_TRACES, @tbl_ods, @tbl_dwh, 'EN_COURS', GETDATE(), @ID_TRT_ALI);

        SELECT @nb_flag = 0, @nb_supp = 0, @nb_rouv = 0, @nb_ferm = 0, @nb_ins = 0, @nb_doublons = 0;
        SET @statut = 'OK';

        BEGIN TRY
            /* Lecture du parametrage grain colonne ------------------------ */
            SET @src = CASE WHEN CHARINDEX('.', @tbl_ods) > 0 THEN @tbl_ods ELSE N'ods.' + @tbl_ods END;
            SET @tgt = CASE WHEN CHARINDEX('.', @tbl_dwh) > 0 THEN @tbl_dwh ELSE N'dbo.' + @tbl_dwh END;

            SELECT @cle_ods = NULL, @cle_dwh = NULL, @join_cond = NULL,
                   @cols_dwh = NULL, @vals_ods = NULL, @col_fenetre = NULL,
                   @ordre = NULL, @filtre = NULL;

            SELECT @cle_ods   = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
                   @cle_dwh   = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
                   @join_cond = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS) + N' = T.' + QUOTENAME(LB_CHAMP_DWH), N' AND ')
            FROM dbo.ORT_PARAM_HISTORISATION_TRACES
            WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1
              AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

            SELECT @cols_dwh = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
                   @vals_ods = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
            FROM dbo.ORT_PARAM_HISTORISATION_TRACES
            WHERE LB_TABLE_ODS = @tbl_ods
              AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

            SELECT @ordre = STRING_AGG(QUOTENAME(LB_CHAMP_ODS) + N' DESC', N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
            FROM dbo.ORT_PARAM_HISTORISATION_TRACES
            WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL;

            SELECT TOP (1) @col_fenetre = LB_CHAMP_ODS
            FROM dbo.ORT_PARAM_HISTORISATION_TRACES
            WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
            ORDER BY NO_CHAMP;

            SELECT @filtre = MAX(LB_FILTRE_WHERE)
            FROM dbo.ORT_PARAM_HISTORISATION_TRACES
            WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1;

            IF @cle_ods IS NULL OR @cols_dwh IS NULL OR @col_fenetre IS NULL
            BEGIN
                SET @msg = N'Parametrage incomplet pour ' + @tbl_ods
                         + N' (cle FL_CLEF, mapping colonnes ou FL_ORDRE_TRI manquants).';
                THROW 50032, @msg, 1;
            END

            SET @where_supp = ISNULL(@filtre, N'');

            /* a) FLAG image fin de journee -------------------------------- */
            SET @dt_step = GETDATE();
            SET @sql = N'UPDATE ' + @src + N' SET FL_FIN_JOURNEE = 0' +
                       N' WHERE ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
                       CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';';
            EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3)', @p_deb = @dt_deb, @p_fin = @dt_fin;

            SET @sql = N';WITH cte AS (' +
                       N'  SELECT *, ROW_NUMBER() OVER (PARTITION BY ' + @cle_ods +
                       N'    ORDER BY ' + @ordre + N') AS rn_ort' +
                       N'  FROM ' + @src +
                       N'  WHERE ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
                       CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
                       N') UPDATE cte SET FL_FIN_JOURNEE = 1 WHERE rn_ort = 1;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                 @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_flag OUTPUT;

            INSERT INTO ods.AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO FLAG [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                    @tbl_ods, @tbl_ods, @nb_flag, N'OK', NULL, @dt_step, GETDATE());

            IF @nb_flag = 0
            BEGIN
                /* Source vide : cible non touchee ------------------------- */
                SET @statut = 'OK_VIDE';
                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, 0, N'OK',
                        N'AVERTISSEMENT: aucune trace pour cette journee (BCPIN non charge ou journee sans mouvement).',
                        GETDATE(), GETDATE());
            END
            ELSE
            BEGIN
                /* b) PURGE cible : DELETE DD_VAL = jour ------------------- */
                SET @dt_step = GETDATE();
                SET @sql = N'DELETE FROM ' + @tgt + N' WHERE DD_VAL = @p_dt;' +
                           N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_nb = @nb_supp OUTPUT;

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO PURGE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, @nb_supp, N'OK', NULL, @dt_step, GETDATE());

                /* c) REOUVERTURE des versions fermees par ce jour --------- */
                SET @dt_step = GETDATE();
                SET @sql = N'UPDATE ' + @tgt +
                           N' SET DF_VAL = @p_infini, FL_VER_CRT = 1' +
                           N' WHERE DF_VAL = @p_dt AND FL_VER_CRT = 0;' +
                           N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, N'@p_dt date, @p_infini date, @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_nb = @nb_rouv OUTPUT;

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO REOUVERTURE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, @nb_rouv, N'OK', NULL, @dt_step, GETDATE());

                /* d) FERMETURE SCD2 des versions courantes concernees ----- */
                SET @dt_step = GETDATE();
                SET @sql = N'UPDATE T SET DF_VAL = @p_dt, FL_VER_CRT = 0' +
                           N' FROM ' + @tgt + N' AS T' +
                           N' INNER JOIN (SELECT DISTINCT ' + @cle_ods +
                           N'             FROM ' + @src +
                           N'             WHERE FL_FIN_JOURNEE = 1' +
                           N'               AND ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
                           CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
                           N'            ) AS S ON ' + @join_cond +
                           N' WHERE T.FL_VER_CRT = 1;' +
                           N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, N'@p_dt date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ferm OUTPUT;

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO FERMETURE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, @nb_ferm, N'OK', NULL, @dt_step, GETDATE());

                /* e) INSERTION des nouvelles versions (hors suppressions) - */
                SET @dt_step = GETDATE();
                SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh + N', DD_VAL, DF_VAL, FL_VER_CRT)' +
                           N' SELECT ' + @vals_ods + N', @p_dt, @p_infini, 1' +
                           N' FROM ' + @src + N' AS S' +
                           N' WHERE S.FL_FIN_JOURNEE = 1' +
                           N'   AND ISNULL(S.CD_CMD_TEC, 0) <> 1' +
                           N'   AND S.' + QUOTENAME(@col_fenetre) + N' > @p_deb AND S.' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
                           CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';' +
                           N' SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql,
                     N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                     @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE,
                     @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ins OUTPUT;

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO INSERTION [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, @nb_ins, N'OK', NULL, @dt_step, GETDATE());

                /* f) CONTROLE anti-doublon (cote DWH) --------------------- */
                SET @dt_step = GETDATE();
                SET @sql = N'SELECT @p_nb = COUNT(*) FROM (' +
                           N'  SELECT ' + @cle_dwh +
                           N'  FROM ' + @tgt +
                           N'  WHERE FL_VER_CRT = 1' +
                           N'  GROUP BY ' + @cle_dwh +
                           N'  HAVING COUNT(*) > 1) d;';
                EXEC sp_executesql @sql, N'@p_nb int OUTPUT', @p_nb = @nb_doublons OUTPUT;

                IF @nb_doublons > 0
                BEGIN
                    INSERT INTO ods.AUDIT_CHARGEMENT
                        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                    VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO CTRL DOUBLON [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                            @tbl_ods, @tbl_dwh, @nb_doublons, N'KO',
                            N'Cles fonctionnelles avec plusieurs versions courantes detectees.', @dt_step, GETDATE());
                    SET @msg = N'Controle anti-doublon en echec sur ' + @tgt + N' : ' +
                               CAST(@nb_doublons AS NVARCHAR(20)) + N' cle(s) en double.';
                    THROW 50001, @msg, 1;
                END

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO CTRL DOUBLON [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, 0, N'OK', NULL, @dt_step, GETDATE());
            END

            UPDATE dbo.ORT_SUIVI_JOUR_TABLE
            SET CD_STATUT = @statut, DT_FIN = GETDATE(),
                NB_LIGNE_FLAG = @nb_flag, NB_LIGNE_SUP = @nb_supp, NB_LIGNE_INS = @nb_ins
            WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;
        END TRY
        BEGIN CATCH
            UPDATE dbo.ORT_SUIVI_JOUR_TABLE
            SET CD_STATUT = 'KO', DT_FIN = GETDATE(),
                NB_LIGNE_FLAG = @nb_flag, NB_LIGNE_SUP = @nb_supp, NB_LIGNE_INS = @nb_ins,
                LB_ERREUR = ERROR_MESSAGE()
            WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;

            INSERT INTO ods.AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                    @tbl_ods, @tbl_dwh, 0, N'KO', ERROR_MESSAGE(), GETDATE(), GETDATE());
            /* on continue avec la table suivante */
        END CATCH
    END

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;

/* Bilan de la journee -------------------------------------------------------- */
DECLARE @nb_ok INT, @nb_err INT;

SELECT @nb_ok  = SUM(CASE WHEN CD_STATUT IN ('OK','OK_VIDE') THEN 1 ELSE 0 END),
       @nb_err = SUM(CASE WHEN CD_STATUT = 'KO' THEN 1 ELSE 0 END)
FROM dbo.ORT_SUIVI_JOUR_TABLE
WHERE DT_JOUR = @DT_TRACES;

SET @nb_ok  = ISNULL(@nb_ok, 0);
SET @nb_err = ISNULL(@nb_err, 0);

INSERT INTO ods.AUDIT_CHARGEMENT
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'HISTO JOURNEE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
        N'*TOUTES*', NULL, @nb_ok,
        CASE WHEN @nb_err > 0 THEN N'KO' ELSE N'OK' END,
        CASE WHEN @nb_err > 0
             THEN CAST(@nb_err AS NVARCHAR(10)) + N' table(s) en KO (detail dans ORT_SUIVI_JOUR_TABLE).'
             ELSE NULL END,
        @dt_deb_jour, GETDATE());

IF @nb_err > 0
BEGIN
    SET @msg = N'TRT_JOURNEE : ' + CAST(@nb_err AS NVARCHAR(10)) +
               N' table(s) en KO pour la journee ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N'.';
    THROW 50010, @msg, 1;
END
