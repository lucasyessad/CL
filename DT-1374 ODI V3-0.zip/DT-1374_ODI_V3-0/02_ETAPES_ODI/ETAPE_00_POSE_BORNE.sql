/* ============================================================================
   ETAPE ODI [0] - POSE DE LA BORNE DE FIN DE JOURNEE  (SQL INLINE, sans proc)
   Ou : dans la chaine de RECUPERATION DES TRACES, en fin d'extraction
        (la ou la V4 appelait ps_INEO_lock_traces), pour les deux cas :
        fin du quotidien (heure variable) ET passage force multi-jours.
   Comment : procedure ODI, commande sur la cible, technologie SQL Server,
        schema logique du DWH INEO. Coller tel quel.
   ============================================================================ */
DECLARE @AUDIT_TABLE NVARCHAR(200) = N'cdc.TEC_AUD_CDC';  -- prefixer par la base LIGIS si besoin
DECLARE @AUDIT_COL   NVARCHAR(128) = N'';                 -- << A RENSEIGNER : colonne "derniere datetime extraite"

DECLARE @DT_JOUR     DATE          = NULL;                -- laisser NULL = deduction auto ; ou forcer 'AAAA-MM-JJ'
DECLARE @DT_BORNE    DATETIME2(3)  = NULL;                -- laisser NULL = lecture audit CDC puis defaut V4
DECLARE @TYPE_BORNE  NVARCHAR(15)  = NULL;                -- laisser NULL = detection auto QUOTIDIEN / MULTI_JOURS
DECLARE @ID_TRT_ALI  INT           = <%=snpRef.getSession("SESS_NO")%>;
DECLARE @LB_PROJET   NVARCHAR(50)  = N'INEO_TRACES';

DECLARE @now DATETIME = GETDATE(),
        @dt_deb_step DATETIME = GETDATE(),
        @auj DATE = CAST(GETDATE() AS DATE),
        @h_tp_ouverture TIME(0) = '07:45:00',
        @h_tp_fermeture TIME(0) = '19:00:00',
        @origine_valeur NVARCHAR(20),
        @dt_jour_prec DATE, @dt_jour_attendu DATE, @dt_debut_periode DATE,
        @sql_audit NVARCHAR(MAX), @msg NVARCHAR(500);

/* 1. Valeur de la borne : parametre > audit CDC > defaut V4 ------------------ */
IF @DT_BORNE IS NOT NULL
    SET @origine_valeur = 'AUDIT_CDC';
ELSE IF @AUDIT_COL <> N''
BEGIN
    BEGIN TRY
        -- MIN sur les instances du perimetre actif : la table la moins
        -- avancee garantit la completude de TOUTES les tables.
        SET @sql_audit =
            N'SELECT @p_borne = MIN(a.' + QUOTENAME(@AUDIT_COL) + N')' +
            N' FROM ' + @AUDIT_TABLE + N' AS a' +
            N' WHERE a.LB_INSTANCE IN (' +
            N'   SELECT DISTINCT ''dbo_'' + SUBSTRING(p.LB_TABLE_ODS, 5, 200)' +
            N'   FROM dbo.ORT_PARAM_HISTORISATION_TRACES p' +
            N'   WHERE p.FL_CLEF = 1 AND p.FL_CHARGEMENT = 1' +
            N'     AND p.LB_TABLE_ODS LIKE ''OIT[_]%'')';
        EXEC sp_executesql @sql_audit, N'@p_borne datetime2(3) OUTPUT', @p_borne = @DT_BORNE OUTPUT;
        IF @DT_BORNE IS NOT NULL SET @origine_valeur = 'AUDIT_CDC';
    END TRY
    BEGIN CATCH
        SET @DT_BORNE = NULL;   -- audit inaccessible : bascule sur le defaut
    END CATCH
END

IF @DT_BORNE IS NULL
BEGIN
    SET @origine_valeur = 'DEFAUT';
    IF CAST(@now AS TIME(0)) > @h_tp_ouverture AND CAST(@now AS TIME(0)) < @h_tp_fermeture
        SET @DT_BORNE = CAST(@auj AS DATETIME) + CAST(@h_tp_ouverture AS DATETIME);  -- clamp 07:45
    ELSE
        SET @DT_BORNE = @now;
END

/* 2. Journee close par defaut ------------------------------------------------ */
IF @DT_JOUR IS NULL
BEGIN
    IF CAST(@now AS TIME(0)) >= @h_tp_fermeture
       AND EXISTS (SELECT 1 FROM dbo.PRTCAL WHERE CONVERT(date, DT_CAL, 121) = @auj)
        SET @DT_JOUR = @auj;
    ELSE
        SELECT @DT_JOUR = MAX(CONVERT(date, DT_CAL, 121))
        FROM dbo.PRTCAL
        WHERE CONVERT(date, DT_CAL, 121) < @auj;
END

IF @DT_JOUR IS NULL
BEGIN
    SET @msg = N'POSE BORNE : impossible de determiner la journee close (PRTCAL vide ?).';
    THROW 50020, @msg, 1;
END

/* 3. Detection automatique du type ------------------------------------------- */
SELECT TOP (1) @dt_jour_prec = DT_JOUR
FROM dbo.ORT_BORNE_JOURNEE
WHERE DT_JOUR < @DT_JOUR
ORDER BY DT_JOUR DESC;

IF @dt_jour_prec IS NOT NULL
    SELECT @dt_jour_attendu = MIN(CONVERT(date, DT_CAL, 121))
    FROM dbo.PRTCAL
    WHERE CONVERT(date, DT_CAL, 121) > @dt_jour_prec;

IF @TYPE_BORNE IS NULL
    SET @TYPE_BORNE = CASE WHEN @dt_jour_prec IS NULL THEN 'QUOTIDIEN'
                           WHEN @DT_JOUR = @dt_jour_attendu THEN 'QUOTIDIEN'
                           ELSE 'MULTI_JOURS' END;

IF @TYPE_BORNE = 'MULTI_JOURS'
    SET @dt_debut_periode = @dt_jour_attendu;

/* 4. Controles --------------------------------------------------------------- */
IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
BEGIN
    SET @msg = N'Borne deja posee pour la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
             + N' : remplacement uniquement par intervention manuelle (recalcul J et J+1 requis).';
    THROW 50021, @msg, 1;
END

IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_JOUR AND DT_BORNE >= @DT_BORNE)
   OR EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR > @DT_JOUR AND DT_BORNE <= @DT_BORNE)
BEGIN
    SET @msg = N'Chainage des bornes incoherent : la borne ' + CONVERT(NVARCHAR(19), @DT_BORNE, 120)
             + N' de la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23) + N' chevauche une borne existante.';
    THROW 50022, @msg, 1;
END

/* 5. Pose + audit format maison ---------------------------------------------- */
INSERT INTO dbo.ORT_BORNE_JOURNEE
    (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, DT_JOUR_DEBUT_PERIODE)
VALUES (@DT_JOUR, @DT_BORNE, @TYPE_BORNE, @origine_valeur, @dt_debut_periode);

INSERT INTO ods.AUDIT_CHARGEMENT
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET,
        N'POSE BORNE [' + CONVERT(NVARCHAR(10), @DT_JOUR, 23) + N']',
        N'*BORNE*', N'ORT_BORNE_JOURNEE', 1, N'OK',
        CASE WHEN @origine_valeur = 'DEFAUT'
             THEN N'AVERTISSEMENT: valeur par defaut (type V4) - renseigner @AUDIT_COL ou passer @DT_BORNE. Borne '
                  + CONVERT(NVARCHAR(19), @DT_BORNE, 120) + N' (' + @TYPE_BORNE + N').'
             ELSE N'Borne ' + CONVERT(NVARCHAR(19), @DT_BORNE, 120) + N' (' + @TYPE_BORNE + N', ' + @origine_valeur + N')'
                  + CASE WHEN @dt_debut_periode IS NOT NULL
                         THEN N' - periode depuis le ' + CONVERT(NVARCHAR(10), @dt_debut_periode, 23) ELSE N'' END + N'.'
        END,
        @dt_deb_step, GETDATE());
