SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_CHARGEMENT_FICHIER_ODS
(
    @LB_PROJET     NVARCHAR(50),
    @LB_FICHIER    NVARCHAR(260),
    @LB_REPERTOIRE NVARCHAR(260),
    @ID_TRT_ALI    BIGINT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @delimiteur  NVARCHAR(10),
        @ligne_debut INT,
        @encodage    NVARCHAR(20),
        @chemin      NVARCHAR(520),
        @sql         NVARCHAR(MAX),
        @nb          BIGINT = 0,
        @msg         NVARCHAR(2000);

    IF @ID_TRT_ALI IS NULL
        SET @ID_TRT_ALI = CONVERT(BIGINT, FORMAT(SYSDATETIME(), N'yyyyMMddHHmmss'));

    /* Recherche du flux par correspondance de masque.
       LB_FICHIER peut etre un nom exact (PITOPE_TABLEREF.csv) ou un masque a
       prefixe stable et suffixe variable (PITOPE_TABLEREF_*.csv). Le job
       resout le masque et transmet le nom reel ; on retrouve ici la ligne de
       parametrage en traduisant le * en % pour un LIKE.
       Le plus long masque gagne, pour qu'un nom exact prime sur un masque
       plus general. */
    SELECT TOP (1)
        @table_ods   = LB_TABLE_ODS,
        @ods_complet = QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
        @delimiteur  = LB_DELIMITEUR,
        @ligne_debut = ISNULL(NO_LIGNE_DEBUT, 1),
        @encodage    = LB_ENCODAGE
    FROM dbo.ORT_PARAM_FLUX
    WHERE LB_PROJET  = @LB_PROJET
      AND FL_ACTIF   = 1
      AND CD_FORMAT  = N'CSV'
      AND LB_FICHIER IS NOT NULL
      AND @LB_FICHIER LIKE REPLACE(LB_FICHIER, N'*', N'%')
    ORDER BY LEN(LB_FICHIER) DESC;

    IF @table_ods IS NULL
    BEGIN
        SET @msg = N'Aucun flux parametre pour le fichier ' + @LB_FICHIER
                 + N' (projet ' + @LB_PROJET + N').';
        THROW 56010, @msg, 1;
    END;

    IF @LB_REPERTOIRE IS NULL OR @LB_REPERTOIRE = N''
    BEGIN
        SET @msg = N'Repertoire non transmis par le job : impossible de localiser '
                 + @LB_FICHIER + N'.';
        THROW 56011, @msg, 1;
    END;

    SET @chemin = @LB_REPERTOIRE
                + CASE WHEN RIGHT(@LB_REPERTOIRE, 1) = N'\' THEN N'' ELSE N'\' END
                + @LB_FICHIER;

    BEGIN TRY
        /* Un fichier delimite porte un etat complet : la cible est videe. */
        SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
        EXEC sp_executesql @sql;

        SET @sql =
              N'BULK INSERT ' + @ods_complet                                       + CHAR(13)
            + N'FROM ''' + REPLACE(@chemin, N'''', N'''''') + N''''                + CHAR(13)
            + N'WITH ('                                                            + CHAR(13)
            + N'    FIELDTERMINATOR = ''' + REPLACE(@delimiteur, N'''', N'''''') + N''',' + CHAR(13)
            + N'    ROWTERMINATOR   = ''0x0a'','                                   + CHAR(13)
            + N'    FIRSTROW        = ' + CONVERT(NVARCHAR(10), @ligne_debut) + N',' + CHAR(13)
            + CASE WHEN @encodage IS NULL THEN N''
                   ELSE N'    CODEPAGE        = ''' + @encodage + N''',' + CHAR(13) END
            /* Une seule ligne mal formee fait echouer le chargement : une table
               de reference chargee a moitie serait plus dangereuse qu'une table
               non chargee. */
            + N'    MAXERRORS       = 0,'                                          + CHAR(13)
            + N'    TABLOCK'                                                       + CHAR(13)
            + N');';
        EXEC sp_executesql @sql;

        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, @nb, N'OK', NULL, @dt_debut, SYSDATETIME());
    END TRY
    BEGIN CATCH
        SET @msg = ERROR_MESSAGE();

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, 0, N'KO', @msg, @dt_debut, SYSDATETIME());

        THROW;
    END CATCH;

    SELECT ID_TRT_ALI = @ID_TRT_ALI, TABLE_ODS = @table_ods, NB_LIGNES = @nb;
END;
GO


/* ============================================================================
   PS_CONTROLE_ODS

   Appelee APRES la boucle de chargement.

   Les jobs appellent bcp depuis un batch : SQL Server ne sait donc pas combien
   de lignes ont ete chargees. La procedure le deduit en comparant le contenu
   actuel a la volumetrie deposee par la preparation dans le journal.

   Elle detecte le cas que rien d'autre n'attrape : bcp qui rend 0 sans avoir
   rien ecrit. Elle sort en erreur si un flux est en echec, ce qui arrete le
   job avant le scenario ODI : un ODS incomplet ne produit pas d'image fausse.

   @FL_EXIGER_LIGNES = 0 pour un projet dont un referentiel peut legitimement
   ne pas changer : l'absence de nouvelle ligne devient un avertissement.
   ============================================================================ */
