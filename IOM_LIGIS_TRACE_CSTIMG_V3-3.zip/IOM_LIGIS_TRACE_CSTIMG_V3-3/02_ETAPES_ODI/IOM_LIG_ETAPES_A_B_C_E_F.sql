/* ============================================================================
   ETAPES ODI COURTES DU PACKAGE - pretes a coller
   Scenario de reference : 'IOM_LIGIS_TRACE_CSTIMG' (a adapter)
   ============================================================================ */

/* ----------------------------------------------------------------------------
   [A] PROCEDURE ODI "IOM_LIG_RECUP_DATES" (commande sur la cible, SQL Server)
---------------------------------------------------------------------------- */
DELETE FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'

INSERT INTO <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
SELECT T.DT_CAL,
       (ROW_NUMBER() OVER (ORDER BY T.DT_CAL)) AS SEQ,
       0 AS TRAITE,
       'IOM_LIGIS_TRACE_CSTIMG' AS LB_NOM_SCN_SUN
FROM
(
    SELECT DISTINCT convert(date, DT_CAL, 121) as DT_CAL
    FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PRTCAL
    WHERE DT_CAL > (select convert(date, DA_DEB_DEL_TRT, 121)
                    from <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PWTTRE
                    where LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
      and DT_CAL < (select isnull(DA_FIN_DEL_FOR, convert(date, GETDATE(), 121))
                    from <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PWTTRE
                    where LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
) AS T
ORDER BY SEQ ASC

/* ----------------------------------------------------------------------------
   [B] VARIABLE ODI V_IOM_LIG_DT_TRACES (Alphanumerique, action Rafraichir,
       schema logique MSSQL_DWH). Seules les journees BORNEES sont eligibles.
---------------------------------------------------------------------------- */
SELECT CONVERT(varchar(10), MIN(P.DT_CAL), 23)
FROM dbo.PITCOT_PERIODE_REPRISE P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE B
              WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))

/* ----------------------------------------------------------------------------
   [C] EVALUATION DE LA VARIABLE
       Condition : V_IOM_LIG_DT_TRACES EST NON NULL
         Vrai -> [D] IOM_LIG_TRT_JOURNEE (fichier ETAPE_D_IOM_LIG_TRT_JOURNEE.sql)
         Faux -> [F] fin de boucle
---------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------------
   [E] PROCEDURE ODI "IOM_LIG_FLAG_DATES" (apres [D] OK uniquement)
       "<=" et non "=" : absorbe automatiquement les journees intermediaires
       d'une periode MULTI_JOURS (sans borne, jamais eligibles, mais dont
       les traces sont dans la fenetre elargie). Puis retour vers [B].
---------------------------------------------------------------------------- */
UPDATE <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND DT_CAL <= '#V_IOM_LIG_DT_TRACES'
  AND TRAITE = 0

/* ----------------------------------------------------------------------------
   [F] PROCEDURE ODI "IOM_LIG_MAJ_PWTTRE" (fin de boucle)
       Grace a l'absorption de [E], il ne reste jamais de trou TRAITE = 0
       derriere la derniere journee traitee : le MAX est sur.
---------------------------------------------------------------------------- */
UPDATE <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PWTTRE
SET DA_DEB_DEL_TRT = (SELECT MAX(DT_CAL)
                      FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
                      WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
                        AND TRAITE = 1)
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND EXISTS (SELECT 1
              FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
              WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
                AND TRAITE = 1)

/* ----------------------------------------------------------------------------
   [0 - one-shot MEP] Initialisation PWTTRE + borne initiale
---------------------------------------------------------------------------- */
-- IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE
--                WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
--     INSERT INTO dbo.PWTTRE (LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_FIN_DEL_FOR)
--     VALUES ('IOM_LIGIS_TRACE_CSTIMG', '<AAAA-MM-JJ veille ouvree>', NULL);
--
-- INSERT INTO dbo.ORT_BORNE_JOURNEE (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
-- VALUES ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss.mmm>', 'INIT', 'MANUEL',
--         'Borne initiale - demarrage historisation DT-1374');
