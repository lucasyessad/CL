/* ============================================================================
   ETAPE ODI [A0] - POSE AUTOMATIQUE DES BORNES depuis l'audit CDC de l'ODS
   PREMIERE etape du package (avant [A]).

   Contexte : l'extraction LIGIS et l'alimentation de TEC_AUD_CDC sont faites
   par un traitement EXISTANT (hors perimetre DT-1374) ; le BCPIN ramene la
   vue ZBCP_LIGIS_TEC_AUD_CDC_V dans l'ODS avec les traces. Cette etape
   deduit la borne et la journee close a partir de ces donnees chargees.

   Borne = MIN( COALESCE(DT_FIN_LSN, DT_EXTRACT) ) sur les instances du
   perimetre actif :
     - DT_FIN_LSN = datetime du LB_FIN_LSN, le MEME LSN qui filtre les
       traces exportees (__$start_lsn <= LB_FIN_LSN) -> coherence exacte ;
     - MIN inter-instances : la table la moins avancee garantit la
       completude de TOUTES les tables ;
     - une instance sans datetime (colonnes NULL) BLOQUE la pose
       (avertissement, pas d'erreur) : rien n'est jamais traite sur une
       couverture inconnue.

   Journee close : deduite de la VALEUR de la borne (pas de l'heure
   d'execution) : borne >= 19h00 un jour ouvre -> ce jour ; sinon la
   veille ouvree (PRTCAL). Type QUOTIDIEN / MULTI_JOURS auto (continuite).

   Cette etape ne leve JAMAIS d'erreur "rien de nouveau" : sans nouvelle
   extraction, aucune journee ne devient eligible et le package se termine
   proprement. Seule une configuration invalide (PRTCAL vide) fait KO.

   Comment : procedure ODI, commande sur la cible, SQL Server, schema DWH.
   ============================================================================ */
DECLARE @AUDIT_TABLE NVARCHAR(200) = N'ods.OIT_TEC_AUD_CDC';  -- << nom ODS de la table chargee depuis ZBCP_LIGIS_TEC_AUD_CDC_V
DECLARE @ID_TRT_ALI  INT           = <%=snpRef.getSession("SESS_NO")%>;
DECLARE @LB_PROJET   NVARCHAR(50)  = N'LIGIS';

DECLARE @h_tp_fermeture TIME(0) = '19:00:00',
        @DT_BORNE datetime2(3), @nb_inst_sans_date INT = 0,
        @dt_borne_max datetime2(3), @DT_JOUR DATE,
        @dt_jour_prec DATE, @dt_jour_attendu DATE, @dt_debut_periode DATE,
        @TYPE_BORNE NVARCHAR(15), @sql NVARCHAR(MAX), @msg NVARCHAR(500),
        @dt_deb_step DATETIME = GETDATE();

/* 1. Borne candidate + controle de completude des dates ---------------------- */
SET @sql =
    N'SELECT @p_borne = MIN(COALESCE(a.DT_FIN_LSN, a.DT_EXTRACT)),' +
    N'       @p_nb_null = SUM(CASE WHEN a.DT_FIN_LSN IS NULL AND a.DT_EXTRACT IS NULL THEN 1 ELSE 0 END)' +
    N' FROM ' + @AUDIT_TABLE + N' AS a' +
    N' WHERE a.LB_INSTANCE IN (' +
    N'   SELECT DISTINCT ''dbo_'' + SUBSTRING(p.LB_TABLE_ODS, 5, 200)' +
    N'   FROM dbo.ORT_PARAM_HISTORISATION_TRACES p' +
    N'   WHERE p.FL_CLEF = 1 AND p.FL_CHARGEMENT = 1' +
    N'     AND p.LB_TABLE_ODS LIKE ''OIT[_]%'')';
EXEC sp_executesql @sql,
     N'@p_borne datetime2(3) OUTPUT, @p_nb_null int OUTPUT',
     @p_borne = @DT_BORNE OUTPUT, @p_nb_null = @nb_inst_sans_date OUTPUT;

IF @DT_BORNE IS NULL OR ISNULL(@nb_inst_sans_date, 0) > 0
BEGIN
    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE AUTO', N'*BORNE*', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: pose impossible - audit CDC sans datetime exploitable ('
            + CAST(ISNULL(@nb_inst_sans_date, 0) AS NVARCHAR(10))
            + N' instance(s) avec DT_FIN_LSN et DT_EXTRACT NULL, ou audit vide).'
            + N' Verifier le traitement amont qui alimente TEC_AUD_CDC. Aucune journee eligible.',
            @dt_deb_step, GETDATE());
    RETURN;
END

/* 2. Rien de nouveau depuis la derniere borne ? ------------------------------ */
SELECT @dt_borne_max = MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE;

IF @dt_borne_max IS NULL
BEGIN
    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE AUTO', N'*BORNE*', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: aucune borne initiale (TYPE_BORNE = INIT) - la poser une fois a la MEP.',
            @dt_deb_step, GETDATE());
    RETURN;
END

IF @DT_BORNE <= @dt_borne_max
BEGIN
    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE AUTO', N'*BORNE*', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'IGNORE: aucune nouvelle extraction depuis la derniere borne ('
            + CONVERT(NVARCHAR(23), @dt_borne_max, 121) + N').',
            @dt_deb_step, GETDATE());
    RETURN;
END

/* 3. Journee close deduite de la VALEUR de la borne -------------------------- */
IF CAST(@DT_BORNE AS TIME(0)) >= @h_tp_fermeture
   AND EXISTS (SELECT 1 FROM dbo.PRTCAL
               WHERE CONVERT(date, DT_CAL, 121) = CONVERT(date, @DT_BORNE))
    SET @DT_JOUR = CONVERT(date, @DT_BORNE);   -- quotidien fini avant minuit (ex 22h)
ELSE
    SELECT @DT_JOUR = MAX(CONVERT(date, DT_CAL, 121))
    FROM dbo.PRTCAL
    WHERE CONVERT(date, DT_CAL, 121) < CONVERT(date, @DT_BORNE);  -- nuit apres minuit / matin force

IF @DT_JOUR IS NULL
BEGIN
    SET @msg = N'POSE BORNE AUTO : impossible de determiner la journee close (PRTCAL vide ?).';
    THROW 50020, @msg, 1;
END

IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
BEGIN
    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE AUTO', N'*BORNE*', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
            + N' a deja une borne mais l''audit avance ('
            + CONVERT(NVARCHAR(23), @DT_BORNE, 121)
            + N') : remplacement manuel requis (recalcul J et J+1).',
            @dt_deb_step, GETDATE());
    RETURN;
END

/* 4. Type QUOTIDIEN / MULTI_JOURS (continuite PRTCAL) ------------------------ */
SELECT TOP (1) @dt_jour_prec = DT_JOUR
FROM dbo.ORT_BORNE_JOURNEE
WHERE DT_JOUR < @DT_JOUR
ORDER BY DT_JOUR DESC;

SELECT @dt_jour_attendu = MIN(CONVERT(date, DT_CAL, 121))
FROM dbo.PRTCAL
WHERE CONVERT(date, DT_CAL, 121) > @dt_jour_prec;

SET @TYPE_BORNE = CASE WHEN @DT_JOUR = @dt_jour_attendu THEN 'QUOTIDIEN'
                       ELSE 'MULTI_JOURS' END;

IF @TYPE_BORNE = 'MULTI_JOURS'
    SET @dt_debut_periode = @dt_jour_attendu;

/* 5. Pose + audit ------------------------------------------------------------ */
INSERT INTO dbo.ORT_BORNE_JOURNEE
    (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, DT_JOUR_DEBUT_PERIODE)
VALUES (@DT_JOUR, @DT_BORNE, @TYPE_BORNE, 'AUDIT_CDC', @dt_debut_periode);

INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET,
        N'POSE BORNE [' + CONVERT(NVARCHAR(10), @DT_JOUR, 23) + N']',
        N'*BORNE*', N'ORT_BORNE_JOURNEE', 1, N'OK',
        N'Borne ' + CONVERT(NVARCHAR(23), @DT_BORNE, 121) + N' (' + @TYPE_BORNE + N', AUDIT_CDC - DT_FIN_LSN)'
        + CASE WHEN @dt_debut_periode IS NOT NULL
               THEN N' - periode depuis le ' + CONVERT(NVARCHAR(10), @dt_debut_periode, 23)
               ELSE N'' END + N'.',
        @dt_deb_step, GETDATE());
