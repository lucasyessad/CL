/* ============================================================================
   DT-1374 - Securisation des journees x tables traitees (esprit BUHTRACE_E)
   V2.3 - 21/07/2026 - Vocabulaire maison (CD_STATUT, LB_ERREUR, NB_LIGNE,
   ID_TRT_ALI) ; cle par LB_TABLE_ODS (parametrage grain colonne, plus
   d'ID_PARAM). Une ligne par (journee, table) : reprise fine, les tables
   deja OK d'une journee sont ignorees a la relance (sauf @FORCER = 1).
   CD_STATUT : EN_COURS -> OK / OK_VIDE / KO
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_SUIVI_JOUR_TABLE', 'U') IS NOT NULL
    DROP TABLE dbo.ORT_SUIVI_JOUR_TABLE   -- refonte de format V2.3
GO

CREATE TABLE dbo.ORT_SUIVI_JOUR_TABLE
(
    ID_SUIVI          INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
    DT_JOUR           DATE               NOT NULL,
    LB_TABLE_ODS      NVARCHAR(128)      NOT NULL,
    LB_TABLE_DWH      NVARCHAR(200)      NOT NULL,
    CD_STATUT         NVARCHAR(20)       NOT NULL DEFAULT ('EN_COURS'),
    NB_LIGNE_FLAG     INT                NULL,   -- lignes flaguees fin de journee (OIT)
    NB_LIGNE_SUP      INT                NULL,   -- lignes purgees dans la cible (recalcul)
    NB_LIGNE_INS      INT                NULL,   -- lignes inserees dans la cible
    DT_DEBUT          DATETIME           NULL,
    DT_FIN            DATETIME           NULL,
    LB_ERREUR         NVARCHAR(MAX)      NULL,
    ID_TRT_ALI        INT                NULL,   -- numero de session ODI (SESS_NO)
    CONSTRAINT UQ_ORT_SUIVI_JOUR_TABLE UNIQUE (DT_JOUR, LB_TABLE_ODS),
    CONSTRAINT CK_ORT_SUIVI_CD_STATUT
        CHECK (CD_STATUT IN ('EN_COURS','OK','OK_VIDE','KO'))
);
GO
