/* ============================================================================
   DT-1374 - Table de parametrage de l'historisation des traces
   V2.3 - 21/07/2026 - FORMAT ALIGNE SUR ods.PARAM_CHARGEMENT (grain COLONNE) :
     une ligne par champ (NO_CHAMP), mapping LB_CHAMP_ODS -> LB_CHAMP_DWH
     (les noms peuvent differer, ex TARIF -> MT_TARIF), cle fonctionnelle
     portee par FL_CLEF = 1, type SCD sur la ligne cle, activation de la
     table par FL_CHARGEMENT = 1 sur la ligne cle.

   Colonnes du format maison : LB_PROJET, LB_SOURCE, LB_TABLE_ODS,
   LB_TABLE_DWH, NO_CHAMP, LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF,
   FL_CHARGEMENT.
   Extensions propres a l'historisation des traces :
     - FL_ORDRE_TRI     : 1 = colonne horodatage servant a la fois de borne
                          de fenetre et d'ordre pour "derniere trace"
                          (plusieurs colonnes possibles = criteres de
                          departage, appliques dans l'ordre NO_CHAMP)
     - LB_FILTRE_WHERE  : filtre optionnel sur la source (porte par la
                          ligne cle), ex MEM_TYPE = 'CNT'

   CONVENTIONS DE NOMS TECHNIQUES (fixes, standard maison constate dans
   PARAM_CHARGEMENT) :
     - ODS  : FL_FIN_JOURNEE (flag image fin de journee)
     - DWH  : DD_VAL, DF_VAL, FL_VER_CRT (version courante = 1)
   Ces colonnes techniques peuvent etre declarees en lignes (LB_CHAMP_ODS
   ou LB_CHAMP_DWH a NULL) a titre documentaire, comme dans
   PARAM_CHARGEMENT ; les procedures ne mappent que les lignes ou LES DEUX
   champs sont renseignes.

   Schemas par defaut si non precises dans le nom : ODS -> [ods],
   DWH -> [dbo] (un nom en 2-3 parties reste accepte, ex DWH_EXP.dbo.IWT_X).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PARAM_HISTORISATION_TRACES', 'U') IS NOT NULL
    DROP TABLE dbo.ORT_PARAM_HISTORISATION_TRACES   -- refonte de format V2.3
GO

CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET        NVARCHAR(50)   NOT NULL DEFAULT ('DT1374'),
    LB_SOURCE        NVARCHAR(200)  NULL,             -- source CDC (informatif)
    LB_TABLE_ODS     NVARCHAR(128)  NOT NULL,         -- ex 'OIT_CONTRAT' (schema ods par defaut)
    LB_TABLE_DWH     NVARCHAR(200)  NOT NULL,         -- ex 'OWT_CONTRAT' (schema dbo par defaut)
    NO_CHAMP         INT            NOT NULL,
    LB_CHAMP_ODS     NVARCHAR(128)  NULL,
    LB_CHAMP_DWH     NVARCHAR(128)  NULL,
    LB_SCD           NVARCHAR(30)   NULL,             -- 'TYPE 2' sur la ligne cle (informatif)
    FL_CLEF          BIT            NOT NULL DEFAULT (0),
    FL_CHARGEMENT    BIT            NULL,             -- 1 sur la ligne cle = table active
    FL_ORDRE_TRI     BIT            NOT NULL DEFAULT (0),
    LB_FILTRE_WHERE  NVARCHAR(1000) NULL,
    CONSTRAINT PK_ORT_PARAM_HISTO PRIMARY KEY (LB_TABLE_ODS, NO_CHAMP)
);
GO

/* ----------------------------------------------------------------------------
   Modele d'alimentation (meme esprit que PARAM_CHARGEMENT) - ex OIT_CONTRAT
   L'ordre "derniere ligne modifiee" vient des colonnes techniques des vues
   CDC exportees : DT_COMMIT_TEC (datetime du commit, borne de fenetre) puis
   CD_SEQ_TEC (__$seqval, departage d'un meme commit) -> FL_ORDRE_TRI = 1
   sur ces deux lignes, dans cet ordre (NO_CHAMP).
-----------------------------------------------------------------------------
INSERT INTO dbo.ORT_PARAM_HISTORISATION_TRACES
    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,
     LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF, FL_CHARGEMENT,
     FL_ORDRE_TRI, LB_FILTRE_WHERE)
VALUES
 ('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT', 1,'NUM_CONTRAT','NUM_CONTRAT','TYPE 2',1,1,0,NULL)
-- ordre / fenetre (colonnes TEC des vues CDC exportees) :
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT', 2,'DT_COMMIT_TEC','DT_COMMIT_TEC',NULL,0,NULL,1,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT', 3,'CD_SEQ_TEC','CD_SEQ_TEC',NULL,0,NULL,1,NULL)
-- tracabilite TEC reprise dans OWT via le mapping :
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT', 4,'ID_INSTANCE_TEC','ID_INSTANCE_TEC',NULL,0,NULL,0,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT', 5,'CD_CMD_TEC','CD_CMD_TEC',NULL,0,NULL,0,NULL)
-- colonnes metier :
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',10,'CD_ETAT','CD_ETAT_CONTRAT',NULL,0,NULL,0,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',11,'LIBELLE','LB_CONTRAT',NULL,0,NULL,0,NULL)
-- colonnes techniques (documentaires, non mappees par les procedures) :
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',90,'FL_FIN_JOURNEE',NULL,NULL,0,NULL,0,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',91,NULL,'DD_VAL',NULL,0,NULL,0,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',92,NULL,'DF_VAL',NULL,0,NULL,0,NULL)
,('DT1374','CDC LIGIS','OIT_CONTRAT','OWT_CONTRAT',93,NULL,'FL_VER_CRT',NULL,0,NULL,0,NULL);
---------------------------------------------------------------------------- */
GO
