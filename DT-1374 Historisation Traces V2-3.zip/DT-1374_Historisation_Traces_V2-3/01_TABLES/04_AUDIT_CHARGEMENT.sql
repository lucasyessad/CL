/* ============================================================================
   DT-1374 - Table d'audit au standard maison
   V2.3 - 21/07/2026
   Structure IDENTIQUE a [ods].[AUDIT_CHARGEMENT] du projet CL_ESTIM
   (cf. PS_CHARGEMENT_CSV_ODS / PS_CHARGEMENT_ODS_DWH) :
     ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
     NB_LIGNE, CD_STATUT (OK/KO), LB_ERREUR, DT_DEBUT, DT_FIN
   Creee dans le schema ods du DWH INEO si elle n'existe pas deja ; si une
   table AUDIT_CHARGEMENT du meme framework existe deja, ce script ne la
   modifie pas et les procedures ORT ecrivent dedans (colonnes explicites).

   Conventions d'usage pour DT-1374 :
     - LB_PROJET     = 'INEO_TRACES' (parametrable via @LB_PROJET des procs)
     - LB_CHARGEMENT = etape + journee, ex :
                       'HISTO FLAG [2026-07-18]', 'HISTO INSERTION [2026-07-18]',
                       'POSE BORNE [2026-07-18]'
     - CD_STATUT     = 'OK' / 'KO' uniquement (standard maison) ; les
                       avertissements sont en 'OK' avec LB_ERREUR renseigne
                       ('AVERTISSEMENT: ...')
     - ID_TRT_ALI    = numero de session ODI (SESS_NO), comme CL_ESTIM
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF SCHEMA_ID('ods') IS NULL
    EXEC('CREATE SCHEMA ods');
GO

IF OBJECT_ID('ods.AUDIT_CHARGEMENT', 'U') IS NULL
BEGIN
    CREATE TABLE ods.AUDIT_CHARGEMENT
    (
        ID_TRT_ALI     INT             NULL,
        LB_PROJET      NVARCHAR(50)    NULL,
        LB_CHARGEMENT  NVARCHAR(100)   NULL,
        LB_SOURCE      NVARCHAR(200)   NULL,
        LB_CIBLE       NVARCHAR(200)   NULL,
        NB_LIGNE       INT             NULL,
        CD_STATUT      NVARCHAR(10)    NULL,
        LB_ERREUR      NVARCHAR(MAX)   NULL,
        DT_DEBUT       DATETIME        NULL,
        DT_FIN         DATETIME        NULL
    );

    CREATE INDEX IX_AUDIT_CHARGEMENT_PROJET_DT
        ON ods.AUDIT_CHARGEMENT (LB_PROJET, DT_DEBUT);
END
GO
