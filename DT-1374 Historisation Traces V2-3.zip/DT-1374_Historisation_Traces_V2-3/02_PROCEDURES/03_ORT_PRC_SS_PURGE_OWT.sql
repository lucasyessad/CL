/* ============================================================================
   DT-1374 - Sous-procedure : PURGE des donnees de la journee dans la cible
   V2.3 - 21/07/2026 - Parametrage GRAIN COLONNE ; colonnes techniques fixes
   (standard maison) : DD_VAL, DF_VAL, FL_VER_CRT.
     1. suppression des versions inserees avec DD_VAL = jour (recalcul)
     2. reouverture des versions fermees par ce jour
        (DF_VAL = jour et FL_VER_CRT = 0 -> DF_VAL = 2400-01-01, flag 1)
   Audit au format maison + ID_TRT_ALI propage.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_PURGE_OWT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_PURGE_OWT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_PURGE_OWT
    @DT_TRACES      DATE,
    @LB_TABLE_ODS   NVARCHAR(128),
    @NB_SUPPRIMEES  INT OUTPUT,
    @ID_TRT_ALI     INT           = NULL,
    @LB_PROJET      NVARCHAR(50)  = N'INEO_TRACES'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DATE_INFINIE DATE = '2400-01-01';

    DECLARE @tbl_dwh NVARCHAR(200), @tgt NVARCHAR(300),
            @sql NVARCHAR(MAX), @nb_rouvertes INT = 0, @msg NVARCHAR(500),
            @dt_deb_step DATETIME = GETDATE();

    SELECT TOP (1) @tbl_dwh = LB_TABLE_DWH
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1;

    IF @tbl_dwh IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_PURGE_OWT : table ' + @LB_TABLE_ODS + N' introuvable dans le parametrage (ligne cle).';
        THROW 50033, @msg, 1;
    END

    SET @tgt = CASE WHEN CHARINDEX('.', @tbl_dwh) > 0 THEN @tbl_dwh ELSE N'dbo.' + @tbl_dwh END;
    SET @NB_SUPPRIMEES = 0;

    -- 1. Suppression des versions de la journee (si un passage precedent existe)
    SET @sql = N'DELETE FROM ' + @tgt + N' WHERE DD_VAL = @p_dt;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_nb = @NB_SUPPRIMEES OUTPUT;

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO PURGE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @tbl_dwh, @NB_SUPPRIMEES, N'OK', NULL, @dt_deb_step, GETDATE());

    -- 2. Reouverture des versions fermees par cette journee
    SET @dt_deb_step = GETDATE();
    SET @sql = N'UPDATE ' + @tgt +
               N' SET DF_VAL = @p_infini, FL_VER_CRT = 1' +
               N' WHERE DF_VAL = @p_dt AND FL_VER_CRT = 0;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_infini date, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_nb = @nb_rouvertes OUTPUT;

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO REOUVERTURE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @tbl_dwh, @nb_rouvertes, N'OK', NULL, @dt_deb_step, GETDATE());
END
GO
