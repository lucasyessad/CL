/* ============================================================================
   DT-1374 - Sous-procedure : CONSTRUCTION DE L'HISTORIQUE (SCD2) dans la cible
   V2.3 - 21/07/2026 - Parametrage GRAIN COLONNE (format PARAM_CHARGEMENT) :
     - liste INSERT construite depuis le mapping LB_CHAMP_ODS -> LB_CHAMP_DWH
       (les noms peuvent differer entre ODS et DWH)
     - jointure de fermeture sur les lignes FL_CLEF = 1
     - colonnes techniques fixes (standard maison) : DD_VAL, DF_VAL, FL_VER_CRT
   Fenetre(J) = ] borne(J-1) ; borne(J) ] (ORT_BORNE_JOURNEE).
     1. fermeture des versions courantes concernees (DF_VAL = jour, FL_VER_CRT = 0)
     2. insertion des nouvelles versions (DD_VAL = jour, DF_VAL = 2400-01-01, flag 1)
     3. controle anti-doublon : une seule version courante par cle (sinon THROW)
   Audit au format maison + ID_TRT_ALI propage.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_HISTORISATION_OWT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_HISTORISATION_OWT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_HISTORISATION_OWT
    @DT_TRACES     DATE,
    @LB_TABLE_ODS  NVARCHAR(128),
    @NB_INSEREES   INT OUTPUT,
    @ID_TRT_ALI    INT           = NULL,
    @LB_PROJET     NVARCHAR(50)  = N'INEO_TRACES'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DATE_INFINIE DATE = '2400-01-01';

    DECLARE @tbl_dwh NVARCHAR(200), @src NVARCHAR(300), @tgt NVARCHAR(300),
            @cle_ods NVARCHAR(MAX), @cle_dwh NVARCHAR(MAX), @join_cond NVARCHAR(MAX),
            @cols_dwh NVARCHAR(MAX), @vals_ods NVARCHAR(MAX),
            @col_fenetre NVARCHAR(128), @filtre NVARCHAR(1000), @where_supp NVARCHAR(1000),
            @sql NVARCHAR(MAX), @nb_fermees INT = 0, @nb_doublons INT = 0,
            @msg NVARCHAR(500), @dt_deb_step DATETIME = GETDATE();

    ------------------------------------------------------------------
    -- Lecture du parametrage grain colonne
    ------------------------------------------------------------------
    SELECT TOP (1) @tbl_dwh = LB_TABLE_DWH
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1;

    IF @tbl_dwh IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : table ' + @LB_TABLE_ODS + N' introuvable dans le parametrage (ligne cle).';
        THROW 50033, @msg, 1;
    END

    SET @src = CASE WHEN CHARINDEX('.', @LB_TABLE_ODS) > 0 THEN @LB_TABLE_ODS ELSE N'ods.' + @LB_TABLE_ODS END;
    SET @tgt = CASE WHEN CHARINDEX('.', @tbl_dwh)      > 0 THEN @tbl_dwh      ELSE N'dbo.' + @tbl_dwh      END;

    SELECT @cle_ods   = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
           @cle_dwh   = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
           @join_cond = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS) + N' = T.' + QUOTENAME(LB_CHAMP_DWH), N' AND ')
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1
      AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

    SELECT @cols_dwh = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
           @vals_ods = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS
      AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

    SELECT TOP (1) @col_fenetre = LB_CHAMP_ODS
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
    ORDER BY NO_CHAMP;

    SELECT @filtre = MAX(LB_FILTRE_WHERE)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1;

    IF @cle_ods IS NULL OR @cols_dwh IS NULL OR @col_fenetre IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : parametrage incomplet pour ' + @LB_TABLE_ODS
                 + N' (cle, mapping colonnes ou colonne FL_ORDRE_TRI manquants).';
        THROW 50032, @msg, 1;
    END

    ------------------------------------------------------------------
    -- Fenetre de la journee : ] borne(J-1) ; borne(J) ]
    ------------------------------------------------------------------
    DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3);

    SELECT @dt_fin = DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES;
    IF @dt_fin IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : borne non posee pour la journee '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N'.';
        THROW 50030, @msg, 1;
    END

    SELECT @dt_deb = MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES;
    IF @dt_deb IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : aucune borne anterieure au '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N' : poser la borne initiale.';
        THROW 50031, @msg, 1;
    END

    SET @where_supp = ISNULL(@filtre, N'');
    SET @NB_INSEREES = 0;

    ------------------------------------------------------------------
    -- 1. Fermeture des versions courantes concernees
    ------------------------------------------------------------------
    SET @sql = N'UPDATE T SET DF_VAL = @p_dt, FL_VER_CRT = 0' +
               N' FROM ' + @tgt + N' AS T' +
               N' INNER JOIN (SELECT DISTINCT ' + @cle_ods +
               N'             FROM ' + @src +
               N'             WHERE FL_FIN_JOURNEE = 1' +
               N'               AND ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
               N'            ) AS S ON ' + @join_cond +
               N' WHERE T.FL_VER_CRT = 1;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_fermees OUTPUT;

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO FERMETURE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @tbl_dwh, @nb_fermees, N'OK', NULL, @dt_deb_step, GETDATE());

    ------------------------------------------------------------------
    -- 2. Insertion des nouvelles versions courantes
    --    REGLE SUPPRESSION : si l'image fin de journee d'une cle est une
    --    suppression LIGIS (CD_CMD_TEC = 1), la version courante a ete
    --    fermee a l'etape 1 et AUCUNE nouvelle version n'est inseree :
    --    la cle n'a plus de version courante, ce qui reflete l'etat reel.
    ------------------------------------------------------------------
    SET @dt_deb_step = GETDATE();
    SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh + N', DD_VAL, DF_VAL, FL_VER_CRT)' +
               N' SELECT ' + @vals_ods + N', @p_dt, @p_infini, 1' +
               N' FROM ' + @src + N' AS S' +
               N' WHERE S.FL_FIN_JOURNEE = 1' +
               N'   AND ISNULL(S.CD_CMD_TEC, 0) <> 1' +
               N'   AND S.' + QUOTENAME(@col_fenetre) + N' > @p_deb AND S.' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql,
         N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE,
         @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @NB_INSEREES OUTPUT;

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO INSERTION [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @tbl_dwh, @NB_INSEREES, N'OK', NULL, @dt_deb_step, GETDATE());

    ------------------------------------------------------------------
    -- 3. Controle anti-doublon : 1 seule version courante par cle (cote DWH)
    ------------------------------------------------------------------
    SET @dt_deb_step = GETDATE();
    SET @sql = N'SELECT @p_nb = COUNT(*) FROM (' +
               N'  SELECT ' + @cle_dwh +
               N'  FROM ' + @tgt +
               N'  WHERE FL_VER_CRT = 1' +
               N'  GROUP BY ' + @cle_dwh +
               N'  HAVING COUNT(*) > 1' +
               N') d;';
    EXEC sp_executesql @sql, N'@p_nb int OUTPUT', @p_nb = @nb_doublons OUTPUT;

    IF @nb_doublons > 0
    BEGIN
        INSERT INTO ods.AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'HISTO CTRL DOUBLON [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                @LB_TABLE_ODS, @tbl_dwh, @nb_doublons, N'KO',
                N'Cles fonctionnelles avec plusieurs versions courantes detectees.',
                @dt_deb_step, GETDATE());

        SET @msg = N'Controle anti-doublon en echec sur ' + @tgt + N' : ' +
                   CAST(@nb_doublons AS NVARCHAR(20)) + N' cle(s) avec plusieurs versions courantes.';
        THROW 50001, @msg, 1;
    END

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO CTRL DOUBLON [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @tbl_dwh, 0, N'OK', NULL, @dt_deb_step, GETDATE());
END
GO
