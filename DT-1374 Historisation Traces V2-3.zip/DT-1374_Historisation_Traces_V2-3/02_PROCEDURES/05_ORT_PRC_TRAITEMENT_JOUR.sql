/* ============================================================================
   DT-1374 - Procedure maitre : traitement complet d'UNE journee
   V2.3 - 21/07/2026 - Parametrage GRAIN COLONNE + audit maison + ID_TRT_ALI.
   Appel dans la boucle ODI (interieur de la boucle jour) :
       EXEC dbo.ORT_PRC_TRAITEMENT_JOUR
            @DT_TRACES = '#V_DT_TRACES',
            @ID_TRT_ALI = <numero de session ODI>
   Boucle interne sur les tables actives du parametrage (lignes cles
   FL_CLEF = 1 et FL_CHARGEMENT = 1), et enchaine par table :
       1. ORT_PRC_SS_FLAG_OIT            (image fin de journee dans OIT)
       2. ORT_PRC_SS_PURGE_OWT           (suppression jour + reouverture)
       3. ORT_PRC_SS_HISTORISATION_OWT   (fermeture + insertion + controle)
   - garde-fou bornes en entree (journee non bornee = non traitable)
   - reprise fine via ORT_SUIVI_JOUR_TABLE (tables deja OK ignorees sauf @FORCER)
   - source vide -> OK_VIDE (cible non touchee)
   - une erreur sur une table ne bloque pas les suivantes ; bilan en fin de
     journee, et THROW vers ODI si au moins une table en KO (la date reste
     TRAITE = 0 dans PITCOT -> reprise a la relance, standard maison)
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_TRAITEMENT_JOUR', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_TRAITEMENT_JOUR
GO

CREATE PROCEDURE dbo.ORT_PRC_TRAITEMENT_JOUR
    @DT_TRACES   DATE,
    @FORCER      BIT           = 0,
    @ID_TRT_ALI  INT           = NULL,               -- numero de session ODI (SESS_NO)
    @LB_PROJET   NVARCHAR(50)  = N'INEO_TRACES'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @msg NVARCHAR(500), @dt_deb_jour DATETIME = GETDATE();

    IF @DT_TRACES IS NULL
    BEGIN
        RAISERROR('ORT_PRC_TRAITEMENT_JOUR : @DT_TRACES est obligatoire.', 16, 1);
        RETURN;
    END

    ------------------------------------------------------------------
    -- Garde-fou : borne de la journee + borne anterieure obligatoires
    ------------------------------------------------------------------
    IF NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES)
       OR NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES)
    BEGIN
        SET @msg = N'Fenetre non definie pour le ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
                 + N' (borne de la journee et/ou borne anterieure absente). '
                 + N'Journee non traitable : extraction non close ou borne initiale manquante.';

        INSERT INTO ods.AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'HISTO JOURNEE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                N'*TOUTES*', NULL, 0, N'KO', @msg, @dt_deb_jour, GETDATE());

        THROW 50011, @msg, 1;
    END

    ------------------------------------------------------------------
    -- Boucle sur les tables actives du parametrage (lignes cles)
    ------------------------------------------------------------------
    DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200),
            @nb_flag INT, @nb_supp INT, @nb_ins INT,
            @statut_table NVARCHAR(20);

    DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
        SELECT LB_TABLE_ODS, MIN(LB_TABLE_DWH)
        FROM dbo.ORT_PARAM_HISTORISATION_TRACES
        WHERE FL_CLEF = 1 AND FL_CHARGEMENT = 1
        GROUP BY LB_TABLE_ODS
        ORDER BY LB_TABLE_ODS;

    OPEN cur_tables;
    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        --------------------------------------------------------------
        -- Reprise fine : table deja OK pour cette journee -> ignoree
        --------------------------------------------------------------
        IF @FORCER = 0 AND EXISTS (
            SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
            WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods
              AND CD_STATUT IN ('OK','OK_VIDE'))
        BEGIN
            INSERT INTO ods.AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET,
                    N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                    @tbl_ods, @tbl_dwh, NULL, N'OK',
                    N'IGNORE: table deja OK pour cette journee (reprise fine).', GETDATE(), GETDATE());
        END
        ELSE
        BEGIN
            -- Ouverture / reinitialisation de la ligne de suivi
            IF EXISTS (SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
                       WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods)
                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET CD_STATUT = 'EN_COURS', DT_DEBUT = GETDATE(), DT_FIN = NULL,
                    NB_LIGNE_FLAG = NULL, NB_LIGNE_SUP = NULL, NB_LIGNE_INS = NULL,
                    LB_ERREUR = NULL, ID_TRT_ALI = @ID_TRT_ALI, LB_TABLE_DWH = @tbl_dwh
                WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;
            ELSE
                INSERT INTO dbo.ORT_SUIVI_JOUR_TABLE
                    (DT_JOUR, LB_TABLE_ODS, LB_TABLE_DWH, CD_STATUT, DT_DEBUT, ID_TRT_ALI)
                VALUES (@DT_TRACES, @tbl_ods, @tbl_dwh, 'EN_COURS', GETDATE(), @ID_TRT_ALI);

            SET @nb_flag = 0; SET @nb_supp = 0; SET @nb_ins = 0;
            SET @statut_table = 'OK';

            BEGIN TRY
                -- 1. Flag de l'image fin de journee dans la source OIT
                EXEC dbo.ORT_PRC_SS_FLAG_OIT
                     @DT_TRACES = @DT_TRACES, @LB_TABLE_ODS = @tbl_ods,
                     @NB_FLAGUEES = @nb_flag OUTPUT,
                     @ID_TRT_ALI = @ID_TRT_ALI, @LB_PROJET = @LB_PROJET;

                IF @nb_flag = 0
                BEGIN
                    -- Source vide : la cible n'est pas touchee (un passage
                    -- precedent valide reste intact)
                    SET @statut_table = 'OK_VIDE';
                    INSERT INTO ods.AUDIT_CHARGEMENT
                        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                    VALUES (@ID_TRT_ALI, @LB_PROJET,
                            N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                            @tbl_ods, @tbl_dwh, 0, N'OK',
                            N'AVERTISSEMENT: aucune trace pour cette journee (BCPIN non charge ou journee sans mouvement).',
                            GETDATE(), GETDATE());
                END
                ELSE
                BEGIN
                    -- 2. Purge des donnees de la journee dans la cible (si existantes)
                    EXEC dbo.ORT_PRC_SS_PURGE_OWT
                         @DT_TRACES = @DT_TRACES, @LB_TABLE_ODS = @tbl_ods,
                         @NB_SUPPRIMEES = @nb_supp OUTPUT,
                         @ID_TRT_ALI = @ID_TRT_ALI, @LB_PROJET = @LB_PROJET;

                    -- 3. Construction de l'historique SCD2
                    EXEC dbo.ORT_PRC_SS_HISTORISATION_OWT
                         @DT_TRACES = @DT_TRACES, @LB_TABLE_ODS = @tbl_ods,
                         @NB_INSEREES = @nb_ins OUTPUT,
                         @ID_TRT_ALI = @ID_TRT_ALI, @LB_PROJET = @LB_PROJET;
                END

                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET CD_STATUT = @statut_table, DT_FIN = GETDATE(),
                    NB_LIGNE_FLAG = @nb_flag, NB_LIGNE_SUP = @nb_supp, NB_LIGNE_INS = @nb_ins
                WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;
            END TRY
            BEGIN CATCH
                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET CD_STATUT = 'KO', DT_FIN = GETDATE(),
                    NB_LIGNE_FLAG = @nb_flag, NB_LIGNE_SUP = @nb_supp, NB_LIGNE_INS = @nb_ins,
                    LB_ERREUR = ERROR_MESSAGE()
                WHERE DT_JOUR = @DT_TRACES AND LB_TABLE_ODS = @tbl_ods;

                INSERT INTO ods.AUDIT_CHARGEMENT
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET,
                        N'HISTO TABLE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
                        @tbl_ods, @tbl_dwh, 0, N'KO', ERROR_MESSAGE(), GETDATE(), GETDATE());
                -- on continue avec la table suivante : bilan en fin de journee
            END CATCH
        END

        FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
    END

    CLOSE cur_tables;
    DEALLOCATE cur_tables;

    ------------------------------------------------------------------
    -- Bilan de la journee : audit recapitulatif + remontee d'erreur a ODI
    ------------------------------------------------------------------
    DECLARE @nb_ok INT, @nb_err INT;

    SELECT @nb_ok  = SUM(CASE WHEN CD_STATUT IN ('OK','OK_VIDE') THEN 1 ELSE 0 END),
           @nb_err = SUM(CASE WHEN CD_STATUT = 'KO' THEN 1 ELSE 0 END)
    FROM dbo.ORT_SUIVI_JOUR_TABLE
    WHERE DT_JOUR = @DT_TRACES;

    SET @nb_ok  = ISNULL(@nb_ok, 0);
    SET @nb_err = ISNULL(@nb_err, 0);

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO JOURNEE [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            N'*TOUTES*', NULL, @nb_ok,
            CASE WHEN @nb_err > 0 THEN N'KO' ELSE N'OK' END,
            CASE WHEN @nb_err > 0
                 THEN CAST(@nb_err AS NVARCHAR(10)) + N' table(s) en KO (detail dans ORT_SUIVI_JOUR_TABLE).'
                 ELSE NULL END,
            @dt_deb_jour, GETDATE());

    IF @nb_err > 0
    BEGIN
        -- L'etape ODI passe KO -> la date reste TRAITE = 0 dans PITCOT ->
        -- reprise automatique a la relance du job (seules les tables non-OK
        -- seront retraitees).
        SET @msg = N'ORT_PRC_TRAITEMENT_JOUR : ' + CAST(@nb_err AS NVARCHAR(10)) +
                   N' table(s) en KO pour la journee ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) +
                   N'. Voir ORT_SUIVI_JOUR_TABLE / ods.AUDIT_CHARGEMENT.';
        THROW 50010, @msg, 1;
    END
END
GO
