/* ============================================================================
   DT-1374 - Pose de la borne de fin de journee
   V2.4 - 21/07/2026 - Borne cablee sur la table d'audit CDC :
   ordre de priorite pour la valeur de la borne :
     1. @DT_BORNE passe en parametre (valeur audit fournie par la chaine)
     2. lecture directe de [cdc].[TEC_AUD_CDC] : MIN de la derniere datetime
        extraite sur les INSTANCES DU PERIMETRE (LB_INSTANCE = 'dbo_' +
        table LIGIS, deduites du parametrage OIT_xxx actif).
        MIN et non MAX : la table la moins avancee determine jusqu'ou
        TOUTES les tables sont completes -> aucune journee ne peut etre
        declaree close avec une table en retard.
     3. a defaut : calcul type V4 (clamp 07:45 pendant les TP), avec
        avertissement au log.
   Configuration en tete de procedure : @AUDIT_TABLE (avec base si l'audit
   est dans la base LIGIS) et @AUDIT_COL (nom exact de la colonne
   "derniere datetime extraite" - A RENSEIGNER).
   Le reste (journee close par defaut, detection QUOTIDIEN/MULTI_JOURS,
   controles de chainage, audit maison, ID_TRT_ALI) est inchange (V2.3).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_POSER_BORNE_JOURNEE', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
GO

CREATE PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
    @DT_JOUR      DATE           = NULL,
    @DT_BORNE     DATETIME2(3)   = NULL,
    @TYPE_BORNE   NVARCHAR(15)   = NULL,
    @COMMENTAIRE  NVARCHAR(500)  = NULL,
    @FORCER       BIT            = 0,
    @ID_TRT_ALI   INT            = NULL,               -- numero de session ODI (SESS_NO)
    @LB_PROJET    NVARCHAR(50)   = N'INEO_TRACES'
AS
BEGIN
    SET NOCOUNT ON;

    ------------------------------------------------------------------
    -- CONFIGURATION lecture directe de l'audit CDC (adapter par env.)
    ------------------------------------------------------------------
    DECLARE @AUDIT_TABLE NVARCHAR(200) = N'cdc.TEC_AUD_CDC';  -- prefixer par la base si necessaire, ex N'DEV_LIGIS_SAHA.cdc.TEC_AUD_CDC'
    DECLARE @AUDIT_COL   NVARCHAR(128) = N'';                 -- << A RENSEIGNER : colonne "derniere datetime extraite"

    DECLARE @now DATETIME = GETDATE(),
            @dt_deb_step DATETIME = GETDATE(),
            @auj DATE     = CAST(GETDATE() AS DATE),
            @h_tp_ouverture TIME(0) = '07:45:00',
            @h_tp_fermeture TIME(0) = '19:00:00',
            @origine_valeur NVARCHAR(20),
            @dt_jour_prec DATE, @dt_borne_prec DATETIME2(3),
            @dt_jour_attendu DATE, @dt_debut_periode DATE,
            @sql_audit NVARCHAR(MAX), @msg NVARCHAR(500);

    ------------------------------------------------------------------
    -- 1. Valeur de la borne : parametre > audit CDC > defaut V4
    ------------------------------------------------------------------
    IF @DT_BORNE IS NOT NULL
        SET @origine_valeur = 'AUDIT_CDC';
    ELSE IF @AUDIT_COL <> N''
    BEGIN
        BEGIN TRY
            -- MIN sur les instances du perimetre actif : la table la moins
            -- avancee garantit la completude de TOUTES les tables.
            SET @sql_audit =
                N'SELECT @p_borne = MIN(a.' + QUOTENAME(@AUDIT_COL) + N')' +
                N' FROM ' + @AUDIT_TABLE + N' AS a' +
                N' WHERE a.LB_INSTANCE IN (' +
                N'   SELECT DISTINCT ''dbo_'' + SUBSTRING(p.LB_TABLE_ODS, 5, 200)' +
                N'   FROM dbo.ORT_PARAM_HISTORISATION_TRACES p' +
                N'   WHERE p.FL_CLEF = 1 AND p.FL_CHARGEMENT = 1' +
                N'     AND p.LB_TABLE_ODS LIKE ''OIT[_]%'')';
            EXEC sp_executesql @sql_audit, N'@p_borne datetime2(3) OUTPUT', @p_borne = @DT_BORNE OUTPUT;

            IF @DT_BORNE IS NOT NULL
                SET @origine_valeur = 'AUDIT_CDC';
        END TRY
        BEGIN CATCH
            SET @DT_BORNE = NULL;   -- audit inaccessible : bascule sur le defaut
        END CATCH
    END

    IF @DT_BORNE IS NULL
    BEGIN
        SET @origine_valeur = 'DEFAUT';
        IF CAST(@now AS TIME(0)) > @h_tp_ouverture AND CAST(@now AS TIME(0)) < @h_tp_fermeture
            SET @DT_BORNE = CAST(@auj AS DATETIME) + CAST(@h_tp_ouverture AS DATETIME);  -- clamp 07:45
        ELSE
            SET @DT_BORNE = @now;
    END

    ------------------------------------------------------------------
    -- 2. Journee close par defaut
    ------------------------------------------------------------------
    IF @DT_JOUR IS NULL
    BEGIN
        IF CAST(@now AS TIME(0)) >= @h_tp_fermeture
           AND EXISTS (SELECT 1 FROM dbo.PRTCAL WHERE CONVERT(date, DT_CAL, 121) = @auj)
            SET @DT_JOUR = @auj;
        ELSE
            SELECT @DT_JOUR = MAX(CONVERT(date, DT_CAL, 121))
            FROM dbo.PRTCAL
            WHERE CONVERT(date, DT_CAL, 121) < @auj;
    END

    IF @DT_JOUR IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_POSER_BORNE_JOURNEE : impossible de determiner la journee close (PRTCAL vide ?).';
        THROW 50020, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 3. Detection automatique du type (QUOTIDIEN / MULTI_JOURS)
    ------------------------------------------------------------------
    SELECT TOP (1) @dt_jour_prec = DT_JOUR, @dt_borne_prec = DT_BORNE
    FROM dbo.ORT_BORNE_JOURNEE
    WHERE DT_JOUR < @DT_JOUR
    ORDER BY DT_JOUR DESC;

    IF @dt_jour_prec IS NOT NULL
        SELECT @dt_jour_attendu = MIN(CONVERT(date, DT_CAL, 121))
        FROM dbo.PRTCAL
        WHERE CONVERT(date, DT_CAL, 121) > @dt_jour_prec;

    IF @TYPE_BORNE IS NULL
        SET @TYPE_BORNE = CASE WHEN @dt_jour_prec IS NULL THEN 'QUOTIDIEN'
                               WHEN @DT_JOUR = @dt_jour_attendu THEN 'QUOTIDIEN'
                               ELSE 'MULTI_JOURS' END;

    IF @TYPE_BORNE = 'MULTI_JOURS'
        SET @dt_debut_periode = @dt_jour_attendu;

    ------------------------------------------------------------------
    -- 4. Controles : borne existante et chainage strictement croissant
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR) AND @FORCER = 0
    BEGIN
        SET @msg = N'Borne deja posee pour la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                 + N'. @FORCER = 1 uniquement en connaissance de cause '
                 + N'(deplacement de frontiere : recalculer les journees J et J+1).';
        THROW 50021, @msg, 1;
    END

    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR < @DT_JOUR AND DT_BORNE >= @DT_BORNE)
       OR EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR > @DT_JOUR AND DT_BORNE <= @DT_BORNE)
    BEGIN
        SET @msg = N'Chainage des bornes incoherent : la borne '
                 + CONVERT(NVARCHAR(19), @DT_BORNE, 120)
                 + N' de la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                 + N' chevauche une borne existante.';
        THROW 50022, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 5. Pose (insert ou remplacement force) + audit format maison
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
    BEGIN
        UPDATE dbo.ORT_BORNE_JOURNEE
        SET DT_BORNE = @DT_BORNE, TYPE_BORNE = @TYPE_BORNE,
            ORIGINE_VALEUR = @origine_valeur,
            DT_JOUR_DEBUT_PERIODE = @dt_debut_periode,
            DT_POSE = GETDATE(),
            COMMENTAIRE = ISNULL(@COMMENTAIRE, N'Borne remplacee (FORCER) le ' + CONVERT(NVARCHAR(19), GETDATE(), 120))
        WHERE DT_JOUR = @DT_JOUR;

        INSERT INTO ods.AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'POSE BORNE [' + CONVERT(NVARCHAR(10), @DT_JOUR, 23) + N']',
                N'*BORNE*', N'ORT_BORNE_JOURNEE', 1, N'OK',
                N'AVERTISSEMENT: borne remplacee (FORCER) - recalcul des journees J et J+1 requis.',
                @dt_deb_step, GETDATE());
    END
    ELSE
    BEGIN
        INSERT INTO dbo.ORT_BORNE_JOURNEE
            (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, DT_JOUR_DEBUT_PERIODE, COMMENTAIRE)
        VALUES (@DT_JOUR, @DT_BORNE, @TYPE_BORNE, @origine_valeur, @dt_debut_periode, @COMMENTAIRE);

        INSERT INTO ods.AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET,
                N'POSE BORNE [' + CONVERT(NVARCHAR(10), @DT_JOUR, 23) + N']',
                N'*BORNE*', N'ORT_BORNE_JOURNEE', 1, N'OK',
                CASE WHEN @origine_valeur = 'DEFAUT'
                     THEN N'AVERTISSEMENT: valeur par defaut (calcul type V4) - renseigner @AUDIT_COL (cdc.TEC_AUD_CDC) ou passer @DT_BORNE. Borne '
                          + CONVERT(NVARCHAR(19), @DT_BORNE, 120) + N' (' + @TYPE_BORNE + N').'
                     ELSE N'Borne ' + CONVERT(NVARCHAR(19), @DT_BORNE, 120) + N' (' + @TYPE_BORNE + N', ' + @origine_valeur + N')'
                          + CASE WHEN @dt_debut_periode IS NOT NULL
                                 THEN N' - periode depuis le ' + CONVERT(NVARCHAR(10), @dt_debut_periode, 23)
                                 ELSE N'' END + N'.'
                END,
                @dt_deb_step, GETDATE());
    END
END
GO
