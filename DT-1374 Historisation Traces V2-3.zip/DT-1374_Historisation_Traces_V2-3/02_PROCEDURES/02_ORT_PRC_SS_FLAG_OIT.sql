/* ============================================================================
   DT-1374 - Sous-procedure : FLAG de l'image fin de journee dans ods.OIT_XXXX
   V2.3 - 21/07/2026 - Parametrage GRAIN COLONNE (format PARAM_CHARGEMENT) :
     - cle fonctionnelle   = lignes FL_CLEF = 1 (LB_CHAMP_ODS)
     - ordre "derniere"    = lignes FL_ORDRE_TRI = 1, DESC, ordre NO_CHAMP
                             (1ere = borne de fenetre, suivantes = departage)
     - filtre optionnel    = LB_FILTRE_WHERE porte par la ligne cle
     - flag                = colonne technique fixe FL_FIN_JOURNEE (standard)
   Fenetre(J) = ] borne(J-1) ; borne(J) ] (ORT_BORNE_JOURNEE).
   Audit au format maison + ID_TRT_ALI propage.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_FLAG_OIT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_FLAG_OIT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_FLAG_OIT
    @DT_TRACES     DATE,
    @LB_TABLE_ODS  NVARCHAR(128),
    @NB_FLAGUEES   INT OUTPUT,
    @ID_TRT_ALI    INT           = NULL,
    @LB_PROJET     NVARCHAR(50)  = N'INEO_TRACES'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @src NVARCHAR(300), @cle_ods NVARCHAR(MAX), @ordre NVARCHAR(MAX),
            @col_fenetre NVARCHAR(128), @filtre NVARCHAR(1000), @where_supp NVARCHAR(1000),
            @sql NVARCHAR(MAX), @msg NVARCHAR(500),
            @dt_deb_step DATETIME = GETDATE();

    ------------------------------------------------------------------
    -- Lecture du parametrage grain colonne
    ------------------------------------------------------------------
    SET @src = CASE WHEN CHARINDEX('.', @LB_TABLE_ODS) > 0
                    THEN @LB_TABLE_ODS ELSE N'ods.' + @LB_TABLE_ODS END;

    SELECT @cle_ods = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1 AND LB_CHAMP_ODS IS NOT NULL;

    SELECT @ordre = STRING_AGG(QUOTENAME(LB_CHAMP_ODS) + N' DESC', N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL;

    SELECT TOP (1) @col_fenetre = LB_CHAMP_ODS
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
    ORDER BY NO_CHAMP;

    SELECT @filtre = MAX(LB_FILTRE_WHERE)
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_TABLE_ODS = @LB_TABLE_ODS AND FL_CLEF = 1;

    IF @cle_ods IS NULL OR @col_fenetre IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_FLAG_OIT : parametrage incomplet pour ' + @LB_TABLE_ODS
                 + N' (cle FL_CLEF = 1 et/ou colonne FL_ORDRE_TRI = 1 manquante).';
        THROW 50032, @msg, 1;
    END

    ------------------------------------------------------------------
    -- Fenetre de la journee : ] borne(J-1) ; borne(J) ]
    ------------------------------------------------------------------
    DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3);

    SELECT @dt_fin = DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES;
    IF @dt_fin IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_FLAG_OIT : borne non posee pour la journee '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N' : journee non traitable.';
        THROW 50030, @msg, 1;
    END

    SELECT @dt_deb = MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES;
    IF @dt_deb IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_FLAG_OIT : aucune borne anterieure au '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
                 + N' : poser la borne initiale (TYPE_BORNE = INIT).';
        THROW 50031, @msg, 1;
    END

    SET @where_supp = ISNULL(@filtre, N'');
    SET @NB_FLAGUEES = 0;

    -- 1. Reset du flag sur la fenetre (idempotence du recalcul)
    SET @sql = N'UPDATE ' + @src +
               N' SET FL_FIN_JOURNEE = 0' +
               N' WHERE ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';';
    EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3)',
         @p_deb = @dt_deb, @p_fin = @dt_fin;

    -- 2. Flag de la derniere trace de la fenetre par cle fonctionnelle
    SET @sql = N';WITH cte AS (' +
               N'  SELECT *, ROW_NUMBER() OVER (PARTITION BY ' + @cle_ods +
               N'    ORDER BY ' + @ordre + N') AS rn_ort' +
               N'  FROM ' + @src +
               N'  WHERE ' + QUOTENAME(@col_fenetre) + N' > @p_deb AND ' + QUOTENAME(@col_fenetre) + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
               N') UPDATE cte SET FL_FIN_JOURNEE = 1 WHERE rn_ort = 1;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
         @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @NB_FLAGUEES OUTPUT;

    INSERT INTO ods.AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET,
            N'HISTO FLAG [' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N']',
            @LB_TABLE_ODS, @LB_TABLE_ODS, @NB_FLAGUEES, N'OK', NULL, @dt_deb_step, GETDATE());
END
GO
