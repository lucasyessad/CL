/* ============================================================================
   DT-1374 - Pose de la borne de fin de journee
   V2.0 - 20/07/2026
   Equivalent V5 de ps_INEO_lock_traces : a appeler au moment ou l'extraction
   INEO est declenchee, dans les DEUX cas d'exploitation :
     - fin normale des batchs LIGIS (nuit, heure variable, y compris apres
       minuit)                              -> @ORIGINE = 'FIN_BATCH'
     - passage force en journee apres batch KO (les batchs ne sont pas
       repris en journee mais l'extraction INEO doit se faire quand meme)
                                            -> @ORIGINE = 'FORCE_JOURNEE'

   Calcul par defaut de la borne (@DT_BORNE = NULL) : reprise exacte de la
   logique V4 :
     - si l'appel a lieu entre 07:45 et 19:00 -> borne = aujourd'hui 07:45
       (passage force en journee : on fige l'image du matin, hors maj batchs)
     - sinon (appel de nuit / fin de batch)  -> borne = GETDATE()

   Journee close par defaut (@DT_JOUR = NULL) :
     - appel apres 19:00 un jour ouvre  -> la journee close = aujourd'hui
       (batchs termines avant minuit)
     - sinon (nuit apres minuit, matin, journee) -> la journee close =
       derniere journee ouvree PRTCAL strictement anterieure a aujourd'hui
   RECOMMANDATION : passer @DT_JOUR explicitement depuis la chaine appelante
   (elle sait quelle journee elle clot) ; le defaut couvre le cas nominal.

   Controles ("infaillibilite") :
     - borne deja posee pour la journee -> erreur, sauf @FORCER = 1
       (avec avertissement : recalcul des journees J et J+1 requis)
     - chainage strictement croissant : la borne doit etre > toute borne de
       journee anterieure et < toute borne de journee posterieure
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_POSER_BORNE_JOURNEE', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
GO

CREATE PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
    @DT_JOUR   DATE          = NULL,
    @DT_BORNE  DATETIME      = NULL,
    @ORIGINE   NVARCHAR(20)  = NULL,
    @FORCER    BIT           = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @now DATETIME = GETDATE(),
            @auj DATE     = CAST(GETDATE() AS DATE),
            @deb_fenetre_jour DATETIME,   -- aujourd'hui 07:45
            @fin_fenetre_jour DATETIME,   -- aujourd'hui 19:00
            @msg NVARCHAR(500);

    SET @deb_fenetre_jour = DATEADD(minute, 45, DATEADD(hour, 7,  CAST(@auj AS DATETIME)));
    SET @fin_fenetre_jour = DATEADD(minute, 0,  DATEADD(hour, 19, CAST(@auj AS DATETIME)));

    ------------------------------------------------------------------
    -- 1. Borne par defaut : logique V4 (ps_INEO_lock_traces)
    ------------------------------------------------------------------
    IF @DT_BORNE IS NULL
    BEGIN
        IF @now > @deb_fenetre_jour AND @now < @fin_fenetre_jour
        BEGIN
            SET @DT_BORNE = @deb_fenetre_jour;   -- image du matin figee a 07:45
            IF @ORIGINE IS NULL SET @ORIGINE = 'FORCE_JOURNEE';
        END
        ELSE
        BEGIN
            SET @DT_BORNE = @now;                -- fin de batch (nuit/soir)
            IF @ORIGINE IS NULL SET @ORIGINE = 'FIN_BATCH';
        END
    END
    IF @ORIGINE IS NULL SET @ORIGINE = 'MANUEL';

    ------------------------------------------------------------------
    -- 2. Journee close par defaut
    ------------------------------------------------------------------
    IF @DT_JOUR IS NULL
    BEGIN
        IF @now >= @fin_fenetre_jour
           AND EXISTS (SELECT 1 FROM dbo.PRTCAL WHERE CONVERT(date, DT_CAL, 121) = @auj)
            SET @DT_JOUR = @auj;   -- batchs termines avant minuit : on clot aujourd'hui
        ELSE
            SELECT @DT_JOUR = MAX(CONVERT(date, DT_CAL, 121))
            FROM dbo.PRTCAL
            WHERE CONVERT(date, DT_CAL, 121) < @auj;   -- nuit/matin : on clot la veille ouvree
    END

    IF @DT_JOUR IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_POSER_BORNE_JOURNEE : impossible de determiner la journee close (PRTCAL vide ?).';
        THROW 50020, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 3. Controle : borne deja posee ?
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
    BEGIN
        IF @FORCER = 0
        BEGIN
            SET @msg = N'Borne deja posee pour la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                     + N'. Utiliser @FORCER = 1 uniquement en connaissance de cause '
                     + N'(necessite le recalcul des journees J et J+1).';
            THROW 50021, @msg, 1;
        END
    END

    ------------------------------------------------------------------
    -- 4. Controle de chainage strictement croissant
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR < @DT_JOUR AND DT_BORNE >= @DT_BORNE)
       OR EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR > @DT_JOUR AND DT_BORNE <= @DT_BORNE)
    BEGIN
        SET @msg = N'Chainage des bornes incoherent : la borne '
                 + CONVERT(NVARCHAR(19), @DT_BORNE, 120)
                 + N' de la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                 + N' chevauche une borne existante.';
        THROW 50022, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 5. Pose (insert ou remplacement force)
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
    BEGIN
        UPDATE dbo.ORT_BORNE_JOURNEE
        SET DT_BORNE = @DT_BORNE, ORIGINE = @ORIGINE, DT_POSE = GETDATE(),
            COMMENTAIRE = N'Borne remplacee (FORCER) le ' + CONVERT(NVARCHAR(19), GETDATE(), 120)
        WHERE DT_JOUR = @DT_JOUR;

        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_JOUR, N'*BORNE*', 'BORNE', 'AVERTISSEMENT',
                N'Borne remplacee : recalcul des journees J et J+1 requis (@FORCER = 1 sur le traitement).');
    END
    ELSE
    BEGIN
        INSERT INTO dbo.ORT_BORNE_JOURNEE (DT_JOUR, DT_BORNE, ORIGINE)
        VALUES (@DT_JOUR, @DT_BORNE, @ORIGINE);

        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_JOUR, N'*BORNE*', 'BORNE', 'OK',
                N'Borne ' + CONVERT(NVARCHAR(19), @DT_BORNE, 120) + N' posee (' + @ORIGINE + N').');
    END
END
GO
