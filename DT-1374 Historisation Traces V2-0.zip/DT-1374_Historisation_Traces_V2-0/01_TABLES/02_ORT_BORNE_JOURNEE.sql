/* ============================================================================
   DT-1374 - Table des bornes de fin de journee
   V2.0 - 20/07/2026
   Equivalent V5 historise du verrou V4 ps_INEO_lock_traces (TABLEREF) :
   au lieu de conserver uniquement la derniere borne, on enregistre UNE borne
   par journee ouvree, posee au moment ou l'extraction INEO est declenchee
   (fin des batchs LIGIS, ou passage force en journee si batch KO).

   La fenetre de la journee J est alors :  ] borne(J-1) ; borne(J) ]
   Proprietes ("infaillibilite") :
     - les fenetres se touchent exactement : aucune trace perdue, aucune
       comptee deux fois, quelle que soit l'heure de fin des batchs
       (avant ou apres minuit, avant ou apres 7h45) ;
     - pas de borne posee = journee non eligible au traitement (elle attend) ;
     - le chainage strictement croissant des bornes est controle a la pose.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_BORNE_JOURNEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_BORNE_JOURNEE
    (
        DT_JOUR        DATE           NOT NULL PRIMARY KEY,  -- journee ouvree que cette borne CLOT
        DT_BORNE       DATETIME       NOT NULL,              -- instant de cloture (fin d'extraction)
        ORIGINE        NVARCHAR(20)   NOT NULL DEFAULT ('FIN_BATCH'),
        DT_POSE        DATETIME       NOT NULL DEFAULT (GETDATE()),
        COMMENTAIRE    NVARCHAR(500)  NULL,
        CONSTRAINT UQ_ORT_BORNE_JOURNEE_DT_BORNE UNIQUE (DT_BORNE),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_ORIGINE
            CHECK (ORIGINE IN ('FIN_BATCH','FORCE_JOURNEE','INIT','MANUEL'))
    );
END
GO

/* ----------------------------------------------------------------------------
   Borne initiale (one-shot a la mise en production) : point de depart de la
   toute premiere fenetre. DT_JOUR = veille ouvree du premier jour a traiter,
   DT_BORNE = instant a partir duquel les traces CDC entrent dans le
   perimetre (ex: activation du CDC).
-----------------------------------------------------------------------------
INSERT INTO dbo.ORT_BORNE_JOURNEE (DT_JOUR, DT_BORNE, ORIGINE, COMMENTAIRE)
VALUES ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss>', 'INIT',
        'Borne initiale - demarrage historisation DT-1374');
---------------------------------------------------------------------------- */
GO
