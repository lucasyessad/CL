/* ============================================================================
   DT-1374 - Requetes de verification (recette)
   V2.0 - 20/07/2026 - Fenetres par bornes (ORT_BORNE_JOURNEE)
   Alignees sur la strategie de recette du ticket :
     cas 1 = integration jour par jour ; cas 2 = recalcul d'une date deja
     traitee (verifications anti-doublon).
   Remplacer les valeurs entre <...> avant execution.
   ============================================================================ */

DECLARE @jour DATE = '<AAAA-MM-JJ>';

-- Fenetre de la journee : ] @deb ; @fin ]
DECLARE @fin DATETIME = (SELECT DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @jour);
DECLARE @deb DATETIME = (SELECT MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @jour);
SELECT @jour AS jour, @deb AS borne_debut_exclue, @fin AS borne_fin_incluse;

------------------------------------------------------------------------------
-- 0. Supervision globale
------------------------------------------------------------------------------
SELECT * FROM dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = 'DT1374_HISTO_TRACES_FIN_JOURNEE' AND DT_CAL = @jour;
SELECT * FROM dbo.ORT_SUIVI_JOUR_TABLE     WHERE DT_JOUR = @jour ORDER BY ID_PARAM;
SELECT * FROM dbo.ORT_LOG_HISTORISATION_TRACES
WHERE DT_TRACES_TRAITEE = @jour ORDER BY DT_EXECUTION;

------------------------------------------------------------------------------
-- 0bis. Controle du chainage des bornes (attendu : 0 ligne)
--       Les bornes doivent etre strictement croissantes avec les journees.
------------------------------------------------------------------------------
SELECT b1.DT_JOUR, b1.DT_BORNE
FROM dbo.ORT_BORNE_JOURNEE b1
WHERE EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE b0
              WHERE b0.DT_JOUR < b1.DT_JOUR AND b0.DT_BORNE >= b1.DT_BORNE);

------------------------------------------------------------------------------
-- 1. Verification du flag fin de journee (source OIT)
--    Attendu : dans la fenetre, exactement 1 ligne flaguee a 1 par cle
--    fonctionnelle, et cette ligne porte la plus grande valeur d'ordre.
--    (exemple sur ods.OIT_CONTRAT / cle NUM_CONTRAT / ordre DT_HORODATAGE)
------------------------------------------------------------------------------
-- a) doublons de flag par cle (attendu : 0 ligne)
SELECT NUM_CONTRAT, COUNT(*) AS nb_flaguees
FROM ods.OIT_CONTRAT
WHERE DT_HORODATAGE > @deb AND DT_HORODATAGE <= @fin AND FL_FIN_JOURNEE = 1
GROUP BY NUM_CONTRAT
HAVING COUNT(*) > 1;

-- b) cles sans aucune ligne flaguee (attendu : 0 ligne)
SELECT NUM_CONTRAT
FROM ods.OIT_CONTRAT
WHERE DT_HORODATAGE > @deb AND DT_HORODATAGE <= @fin
GROUP BY NUM_CONTRAT
HAVING MAX(CASE WHEN FL_FIN_JOURNEE = 1 THEN 1 ELSE 0 END) = 0;

-- c) la ligne flaguee est bien la derniere de la fenetre (attendu : 0 ligne)
SELECT s.NUM_CONTRAT
FROM ods.OIT_CONTRAT s
WHERE s.DT_HORODATAGE > @deb AND s.DT_HORODATAGE <= @fin AND s.FL_FIN_JOURNEE = 1
  AND EXISTS (SELECT 1 FROM ods.OIT_CONTRAT s2
              WHERE s2.NUM_CONTRAT = s.NUM_CONTRAT
                AND s2.DT_HORODATAGE > @deb AND s2.DT_HORODATAGE <= @fin
                AND s2.DT_HORODATAGE > s.DT_HORODATAGE);

------------------------------------------------------------------------------
-- 2. Verification de l'alimentation de la cible (OWT/IWT)
------------------------------------------------------------------------------
-- a) nb de lignes inserees pour la journee = nb de lignes flaguees en source
SELECT
  (SELECT COUNT(*) FROM ods.OIT_CONTRAT
   WHERE DT_HORODATAGE > @deb AND DT_HORODATAGE <= @fin
     AND FL_FIN_JOURNEE = 1)                                        AS nb_flaguees_source,
  (SELECT COUNT(*) FROM dbo.OWT_CONTRAT WHERE DD_VAL = @jour)       AS nb_inserees_cible;

-- b) anti-doublon : 1 seule version courante par cle (attendu : 0 ligne)
SELECT NUM_CONTRAT, COUNT(*) AS nb_versions_courantes
FROM dbo.OWT_CONTRAT
WHERE FLAG_COURANT = 1
GROUP BY NUM_CONTRAT
HAVING COUNT(*) > 1;

-- c) coherence SCD2 : la version courante porte DF_VAL = 2400-01-01 (attendu : 0 ligne)
SELECT *
FROM dbo.OWT_CONTRAT
WHERE FLAG_COURANT = 1 AND DF_VAL <> '2400-01-01';

-- d) coherence SCD2 : pas de version historique "ouverte" (attendu : 0 ligne)
SELECT *
FROM dbo.OWT_CONTRAT
WHERE FLAG_COURANT = 0 AND DF_VAL = '2400-01-01';

-- e) chainage : pour une cle, la version fermee a DF_VAL = DD_VAL de la
--    version suivante (borne exclusive) (attendu : 0 ligne)
SELECT h.NUM_CONTRAT, h.DD_VAL, h.DF_VAL
FROM dbo.OWT_CONTRAT h
WHERE h.FLAG_COURANT = 0
  AND NOT EXISTS (SELECT 1 FROM dbo.OWT_CONTRAT n
                  WHERE n.NUM_CONTRAT = h.NUM_CONTRAT
                    AND n.DD_VAL = h.DF_VAL);

------------------------------------------------------------------------------
-- 3. Test de recalcul (cas 2 de la strategie de recette)
--    Rejouer une date deja calculee :
--        EXEC dbo.ORT_PRC_TRAITEMENT_JOUR @DT_TRACES = @jour, @FORCER = 1;
--    (les bornes sont conservees : memes fenetres, resultats identiques)
--    Puis re-derouler les controles 0bis, 1 et 2 : aucun doublon,
--    memes volumetries qu'avant recalcul.
------------------------------------------------------------------------------

-- Volumetrie de reference a relever AVANT et APRES recalcul :
SELECT COUNT(*) AS nb_total, SUM(CASE WHEN FLAG_COURANT = 1 THEN 1 ELSE 0 END) AS nb_courantes
FROM dbo.OWT_CONTRAT;

------------------------------------------------------------------------------
-- 4. Cas d'exploitation "batch KO" a recetter specifiquement
------------------------------------------------------------------------------
-- a) Batch KO + extraction forcee en journee : verifier que la borne du jour
--    est a 07:45 avec ORIGINE = 'FORCE_JOURNEE', puis que l'image du jour
--    ne contient AUCUNE trace posterieure a 07:45 :
SELECT * FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @jour;
SELECT COUNT(*) AS nb_traces_hors_fenetre     -- attendu : 0
FROM ods.OIT_CONTRAT
WHERE FL_FIN_JOURNEE = 1
  AND DT_HORODATAGE > @deb AND DT_HORODATAGE <= @fin
  AND DT_HORODATAGE > @fin;

-- b) Journee jamais bornee : verifier que la journee suivante bornee a bien
--    absorbe les traces (fenetre elargie) et qu'aucune trace de la periode
--    n'est restee hors de toute fenetre :
SELECT COUNT(*) AS nb_traces_orphelines       -- attendu : 0
FROM ods.OIT_CONTRAT t
WHERE NOT EXISTS (SELECT 1
                  FROM dbo.ORT_BORNE_JOURNEE b
                  WHERE t.DT_HORODATAGE <= b.DT_BORNE
                    AND t.DT_HORODATAGE > ISNULL((SELECT MAX(b0.DT_BORNE)
                                                  FROM dbo.ORT_BORNE_JOURNEE b0
                                                  WHERE b0.DT_JOUR < b.DT_JOUR), '1900-01-01'));
