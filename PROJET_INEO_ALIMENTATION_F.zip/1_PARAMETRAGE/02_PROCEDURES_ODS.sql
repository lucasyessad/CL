/* ============================================================================
   PROCEDURES D'ALIMENTATION DE L'ODS

   Trois procedures, valables pour tous les projets. Elles ne connaissent aucun
   nom de table, aucun schema, aucun repertoire : tout vient du parametrage,
   lu dans ORT_PARAM_FLUX.

       PS_PREPARATION_ODS         avant le chargement : prepare les cibles
       PS_CHARGEMENT_FICHIER_ODS  charge un fichier delimite
       PS_CONTROLE_ODS            apres le chargement : mesure, trace, conclut

   ----------------------------------------------------------------------------
   LE SUIVI TIENT DANS UNE SEULE TABLE, ET UNE SEULE LIGNE PAR TABLE
   ----------------------------------------------------------------------------
   Tout est ecrit dans dbo.ORT_AUDIT_CHARGEMENT, qui existe deja et sert deja
   au scenario ODI. Aucune table de suivi supplementaire.

   Une seule ligne par table chargee. La preparation la CREE avec la
   volumetrie avant chargement et un statut vide ; le controle la MET A JOUR
   avec la volumetrie chargee et le statut final. Une ligne dont le statut est
   reste vide signale une preparation jamais suivie de son controle.

   Les jobs appellent bcp depuis un batch : SQL Server ne sait pas combien de
   lignes ont ete chargees. La volumetrie avant chargement, portee par la ligne
   entre les deux appels, est ce qui permet de le mesurer.

   Ou en est le traitement se lit d'une requete :

       SELECT LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR
       FROM dbo.ORT_AUDIT_CHARGEMENT
       WHERE ID_TRT_ALI = <run>
       ORDER BY DT_DEBUT;
   ============================================================================ */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO


/* ============================================================================
   PS_PREPARATION_ODS

   Appelee AVANT la boucle de chargement, et APRES le chargement de la table
   d'audit lorsque le projet a des flux DELTA.

   DELTA  Supprime la plage que le fichier va recharger, bornee par les LSN
          lus dans la table d'audit. La table n'est PAS videe : elle conserve
          les traces posterieures a la derniere fin de journee, qui n'ont pas
          encore ete traitees. Les vider les ferait disparaitre, et le
          pointeur de l'extraction suivante ne les ramenerait jamais.
          Supprimer la plage rend le chargement rejouable.

   FULL   Vide la table. Le fichier porte l'etat complet.

   @FL_INIT = 1 restreint le traitement aux flux marques en initialisation, et
   vide leur cible quel que soit le mode d'entree : une reprise d'existant part
   toujours d'un sas propre. La procedure refuse alors un flux dont
   l'historique DWH est deja alimente : une seconde version initiale a la date
   du jour, sans fermeture de la precedente, rendrait l'historique incoherent
   sans que rien ne le signale.
   ============================================================================ */
CREATE OR ALTER PROCEDURE dbo.PS_PREPARATION_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT       = NULL,
    @CD_FORMAT  NVARCHAR(10) = N'BCP',
    @FL_INIT    BIT          = 0
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @sql         NVARCHAR(MAX),
        @msg         NVARCHAR(2000),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @dwh_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @entree      NVARCHAR(10),
        @schema_ods  NVARCHAR(128),
        @table_audit NVARCHAR(128),
        @nb          BIGINT,
        @nb_flux     INT = 0,
        @nb_ko       INT = 0;

    IF @ID_TRT_ALI IS NULL
        SET @ID_TRT_ALI = CONVERT(BIGINT, FORMAT(SYSDATETIME(), N'yyyyMMddHHmmss'));

    /* L'audit doit etre charge des lors qu'un flux DELTA est au programme :
       sans lui, aucune plage de LSN n'est connue. */
    IF @FL_INIT = 0
       AND EXISTS
       (
           SELECT 1 FROM dbo.ORT_PARAM_FLUX
           WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1
             AND CD_FORMAT = @CD_FORMAT
             AND CD_MODE_ENTREE = N'DELTA'
       )
    BEGIN
        SELECT TOP (1) @schema_ods = LB_SCHEMA_ODS, @table_audit = LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1 AND CD_MODE_ENTREE = N'DELTA';

        SET @nb = 0;
        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM '
                 + QUOTENAME(@schema_ods) + N'.' + QUOTENAME(@table_audit) + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        IF ISNULL(@nb, 0) = 0
        BEGIN
            SET @msg = N'PS_PREPARATION_ODS : ' + @schema_ods + N'.' + @table_audit
                     + N' est vide. Charger l''audit avant d''appeler cette procedure.';
            THROW 56000, @msg, 1;
        END;
    END;

    /* Un run repris repart d'une trace propre. */
    DELETE FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE ID_TRT_ALI = @ID_TRT_ALI
      AND LB_PROJET  = @LB_PROJET
      AND LB_CHARGEMENT = N'Chargement bcp -> ods';

    DECLARE cur_flux CURSOR LOCAL FAST_FORWARD FOR
        SELECT LB_TABLE_ODS,
               QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
               CASE WHEN LB_TABLE_DWH IS NULL THEN NULL
                    ELSE QUOTENAME(LB_SCHEMA_DWH) + N'.' + QUOTENAME(LB_TABLE_DWH) END,
               LB_SOURCE, CD_MODE_ENTREE, LB_SCHEMA_ODS, LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET
          AND FL_ACTIF  = 1
          AND CD_FORMAT = @CD_FORMAT
          AND (@FL_INIT = 0 OR FL_INIT = 1)
        ORDER BY NO_ORDRE, LB_TABLE_ODS;

    OPEN cur_flux;
    FETCH NEXT FROM cur_flux
    INTO @table_ods, @ods_complet, @dwh_complet, @source, @entree, @schema_ods, @table_audit;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @nb = NULL;

        BEGIN TRY
            IF @FL_INIT = 1 AND @dwh_complet IS NOT NULL
            BEGIN
                DECLARE @nb_histo BIGINT = 0;
                SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @dwh_complet + N';';
                EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb_histo OUTPUT;

                IF @nb_histo > 0
                BEGIN
                    SET @msg = N'Historique deja alimente : '
                             + CONVERT(NVARCHAR(20), @nb_histo) + N' ligne(s) dans '
                             + @dwh_complet + N'. Initialisation refusee.';
                    THROW 56001, @msg, 1;
                END;
            END;

            IF @FL_INIT = 1 OR @entree = N'FULL'
            BEGIN
                SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
                EXEC sp_executesql @sql;
                SET @nb = 0;
            END
            ELSE
            BEGIN
                SET @sql =
                      N'DELETE T'                                     + CHAR(13)
                    + N'FROM ' + @ods_complet + N' AS T'              + CHAR(13)
                    + N'INNER JOIN ' + QUOTENAME(@schema_ods) + N'.'
                                     + QUOTENAME(@table_audit) + N' AS A' + CHAR(13)
                    + N'        ON A.LB_INSTANCE = @p_source'         + CHAR(13)
                    + N'WHERE T.LB_LSN_COMMIT_TEC >  A.LB_DEB_LSN'    + CHAR(13)
                    + N'  AND T.LB_LSN_COMMIT_TEC <= A.LB_FIN_LSN;';
                EXEC sp_executesql @sql, N'@p_source nvarchar(260)', @p_source = @source;

                SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
                EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;
            END;

            /* La ligne de chargement est creee ici, statut vide. NB_LIGNE porte
               provisoirement la volumetrie AVANT chargement : le controle la
               remplacera par la volumetrie chargee et posera le statut. */
            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement bcp -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 @nb, NULL, NULL, @dt_debut, NULL);

            SET @nb_flux += 1;
        END TRY
        BEGIN CATCH
            SET @nb_ko += 1;
            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement bcp -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 0, N'KO', N'Preparation : ' + ERROR_MESSAGE(), @dt_debut, SYSDATETIME());
        END CATCH;

        FETCH NEXT FROM cur_flux
        INTO @table_ods, @ods_complet, @dwh_complet, @source, @entree, @schema_ods, @table_audit;
    END;

    CLOSE cur_flux;
    DEALLOCATE cur_flux;

    /* Une preparation en echec doit arreter le job : charger par-dessus une
       cible mal preparee produirait des doublons silencieux. */
    IF @nb_ko > 0
    BEGIN
        SET @msg = N'PS_PREPARATION_ODS : ' + CONVERT(NVARCHAR(10), @nb_ko)
                 + N' flux en echec. Detail dans ORT_AUDIT_CHARGEMENT pour'
                 + N' ID_TRT_ALI = ' + CONVERT(NVARCHAR(20), @ID_TRT_ALI) + N'.';
        THROW 56002, @msg, 1;
    END;

    SELECT ID_TRT_ALI = @ID_TRT_ALI, NB_FLUX = @nb_flux;
END;
GO


/* ============================================================================
   PS_CHARGEMENT_FICHIER_ODS

   Charge un fichier delimite dans sa table ODS. Le format vient du
   parametrage : delimiteur, ligne de debut, encodage.

   Le job liste les fichiers et appelle la procedure une fois par fichier :
   c'est lui qui parcourt le repertoire, ce qui evite xp_cmdshell, que
   l'exploitation n'autorise generalement pas.

   BULK INSERT lit le fichier depuis le MOTEUR SQL, pas depuis le poste qui
   lance la commande : le compte de service doit avoir acces au repertoire.
   ============================================================================ */
CREATE OR ALTER PROCEDURE dbo.PS_CHARGEMENT_FICHIER_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @LB_FICHIER NVARCHAR(260),
    @ID_TRT_ALI BIGINT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @repertoire  NVARCHAR(260),
        @delimiteur  NVARCHAR(10),
        @ligne_debut INT,
        @encodage    NVARCHAR(20),
        @chemin      NVARCHAR(520),
        @sql         NVARCHAR(MAX),
        @nb          BIGINT = 0,
        @msg         NVARCHAR(2000);

    IF @ID_TRT_ALI IS NULL
        SET @ID_TRT_ALI = CONVERT(BIGINT, FORMAT(SYSDATETIME(), N'yyyyMMddHHmmss'));

    SELECT
        @table_ods   = LB_TABLE_ODS,
        @ods_complet = QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
        @repertoire  = LB_REPERTOIRE,
        @delimiteur  = LB_DELIMITEUR,
        @ligne_debut = ISNULL(NO_LIGNE_DEBUT, 1),
        @encodage    = LB_ENCODAGE
    FROM dbo.ORT_PARAM_FLUX
    WHERE LB_PROJET  = @LB_PROJET
      AND FL_ACTIF   = 1
      AND CD_FORMAT  = N'CSV'
      AND LB_FICHIER = @LB_FICHIER;

    IF @table_ods IS NULL
    BEGIN
        SET @msg = N'Aucun flux parametre pour le fichier ' + @LB_FICHIER
                 + N' (projet ' + @LB_PROJET + N').';
        THROW 56010, @msg, 1;
    END;

    SET @chemin = @repertoire
                + CASE WHEN RIGHT(@repertoire, 1) = N'\' THEN N'' ELSE N'\' END
                + @LB_FICHIER;

    BEGIN TRY
        /* Un fichier delimite porte un etat complet : la cible est videe. */
        SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
        EXEC sp_executesql @sql;

        SET @sql =
              N'BULK INSERT ' + @ods_complet                                       + CHAR(13)
            + N'FROM ''' + REPLACE(@chemin, N'''', N'''''') + N''''                + CHAR(13)
            + N'WITH ('                                                            + CHAR(13)
            + N'    FIELDTERMINATOR = ''' + REPLACE(@delimiteur, N'''', N'''''') + N''',' + CHAR(13)
            + N'    ROWTERMINATOR   = ''0x0a'','                                   + CHAR(13)
            + N'    FIRSTROW        = ' + CONVERT(NVARCHAR(10), @ligne_debut) + N',' + CHAR(13)
            + CASE WHEN @encodage IS NULL THEN N''
                   ELSE N'    CODEPAGE        = ''' + @encodage + N''',' + CHAR(13) END
            /* Une seule ligne mal formee fait echouer le chargement : une table
               de reference chargee a moitie serait plus dangereuse qu'une table
               non chargee. */
            + N'    MAXERRORS       = 0,'                                          + CHAR(13)
            + N'    TABLOCK'                                                       + CHAR(13)
            + N');';
        EXEC sp_executesql @sql;

        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, @nb, N'OK', NULL, @dt_debut, SYSDATETIME());
    END TRY
    BEGIN CATCH
        SET @msg = ERROR_MESSAGE();

        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Chargement csv -> ods',
             @LB_FICHIER, @table_ods, 0, N'KO', @msg, @dt_debut, SYSDATETIME());

        THROW;
    END CATCH;

    SELECT ID_TRT_ALI = @ID_TRT_ALI, TABLE_ODS = @table_ods, NB_LIGNES = @nb;
END;
GO


/* ============================================================================
   PS_CONTROLE_ODS

   Appelee APRES la boucle de chargement.

   Les jobs appellent bcp depuis un batch : SQL Server ne sait donc pas combien
   de lignes ont ete chargees. La procedure le deduit en comparant le contenu
   actuel a la volumetrie deposee par la preparation dans le journal.

   Elle detecte le cas que rien d'autre n'attrape : bcp qui rend 0 sans avoir
   rien ecrit. Elle sort en erreur si un flux est en echec, ce qui arrete le
   job avant le scenario ODI : un ODS incomplet ne produit pas d'image fausse.

   @FL_EXIGER_LIGNES = 0 pour un projet dont un referentiel peut legitimement
   ne pas changer : l'absence de nouvelle ligne devient un avertissement.
   ============================================================================ */
CREATE OR ALTER PROCEDURE dbo.PS_CONTROLE_ODS
(
    @LB_PROJET        NVARCHAR(50),
    @ID_TRT_ALI       BIGINT,
    @FL_EXIGER_LIGNES BIT = 1
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @nb_avant    BIGINT,
        @nb_apres    BIGINT,
        @dt_debut    DATETIME2(3),
        @sql         NVARCHAR(MAX),
        @msg         NVARCHAR(2000),
        @statut      NVARCHAR(10),
        @nb_ko       INT = 0,
        @nb_total    BIGINT = 0;

    IF NOT EXISTS
    (
        SELECT 1 FROM dbo.ORT_AUDIT_CHARGEMENT
        WHERE ID_TRT_ALI = @ID_TRT_ALI
          AND LB_PROJET  = @LB_PROJET
          AND LB_CHARGEMENT = N'Chargement bcp -> ods'
          AND CD_STATUT IS NULL
    )
    BEGIN
        SET @msg = N'PS_CONTROLE_ODS : aucune preparation tracee pour ID_TRT_ALI = '
                 + CONVERT(NVARCHAR(20), @ID_TRT_ALI)
                 + N'. La preparation a-t-elle bien tourne ?';
        THROW 56020, @msg, 1;
    END;

    DECLARE cur_ctrl CURSOR LOCAL FAST_FORWARD FOR
        SELECT A.LB_CIBLE,
               QUOTENAME(F.LB_SCHEMA_ODS) + N'.' + QUOTENAME(F.LB_TABLE_ODS),
               A.LB_SOURCE, A.NB_LIGNE, A.DT_DEBUT
        FROM dbo.ORT_AUDIT_CHARGEMENT AS A
        INNER JOIN dbo.ORT_PARAM_FLUX AS F
            ON F.LB_PROJET = A.LB_PROJET AND F.LB_TABLE_ODS = A.LB_CIBLE
        WHERE A.ID_TRT_ALI    = @ID_TRT_ALI
          AND A.LB_PROJET     = @LB_PROJET
          AND A.LB_CHARGEMENT = N'Chargement bcp -> ods'
          AND A.CD_STATUT     IS NULL
        ORDER BY A.LB_CIBLE;

    OPEN cur_ctrl;
    FETCH NEXT FROM cur_ctrl INTO @table_ods, @ods_complet, @source, @nb_avant, @dt_debut;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @statut = N'OK';
        SET @msg = NULL;
        SET @nb_apres = NULL;

        BEGIN TRY
            SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
            EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb_apres OUTPUT;

            IF @nb_apres = @nb_avant
            BEGIN
                SET @msg = N'Aucune ligne chargee : la volumetrie n''a pas evolue ('
                         + CONVERT(NVARCHAR(20), @nb_avant) + N' avant et apres).'
                         + N' Fichier absent, vide, ou chargement sans effet.';
                IF @FL_EXIGER_LIGNES = 1 SET @statut = N'KO';
            END;
        END TRY
        BEGIN CATCH
            SET @statut = N'KO';
            SET @msg = ERROR_MESSAGE();
        END CATCH;

        /* La ligne creee par la preparation recoit son resultat. */
        UPDATE dbo.ORT_AUDIT_CHARGEMENT
        SET NB_LIGNE  = ISNULL(@nb_apres, 0) - ISNULL(@nb_avant, 0),
            CD_STATUT = @statut,
            LB_ERREUR = @msg,
            DT_FIN    = SYSDATETIME()
        WHERE ID_TRT_ALI    = @ID_TRT_ALI
          AND LB_PROJET     = @LB_PROJET
          AND LB_CHARGEMENT = N'Chargement bcp -> ods'
          AND LB_CIBLE      = @table_ods;

        IF @statut = N'KO' SET @nb_ko += 1;
        SET @nb_total += ISNULL(@nb_apres, 0) - ISNULL(@nb_avant, 0);

        FETCH NEXT FROM cur_ctrl INTO @table_ods, @ods_complet, @source, @nb_avant, @dt_debut;
    END;

    CLOSE cur_ctrl;
    DEALLOCATE cur_ctrl;

    /* Pas de ligne de bilan en marche normale : les lignes par table
       suffisent. Une seule ligne, uniquement s'il y a un echec a signaler. */
    IF @nb_ko > 0
        INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
             NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES
            (@ID_TRT_ALI, @LB_PROJET, N'Bilan chargement ods', N'*TOUTES*', NULL,
             @nb_total, N'KO',
             CONVERT(NVARCHAR(10), @nb_ko) + N' flux en echec.',
             SYSDATETIME(), SYSDATETIME());

    SELECT LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR
    FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE ID_TRT_ALI = @ID_TRT_ALI AND LB_PROJET = @LB_PROJET
    ORDER BY CD_STATUT DESC, DT_DEBUT;

    IF @nb_ko > 0
    BEGIN
        SET @msg = N'PS_CONTROLE_ODS : ' + CONVERT(NVARCHAR(10), @nb_ko)
                 + N' flux en echec. L''ODS est incomplet, le scenario ODI ne'
                 + N' doit pas etre lance.';
        THROW 56021, @msg, 1;
    END;
END;
GO


/* ============================================================================
   PS_CLOTURE_INIT_ODS

   Appelee par le scenario ODI apres l'historisation, une fois les versions
   initiales creees. Remet FL_INIT a 0 : les flux repassent en alimentation
   quotidienne, et l'initialisation ne peut pas etre rejouee le lendemain.
   ============================================================================ */
CREATE OR ALTER PROCEDURE dbo.PS_CLOTURE_INIT_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @nb_cloture INT, @nb_restant INT;

    UPDATE dbo.ORT_PARAM_FLUX
    SET FL_INIT    = 0,
        DT_MAJ     = SYSDATETIME(),
        CD_USR_MAJ = N'INIT'
    WHERE LB_PROJET = @LB_PROJET
      AND FL_INIT   = 1;

    SET @nb_cloture = @@ROWCOUNT;

    SELECT @nb_restant = COUNT(*)
    FROM dbo.ORT_PARAM_FLUX
    WHERE LB_PROJET = @LB_PROJET AND FL_INIT = 1;

    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
         NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES
        (@ID_TRT_ALI, @LB_PROJET, N'Cloture initialisation', N'*TOUTES*', NULL,
         @nb_cloture, N'OK', NULL, SYSDATETIME(), SYSDATETIME());

    SELECT NB_CLOTURE = @nb_cloture, NB_RESTANT = @nb_restant;
END;
GO
