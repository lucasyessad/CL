/* ============================================================================
   01 - PARAMETRAGE : creation et premiere alimentation

   Deux tables, deux grains :

     ORT_PARAM_FLUX               une ligne par table alimentee
                                  dit COMMENT alimenter (projet, modes, format)

     ORT_PARAM_HISTORISATION_TRACES   une ligne par colonne
                                  dit QUOI mapper (nom ODS, nom DWH, roles)

   Tout est cle par LB_PROJET : chaque progiciel est isole des autres.

   PK et index uniquement. Aucune autre contrainte : le parametrage est
   verifie par les scripts du dossier 6_CONTROLES, pas par des CHECK.

   La premiere alimentation d'ORT_PARAM_FLUX est dynamique : une ligne par
   table deja decrite au grain colonne, en DELTA + BCP + SCD2.
   ============================================================================ */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* ----------------------------------------------------------------------------
   ORT_PARAM_FLUX  -  grain table

     CD_MODE_ENTREE   DELTA (modifications) | FULL (etat complet)
     CD_FORMAT        BCP | CSV
     CD_MODE_ALIM     SCD2 | SCD1 | AJOUT | AUCUNE
     FL_INIT          1 le temps d'une reprise d'existant, remis a 0 en fin
                      de traitement par PS_CLOTURE_INIT_ODS
---------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.ORT_PARAM_FLUX', N'U') IS NOT NULL
    DROP TABLE dbo.ORT_PARAM_FLUX;
GO

CREATE TABLE dbo.ORT_PARAM_FLUX
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS    NVARCHAR(128)  NOT NULL,
    LB_TABLE_DWH    NVARCHAR(128)  NULL,
    LB_SOURCE       NVARCHAR(260)  NULL,

    CD_MODE_ENTREE  NVARCHAR(10)   NOT NULL,
    CD_FORMAT       NVARCHAR(10)   NOT NULL,
    CD_MODE_ALIM    NVARCHAR(10)   NOT NULL,

    FL_ACTIF        BIT            NOT NULL,
    FL_INIT         BIT            NOT NULL,
    NO_ORDRE        INT            NOT NULL,
    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    LB_SCHEMA_ODS   NVARCHAR(128)  NOT NULL,
    LB_SCHEMA_DWH   NVARCHAR(128)  NOT NULL,
    LB_TABLE_AUDIT  NVARCHAR(128)  NULL,
    HR_FRONTIERE    TIME(0)        NULL,

    LB_FICHIER      NVARCHAR(260)  NULL,
    LB_REPERTOIRE   NVARCHAR(260)  NULL,
    LB_DELIMITEUR   NVARCHAR(10)   NULL,
    NO_LIGNE_DEBUT  INT            NULL,
    LB_ENCODAGE     NVARCHAR(20)   NULL,

    DT_MAJ          DATETIME2(3)   NULL,
    CD_USR_MAJ      NVARCHAR(20)   NULL,
    LB_COMMENTAIRE  NVARCHAR(500)  NULL,

    CONSTRAINT PK_ORT_PARAM_FLUX PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_FLUX_ACTIFS
    ON dbo.ORT_PARAM_FLUX (LB_PROJET, FL_ACTIF, NO_ORDRE)
    INCLUDE (LB_TABLE_ODS, CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM);
GO


/* ----------------------------------------------------------------------------
   ORT_PARAM_HISTORISATION_TRACES  -  grain colonne

     FL_CLEF        colonne de la cle fonctionnelle
     FL_CHARGEMENT  colonne reprise dans le DWH, et comparee en historisation
     FL_ORDRE_TRI   colonne d'horodatage, pour trouver l'image en DELTA
---------------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.ORT_PARAM_HISTORISATION_TRACES', N'U') IS NOT NULL
    DROP TABLE dbo.ORT_PARAM_HISTORISATION_TRACES;
GO

CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
(
    LB_PROJET      NVARCHAR(50)   NOT NULL,
    LB_TABLE_ODS   NVARCHAR(128)  NOT NULL,
    NO_CHAMP       INT            NOT NULL,

    LB_SOURCE      NVARCHAR(260)  NULL,
    LB_TABLE_DWH   NVARCHAR(128)  NULL,
    LB_CHAMP_ODS   NVARCHAR(128)  NULL,
    LB_CHAMP_DWH   NVARCHAR(128)  NULL,
    LB_SCD         NVARCHAR(30)   NULL,

    FL_CLEF        BIT            NOT NULL,
    FL_CHARGEMENT  BIT            NOT NULL,
    FL_ORDRE_TRI   BIT            NOT NULL,

    LB_FILTRE_WHERE NVARCHAR(1000) NULL,

    CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
        PRIMARY KEY CLUSTERED (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
);
GO

CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ROLES
    ON dbo.ORT_PARAM_HISTORISATION_TRACES (LB_PROJET, LB_TABLE_ODS, FL_CLEF, FL_CHARGEMENT)
    INCLUDE (NO_CHAMP, LB_CHAMP_ODS, LB_CHAMP_DWH, FL_ORDRE_TRI);
GO


/* ----------------------------------------------------------------------------
   PREMIERE ALIMENTATION D'ORT_PARAM_FLUX

   Une ligne par table deja decrite au grain colonne, en DELTA + BCP + SCD2.
   Dynamique : ne suppose aucune liste en dur, et ne cree que ce qui manque.
   La cible et la source sont reprises de la ligne cle de plus petit NO_CHAMP.
---------------------------------------------------------------------------- */
INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, FL_INIT, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
SELECT
    S.LB_PROJET, S.LB_TABLE_ODS, S.LB_TABLE_DWH, S.LB_SOURCE,
    N'DELTA', N'BCP', N'SCD2',
    1, 0, 100 + (ROW_NUMBER() OVER (ORDER BY S.LB_TABLE_ODS)) * 10, S.LB_FILTRE_WHERE,
    N'ods', N'dbo', N'OIT_TEC_AUDIT_CDC', '07:45:00',
    SYSDATETIME(), N'INIT', N'Cree depuis ORT_PARAM_HISTORISATION_TRACES'
FROM
(
    SELECT T.LB_PROJET, T.LB_TABLE_ODS, T.LB_TABLE_DWH, T.LB_SOURCE, T.LB_FILTRE_WHERE,
           Rang = ROW_NUMBER() OVER
           (
               PARTITION BY T.LB_PROJET, T.LB_TABLE_ODS
               ORDER BY CASE WHEN T.FL_CLEF = 1 THEN 0 ELSE 1 END, T.NO_CHAMP
           )
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
) AS S
WHERE S.Rang = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
      WHERE F.LB_PROJET = S.LB_PROJET AND F.LB_TABLE_ODS = S.LB_TABLE_ODS
  );
GO
