/* ============================================================================
   01 - dbo.PITCOT_PERIODE_REPRISE

   File des journees a traiter, une ligne par journee et par scenario. Videe et
   reconstruite a chaque execution par l'etape ODI 003, marquee par l'etape 010.

   Cle par LB_PROJET comme toutes les tables du dispositif, en complement du
   nom de scenario qui distingue deja les projets.

   PK et index seulement.
   ============================================================================ */

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.PITCOT_PERIODE_REPRISE', N'U') IS NOT NULL
    DROP TABLE dbo.PITCOT_PERIODE_REPRISE;
GO

CREATE TABLE dbo.PITCOT_PERIODE_REPRISE
(
    LB_PROJET       NVARCHAR(50)   NOT NULL,
    DT_CAL          DATE           NOT NULL,
    NO_SEQ          INT            NOT NULL,
    TRAITE          BIT            NOT NULL,
    LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,

    CONSTRAINT PK_PITCOT_PERIODE_REPRISE PRIMARY KEY CLUSTERED (LB_PROJET, LB_NOM_SCN_SUN, DT_CAL)
);
GO

CREATE NONCLUSTERED INDEX IX_PITCOT_PERIODE_REPRISE_A_TRAITER
    ON dbo.PITCOT_PERIODE_REPRISE (LB_NOM_SCN_SUN, TRAITE, DT_CAL);
GO
