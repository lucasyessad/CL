-- schema logique : MSSQL_DWH
-- type : V

SELECT COUNT(P.DT_CAL)
FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = '#INEO.V_NOM_PROJET'
  AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B
              WHERE B.LB_PROJET = '#INEO.V_NOM_PROJET' AND B.DT_JOUR = CONVERT(date, P.DT_CAL, 121) )
