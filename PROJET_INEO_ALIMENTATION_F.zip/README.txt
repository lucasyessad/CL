================================================================================
INEO  -  ALIMENTATION DU DWH DEPUIS LES PROGICIELS SOURCES
================================================================================

Projet complet, en phase de developpement : les scripts creent tout depuis
zero, il n'y a pas de migration de l'existant.

--------------------------------------------------------------------------------
LE PRINCIPE, EN BREF
--------------------------------------------------------------------------------

Tout est pilote par le parametrage, cle par LB_PROJET. Un traitement, un
scenario ODI, un jeu de jobs servent tous les projets : on change les lignes de
parametrage, pas le code.

Le c\oeur du dispositif : DELTA et FULL CONVERGENT. Quel que soit le mode
d'entree, l'etape 004 pose une IMAGE de fin de journee dans le sas - une ligne
par cle, marquee FL_FIN_JOURNEE = 1 - et l'etape 006 compare cette image a la
cible. En DELTA l'image est la derniere trace de chaque cle ; en FULL le
fichier est deja l'image. La suite est identique.

--------------------------------------------------------------------------------
LES TROIS AXES DU PARAMETRAGE
--------------------------------------------------------------------------------

  CD_MODE_ENTREE   DELTA (modifications) | FULL (etat complet)
  CD_FORMAT        BCP | CSV
  CD_MODE_ALIM     SCD2 | SCD1 | AJOUT | AUCUNE

Independants, ils se combinent librement.

--------------------------------------------------------------------------------
LES DEUX TABLES DE PARAMETRAGE
--------------------------------------------------------------------------------

  ORT_PARAM_FLUX               une ligne par table : les trois axes, le format,
                               les schemas, la source, la cible, l'ordre
  ORT_PARAM_HISTORISATION_TRACES   une ligne par colonne : mapping et roles

Il n'y a pas de vue : les traitements lisent les deux tables directement. Le
controle 8 verifie qu'elles restent d'accord.

Toutes les tables portent LB_PROJET. PK et index uniquement, aucune autre
contrainte : la coherence est verifiee par 6_CONTROLES, pas par des CHECK.

--------------------------------------------------------------------------------
CONTENU, DANS L'ORDRE DE DEPLOIEMENT
--------------------------------------------------------------------------------

1_PARAMETRAGE
  01  les deux tables de parametrage + premiere alimentation dynamique
  02  les quatre procedures PS_ (preparation, chargement csv, controle, cloture)

2_TABLES
  01  PITCOT_PERIODE_REPRISE      05  OWT_TEC_AUDIT_CDC
  02  ORT_BORNE_JOURNEE           06  INIT_MEP (une fois)
  03  ORT_AUDIT_CHARGEMENT
  04  OIT_TEC_AUDIT_CDC

3_GENERATEURS  (a executer sur la base source, la sortie s'execute sur le DWH)
  01-02  vues d'audit et vues CDC        02_bis  vues d'initialisation
  03  genere les tables OIT et OWT       04  genere les archives HISTO
  05  genere le parametrage colonne

4_ODI  (a coller dans les taches du scenario)
  01 a 11, dans l'ordre du scenario. Modes multiples pris en charge par 006,
  perimetre par projet dans 001, 004, 005, 006, 011.

5_EXPLOITATION  (jobs de l'exploitation, completes)
  RIWLIG10  import BCP + appels PS_       RIWLIG13  archivage GDG
  RIWLIG14  chargement CSV               RIWLIN10  import initialisation
  RIWLIG11  scenario ODI                 RIWLIN11  scenario ODI init
  RIWLIG12  ZIP

6_CONTROLES  (separes des executables)
  01  coherence du parametrage (8 controles)
  02  suivi d'exploitation
  03  purge de retention du journal

NOTE_UTILISATION.txt  -  comment declarer une table, une colonne, un fichier,
                         choisir un mode, initialiser, retirer une table.

--------------------------------------------------------------------------------
DONNEES DATEES DANS LE FUTUR
--------------------------------------------------------------------------------

L'etape 001 plafonne la couverture d'extraction a l'instant present :

    IF @fin_extraction > SYSDATETIME() SET @fin_extraction = SYSDATETIME();

Une trace datee dans le futur ne peut donc plus poser de borne sur une journee
pas encore arrivee ni bloquer le quotidien : elle attend dans le sas que sa
journee soit reellement atteinte.

--------------------------------------------------------------------------------
CE QUI A ETE VERIFIE
--------------------------------------------------------------------------------

  - equilibrage BEGIN/CASE/END, TRY/CATCH, transactions et curseurs de chaque
    script ;
  - LB_PROJET present dans toutes les tables et dans tous les filtres ODI ;
  - vocabulaire des modes uniforme (DELTA/FULL, BCP/CSV, SCD2/SCD1/AJOUT/AUCUNE) ;
  - aucune vue, aucune contrainte hors PK ;
  - colonne DT_CAL de PITCOT coherente entre creation, ecriture et lectures
    (un DD_VAL errone du scenario deploye a ete corrige) ;
  - jobs : expansion retardee, labels, codes retour.

Ce qui ne peut pas etre verifie ici : aucun script n'a ete execute. La recette
dans SSMS reste le passage oblige, en priorite l'etape 006 sur un flux de
chaque mode d'alimentation.
================================================================================
