/* ============================================================================
   07_ODS_TRACES_CREATE_TABLE_OIT_HISTO
   A EXECUTER SUR LA BASE D'ARCHIVE (ODS_Traces).
   Recoit la SORTIE du generateur A_LIGIS/05_LIGIS_GEN_TABLES_HISTO.
   Coller ici le contenu de la colonne ScriptComplet.
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR HISTO <<<
