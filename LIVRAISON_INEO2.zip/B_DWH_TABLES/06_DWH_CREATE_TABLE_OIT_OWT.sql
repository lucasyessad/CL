/* ============================================================================
   06_DWH_CREATE_TABLE_OIT_OWT
   A EXECUTER SUR LE DWH.
   Recoit la SORTIE du generateur A_LIGIS/04_LIGIS_GEN_TABLES_OIT_OWT.
   Coller ici le contenu de la colonne ScriptComplet.
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR OIT/OWT <<<
