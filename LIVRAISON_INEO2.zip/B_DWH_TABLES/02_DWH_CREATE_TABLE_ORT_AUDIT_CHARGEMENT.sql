/* ============================================================================
   JOURNAL DU TRAITEMENT  -  dbo.ORT_AUDIT_CHARGEMENT

   Cette table conserve le detail des traitements, des volumes, des statuts
   et des erreurs. Elle constitue le premier point de controle en cas
   d'anomalie.

   ENVIRONNEMENT DE DEVELOPPEMENT :
   la table existante est supprimee puis recreee integralement.

   Toutes les dates techniques utilisent DATETIME2(3).
   Aucune valeur par defaut n'est definie.
   ============================================================================ */

USE [DWH];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

DROP TABLE IF EXISTS dbo.ORT_AUDIT_CHARGEMENT;
GO

CREATE TABLE dbo.ORT_AUDIT_CHARGEMENT
(
    LB_PROJET       nvarchar(50)   NULL,
    LB_CHARGEMENT   nvarchar(100)  NULL,
    LB_SOURCE       nvarchar(200)  NULL,
    LB_CIBLE        nvarchar(200)  NULL,
    NB_LIGNE        int            NULL,
    CD_STATUT       nvarchar(10)   NULL,
    LB_ERREUR       nvarchar(MAX)  NULL,
    DT_DEBUT        datetime2(3)   NULL,
    DT_FIN          datetime2(3)   NULL,
    CD_USR_MAJ      nvarchar(20)   NULL,
    ID_TRT_ALI      numeric        NULL

);
GO

CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_PROJET_DT
    ON dbo.ORT_AUDIT_CHARGEMENT
    (
        LB_PROJET,
        DT_DEBUT
    )
    INCLUDE
    (
        ID_TRT_ALI,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        DT_FIN
    );
GO

CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_SESSION
    ON dbo.ORT_AUDIT_CHARGEMENT
    (
        ID_TRT_ALI,
        LB_PROJET,
        CD_STATUT
    )
    INCLUDE
    (
        LB_SOURCE,
        LB_CIBLE,
        LB_CHARGEMENT,
        NB_LIGNE,
        DT_DEBUT,
        DT_FIN
    );
GO
