#-----------------------------------------------------------------------------#
# SCHEDULE : quotidien, apres le batch LIGIS                                  #
# PROJET   : EXPORT / IMPORT BCP                                              #
# TITRE    : Export des vues CDC vers des fichiers BCP                        #
#-----------------------------------------------------------------------------#
# CODES RETOUR : 0 = OK ; 1 = configuration/connexion SQL ; 2 = export/copie  #
#                3 = ecart de volumetrie entre SQL et le fichier produit      #
#-----------------------------------------------------------------------------#

[CmdletBinding()]
param(
    [string]$ConfigFile = 'export-parameters.json',
    [string]$CheminBat = 'E:\dsi\exploit\parmlib\Chemin.bat'
)

$ErrorActionPreference = 'Stop'
$code = 0
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$workDir = $null
$logDir = $null
$recapFile = $null
$erreur = ''
$dateExtraction = 'INCONNUE'
$sequence = 'INCONNUE'
$recapLines = [System.Collections.Generic.List[string]]::new()

# La transcription demarre AVANT toute autre operation, sur un chemin de repli.
# Sans cela, une panne sur Chemin.bat ou sur le JSON ne laisserait aucune trace
# fichier : or ce sont les deux causes d'echec les plus frequentes.
$logRepli = Join-Path $env:TEMP "EXPORT_$stamp.log"
Start-Transcript -Path $logRepli | Out-Null
$transcriptStarted = $true

function Import-BatEnvironment {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Chemin.bat introuvable : $Path"
    }

    $command = 'call "' + $Path + '" >nul && set'
    $lines = & $env:ComSpec /d /s /c $command

    if ($LASTEXITCODE -ne 0) {
        throw "Echec du chargement de Chemin.bat (code $LASTEXITCODE)."
    }

    foreach ($line in $lines) {
        if ($line -match '^([^=]+)=(.*)$') {
            [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process')
        }
    }
}

# Renvoie le nombre de lignes annonce par bcp, en francais comme en anglais.
# -1 signifie que la ligne n'a pas ete trouvee dans la sortie.
function Get-BcpRowCount {
    param(
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [object[]]$Sortie
    )

    $m = $Sortie |
         Select-String -Pattern '^\s*(\d+)\s+(rows copied|lignes copi(?:e|é)es)\.?\s*$' |
         Select-Object -Last 1

    if ($m) {
        return [long]$m.Matches[0].Groups[1].Value
    }

    return [long]-1
}

try {
    Import-BatEnvironment -Path $CheminBat

    $configPath = if ([IO.Path]::IsPathRooted($ConfigFile)) {
        $ConfigFile
    } else {
        Join-Path $env:parmlib $ConfigFile
    }

    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "Fichier de configuration introuvable : $configPath"
    }

    $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 |
           ConvertFrom-Json -ErrorAction Stop

    $outputDir = $env:datalib
    $logDir = $env:loglib
    $workRoot = Join-Path $outputDir 'work'

    if ([string]::IsNullOrWhiteSpace($outputDir)) { throw 'Variable datalib non definie par Chemin.bat.' }
    if ([string]::IsNullOrWhiteSpace($logDir))    { throw 'Variable loglib non definie par Chemin.bat.' }

    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    New-Item -ItemType Directory -Path $workRoot -Force | Out-Null

    # Bascule de la transcription vers loglib, en conservant ce qui precede.
    Stop-Transcript | Out-Null
    $logFile = Join-Path $logDir "EXPORT_$stamp.log"
    Get-Content -LiteralPath $logRepli | Set-Content -LiteralPath $logFile -Encoding UTF8
    Remove-Item -LiteralPath $logRepli -Force -ErrorAction SilentlyContinue
    Start-Transcript -Path $logFile -Append | Out-Null

    foreach ($identifier in @($cfg.Schema, $cfg.AuditSource)) {
        if ([string]$identifier -notmatch '^[A-Za-z0-9_]+$') {
            throw "Identifiant SQL non autorise : $identifier"
        }
    }

    $schemaSql = ([string]$cfg.Schema).Replace("'", "''")
    $auditSql = ([string]$cfg.AuditSource).Replace("'", "''")

    $tablesQuery = @"
SET NOCOUNT ON;
SELECT ligne
FROM
(
    SELECT 0 AS ordre, N'$auditSql' AS ligne
    UNION ALL
    SELECT DISTINCT 1 AS ordre, STUFF(A.LB_INSTANCE, 1, 4, N'') AS ligne
    FROM [$($cfg.Schema)].[$($cfg.AuditSource)] AS A
    INNER JOIN sys.views AS V
        ON V.name = N'ZBCP_LIGIS_' + STUFF(A.LB_INSTANCE, 1, 4, N'') + N'_V'
    INNER JOIN sys.schemas AS S
        ON S.schema_id = V.schema_id
       AND S.name = N'$schemaSql'
    WHERE A.LB_INSTANCE LIKE N'dbo[_]%'
      AND V.name <> N'ZBCP_LIGIS_${auditSql}_V'
) AS X
ORDER BY ordre, ligne;
"@

    $sqlOutput = & sqlcmd.exe -S $cfg.Server -d $cfg.Database -E -b -h -1 -W -w 65535 -Q $tablesQuery 2>&1
    $sqlExitCode = $LASTEXITCODE

    if ($sqlExitCode -ne 0) {
        throw "Lecture SQL de la liste des vues en echec (code $sqlExitCode) : $($sqlOutput -join ' ')"
    }

    $tables = @(
        $sqlOutput |
        ForEach-Object { ([string]$_).Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )

    if ($tables.Count -eq 0) {
        throw 'Aucune vue a exporter.'
    }

    # MAX et non TOP (1) : toutes les lignes portent la meme valeur, mais un
    # TOP sans ORDER BY n'est pas deterministe.
    $metadataQuery = @"
SET NOCOUNT ON;
SELECT CONVERT(CHAR(8), MAX(DT_EXTRACT), 112)
     + N'|'
     + RIGHT(REPLICATE(N'0', 10) + CONVERT(VARCHAR(20), MAX(NO_SEQUENCE)), 10)
FROM [$($cfg.Schema)].[$($cfg.AuditSource)];
"@

    $metadataOutput = & sqlcmd.exe -S $cfg.Server -d $cfg.Database -E -b -h -1 -W -Q $metadataQuery 2>&1
    $metadataExitCode = $LASTEXITCODE

    if ($metadataExitCode -ne 0) {
        throw "Lecture des metadonnees d'extraction en echec (code $metadataExitCode) : $($metadataOutput -join ' ')"
    }

    $metadata = @(
        $metadataOutput |
        ForEach-Object { ([string]$_).Trim() } |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    ) | Select-Object -First 1

    if ($metadata -notmatch '^(\d{8})\|(\d{10})$') {
        throw "Metadonnees d'extraction invalides : '$metadata'."
    }

    $dateExtraction = $matches[1]
    $sequence = $matches[2]
    $workDir = Join-Path $workRoot "${dateExtraction}_${sequence}"

    if (Test-Path -LiteralPath $workDir) {
        Remove-Item -LiteralPath $workDir -Recurse -Force
    }
    New-Item -ItemType Directory -Path $workDir -Force | Out-Null

    Write-Host "Date d'extraction : $dateExtraction" -ForegroundColor Cyan
    Write-Host "Sequence          : $sequence" -ForegroundColor Cyan
    Write-Host "Repertoire travail: $workDir" -ForegroundColor Cyan

    $listFile = Join-Path $workDir $cfg.ListFileName
    $listContent = @(
        "#DATE_EXTRACTION=$dateExtraction"
        "#SEQUENCE=$sequence"
    ) + $tables
    Set-Content -LiteralPath $listFile -Value $listContent -Encoding UTF8

    $recapFile = Join-Path $logDir "RECAP_EXPORT_${dateExtraction}_${sequence}.txt"

    $totalRows = [long]0
    $totalBytes = [long]0

    foreach ($table in $tables) {
        if ($table -notmatch '^[A-Za-z0-9_]+$') {
            throw "Nom de vue non autorise : $table"
        }

        $source = "$($cfg.Database).$($cfg.Schema).ZBCP_LIGIS_${table}_V"
        $file = Join-Path $workDir "$table.bcp"

        # Nombre de lignes attendu, lu dans la vue elle-meme.
        $countQuery = "SET NOCOUNT ON; SELECT COUNT_BIG(*) FROM [$($cfg.Schema)].[ZBCP_LIGIS_${table}_V];"
        $countOutput = & sqlcmd.exe -S $cfg.Server -d $cfg.Database -E -b -h -1 -W -Q $countQuery 2>&1
        $countExitCode = $LASTEXITCODE
        if ($countExitCode -ne 0) {
            throw "Comptage SQL en echec pour $table (code $countExitCode) : $($countOutput -join ' ')"
        }
        $rowCount = [long]((@($countOutput | ForEach-Object { ([string]$_).Trim() } | Where-Object { $_ }) | Select-Object -First 1))

        Write-Host "Export de $source" -ForegroundColor Cyan
        $bcpOutput = @(& bcp.exe $source out $file -n -S $cfg.Server -T 2>&1)
        $bcpExitCode = $LASTEXITCODE
        $bcpOutput | ForEach-Object { Write-Host $_ }

        if ($bcpExitCode -ne 0) {
            $recapLines.Add("$table|$rowCount|0|0|ECHEC_BCP")
            $code = 2
            throw "BCP OUT en echec pour $table (code $bcpExitCode)."
        }

        # Nombre de lignes reellement ecrites dans le fichier.
        $rowsCopied = Get-BcpRowCount -Sortie $bcpOutput

        # bcp peut rendre 0 en ayant ecrit moins de lignes que prevu. La
        # comparaison est le seul controle qui detecte ce cas.
        if ($rowsCopied -ge 0 -and $rowsCopied -ne $rowCount) {
            $recapLines.Add("$table|$rowCount|$rowsCopied|0|ECART_VOLUMETRIE")
            $code = 3
            throw "Ecart de volumetrie pour $table : $rowCount ligne(s) dans la vue, $rowsCopied exportee(s)."
        }

        $fileSize = if (Test-Path -LiteralPath $file) { (Get-Item -LiteralPath $file).Length } else { 0 }
        if ($fileSize -eq 0 -and $rowCount -gt 0) {
            $recapLines.Add("$table|$rowCount|$rowsCopied|0|FICHIER_VIDE")
            $code = 2
            throw "Fichier vide alors que la vue contient $rowCount ligne(s) : $table."
        }

        $totalRows += $rowCount
        $totalBytes += $fileSize
        $recapLines.Add("$table|$rowCount|$rowsCopied|$fileSize|OK")
    }

    $zipName = "$($cfg.ZipPrefix)_${dateExtraction}_${sequence}.zip"
    $zipPath = Join-Path $outputDir $zipName
    if (Test-Path -LiteralPath $zipPath) {
        Remove-Item -LiteralPath $zipPath -Force
    }

    # Le recap est place dans l'archive AVANT compression : l'import s'en sert
    # pour verifier qu'il charge bien le nombre de lignes exporte.
    $recapDansArchive = Join-Path $workDir 'recap-export.txt'
    $enTete = @(
        "DATE_EXTRACTION=$dateExtraction"
        "SEQUENCE=$sequence"
        "SERVEUR=$($cfg.Server)"
        "BASE=$($cfg.Database)"
        "NB_TABLES=$($tables.Count)"
        ''
        'TABLE|NB_LIGNES_VUE|NB_LIGNES_FICHIER|TAILLE_OCTETS|STATUT'
    )
    Set-Content -LiteralPath $recapDansArchive -Value ($enTete + $recapLines) -Encoding UTF8

    Compress-Archive -Path (Join-Path $workDir '*') -DestinationPath $zipPath -Force

    # Un repertoire cible inexistant transformerait Copy-Item en creation de
    # FICHIER portant ce nom, sans erreur : le controle est indispensable.
    if (-not (Test-Path -LiteralPath $cfg.TargetCopyDir -PathType Container)) {
        $code = 2
        throw "Repertoire de destination introuvable : $($cfg.TargetCopyDir)"
    }
    Copy-Item -LiteralPath $zipPath -Destination $cfg.TargetCopyDir -Force -ErrorAction Stop

    Remove-Item -LiteralPath $workDir -Recurse -Force
    $workDir = $null

    Write-Host "Export termine : $zipName, $($tables.Count) table(s), $totalRows ligne(s)." -ForegroundColor Green
}
catch {
    if ($code -eq 0) { $code = 1 }
    $erreur = $_.Exception.Message
    Write-Host "*** EXPORT EN ECHEC (code $code) : $erreur" -ForegroundColor Red
    if ($workDir) {
        Write-Host "Repertoire de travail conserve : $workDir" -ForegroundColor Yellow
    }
}
finally {
    # Le recap est ecrit dans TOUS les cas, y compris quand l'echec survient
    # avant la boucle : c'est justement la qu'on a besoin de savoir ou on en
    # etait.
    if ($logDir) {
        if (-not $recapFile) {
            $recapFile = Join-Path $logDir "RECAP_EXPORT_${stamp}_ECHEC.txt"
        }
        $entete = @(
            "DATE_EXTRACTION=$dateExtraction"
            "SEQUENCE=$sequence"
            "DATE_FIN=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "STATUT_GLOBAL=$(if ($code -eq 0) { 'OK' } else { 'KO' })"
            "CODE_RETOUR=$code"
            "ERREUR=$erreur"
            ''
            'TABLE|NB_LIGNES_VUE|NB_LIGNES_FICHIER|TAILLE_OCTETS|STATUT'
        )
        Set-Content -LiteralPath $recapFile -Value ($entete + $recapLines) -Encoding UTF8

        # Retention : sans purge, les journaux et les archives s'accumulent
        # indefiniment sur un partage reseau.
        $jours = if ($cfg -and $cfg.RetentionJours) { [int]$cfg.RetentionJours } else { 30 }
        if ($jours -gt 0) {
            $limite = (Get-Date).AddDays(-$jours)
            Get-ChildItem -LiteralPath $logDir -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -lt $limite -and $_.Name -like 'EXPORT_*' } |
                Remove-Item -Force -ErrorAction SilentlyContinue
            Get-ChildItem -LiteralPath $logDir -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -lt $limite -and $_.Name -like 'RECAP_EXPORT_*' } |
                Remove-Item -Force -ErrorAction SilentlyContinue
            if ($env:datalib) {
                Get-ChildItem -LiteralPath $env:datalib -File -Filter '*.zip' -ErrorAction SilentlyContinue |
                    Where-Object { $_.LastWriteTime -lt $limite } |
                    Remove-Item -Force -ErrorAction SilentlyContinue
            }
        }
    }
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}

exit $code
