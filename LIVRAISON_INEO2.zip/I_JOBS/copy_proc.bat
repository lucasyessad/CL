@echo off

rem --- copie fichier 

echo.
echo --- Copie du fichier %infile% vers %outfile% ---
echo.

copy /y %infile% %outfile%


echo.
echo code retour = %ERRORLEVEL%
echo.

rem set RC=%ERRORLEVEL%

rem IF %RC% EQU 0 goto FINOK 

rem --- si pb 
rem echo %rc%
rem echo Attention PB

rem call %PROCLIB%\CompteRendu_Fin_Anormale 
rem goto FINKO

rem :FINOK
rem echo %rc%
rem echo tout ok 

rem call %PROCLIB%\CompteRendu_Fin_normale 

rem :FINKO