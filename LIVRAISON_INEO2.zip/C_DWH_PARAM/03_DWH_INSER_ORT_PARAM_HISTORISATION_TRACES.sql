/* ============================================================================
   03_DWH_INSER_ORT_PARAM_HISTORISATION_TRACES
   A EXECUTER SUR LE DWH, apres 02 (table creee).
   Recoit la SORTIE du generateur A_LIGIS/06_LIGIS_GEN_PARAMETRAGE.
   Coller ici le contenu de la colonne ScriptComplet.
   C'est le PREMIER remplissage : ORT_PARAM_FLUX (04) le lit ensuite.
   ============================================================================ */

-- >>> COLLER ICI LA SORTIE DU GENERATEUR DE PARAMETRAGE <<<
