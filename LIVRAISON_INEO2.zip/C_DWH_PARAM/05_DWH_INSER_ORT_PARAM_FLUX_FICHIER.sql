/* ============================================================================
   05_DWH_INSER_ORT_PARAM_FLUX_FICHIER
   A EXECUTER SUR LE DWH. Saisie MANUELLE, une ligne par fichier delimite.

   Les fichiers ne sont pas dans le CDC : ils se declarent a la main. Les
   colonnes de ces flux doivent aussi etre saisies dans
   ORT_PARAM_HISTORISATION_TRACES (le generateur ne les connait pas).

   Exemple renseigne, a adapter puis decommenter.
   ============================================================================ */

/*
INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, FL_INIT, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    LB_FICHIER, LB_REPERTOIRE, LB_DELIMITEUR, NO_LIGNE_DEBUT, LB_ENCODAGE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
VALUES
(
    N'LIGIS', N'OIT_PITOPE_TABLEREF', N'OWT_PITOPE_TABLEREF', NULL,
    N'FULL', N'CSV', N'SCD1',
    1, 0, 900, NULL,
    N'ods', N'dbo', NULL, NULL,
    N'PITOPE_TABLEREF.csv', N'\\kenya\dsi\datalib', N';', 2, N'65001',
    SYSDATETIME(), N'INIT', N'Referentiel livre en CSV, etat courant'
);
GO
*/
