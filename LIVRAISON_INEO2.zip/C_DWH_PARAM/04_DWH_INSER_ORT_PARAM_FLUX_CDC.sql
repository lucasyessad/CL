/* ============================================================================
   04_DWH_INSER_ORT_PARAM_FLUX_CDC
   A EXECUTER SUR LE DWH, apres 03 (parametrage colonne rempli).

   Cree une ligne DELTA + BCP + SCD2 par table decrite au grain colonne, avec
   la cible et la source reprises de la ligne cle. Se joue tel quel.
   Ajuster ensuite par UPDATE si une table doit etre en SCD1, AJOUT ou AUCUNE.
   ============================================================================ */

INSERT INTO dbo.ORT_PARAM_FLUX
(
    LB_PROJET, LB_TABLE_ODS, LB_TABLE_DWH, LB_SOURCE,
    CD_MODE_ENTREE, CD_FORMAT, CD_MODE_ALIM,
    FL_ACTIF, FL_INIT, NO_ORDRE, LB_FILTRE_WHERE,
    LB_SCHEMA_ODS, LB_SCHEMA_DWH, LB_TABLE_AUDIT, HR_FRONTIERE,
    DT_MAJ, CD_USR_MAJ, LB_COMMENTAIRE
)
SELECT
    S.LB_PROJET, S.LB_TABLE_ODS, S.LB_TABLE_DWH, S.LB_SOURCE,
    N'DELTA', N'BCP', N'SCD2',
    1, 0, 100 + (ROW_NUMBER() OVER (ORDER BY S.LB_TABLE_ODS)) * 10, S.LB_FILTRE_WHERE,
    N'ods', N'dbo', N'OIT_TEC_AUDIT_CDC', '07:45:00',
    SYSDATETIME(), N'INIT', N'Flux CDC cree depuis le parametrage colonne'
FROM
(
    SELECT T.LB_PROJET, T.LB_TABLE_ODS, T.LB_TABLE_DWH, T.LB_SOURCE, T.LB_FILTRE_WHERE,
           Rang = ROW_NUMBER() OVER
           (
               PARTITION BY T.LB_PROJET, T.LB_TABLE_ODS
               ORDER BY CASE WHEN T.FL_CLEF = 1 THEN 0 ELSE 1 END, T.NO_CHAMP
           )
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
) AS S
WHERE S.Rang = 1
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
      WHERE F.LB_PROJET = S.LB_PROJET AND F.LB_TABLE_ODS = S.LB_TABLE_ODS
  );
GO
