SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_CLOTURE_INIT_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT = NULL
)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @nb_cloture INT, @nb_restant INT;

    UPDATE dbo.ORT_PARAM_FLUX
    SET FL_INIT    = 0,
        DT_MAJ     = SYSDATETIME(),
        CD_USR_MAJ = N'INIT'
    WHERE LB_PROJET = @LB_PROJET
      AND FL_INIT   = 1;

    SET @nb_cloture = @@ROWCOUNT;

    SELECT @nb_restant = COUNT(*)
    FROM dbo.ORT_PARAM_FLUX
    WHERE LB_PROJET = @LB_PROJET AND FL_INIT = 1;

    INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
         NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES
        (@ID_TRT_ALI, @LB_PROJET, N'Cloture initialisation', N'*TOUTES*', NULL,
         @nb_cloture, N'OK', NULL, SYSDATETIME(), SYSDATETIME());

    SELECT NB_CLOTURE = @nb_cloture, NB_RESTANT = @nb_restant;
END;
GO
