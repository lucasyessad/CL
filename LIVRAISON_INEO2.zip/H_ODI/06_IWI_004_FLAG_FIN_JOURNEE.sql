-- schema logique : MSSQL_DWH
-- type : S

/* ============================================================================
   IWI.004  -  FLAG DE L'IMAGE DE FIN DE JOURNEE

   Marque dans le sas la ligne qui represente l'etat de fin de journee de
   chaque cle. C'est cette image que l'etape 006 comparera a la cible, sans
   avoir a connaitre le mode d'entree.

     DELTA   plusieurs traces par cle dans la fenetre. On garde la derniere,
             au sens des colonnes d'ordre.
     FULL    le sas contient deja un etat complet, une ligne par cle. Tout est
             donc l'image : on flague toutes les lignes de la fenetre.

   Apres cette etape, l'image est toujours "les lignes FL_FIN_JOURNEE = 1",
   quel que soit le mode.
   ============================================================================ */

DECLARE @DT_TRACES  DATE          = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'#INEO.V_NOM_PROJET';
DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(500),
        @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

/* Fenetre : ] borne(J-1) ; borne(J) ] */
SELECT @dt_fin = DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR = @DT_TRACES AND LB_PROJET = @LB_PROJET;

SELECT @dt_deb = MAX(DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR < @DT_TRACES AND LB_PROJET = @LB_PROJET;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + @jour + N'.';
    THROW 50011, @msg, 1;
END

DECLARE @tbl_ods NVARCHAR(128), @entree NVARCHAR(10),
        @cle NVARCHAR(MAX), @ordre NVARCHAR(MAX), @col_fen NVARCHAR(128),
        @filtre NVARCHAR(1000), @src NVARCHAR(400), @sql NVARCHAR(MAX),
        @nb INT, @dt_step DATETIME;

/* Flux DELTA et FULL : les deux ont une image a poser. */
DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.CD_MODE_ENTREE
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ALIM <> N'AUCUNE'
      AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1)
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @entree;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SELECT @cle = NULL, @ordre = NULL, @col_fen = NULL, @filtre = NULL;

        SELECT @cle = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET = @LB_PROJET AND LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1 AND LB_CHAMP_ODS IS NOT NULL;

        SELECT @ordre = STRING_AGG(QUOTENAME(LB_CHAMP_ODS) + N' DESC', N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET = @LB_PROJET AND LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL;

        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_PROJET = @LB_PROJET AND LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        SELECT @filtre = ISNULL(F.LB_FILTRE_WHERE, N'')
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
        WHERE F.LB_PROJET = @LB_PROJET AND F.LB_TABLE_ODS = @tbl_ods;

        IF @cle IS NULL
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods + N' (aucune colonne cle).';
            THROW 50032, @msg, 1;
        END

        /* Remise a zero sur la fenetre : idempotent. */
        SET @sql = N'UPDATE ' + @src + N' SET FL_FIN_JOURNEE = 0'
                 + N' WHERE ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin'
                 + CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3)',
             @p_deb = @dt_deb, @p_fin = @dt_fin;

        IF @entree = N'DELTA'
        BEGIN
            /* Derniere trace par cle. */
            IF @ordre IS NULL
            BEGIN
                SET @msg = N'Flux DELTA sans colonne d''ordre : ' + @tbl_ods + N'.';
                THROW 50033, @msg, 1;
            END
            SET @sql = N';WITH cte AS ('
                     + N'  SELECT FL_FIN_JOURNEE, ROW_NUMBER() OVER (PARTITION BY ' + @cle
                     + N'    ORDER BY ' + @ordre + N') AS rn_ort'
                     + N'  FROM ' + @src
                     + N'  WHERE ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin'
                     + CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END
                     + N') UPDATE cte SET FL_FIN_JOURNEE = 1 WHERE rn_ort = 1;'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
        END
        ELSE
        BEGIN
            /* FULL : tout le sas est l'image, une ligne par cle. */
            SET @sql = N'UPDATE ' + @src + N' SET FL_FIN_JOURNEE = 1'
                     + N' WHERE ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin'
                     + CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';'
                     + N' SELECT @p_nb = @@ROWCOUNT;';
        END

        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb OUTPUT;

        IF @nb = 0
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_ods, 0, N'OK',
                    N'AVERTISSEMENT: aucune ligne sur la fenetre - cible non modifiee.', @dt_step, GETDATE());
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_ods, 0, N'KO',
                N'FLAG : ' + ERROR_MESSAGE(), @dt_step, GETDATE());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @entree;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
