-- schema logique : MSSQL_DWH
-- type : S

DELETE FROM <?=odiRef.getObjectName("L", "ORT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = '#INEO.V_NOM_PROJET'
