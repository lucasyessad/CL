-- schema logique : MSSQL_DWH
-- type : S

DECLARE @ID_TRT_ALI INT = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @H_FRONTIERE TIME(0) = '07:45:00';

DECLARE
    @fin_extraction    DATETIME2(3),
    @nb_inst_sans_date INT,
    @dt_jour_prec      DATE,
    @jour              DATE,
    @jour_suivant      DATE,
    @frontiere         DATETIME2(3),
    @nb_bornes         INT = 0,
    @premiere          DATE,
    @derniere          DATE,
    @dt_step           DATETIME2(3) = SYSDATETIME(),
    @dt_pose           DATETIME2(3);
    
/* ============================================================================
   1. DETERMINATION DE LA COUVERTURE COMMUNE DE L'EXTRACTION
============================================================================ */

/* Seuls les flux DELTA dependent de la capture. L'instance est lue dans
   ORT_PARAM_FLUX.LB_SOURCE plutot que reconstruite a partir du nom de table. */
SELECT
    @fin_extraction = MIN(A.DT_FIN_LSN),
    @nb_inst_sans_date = SUM (CASE WHEN A.DT_FIN_LSN IS NULL THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUDIT_CDC", "MSSQL_ODS", "D") ?> AS A
WHERE A.LB_INSTANCE IN
(
    SELECT DISTINCT F.LB_SOURCE
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ENTREE = N'DELTA'
      AND F.LB_SOURCE IS NOT NULL
);

/* Un projet sans aucun flux DELTA n'a pas d'extraction a attendre : sa
   couverture est l'instant present, et chaque journee dont la frontiere est
   passee devient eligible. Les flux FULL et CSV sont ainsi traites sans
   dependre d'une capture qui n'existe pas. */
IF NOT EXISTS
(
    SELECT 1
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ENTREE = N'DELTA'
)
BEGIN
    SET @fin_extraction = SYSDATETIME();
    SET @nb_inst_sans_date = 0;
END;

/* Plafond a l'instant present. Une trace dont la date de commit est dans le
   futur - horloge source dereglee, saisie manuelle - tirerait la couverture
   au-dela d'aujourd'hui et poserait des bornes sur des journees pas encore
   arrivees, ce qui bloquerait le quotidien. On borne donc la couverture a
   maintenant : les journees passees se traitent normalement, et la trace au
   futur reste dans le sas jusqu'a ce que sa journee soit reellement atteinte. */
IF @fin_extraction > SYSDATETIME()
    SET @fin_extraction = SYSDATETIME();

/* Si la couverture commune ne peut pas être déterminée,
   aucune journée n'est traitée. */

IF @fin_extraction IS NULL OR ISNULL(@nb_inst_sans_date, 0) > 0
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'POSE BORNE',
        N'OIT_TEC_AUDIT_CDC',
        N'ORT_BORNE_JOURNEE',
        0,
        N'OK',
        N'AVERTISSEMENT: couverture d''extraction indeterminable ('
        + CONVERT ( NVARCHAR(10), ISNULL(@nb_inst_sans_date, 0) )
        + N' instance(s) sans DT_FIN_LSN, ou audit vide). '
        + N'Aucune journee eligible : mieux vaut attendre que traiter '
        + N'une periode dont on ignore ou elle s''arrete.',
        @dt_step,
        SYSDATETIME()
    );

    RETURN;
END;


/* ============================================================================
   2. RECUPERATION DE LA DERNIERE JOURNEE DEJA BORNEE
============================================================================ */

SELECT @dt_jour_prec = MAX(CONVERT(DATE, DT_JOUR))
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE LB_PROJET = @LB_PROJET;

/* Une borne INIT doit avoir été créée avant le traitement quotidien. */

IF @dt_jour_prec IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (
        ID_TRT_ALI,
        LB_PROJET,
        LB_CHARGEMENT,
        LB_SOURCE,
        LB_CIBLE,
        NB_LIGNE,
        CD_STATUT,
        LB_ERREUR,
        DT_DEBUT,
        DT_FIN
    )
    VALUES
    (
        @ID_TRT_ALI,
        @LB_PROJET,
        N'POSE BORNE',
        N'OIT_TEC_AUDIT_CDC',
        N'ORT_BORNE_JOURNEE',
        0,
        N'OK',
        N'AVERTISSEMENT: aucune borne initiale '
        + N'(TYPE_BORNE = INIT). '
        + N'Executer 01_INIT_MEP_ONE_SHOT.sql.',
        @dt_step,
        SYSDATETIME()
    );

    RETURN;
END;

/* ============================================================================
   3. POSE DES BORNES QUOTIDIENNES

   Une borne est créée uniquement lorsque l'extraction couvre entièrement
   la journée fonctionnelle jusqu'à la frontière du jour ouvrable suivant.
============================================================================ */

WHILE 1 = 1
BEGIN
    SET @jour = NULL;
    SET @jour_suivant = NULL;
    SET @frontiere = NULL;

    /* Première journée ouvrable non encore bornée. */
    SELECT TOP (1) @jour = CONVERT(DATE, DT_CAL)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND CONVERT(DATE, DT_CAL) > @dt_jour_prec
    ORDER BY DT_CAL;

    /* Calendrier épuisé. */
    IF @jour IS NULL BREAK;

    /* Journée ouvrable suivante permettant de calculer la frontière. */
    SELECT TOP (1) @jour_suivant = CONVERT(DATE, DT_CAL)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND CONVERT(DATE, DT_CAL) > @jour
    ORDER BY DT_CAL;

    /* La frontière ne peut pas être calculée.
       Le calendrier PRTCAL doit être prolongé. */
    IF @jour_suivant IS NULL BREAK;

    SET @frontiere =
        DATETIME2FROMPARTS
        (
            DATEPART(YEAR,  @jour_suivant),
            DATEPART(MONTH, @jour_suivant),
            DATEPART(DAY,   @jour_suivant),
            DATEPART(HOUR,   @H_FRONTIERE),
            DATEPART(MINUTE, @H_FRONTIERE),
            0,
            0,
            3
        );

    /* La journée n'est pas encore entièrement couverte par l'extraction. */
    IF @fin_extraction < @frontiere BREAK;
    SET @dt_pose = SYSDATETIME();

    INSERT INTO <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
    (
        LB_PROJET,
        DT_JOUR,
        DT_BORNE,
        TYPE_BORNE,
        ORIGINE_VALEUR,
        DT_POSE,
        COMMENTAIRE
    )
    VALUES
    (
        @LB_PROJET,
        CONVERT(DATETIME2(3), @jour),
        @frontiere,
        N'QUOTIDIEN',
        N'AUDIT_CDC',
        @dt_pose,
        N'Borne posee automatiquement a partir de la couverture '
        + N'OIT_TEC_AUDIT_CDC. Fin extraction commune : '
        + CONVERT(NVARCHAR(23), @fin_extraction, 121)
    );

    IF @nb_bornes = 0
       SET @premiere = @jour;

    SET @derniere = @jour;
    SET @nb_bornes = @nb_bornes + 1;
    SET @dt_jour_prec = @jour;
END;


/* ============================================================================
   4. AUDIT RECAPITULATIF
============================================================================ */

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
(
    ID_TRT_ALI,
    LB_PROJET,
    LB_CHARGEMENT,
    LB_SOURCE,
    LB_CIBLE,
    NB_LIGNE,
    CD_STATUT,
    LB_ERREUR,
    DT_DEBUT,
    DT_FIN
)
VALUES
(
    @ID_TRT_ALI,
    @LB_PROJET,
    N'POSE BORNE',
    N'OIT_TEC_AUDIT_CDC',
    N'ORT_BORNE_JOURNEE',
    @nb_bornes,
    N'OK',

    CASE
        WHEN @nb_bornes = 0
        THEN
            N'IGNORE: extraction arretee au '
            + CONVERT(NVARCHAR(23), @fin_extraction, 121)
            + N'. Journee suivante non encore complete, frontiere : '
            + ISNULL
              (
                  CONVERT(NVARCHAR(23), @frontiere, 121),
                  N'inconnue'
              )
            + N'.'

        ELSE
            N'Extraction au '
            + CONVERT(NVARCHAR(23), @fin_extraction, 121)
            + N' : '
            + CONVERT(NVARCHAR(10), @nb_bornes)
            + N' journee(s) bornee(s) du '
            + CONVERT(NVARCHAR(10), @premiere, 23)
            + N' au '
            + CONVERT(NVARCHAR(10), @derniere, 23)
            + CASE
                WHEN @nb_bornes > 1
                    THEN N' (rattrapage).'
                ELSE N' (quotidien).'
              END
    END,

    @dt_step,
    SYSDATETIME()
);
