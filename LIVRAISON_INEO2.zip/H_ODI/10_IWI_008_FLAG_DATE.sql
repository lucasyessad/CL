-- schema logique : MSSQL_DWH
-- type : S

UPDATE <?=odiRef.getObjectName("L", "ORT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = '#INEO.V_NOM_PROJET'
  AND DT_CAL <= '#INEO.V_IWI_LIGIS_DT_TRACES'
  AND TRAITE = 0
