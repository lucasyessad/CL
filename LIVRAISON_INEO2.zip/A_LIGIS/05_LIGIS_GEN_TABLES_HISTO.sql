/* ============================================================================
   GENERATEUR DES TABLES D'ARCHIVE

   A EXECUTER SUR LA BASE LIGIS.
   La sortie generee doit ensuite etre executee sur la base ODS_Traces.

   ----------------------------------------------------------------------------
   CONTRAT COMMUN AUX SCRIPTS 03, 04 ET 05
   ----------------------------------------------------------------------------
   Les trois generateurs lisent la MEME source de colonnes :
       export_cdc.ZBCP_LIGIS_<TABLE>_V
   et partagent le meme perimetre, la meme resolution de cle metier et les
   memes noms de colonnes techniques.

   Colonnes techniques CDC, portees par la vue :
       ID_INSTANCE_TEC, NO_SEQUENCE_TEC, LB_SEQVAL_TEC,
       CD_DML_TEC, DT_COMMIT_TEC, LB_LSN_COMMIT_TEC
   Colonne de flag, portee par la vue, en derniere position :
       FL_FIN_JOURNEE

   Resolution de la cle metier, dans cet ordre :
       1. cle primaire source, si toutes ses colonnes sont exposees par la vue
       2. cle manuelle declaree, si toutes ses colonnes sont exposees
       3. index unique non filtre, si toutes ses colonnes sont exposees
          (desactivable par @AutoriserIndexUnique)

   ----------------------------------------------------------------------------
   STRUCTURE DE L'ARCHIVE
   ----------------------------------------------------------------------------
   La table d'archive reproduit la table OIT a l'identique, colonne pour
   colonne et dans le meme ordre, ce qui permet une copie sans transformation.
   FL_FIN_JOURNEE est conservee : elle indique quelle trace a servi d'image.

   Quatre colonnes d'archivage sont ajoutees en fin :
       DT_JOUR_TEC   journee de rattachement de la trace
       DT_MAJ_TRT    date d'archivage
       CD_USR_MAJ    utilisateur ou traitement d'archivage
       ID_TRT_ALI    numero de session ODI

   Index generes :
       UX_..._TRACE       unique sur (LB_LSN_COMMIT_TEC, LB_SEQVAL_TEC),
                          le couple qui identifie une trace CDC ; rend la
                          copie rejouable
       IX_..._JOUR        consultation et purge par journee
       IX_..._CLE_METIER  consultation par cle metier, si une cle est resolue
   ============================================================================ */

DROP TABLE IF EXISTS ##TableListHisto;
GO

CREATE TABLE ##TableListHisto
(
    TableNameSource   sysname       NOT NULL,
    ViewNameSource    sysname       NOT NULL,
    TableNameHisto    sysname       NOT NULL,
    NbColonnesVue     int           NULL,
    SourceCleMetier   nvarchar(30)  NULL,
    ColonnesCleMetier nvarchar(MAX) NULL,
    NbColonnesCle     int           NOT NULL DEFAULT (0),
    CreateScript      nvarchar(MAX) NULL,
    MessageControle   nvarchar(500) NULL,

    CONSTRAINT PK_TableListHisto
        PRIMARY KEY CLUSTERED (TableNameSource)
);
GO

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @SchemaSource sysname = N'dbo';
DECLARE @SchemaVue    sysname = N'export_cdc';
DECLARE @BaseHisto    sysname = N'ODS_Traces';   -- base sur laquelle executer la sortie
DECLARE @SchemaHisto  sysname = N'ods';

/* Autorise l'usage d'un index unique comme cle metier lorsque la table n'a ni
   cle primaire ni cle manuelle declaree. */
DECLARE @AutoriserIndexUnique bit = 1;

/* ----------------------------------------------------------------------------
   CLES MANUELLES
   >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
       Toute modification doit etre reportee dans les trois.
---------------------------------------------------------------------------- */
DECLARE @ClesManuelles TABLE
(
    TableNameSource sysname NOT NULL,
    ColumnName      sysname NOT NULL,
    KeyOrdinal      int     NOT NULL,
    PRIMARY KEY (TableNameSource, ColumnName)
);

INSERT INTO @ClesManuelles
(
    TableNameSource,
    ColumnName,
    KeyOrdinal
)
VALUES
    (N'DECOMPTE_CONTRATS', N'DECOMPTE_ID', 1),
    (N'DECOMPTE_CONTRATS', N'CONTRAT_ID',  2),
    (N'GARANTIE_CONTRATS', N'GARANTIE_ID', 1),
    (N'GARANTIE_CONTRATS', N'CONTRAT_ID',  2);

/* ----------------------------------------------------------------------------
   PERIMETRE : tables sous CDC disposant d'une vue d'export.
   >>> REQUETE IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
---------------------------------------------------------------------------- */
INSERT INTO ##TableListHisto
(
    TableNameSource,
    ViewNameSource,
    TableNameHisto
)
SELECT DISTINCT
    T.name,
    N'ZBCP_LIGIS_' + T.name + N'_V',
    N'OIT_' + T.name + N'_HISTO'
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON S.schema_id = T.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS A
    ON A.LB_INSTANCE COLLATE DATABASE_DEFAULT =
       (@SchemaSource + N'_' + T.name) COLLATE DATABASE_DEFAULT
WHERE S.name = @SchemaSource
  AND EXISTS
  (
      SELECT 1
      FROM sys.views AS V
      INNER JOIN sys.schemas AS VS
          ON VS.schema_id = V.schema_id
      WHERE VS.name = @SchemaVue
        AND V.name = N'ZBCP_LIGIS_' + T.name + N'_V'
  );

/* Colonnes d'archivage ajoutees en fin de table. */
DECLARE @TechColsArchive nvarchar(MAX) =
      N'[DT_JOUR_TEC] datetime2(3) NULL,' + CHAR(13)
    + N'        [DT_MAJ_TRT] datetime2(3) NULL,' + CHAR(13)
    + N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13)
    + N'        [ID_TRT_ALI] bigint NULL';

DECLARE
    @TableNameSource   sysname,
    @ViewNameSource    sysname,
    @TableNameHisto    sysname,
    @ViewObjectId      int,
    @SourceObjectId    int,
    @IndexCleObjectId  int,
    @IndexCleId        int,
    @SourceCleMetier   nvarchar(30),
    @ColonnesCleMetier nvarchar(MAX),
    @NbColonnesCle     int,
    @NbColonnesVue     int,
    @ColsHisto         nvarchar(MAX),
    @Create            nvarchar(MAX),
    @Message           nvarchar(500);

DECLARE cur_histo CURSOR LOCAL FAST_FORWARD FOR
    SELECT
        TableNameSource,
        ViewNameSource,
        TableNameHisto
    FROM ##TableListHisto
    ORDER BY TableNameSource;

OPEN cur_histo;
FETCH NEXT FROM cur_histo
INTO @TableNameSource, @ViewNameSource, @TableNameHisto;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @ViewObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaVue) + N'.' + QUOTENAME(@ViewNameSource)
    );

    SET @SourceObjectId = OBJECT_ID
    (
        QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource)
    );

    SELECT
        @ColsHisto = NULL,
        @IndexCleObjectId = NULL,
        @IndexCleId = NULL,
        @SourceCleMetier = NULL,
        @ColonnesCleMetier = NULL,
        @NbColonnesCle = 0,
        @NbColonnesVue = 0,
        @Message = N'OK';

    /* ------------------------------------------------------------------------
       Colonnes de la vue.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #ViewCols;

    SELECT
        C.column_id,
        ColumnName = C.name,
        QuotedName = QUOTENAME(C.name),
        TypeDefinition =
            CASE
                WHEN TY.name IN (N'varchar', N'char', N'varbinary', N'binary')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length)
                         END
                       + N')'

                WHEN TY.name IN (N'nvarchar', N'nchar')
                    THEN TY.name + N'('
                       + CASE
                             WHEN C.max_length = -1 THEN N'MAX'
                             ELSE CONVERT(nvarchar(10), C.max_length / 2)
                         END
                       + N')'

                WHEN TY.name IN (N'decimal', N'numeric')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N','
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name IN (N'datetime2', N'time', N'datetimeoffset')
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.scale) + N')'

                WHEN TY.name = N'float'
                    THEN TY.name + N'('
                       + CONVERT(nvarchar(10), C.precision) + N')'

                ELSE TY.name
            END,
        NullClause =
            CASE WHEN C.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
    INTO #ViewCols
    FROM sys.columns AS C
    INNER JOIN sys.types AS TY
        ON TY.user_type_id = C.user_type_id
    WHERE C.object_id = @ViewObjectId;

    SELECT @NbColonnesVue = COUNT(*)
    FROM #ViewCols;

    IF @NbColonnesVue = 0
        SET @Message = N'Vue BCP sans colonne exploitable.';

    /* ------------------------------------------------------------------------
       Resolution de la cle metier.
       >>> BLOC IDENTIQUE DANS LES SCRIPTS 03, 04 ET 05.
    ------------------------------------------------------------------------ */
    DROP TABLE IF EXISTS #KeyCols;

    CREATE TABLE #KeyCols
    (
        name        sysname COLLATE DATABASE_DEFAULT NOT NULL,
        key_ordinal int NOT NULL,
        is_desc     bit NOT NULL DEFAULT (0),
        PRIMARY KEY (name)
    );

    /* 1. Cle primaire source, entierement exposee par la vue. */
    IF EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
    )
    AND NOT EXISTS
    (
        SELECT 1
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK'
          AND NOT EXISTS
          (
              SELECT 1
              FROM #ViewCols AS V
              WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                    C.name COLLATE DATABASE_DEFAULT
          )
    )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT C.name, IC.key_ordinal, IC.is_descending_key
        FROM sys.key_constraints AS KC
        INNER JOIN sys.index_columns AS IC
            ON IC.object_id = KC.parent_object_id
           AND IC.index_id = KC.unique_index_id
           AND IC.key_ordinal > 0
        INNER JOIN sys.columns AS C
            ON C.object_id = IC.object_id
           AND C.column_id = IC.column_id
        WHERE KC.parent_object_id = @SourceObjectId
          AND KC.type = N'PK';

        SET @SourceCleMetier = N'PRIMARY KEY';
    END;

    /* 2. Sinon, cle manuelle declaree, entierement exposee par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
       )
       AND NOT EXISTS
       (
           SELECT 1
           FROM @ClesManuelles AS M
           WHERE M.TableNameSource = @TableNameSource
             AND NOT EXISTS
             (
                 SELECT 1
                 FROM #ViewCols AS V
                 WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                       M.ColumnName COLLATE DATABASE_DEFAULT
             )
       )
    BEGIN
        INSERT INTO #KeyCols (name, key_ordinal, is_desc)
        SELECT M.ColumnName, M.KeyOrdinal, 0
        FROM @ClesManuelles AS M
        WHERE M.TableNameSource = @TableNameSource;

        SET @SourceCleMetier = N'CLE MANUELLE';
    END;

    /* 3. Sinon, index unique non filtre, entierement expose par la vue. */
    IF NOT EXISTS (SELECT 1 FROM #KeyCols)
       AND @AutoriserIndexUnique = 1
    BEGIN
        SELECT TOP (1)
            @IndexCleObjectId = I.object_id,
            @IndexCleId = I.index_id
        FROM sys.indexes AS I
        WHERE I.object_id = @SourceObjectId
          AND I.is_unique = 1
          AND I.is_primary_key = 0
          AND I.is_disabled = 0
          AND I.is_hypothetical = 0
          AND I.has_filter = 0
          AND NOT EXISTS
          (
              SELECT 1
              FROM sys.index_columns AS IC
              INNER JOIN sys.columns AS C
                  ON C.object_id = IC.object_id
                 AND C.column_id = IC.column_id
              WHERE IC.object_id = I.object_id
                AND IC.index_id = I.index_id
                AND IC.key_ordinal > 0
                AND NOT EXISTS
                (
                    SELECT 1
                    FROM #ViewCols AS V
                    WHERE V.ColumnName COLLATE DATABASE_DEFAULT =
                          C.name COLLATE DATABASE_DEFAULT
                )
          )
        ORDER BY
            (
                SELECT COUNT(*)
                FROM sys.index_columns AS IC_Count
                WHERE IC_Count.object_id = I.object_id
                  AND IC_Count.index_id = I.index_id
                  AND IC_Count.key_ordinal > 0
            ),
            I.index_id;

        IF @IndexCleId IS NOT NULL
        BEGIN
            INSERT INTO #KeyCols (name, key_ordinal, is_desc)
            SELECT C.name, IC.key_ordinal, IC.is_descending_key
            FROM sys.index_columns AS IC
            INNER JOIN sys.columns AS C
                ON C.object_id = IC.object_id
               AND C.column_id = IC.column_id
            WHERE IC.object_id = @IndexCleObjectId
              AND IC.index_id = @IndexCleId
              AND IC.key_ordinal > 0;

            SET @SourceCleMetier = N'INDEX UNIQUE';
        END;
    END;

    SELECT
        @NbColonnesCle = COUNT(*),
        @ColonnesCleMetier = STRING_AGG
        (
            CONVERT(nvarchar(MAX), QUOTENAME(name)),
            N', '
        ) WITHIN GROUP (ORDER BY key_ordinal)
    FROM #KeyCols;

    IF @NbColonnesCle = 0 AND @Message = N'OK'
        SET @Message = N'Aucune cle metier exploitable : archive sans index metier.';

    /* ------------------------------------------------------------------------
       Colonnes de l'archive : copie conforme de la vue, donc de la table OIT.
    ------------------------------------------------------------------------ */
    SELECT
        @ColsHisto = STRING_AGG
        (
            CONVERT
            (
                nvarchar(MAX),
                N'        ' + QuotedName + N' ' + TypeDefinition + NullClause
            ),
            N',' + CHAR(13)
        ) WITHIN GROUP (ORDER BY column_id)
    FROM #ViewCols;

    SET @Create =
          N'DROP TABLE IF EXISTS '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N';'
        + CHAR(13) + CHAR(13)
        + N'CREATE TABLE '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto) + N' (' + CHAR(13)
        + @ColsHisto + N',' + CHAR(13)
        + N'        ' + @TechColsArchive + CHAR(13)
        + N');' + CHAR(13)

        /* Anti-doublon : le couple LSN + sequence identifie une trace CDC.
           Le LSN seul ne suffit pas, une transaction pouvant porter plusieurs
           modifications. */
        + N'CREATE UNIQUE NONCLUSTERED INDEX '
        + QUOTENAME(N'UX_' + @TableNameHisto + N'_TRACE')
        + N' ON '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
        + N' ([LB_LSN_COMMIT_TEC], [LB_SEQVAL_TEC]);' + CHAR(13)

        /* Consultation et purge de retention par journee. */
        + N'CREATE NONCLUSTERED INDEX '
        + QUOTENAME(N'IX_' + @TableNameHisto + N'_JOUR')
        + N' ON '
        + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
        + N' ([DT_JOUR_TEC]);' + CHAR(13)

        /* Consultation par cle metier, si une cle a pu etre resolue. */
        + CASE
              WHEN @ColonnesCleMetier IS NOT NULL
                  THEN N'CREATE NONCLUSTERED INDEX '
                     + QUOTENAME(N'IX_' + @TableNameHisto + N'_CLE_METIER')
                     + N' ON '
                     + QUOTENAME(@SchemaHisto) + N'.' + QUOTENAME(@TableNameHisto)
                     + N' (' + @ColonnesCleMetier + N', [DT_COMMIT_TEC]);' + CHAR(13)
              ELSE N''
          END;

    UPDATE ##TableListHisto
    SET
        NbColonnesVue = @NbColonnesVue,
        SourceCleMetier = @SourceCleMetier,
        ColonnesCleMetier = @ColonnesCleMetier,
        NbColonnesCle = @NbColonnesCle,
        CreateScript = @Create,
        MessageControle = @Message
    WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur_histo
    INTO @TableNameSource, @ViewNameSource, @TableNameHisto;
END;

CLOSE cur_histo;
DEALLOCATE cur_histo;
GO

/* Script complet a executer sur la base ODS_Traces. */
SELECT
    ScriptComplet =
    (
        SELECT CHAR(13) + CreateScript + CHAR(13)
        FROM ##TableListHisto
        ORDER BY TableNameSource
        FOR XML PATH(N''), TYPE
    );

/* Detail et controle de la cle metier detectee. */
SELECT
    TableNameSource,
    ViewNameSource,
    TableNameHisto,
    NbColonnesVue,
    SourceCleMetier,
    ColonnesCleMetier,
    NbColonnesCle,
    MessageControle,
    CreateScript
FROM ##TableListHisto
ORDER BY TableNameSource;

/* Tables sans cle metier exploitable. */
SELECT
    TableNameSource,
    ViewNameSource,
    MessageControle
FROM ##TableListHisto
WHERE SourceCleMetier IS NULL
ORDER BY TableNameSource;
GO
