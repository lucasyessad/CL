/* ============================================================================
   CONTROLES DU PARAMETRAGE
   A passer apres toute modification. Chaque requete doit renvoyer zero ligne.
   Filtrer sur @LB_PROJET pour un projet donne.
   ============================================================================ */

DECLARE @LB_PROJET NVARCHAR(50) = N'LIGIS';

/* 1. Table decrite au grain colonne mais absente du grain flux. */
SELECT DISTINCT T.LB_TABLE_ODS, N'flux non declare dans ORT_PARAM_FLUX' AS Probleme
FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS T
WHERE T.LB_PROJET = @LB_PROJET
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_FLUX AS F
                  WHERE F.LB_PROJET = T.LB_PROJET AND F.LB_TABLE_ODS = T.LB_TABLE_ODS);

/* 2. Flux sans aucune colonne. */
SELECT F.LB_TABLE_ODS, N'aucune colonne decrite' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS);

/* 3. Flux sans colonne cle. */
SELECT F.LB_TABLE_ODS, N'aucune colonne cle' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1);

/* 4. Flux DELTA sans colonne d'ordre. */
SELECT F.LB_TABLE_ODS, N'mode DELTA sans colonne d''ordre' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1 AND F.CD_MODE_ENTREE = N'DELTA'
  AND NOT EXISTS (SELECT 1 FROM dbo.ORT_PARAM_HISTORISATION_TRACES AS C
                  WHERE C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_ORDRE_TRI = 1);

/* 5. Cible manquante alors que le flux alimente le DWH. */
SELECT F.LB_TABLE_ODS, N'LB_TABLE_DWH absent' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND F.CD_MODE_ALIM <> N'AUCUNE' AND F.LB_TABLE_DWH IS NULL;

/* 6. Valeurs de mode hors domaine. */
SELECT F.LB_TABLE_ODS, N'mode hors domaine' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET
  AND (F.CD_MODE_ENTREE NOT IN (N'DELTA', N'FULL')
    OR F.CD_FORMAT      NOT IN (N'BCP', N'CSV')
    OR F.CD_MODE_ALIM   NOT IN (N'SCD2', N'SCD1', N'AJOUT', N'AUCUNE'));

/* 7. Tables physiques absentes. */
SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH,
       CASE WHEN OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS)+N'.'+QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
            THEN N'table ODS absente' ELSE N'table DWH absente' END AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
WHERE F.LB_PROJET = @LB_PROJET AND F.FL_ACTIF = 1
  AND (OBJECT_ID(QUOTENAME(F.LB_SCHEMA_ODS)+N'.'+QUOTENAME(F.LB_TABLE_ODS), N'U') IS NULL
    OR (F.LB_TABLE_DWH IS NOT NULL
        AND OBJECT_ID(QUOTENAME(F.LB_SCHEMA_DWH)+N'.'+QUOTENAME(F.LB_TABLE_DWH), N'U') IS NULL));

/* 8. Desaccord entre les deux niveaux sur la cible ou la source. */
SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH AS Flux_Cible, C.LB_TABLE_DWH AS Colonne_Cible,
       N'desaccord flux / colonne' AS Probleme
FROM dbo.ORT_PARAM_FLUX AS F
INNER JOIN dbo.ORT_PARAM_HISTORISATION_TRACES AS C
    ON C.LB_PROJET = F.LB_PROJET AND C.LB_TABLE_ODS = F.LB_TABLE_ODS AND C.FL_CLEF = 1
WHERE F.LB_PROJET = @LB_PROJET
  AND (ISNULL(F.LB_TABLE_DWH,N'') <> ISNULL(C.LB_TABLE_DWH,N'')
    OR ISNULL(F.LB_SOURCE,N'')    <> ISNULL(C.LB_SOURCE,N''));
