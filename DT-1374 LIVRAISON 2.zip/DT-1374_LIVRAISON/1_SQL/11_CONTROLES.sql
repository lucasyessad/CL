/* ============================================================================
   CONTROLES  -  a passer apres l'installation, puis en exploitation

   Dix requetes independantes. Pour chacune, le resultat attendu est indique
   en commentaire : la plupart doivent ne renvoyer AUCUNE ligne.

   Les six premieres verifient l'installation (tables presentes, parametrage
   coherent, colonnes existantes). Les quatre dernieres servent au quotidien :
   suivre une journee, verifier l'historique d'une table, voir ce qui reste
   en attente dans le sas.
   ============================================================================ */

/* 1. Tables du dispositif (attendu : que des 'OK') -------------------------- */
SELECT nom = t.nom,
       etat = CASE WHEN OBJECT_ID(t.nom, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END
FROM (VALUES ('dbo.ORT_PARAM_HISTORISATION_TRACES'),
             ('dbo.ORT_BORNE_JOURNEE'),
             ('dbo.ORT_AUDIT_CHARGEMENT'),
             ('ods.OIT_TEC_AUD_CDC'),
             ('dbo.OWT_TEC_AUD_CDC'),
             ('dbo.PITCOT_PERIODE_REPRISE'),
             ('dbo.PWTTRE'), ('dbo.PWTSDC'), ('dbo.PWTSPF'),
             ('dbo.PWTCHE'), ('dbo.PRTCAL')) t(nom);

/* 2. Perimetre actif -------------------------------------------------------- */
SELECT LB_TABLE_ODS, LB_TABLE_DWH,
       nb_colonnes     = COUNT(*),
       nb_colonnes_cle = SUM(CASE WHEN FL_CLEF = 1 THEN 1 ELSE 0 END),
       nb_colonnes_tri = SUM(CASE WHEN FL_ORDRE_TRI = 1 THEN 1 ELSE 0 END),
       filtre          = MAX(LB_FILTRE_WHERE)
FROM dbo.ORT_PARAM_HISTORISATION_TRACES
WHERE LB_PROJET = 'LIGIS'
GROUP BY LB_TABLE_ODS, LB_TABLE_DWH
ORDER BY LB_TABLE_ODS;

/* 3. Parametrage incoherent (attendu : 0 ligne) ---------------------------- */
SELECT LB_TABLE_ODS, probleme
FROM (
    SELECT LB_TABLE_ODS,
           probleme = CASE
             WHEN SUM(CASE WHEN FL_CLEF = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne cle'
             WHEN SUM(CASE WHEN FL_ORDRE_TRI = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne d''ordre'
             WHEN SUM(CASE WHEN FL_CLEF = 1 AND (LB_CHAMP_ODS IS NULL OR LB_CHAMP_DWH IS NULL)
                           THEN 1 ELSE 0 END) > 0
                  THEN 'ligne cle avec mapping incomplet'
             ELSE NULL END
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_PROJET = 'LIGIS'
    GROUP BY LB_TABLE_ODS
) c
WHERE probleme IS NOT NULL
ORDER BY LB_TABLE_ODS;

/* 4. Tables physiques manquantes (attendu : 0 ligne) ----------------------- */
SELECT LB_TABLE_ODS, LB_TABLE_DWH,
       table_ods = CASE WHEN OBJECT_ID('ods.' + LB_TABLE_ODS, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END,
       table_dwh = CASE WHEN OBJECT_ID('dbo.' + LB_TABLE_DWH, 'U') IS NULL THEN 'MANQUANTE' ELSE 'OK' END
FROM (SELECT DISTINCT LB_TABLE_ODS, LB_TABLE_DWH
      FROM dbo.ORT_PARAM_HISTORISATION_TRACES
      WHERE LB_PROJET = 'LIGIS' AND FL_CLEF = 1 AND FL_CHARGEMENT = 1) p
WHERE OBJECT_ID('ods.' + LB_TABLE_ODS, 'U') IS NULL
   OR OBJECT_ID('dbo.' + LB_TABLE_DWH, 'U') IS NULL;

/* 5. Colonnes parametrees absentes des tables (attendu : 0 ligne) ---------- */
SELECT p.LB_TABLE_ODS, p.NO_CHAMP, p.LB_CHAMP_ODS, p.LB_CHAMP_DWH,
       manquant = CASE WHEN co.name IS NULL THEN 'colonne ODS absente' ELSE 'colonne DWH absente' END
FROM dbo.ORT_PARAM_HISTORISATION_TRACES p
LEFT JOIN sys.columns co ON co.object_id = OBJECT_ID('ods.' + p.LB_TABLE_ODS)
                        AND co.name = p.LB_CHAMP_ODS
LEFT JOIN sys.columns cd ON cd.object_id = OBJECT_ID('dbo.' + p.LB_TABLE_DWH)
                        AND cd.name = p.LB_CHAMP_DWH
WHERE p.LB_PROJET = 'LIGIS'
  AND p.LB_CHAMP_ODS IS NOT NULL AND p.LB_CHAMP_DWH IS NOT NULL
  AND (co.name IS NULL OR cd.name IS NULL)
ORDER BY p.LB_TABLE_ODS, p.NO_CHAMP;

/* 6. Audit CDC : datetimes alimentees par l'amont ? ------------------------ */
SELECT LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM ods.OIT_TEC_AUD_CDC
ORDER BY LB_INSTANCE;

/* 7. Bornes posees et continuite (2e requete attendue : 0 ligne) ----------- */
SELECT TOP (20) * FROM dbo.ORT_BORNE_JOURNEE ORDER BY DT_JOUR DESC;

SELECT b1.DT_JOUR, b1.DT_BORNE, b2.DT_JOUR AS jour_suivant, b2.DT_BORNE AS borne_suivante
FROM dbo.ORT_BORNE_JOURNEE b1
JOIN dbo.ORT_BORNE_JOURNEE b2 ON b2.DT_JOUR > b1.DT_JOUR
WHERE b2.DT_BORNE <= b1.DT_BORNE;

/* 8. Deroule d'une journee -------------------------------------------------- */
DECLARE @jour DATE = '2026-07-22';

SELECT ID_TRT_ALI, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE,
       CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN
FROM dbo.ORT_AUDIT_CHARGEMENT
WHERE LB_PROJET = 'LIGIS'
  AND CHARINDEX('[' + CONVERT(varchar(10), @jour, 23) + ']', LB_CHARGEMENT) > 0
ORDER BY DT_DEBUT, LB_SOURCE;

/* 9. Coherence de l'historique d'une table (attendu : 0 ligne) -------------- */
-- Plusieurs versions courantes pour une meme cle : impossible si l'index
-- unique filtre est en place. A lancer avant de le creer sur une table
-- deja alimentee.
SELECT NUM_CONTRAT, nb = COUNT(*)
FROM dbo.OWT_CONTRAT
WHERE FL_VER_CRT = 1
GROUP BY NUM_CONTRAT
HAVING COUNT(*) > 1;

-- Trous ou chevauchements dans le chainage des versions
SELECT NUM_CONTRAT, DT_DEB_VAL, DT_FIN_VAL,
       deb_suivant = LEAD(DT_DEB_VAL) OVER (PARTITION BY NUM_CONTRAT ORDER BY DT_DEB_VAL)
FROM dbo.OWT_CONTRAT
WHERE DT_FIN_VAL <> LEAD(DT_DEB_VAL) OVER (PARTITION BY NUM_CONTRAT ORDER BY DT_DEB_VAL)
  AND DT_FIN_VAL <> '2400-01-01';

/* 10. Sas ODS : ce qui reste en attente de sa journee ---------------------- */
SELECT nb_en_attente = COUNT(*),
       plus_ancienne = MIN(DT_COMMIT_TEC),
       plus_recente  = MAX(DT_COMMIT_TEC)
FROM ods.OIT_CONTRAT;
