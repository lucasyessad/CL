/* ============================================================================
   RECEPTION DE L'AUDIT CDC  -  ods.OIT_TEC_AUD_CDC

   A chaque extraction, LIGIS produit un fichier d'audit qui dit, pour chaque
   table, jusqu'ou l'extraction est allee : le dernier LSN lu et sa date.

   C'est cette date qui permet de savoir si une journee est complete.

   Le traitement retient la valeur la PLUS PETITE parmi toutes les tables du
   perimetre. Exemple : si CONTRAT est extrait jusqu'a 09:00 mais MEMO
   seulement jusqu'a 06:00, on ne peut garantir la completude que jusqu'a
   06:00. La table la moins avancee decide pour toutes.

   Cette table est videe et rechargee a chaque import : elle ne contient que
   la derniere extraction. L'historique est conserve dans OWT_TEC_AUD_CDC.

   L'ordre des colonnes doit etre exactement celui de la vue exportee : le
   chargement BCP en format natif se fait par position, pas par nom.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF SCHEMA_ID('ods') IS NULL
    EXEC('CREATE SCHEMA ods');
GO

IF OBJECT_ID('ods.OIT_TEC_AUD_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE ods.OIT_TEC_AUD_CDC
    (
        ID_INSTANCE   BINARY(32)     NULL,   -- identifiant de l'instance de capture
        LB_INSTANCE   NVARCHAR(128)  NULL,   -- 'dbo_' + nom de la table source
        LB_DEB_LSN    BINARY(10)     NULL,   -- borne basse d'extraction (exclue)
        LB_FIN_LSN    BINARY(10)     NULL,   -- borne haute d'extraction (incluse)
        DT_DEB_LSN    DATETIME2(3)   NULL,
        DT_FIN_LSN    DATETIME2(3)   NULL,   -- datetime de couverture
        DT_EXTRACT    DATETIME2(3)   NULL    -- utilisee si DT_FIN_LSN est NULL
    );

    CREATE NONCLUSTERED INDEX IX_OIT_TEC_AUD_CDC_INSTANCE
        ON ods.OIT_TEC_AUD_CDC (LB_INSTANCE) INCLUDE (DT_FIN_LSN, DT_EXTRACT);
END
GO

/* Controle : les datetimes doivent etre alimentees par le traitement amont.
   Tant qu'elles sont NULL, aucune journee ne peut etre bornee.
-------------------------------------------------------------------------------
SELECT LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM ods.OIT_TEC_AUD_CDC
ORDER BY LB_INSTANCE;
---------------------------------------------------------------------------- */
