/* ============================================================================
   TABLE DES FRONTIERES DE JOURNEE  -  dbo.ORT_BORNE_JOURNEE

   Une journee de travail ne s'arrete pas a minuit. Les batchs LIGIS tournent
   la nuit : ce qui est ecrit a 3h du matin fait encore partie de la veille.

   On considere donc qu'une journee se termine a 07:45 le lendemain ouvrable.
   Cette table stocke ces frontieres, une ligne par journee :

     DT_JOUR    2026-07-22
     DT_BORNE   2026-07-23 07:45:00.000

   Autrement dit, la journee du 22 contient tout ce qui a ete modifie entre
   le 22 a 07:45 et le 23 a 07:45.

   Une ligne apparait ici seulement quand la journee est complete, c'est-a-
   dire quand l'extraction LIGIS est allee au-dela de cette frontiere. Tant
   qu'il n'y a pas de ligne, la journee n'est pas traitee.

   Le samedi compte comme jour ouvrable s'il est travaille (voir PRTCAL).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_BORNE_JOURNEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_BORNE_JOURNEE
    (
        DT_JOUR         DATE           NOT NULL,
        DT_BORNE        DATETIME2(3)   NOT NULL,
        TYPE_BORNE      NVARCHAR(15)   NOT NULL DEFAULT ('QUOTIDIEN'),
        ORIGINE_VALEUR  NVARCHAR(20)   NOT NULL DEFAULT ('AUDIT_CDC'),
        DT_POSE         DATETIME       NOT NULL DEFAULT (GETDATE()),
        COMMENTAIRE     NVARCHAR(500)  NULL,
        CONSTRAINT PK_ORT_BORNE_JOURNEE PRIMARY KEY (DT_JOUR),
        CONSTRAINT UQ_ORT_BORNE_JOURNEE_DT_BORNE UNIQUE (DT_BORNE),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_TYPE
            CHECK (TYPE_BORNE IN ('QUOTIDIEN','INIT')),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_ORIGINE
            CHECK (ORIGINE_VALEUR IN ('AUDIT_CDC','MANUEL'))
    );
END
GO
