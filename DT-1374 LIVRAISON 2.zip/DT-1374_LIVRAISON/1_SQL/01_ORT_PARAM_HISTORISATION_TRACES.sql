/* ============================================================================
   TABLE DE PARAMETRAGE  -  dbo.ORT_PARAM_HISTORISATION_TRACES

   C'est elle qui dit au traitement quelles tables historiser et comment.
   Rien n'est ecrit en dur dans les scripts : pour ajouter ou retirer une
   table, on modifie cette table, pas le code.

   Une ligne par colonne. Quatre indicateurs pilotent tout :

     FL_CHARGEMENT = 1   la table fait partie du perimetre
     FL_CLEF       = 1   cette colonne fait partie de la cle
                         (ce qui identifie un contrat, un client...)
     FL_ORDRE_TRI  = 1   cette colonne sert a trier les modifications dans
                         le temps, pour savoir laquelle est la derniere
     LB_FILTRE_WHERE     condition SQL optionnelle, si on ne veut qu'une
                         partie des lignes (exemple : MEM_TYPE = 'CNT')

   LB_CHAMP_ODS et LB_CHAMP_DWH permettent de renommer une colonne entre la
   source et la cible.

   Le script ne recree pas la table si elle existe deja : les ajustements
   faits a la main ne sont jamais perdus.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PARAM_HISTORISATION_TRACES', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
    (
        LB_PROJET        NVARCHAR(50)   NOT NULL DEFAULT ('LIGIS'),
        LB_SOURCE        NVARCHAR(200)  NULL,
        LB_TABLE_ODS     NVARCHAR(128)  NOT NULL,
        LB_TABLE_DWH     NVARCHAR(200)  NOT NULL,
        NO_CHAMP         INT            NOT NULL,
        LB_CHAMP_ODS     NVARCHAR(128)  NULL,
        LB_CHAMP_DWH     NVARCHAR(128)  NULL,
        LB_SCD           NVARCHAR(30)   NULL,
        FL_CLEF          BIT            NOT NULL DEFAULT (0),
        FL_CHARGEMENT    BIT            NULL,
        FL_ORDRE_TRI     BIT            NOT NULL DEFAULT (0),
        LB_FILTRE_WHERE  NVARCHAR(1000) NULL,
        CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
            PRIMARY KEY (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
    );

    CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ACTIVES
        ON dbo.ORT_PARAM_HISTORISATION_TRACES (FL_CLEF, FL_CHARGEMENT)
        INCLUDE (LB_TABLE_ODS, LB_TABLE_DWH);
END
GO
