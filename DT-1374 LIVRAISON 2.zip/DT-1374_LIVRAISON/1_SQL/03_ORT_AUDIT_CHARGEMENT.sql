/* ============================================================================
   JOURNAL DU TRAITEMENT  -  dbo.ORT_AUDIT_CHARGEMENT

   Tout ce que fait le traitement est trace ici : c'est le premier endroit ou
   regarder quand quelque chose ne va pas.

   En marche normale, une seule ligne par table et par journee :

     LB_CHARGEMENT   TRACES [2026-07-22]
     LB_SOURCE       OIT_CONTRAT
     NB_LIGNE        340
     CD_STATUT       OK
     LB_ERREUR       Flaguees: 340 / fermees: 312 / inserees: 340.

   Plus une ligne de bilan par journee, et trois lignes par execution (pose
   des bornes, archivage de l'audit CDC, cadrage de la periode).

   Des lignes supplementaires apparaissent uniquement quand il y a quelque
   chose a signaler : aucune trace recue, journee recalculee, erreur.

   CD_STATUT ne vaut que OK ou KO. Un avertissement est un OK avec un texte
   dans LB_ERREUR.

   Le traitement RELIT cette table pendant son execution : quand une table
   tombe en erreur, les etapes suivantes la reconnaissent et l'ecartent au
   lieu de travailler sur des donnees incompletes.

   Meme structure que la table AUDIT_CHARGEMENT du projet CL_ESTIM.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_AUDIT_CHARGEMENT', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_AUDIT_CHARGEMENT
    (
        ID_TRT_ALI     INT             NULL,
        LB_PROJET      NVARCHAR(50)    NULL,
        LB_CHARGEMENT  NVARCHAR(100)   NULL,
        LB_SOURCE      NVARCHAR(200)   NULL,
        LB_CIBLE       NVARCHAR(200)   NULL,
        NB_LIGNE       INT             NULL,
        CD_STATUT      NVARCHAR(10)    NULL,
        LB_ERREUR      NVARCHAR(MAX)   NULL,
        DT_DEBUT       DATETIME        NULL,
        DT_FIN         DATETIME        NULL
    );

    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_PROJET_DT
        ON dbo.ORT_AUDIT_CHARGEMENT (LB_PROJET, DT_DEBUT);

    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_SESSION
        ON dbo.ORT_AUDIT_CHARGEMENT (ID_TRT_ALI, LB_PROJET, CD_STATUT)
        INCLUDE (LB_SOURCE, LB_CHARGEMENT);
END
GO
