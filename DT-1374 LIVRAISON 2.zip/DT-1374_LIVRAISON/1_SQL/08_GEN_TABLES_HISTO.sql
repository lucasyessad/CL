/* ============================================================================
   GENERATEUR DES TABLES D'ARCHIVE

   Meme principe que le script 07 : il ecrit les CREATE TABLE, vous executez
   le resultat - ici sur la base ODS_Traces.

   POURQUOI CES TABLES

   La table ods.OIT_<table> n'est pas un stock, c'est un sas : elle ne
   contient que les traces qui n'ont pas encore ete traitees. Une fois une
   journee historisee, ses traces sont deplacees ici et effacees du sas.

   ODS_Traces.dbo.OIT_<table>_HISTO conserve donc toutes les traces deja
   traitees. C'est la que l'on va chercher de quoi rejouer un historique,
   verifier une image passee ou alimenter un autre traitement.

   La structure est identique a celle du sas, pour que la copie soit un
   simple INSERT sans transformation, avec quatre colonnes en plus :

       DT_JOUR_TEC   la journee a laquelle la trace a ete rattachee
       DT_MAJ        quand elle a ete archivee
       CD_USR_MAJ    'SUPERVIS'
       ID_TRT_ALI    le numero de session ODI

   FL_FIN_JOURNEE est conservee : elle indique quelle trace a servi d'image
   pour la journee, ce qui reste utile a posteriori.

   L'index unique sur (CD_LSN_TEC, CD_SEQ_TEC) empeche d'archiver deux fois
   la meme trace : la copie peut donc etre relancee sans risque.

   Ces tables ne sont jamais videes par le traitement. Leur purge (13 mois de
   retention) fera l'objet d'un traitement separe, d'ou l'index sur
   DT_JOUR_TEC.
   ============================================================================ */

IF EXISTS (SELECT 1 FROM tempdb.sys.tables WHERE name LIKE '##TableListHisto%')
    DROP TABLE ##TableListHisto;
GO

CREATE TABLE ##TableListHisto (
    TableNameSource sysname NOT NULL,
    TableNameHisto  sysname NOT NULL,
    CreateScript    nvarchar(MAX) NULL
);
GO

SET NOCOUNT ON;

DECLARE @SchemaSource sysname = N'dbo';
DECLARE @BaseHisto    sysname = N'ODS_Traces';   -- <<< base d'archive
DECLARE @SchemaHisto  sysname = N'dbo';          -- <<< schema d'archive

INSERT INTO ##TableListHisto (TableNameSource, TableNameHisto)
SELECT t.name, 'OIT_' + t.name + '_HISTO'
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN [cdc].[TEC_AUD_CDC] tm ON tm.LB_INSTANCE = ('dbo_' + t.name)
WHERE s.name = @SchemaSource
ORDER BY t.name;

/* Colonnes techniques : memes definitions que dans 07_GENERATION_OIT_OWT.sql */
DECLARE @TechColsCDC nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL';

DECLARE @TechColsFin nvarchar(MAX) =
      N'[FL_FIN_JOURNEE] bit NULL,' + CHAR(13) +
      N'        [DT_JOUR_TEC] date NULL,' + CHAR(13) +
      N'        [DT_MAJ] datetime NOT NULL DEFAULT (GETDATE()),' + CHAR(13) +
      N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13) +
      N'        [ID_TRT_ALI] int NULL';

DECLARE @TableNameSource sysname, @TableNameHisto sysname, @Create nvarchar(MAX);

DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT TableNameSource, TableNameHisto FROM ##TableListHisto;

OPEN cur;
FETCH NEXT FROM cur INTO @TableNameSource, @TableNameHisto;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID('tempdb..#cols') IS NOT NULL DROP TABLE #cols;

    SELECT
        c.column_id,
        ColumnName = QUOTENAME(c.name),
        TypeBase =
            CASE
                WHEN t.name IN ('varchar','char','varbinary','binary')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length = -1 THEN 'MAX'
                              ELSE CAST(c.max_length AS varchar(10)) END + ')'
                WHEN t.name IN ('nvarchar','nchar')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length <> -1 THEN CAST(c.max_length/2 AS varchar(10))
                              ELSE 'MAX' END + ')'
                WHEN t.name IN ('decimal','numeric')
                    THEN t.name + '(' + CAST(c.precision AS varchar(10)) + ',' + CAST(c.scale AS varchar(10)) + ')'
                WHEN t.name IN ('datetime2','time','datetimeoffset')
                    THEN t.name + '(' + CAST(c.scale AS varchar(10)) + ')'
                ELSE t.name
            END
    INTO #cols
    FROM sys.tables tb
    JOIN sys.schemas s ON s.schema_id = tb.schema_id
    JOIN sys.columns c ON c.object_id = tb.object_id
    JOIN sys.types   t ON t.user_type_id = c.user_type_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND c.is_computed = 0
      AND c.name NOT LIKE 'CS%';

    SELECT @Create =
        'IF OBJECT_ID(N''' + @SchemaHisto + '.' + @TableNameHisto + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto) + ' (' + CHAR(13) +
        '        ' + @TechColsCDC + ',' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + ' NULL',
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsFin + CHAR(13) +
        '    );' + CHAR(13) +
        -- purge de retention et consultation par journee
        'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameHisto + '_JOUR')
        + ' ON ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto)
        + ' ([DT_JOUR_TEC]);' + CHAR(13) +
        -- anti-doublon : une trace CDC est identifiee par son LSN et sa sequence.
        -- Rend la copie rejouable : un second passage echoue au lieu de dupliquer.
        'CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME('UX_' + @TableNameHisto + '_TRACE')
        + ' ON ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto)
        + ' ([CD_LSN_TEC], [CD_SEQ_TEC]);' + CHAR(13) +
        'END;'
    FROM #cols;

    UPDATE ##TableListHisto SET CreateScript = @Create
     WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur INTO @TableNameSource, @TableNameHisto;
END

CLOSE cur;
DEALLOCATE cur;
GO

/* Scripts a executer sur la base ODS_Traces */
SELECT ScriptComplet =
    (SELECT CHAR(13) + CreateScript + CHAR(13)
     FROM ##TableListHisto ORDER BY TableNameSource
     FOR XML PATH(''), TYPE);

SELECT * FROM ##TableListHisto ORDER BY TableNameSource;
