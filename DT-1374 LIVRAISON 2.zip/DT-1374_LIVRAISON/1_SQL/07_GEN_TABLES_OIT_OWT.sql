/* ============================================================================
   GENERATEUR DES TABLES OIT ET OWT

   Ce script n'a pas creer les tables : il ECRIT les CREATE TABLE a votre
   place, en lisant la structure reelle des tables LIGIS. Vous recuperez le
   resultat et vous l'executez sur le DWH.

   A EXECUTER SUR LA BASE LIGIS (c'est la que sont les structures et les
   cles). La sortie s'execute sur le DWH.

   Il produit deux tables par table LIGIS :

   ods.OIT_<table>  -  ce qui arrive du fichier
       Sa structure doit etre la copie exacte de la vue exportee, dans le
       meme ordre, car le chargement BCP se fait par POSITION et non par nom
       de colonne. Une colonne en trop ou deplacee, et tout le fichier est
       decale sans message clair.
       Contenu : 5 colonnes techniques CDC, puis les colonnes metier, puis
       FL_FIN_JOURNEE en derniere position.
       Pas de cle primaire : une meme cle apparait plusieurs fois par jour,
       autant de fois qu'elle a ete modifiee.

   dbo.OWT_<table>  -  l'historique
       Les colonnes metier, plus les colonnes techniques CDC pour savoir
       quelle modification a produit chaque version, plus le bloc technique
       maison : NO_SEQ, DT_DEB_VAL, DT_FIN_VAL, FL_SUP, FL_VER_CRT, DT_MAJ,
       CD_USR_MAJ, ID_TRT_ALI.
       Cle primaire = cle metier + DT_DEB_VAL : une version par cle et par
       journee.

   Trois index sont crees sur chaque OWT, et chacun a une raison precise :
       UX_..._VER_CRT      index UNIQUE sur la cle, limite aux versions
                           courantes. Il rend physiquement impossible d'avoir
                           deux versions courantes pour une meme cle. C'est
                           plus sur qu'un controle apres coup, qui ne
                           detecterait le probleme qu'une fois les donnees
                           ecrites.
       IX_..._DT_DEB_VAL   pour la suppression lors d'un recalcul
       IX_..._DT_FIN_VAL   pour la reouverture des versions fermees
       Ces deux derniers sont necessaires parce que DT_DEB_VAL est la
       DERNIERE colonne de la cle primaire : sans eux, ces recherches
       parcourraient toute la table.

   DEUX OPTIONS EN TETE DE SCRIPT

     @DROP_EXISTANT = 0     Par defaut, les tables existantes ne sont pas
                            touchees. A 1, le script les supprime d'abord :
                            cela EFFACE l'historique deja constitue.

     @REPRENDRE_DEFAUTS = 0 Les valeurs par defaut des colonnes LIGIS ne sont
                            pas recopiees. Elles peuvent appeler des
                            fonctions qui n'existent pas sur le DWH, ce qui
                            ferait echouer la creation. Elles ne servent a
                            rien ici, les valeurs venant toujours du fichier.

   AVANT D'UTILISER CE SCRIPT, les vues exportees doivent contenir :
       C.__$start_lsn AS CD_LSN_TEC          en 5e colonne technique
       , CONVERT(bit, 0) AS FL_FIN_JOURNEE   en toute derniere colonne
   ============================================================================ */

IF EXISTS (SELECT 1 FROM tempdb.sys.tables WHERE name LIKE '##TableListODS%')
    DROP TABLE ##TableListODS;
GO

CREATE TABLE ##TableListODS (
    TableNameSource   sysname NOT NULL,
    TableNameCibleODS sysname NOT NULL,
    TableNameCibleDWH sysname NOT NULL,
    NbColonnesCle     int     NULL,
    CreateScriptODS   nvarchar(MAX) NULL,
    CreateScriptDWH   nvarchar(MAX) NULL
);
GO

--  Perimetre : tables sous CDC (table d'audit cdc.TEC_AUD_CDC)
INSERT INTO ##TableListODS (TableNameSource, TableNameCibleODS, TableNameCibleDWH)
SELECT
    t.name              AS TableNameSource,
    'OIT_' + t.name     AS TableNameCibleODS,
    'OWT_' + t.name     AS TableNameCibleDWH
FROM sys.tables t
INNER JOIN sys.schemas s
    ON s.schema_id = t.schema_id
INNER JOIN [cdc].[TEC_AUD_CDC] tm
    ON tm.LB_INSTANCE = ('dbo_' + t.name)
ORDER BY t.name;

SET NOCOUNT ON;

DECLARE @SchemaSource   sysname = N'dbo';
DECLARE @SchemaCibleODS sysname = N'ods';   -- <<< schema cible ODS
DECLARE @SchemaCibleDWH sysname = N'dbo';   -- <<< schema cible DWH

/* ----------------------------------------------------------------
   OPTIONS DE GENERATION
   ---------------------------------------------------------------- */
DECLARE @DROP_EXISTANT    bit = 0;  -- 1 = DROP + CREATE (DESTRUCTIF : vide les OWT)
DECLARE @REPRENDRE_DEFAUTS bit = 0; -- 1 = recopier les contraintes DEFAULT de la source

/* ----------------------------------------------------------------
   COLONNES TECHNIQUES (listes ajustables)
   ---------------------------------------------------------------- */
-- En TETE de OIT (memes noms/ordre que la vue CDC exportee) :
DECLARE @TechColsCDC nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL';
-- CD_LSN_TEC = __$start_lsn. Necessaire au rechargement idempotent : avant
-- chaque BCP IN, l'import supprime la plage ] LB_DEB_LSN ; LB_FIN_LSN ] que
-- le fichier va recharger. Le LSN est exact, la datetime ne l'est pas (deux
-- commits peuvent partager la meme milliseconde).

-- En FIN de OIT :
DECLARE @TechColsODS nvarchar(MAX) = N'[FL_FIN_JOURNEE] bit NOT NULL DEFAULT (0)';

-- En FIN de OWT (tracabilite TEC + bloc technique maison).
-- Noms et ordre ALIGNES sur PS_CHARGEMENT_ODS_DWH pour que les deux moteurs
-- d'historisation produisent des tables lisibles de la meme facon.
DECLARE @TechColsDWH nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL,' + CHAR(13) +
      N'        [NO_SEQ] int NULL,' + CHAR(13) +
      N'        [DT_DEB_VAL] date NOT NULL,' + CHAR(13) +
      N'        [DT_FIN_VAL] date NOT NULL DEFAULT (''2400-01-01''),' + CHAR(13) +
      N'        [FL_SUP] bit NULL,' + CHAR(13) +
      N'        [FL_VER_CRT] bit NOT NULL DEFAULT (1),' + CHAR(13) +
      N'        [DT_MAJ] datetime NULL DEFAULT (GETDATE()),' + CHAR(13) +
      N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13) +
      N'        [ID_TRT_ALI] int NULL';

DECLARE
    @TableNameSource   sysname,
    @TableNameCibleODS sysname,
    @TableNameCibleDWH sysname,
    @CreateODS         nvarchar(MAX),
    @CreateDWH         nvarchar(MAX),
    @PKSorted          nvarchar(MAX),
    @PKPlain           nvarchar(MAX),
    @NbCle             int,
    @IsClustered       bit;

DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT TableNameSource, TableNameCibleODS, TableNameCibleDWH
    FROM ##TableListODS;

OPEN cur;
FETCH NEXT FROM cur INTO @TableNameSource, @TableNameCibleODS, @TableNameCibleDWH;

WHILE @@FETCH_STATUS = 0
BEGIN
    /* 1) Colonnes metier de la source (types exacts) */
    IF OBJECT_ID('tempdb..#cols') IS NOT NULL DROP TABLE #cols;

    SELECT
        c.column_id,
        ColumnName = QUOTENAME(c.name),
        TypeBase =
            CASE
                WHEN t.name IN ('varchar','char','varbinary','binary')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length = -1 THEN 'MAX'
                              ELSE CAST(c.max_length AS varchar(10)) END + ')'
                WHEN t.name IN ('nvarchar','nchar')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length <> -1 THEN CAST(c.max_length/2 AS varchar(10))
                              ELSE 'MAX' END + ')'
                WHEN t.name IN ('decimal','numeric')
                    THEN t.name + '(' + CAST(c.precision AS varchar(10)) + ',' + CAST(c.scale AS varchar(10)) + ')'
                WHEN t.name IN ('datetime2','time','datetimeoffset')
                    THEN t.name + '(' + CAST(c.scale AS varchar(10)) + ')'
                ELSE t.name
            END,
        DefaultClause =
            CASE WHEN @REPRENDRE_DEFAUTS = 1 AND dc.definition IS NOT NULL
                 THEN ' DEFAULT ' + dc.definition
                 ELSE '' END,
        NullClause =
            CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END
    INTO #cols
    FROM sys.tables tb
    JOIN sys.schemas s ON s.schema_id = tb.schema_id
    JOIN sys.columns c ON c.object_id = tb.object_id
    JOIN sys.types   t ON t.user_type_id = c.user_type_id
    LEFT JOIN sys.default_constraints dc
           ON dc.parent_object_id = tb.object_id AND dc.parent_column_id = c.column_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND c.is_computed = 0
      AND c.name NOT LIKE 'CS%';        -- colonnes techniques CDC source exclues (comme la vue)

    /* 2) PK de la source (2 formats) */
    SELECT @PKSorted = NULL, @PKPlain = NULL, @IsClustered = NULL, @NbCle = 0;

    SELECT
        @IsClustered = CASE WHEN idx.type = 1 THEN 1 ELSE 0 END,
        @NbCle    = COUNT(*),
        @PKSorted = STRING_AGG(QUOTENAME(c.name)
                        + CASE WHEN ic.is_descending_key = 1 THEN ' DESC' ELSE ' ASC' END,
                        ', ') WITHIN GROUP (ORDER BY ic.key_ordinal),
        @PKPlain  = STRING_AGG(QUOTENAME(c.name), ', ') WITHIN GROUP (ORDER BY ic.key_ordinal)
    FROM sys.tables tb
    JOIN sys.schemas s          ON s.schema_id = tb.schema_id
    JOIN sys.key_constraints kc ON kc.parent_object_id = tb.object_id
    JOIN sys.indexes idx        ON idx.object_id = kc.parent_object_id
                               AND idx.index_id  = kc.unique_index_id
    JOIN sys.index_columns ic   ON ic.object_id = idx.object_id
                               AND ic.index_id  = idx.index_id
    JOIN sys.columns c          ON c.object_id = ic.object_id
                               AND c.column_id = ic.column_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND kc.type = 'PK'
    GROUP BY idx.type;

    /* 3) Script ODS : TEC en tete + metier (tout NULLable) + FL_FIN_JOURNEE
          SANS PK (plusieurs traces par cle) ; index cle + DT_COMMIT_TEC */
    SELECT @CreateODS =
        CASE WHEN @DROP_EXISTANT = 1
             THEN 'IF OBJECT_ID(N''' + @SchemaCibleODS + '.' + @TableNameCibleODS + ''',''U'') IS NOT NULL DROP TABLE '
                  + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS) + ';' + CHAR(13) + CHAR(13)
             ELSE '' END +
        'IF OBJECT_ID(N''' + @SchemaCibleODS + '.' + @TableNameCibleODS + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS) + ' (' + CHAR(13) +
        '        ' + @TechColsCDC + ',' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + DefaultClause + ' NULL',
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsODS + CHAR(13) +
        '    );' + CHAR(13)
        + CASE WHEN @PKPlain IS NOT NULL
               THEN 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleODS + '_CLE')
                    + ' ON ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS)
                    + ' (' + @PKPlain + ', [DT_COMMIT_TEC]);' + CHAR(13)
               ELSE 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleODS + '_COMMIT')
                    + ' ON ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS)
                    + ' ([DT_COMMIT_TEC]);' + CHAR(13) END
        + 'END;'
    FROM #cols;

    /* 4) Script DWH : metier + TEC + tech DWH ; PK = (PK source + DT_DEB_VAL)
          + index de purge / fermeture SCD2 (voir R4 en tete de fichier) */
    SELECT @CreateDWH =
        CASE WHEN @DROP_EXISTANT = 1
             THEN 'IF OBJECT_ID(N''' + @SchemaCibleDWH + '.' + @TableNameCibleDWH + ''',''U'') IS NOT NULL DROP TABLE '
                  + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH) + ';' + CHAR(13) + CHAR(13)
             ELSE '' END +
        'IF OBJECT_ID(N''' + @SchemaCibleDWH + '.' + @TableNameCibleDWH + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH) + ' (' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + DefaultClause + NullClause,
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsDWH +
        CASE WHEN @PKSorted IS NOT NULL
             THEN ',' + CHAR(13) + '        CONSTRAINT ' + QUOTENAME('PK_' + @TableNameCibleDWH)
                  + ' PRIMARY KEY ' + CASE WHEN @IsClustered = 1 THEN 'CLUSTERED ' ELSE 'NONCLUSTERED ' END
                  + '(' + @PKSorted + ', [DT_DEB_VAL] ASC)'
             ELSE '' END
        + CHAR(13) + '    );' + CHAR(13)
        -- Index UNIQUE filtre : garantit STRUCTURELLEMENT qu'une cle n'a
        -- jamais plus d'une version courante. Remplace le controle
        -- anti-doublon qui balayait la table entiere a chaque journee :
        -- un doublon fait echouer l'INSERT immediatement, avant ecriture.
        + CASE WHEN @PKPlain IS NOT NULL
               THEN 'CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME('UX_' + @TableNameCibleDWH + '_VER_CRT')
                    + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
                    + ' (' + @PKPlain + ') WHERE [FL_VER_CRT] = 1;' + CHAR(13)
               ELSE '' END
        -- purge de la journee (etape D2) : DELETE ... WHERE DT_DEB_VAL = @jour
        + 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleDWH + '_DT_DEB_VAL')
        + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
        + ' ([DT_DEB_VAL]);' + CHAR(13)
        -- reouverture (etape D2) : UPDATE ... WHERE DT_FIN_VAL = @jour AND FL_VER_CRT = 0
        + 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleDWH + '_DT_FIN_VAL')
        + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
        + ' ([DT_FIN_VAL], [FL_VER_CRT]);' + CHAR(13)
        + 'END;'
    FROM #cols;

    /* 5) Mise a jour dans la table de correspondance */
    UPDATE ##TableListODS
       SET CreateScriptODS = @CreateODS,
           CreateScriptDWH = @CreateDWH,
           NbColonnesCle   = @NbCle
     WHERE TableNameSource = @TableNameSource;

    /* ==============================================================
       OPTION A : EXECUTER LES SCRIPTS IMMEDIATEMENT (uniquement si ce
       script tourne sur le DWH ; sinon copier la sortie ci-dessous)
       ==============================================================
     PRINT 'Execution ODS : ' + @TableNameCibleODS;  EXEC(@CreateODS);
     PRINT 'Execution DWH : ' + @TableNameCibleDWH;  EXEC(@CreateDWH); */

    FETCH NEXT FROM cur INTO @TableNameSource, @TableNameCibleODS, @TableNameCibleDWH;
END

CLOSE cur;
DEALLOCATE cur;
GO

/* ---------------------------------------------------------------------------
   RESULTAT
--------------------------------------------------------------------------- */
SELECT * FROM ##TableListODS ORDER BY TableNameSource;

/* Tables SANS cle primaire : elles seront generees sans PK cote OWT et
   devront recevoir une cle fonctionnelle manuelle dans le parametrage,
   sinon le package les ignorera (aucune ligne FL_CLEF = 1). */
SELECT TableNameSource, TableNameCibleODS, TableNameCibleDWH
FROM ##TableListODS
WHERE ISNULL(NbColonnesCle, 0) = 0
ORDER BY TableNameSource;
