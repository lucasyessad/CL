/* ============================================================================
   LISTE DES JOURNEES A TRAITER  -  dbo.PITCOT_PERIODE_REPRISE

   Table du standard maison, deja utilisee par d'autres chaines du projet.
   Elle contient la liste des journees restant a traiter, avec un indicateur
   TRAITE qui passe a 1 une fois la journee terminee.

   Le traitement la vide et la reconstruit a chaque execution, puis la
   parcourt journee par journee.

   ELLE EXISTE PROBABLEMENT DEJA. Ce script ne la recree que si elle est
   absente et ne modifie jamais une table existante. Si sa structure differe
   de celle decrite ici, ne pas la recreer : adapter plutot les scripts ODI
   04 et 10, qui sont les seuls a l'utiliser.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PITCOT_PERIODE_REPRISE
    (
        DT_CAL          DATE           NOT NULL,
        NO_SEQ          INT            NOT NULL,
        TRAITE          BIT            NOT NULL DEFAULT (0),
        LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,
        CONSTRAINT PK_PITCOT_PERIODE_REPRISE PRIMARY KEY (LB_NOM_SCN_SUN, DT_CAL)
    );

    CREATE NONCLUSTERED INDEX IX_PITCOT_PERIODE_REPRISE_A_TRAITER
        ON dbo.PITCOT_PERIODE_REPRISE (LB_NOM_SCN_SUN, TRAITE, DT_CAL);
END
GO

/* Controle de structure si la table preexiste
-------------------------------------------------------------------------------
SELECT c.name, t.name AS type, c.max_length, c.is_nullable
FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE')
ORDER BY c.column_id;
---------------------------------------------------------------------------- */
