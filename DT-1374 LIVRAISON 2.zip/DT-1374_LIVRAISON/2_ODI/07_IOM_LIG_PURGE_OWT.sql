/* ============================================================================
   ETAPE 7  -  IOM_LIG_PURGE_OWT

   Remet la table d'historique dans l'etat ou elle etait avant que cette
   journee ne soit traitee.

   POURQUOI

   Si on relance une journee deja traitee - apres correction d'une anomalie
   par exemple - il faut d'abord defaire ce qui avait ete fait, sinon on
   empile deux versions pour la meme journee.

   Deux operations :
     1. supprimer les versions creees par cette journee (DT_DEB_VAL = jour) ;
     2. rouvrir les versions que cette journee avait fermees : leur date de
        fin repasse a 2400-01-01 et elles redeviennent courantes.

   En marche normale la journee n'a jamais ete traitee : rien n'est supprime,
   rien n'est rouvert, et l'etape n'ecrit rien dans le journal. Elle n'ecrit
   que lorsqu'un recalcul a reellement eu lieu, ce qui est justement
   l'information interessante.

   DEUX SECURITES AVANT DE SUPPRIMER QUOI QUE CE SOIT

     - une table tombee en erreur a l'etape precedente est ignoree : on ne
       vide pas une cible qu'on ne saura pas reconstruire ;
     - si aucune trace n'a ete marquee pour cette journee, la table est
       laissee telle quelle.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';
DECLARE @DATE_INFINIE DATE        = '2400-01-01';

DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(500),
        @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

/* Fenetre de la journee ------------------------------------------------------ */
SELECT @dt_fin = DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR = @DT_TRACES;

SELECT @dt_deb = MAX(DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR < @DT_TRACES;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + @jour + N' (ORT_BORNE_JOURNEE).';
    THROW 50011, @msg, 1;
END

DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200),
        @src NVARCHAR(400), @tgt NVARCHAR(400),
        @col_fen NVARCHAR(128), @filtre NVARCHAR(1000),
        @sql NVARCHAR(MAX), @nb_flag INT, @nb_supp INT, @nb_rouv INT,
        @dt_step DATETIME;

/* Tables actives, hors tables deja en KO dans cette session ------------------- */
DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT P.LB_TABLE_ODS, MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
    WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
      AND NOT EXISTS (
            SELECT 1
            FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> A
            WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
              AND A.LB_PROJET = @LB_PROJET
              AND A.CD_STATUT = 'KO'
              AND A.LB_SOURCE = P.LB_TABLE_ODS
              AND CHARINDEX('[' + @jour + ']', A.LB_CHARGEMENT) > 0)
    GROUP BY P.LB_TABLE_ODS
    ORDER BY P.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb_supp = 0; SET @nb_rouv = 0; SET @nb_flag = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        SELECT @col_fen = NULL, @filtre = NULL;

        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        SELECT @filtre = MAX(LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1;

        SET @filtre = ISNULL(@filtre, N'');

        /* Garde-fou source vide : compte des lignes flaguees sur la fenetre */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src +
                   N' WHERE FL_FIN_JOURNEE = 1' +
                   N'   AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                   CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_flag OUTPUT;

        IF @nb_flag = 0
        BEGIN
            -- rien a purger : aucune trace d'audit (deja signale par FLAG_OIT)
            SET @nb_supp = 0;
        END
        ELSE
        BEGIN
            /* 1. Suppression des versions creees par cette journee */
            SET @sql = N'DELETE FROM ' + @tgt + N' WHERE DT_DEB_VAL = @p_dt;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_nb = @nb_supp OUTPUT;

            /* 2. Reouverture des versions fermees par cette journee */
            SET @sql = N'UPDATE ' + @tgt +
                       N' SET DT_FIN_VAL = @p_infini, FL_VER_CRT = 1' +
                       N' WHERE DT_FIN_VAL = @p_dt AND FL_VER_CRT = 0;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_dt date, @p_infini date, @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_nb = @nb_rouv OUTPUT;

            -- Ecriture UNIQUEMENT si un recalcul a reellement eu lieu : en
            -- marche nominale la journee n'a jamais ete traitee, donc rien
            -- n'est supprime ni rouvert et aucune ligne n'est produite.
            IF @nb_supp > 0 OR @nb_rouv > 0
                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'RECALCUL [' + @jour + N']',
                        @tbl_ods, @tbl_dwh, @nb_supp, N'OK',
                        N'Journee deja traitee : ' + CAST(@nb_supp AS NVARCHAR(10))
                        + N' version(s) supprimee(s), ' + CAST(@nb_rouv AS NVARCHAR(10))
                        + N' rouverte(s) avant reconstruction.',
                        @dt_step, GETDATE());
        END
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']',
                @tbl_ods, @tbl_dwh, 0, N'KO', N'PURGE : ' + ERROR_MESSAGE(), @dt_step, GETDATE());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
