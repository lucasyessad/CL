/* ============================================================================
   ETAPE 4  -  IOM_LIG_RECUP_DATES

   Construit la liste des journees a traiter dans PITCOT_PERIODE_REPRISE.

   La periode va de la derniere journee traitee (exclue) a la fin de periode
   figee par T003 (incluse).

   DEUX POINTS D'ATTENTION

   Le "<=" sur la fin de periode n'est pas anodin : c'est cette meme valeur
   que T004 reportera comme nouveau point de depart. Avec un "<", la journee
   correspondante ne serait jamais generee alors que la periode avancerait
   quand meme : un jour perdu a chaque execution.

   Le filtre FL_OVR = 1 ne garde que les jours ouvrables. PRTCAL est un
   calendrier complet, il contient aussi les dimanches et les feries. Sans ce
   filtre, ces jours seraient generes comme journees a traiter alors qu'ils
   ne peuvent jamais etre bornes : ils resteraient indefiniment en attente et
   bloqueraient la file.

   FL_OVR (ouvrable) et non FL_OUV (ouvre), parce que le samedi peut etre
   travaille.
   ============================================================================ */
DELETE FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'

INSERT INTO <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SELECT T.DT_CAL,
       (ROW_NUMBER() OVER (ORDER BY T.DT_CAL)) AS SEQ,
       0 AS TRAITE,
       '<?=odiRef.getSession("SESS_NAME") ?>' AS LB_NOM_SCN_SUN
FROM
(
    SELECT DISTINCT convert(date, DT_CAL, 121) as DT_CAL
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND convert(date, DT_CAL, 121) >  (select convert(date, DA_DEB_DEL_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
      and convert(date, DT_CAL, 121) <= (select convert(date, DA_DON_A_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
) AS T
ORDER BY SEQ ASC

-- FILTRE FL_OVR = 1 : PRTCAL est un CALENDRIER COMPLET (tous les jours y
-- figurent, qualifies par CD_OUV / FL_OUV / FL_OVR / FL_FER). Sans ce
-- filtre, les dimanches et jours feries etaient generes comme journees a
-- traiter alors qu'ils ne peuvent pas etre bornes : ils bloquaient la file.
-- FL_OVR (ouvrable) et non FL_OUV (ouvre) : le samedi peut etre travaille.
-- Un jour ouvrable sans trace est gere (cible non modifiee, avertissement
-- dans ORT_AUDIT_CHARGEMENT).
