/* ============================================================================
   ETAPE 10  -  IOM_LIG_FLAG_DATES

   Marque la journee comme traitee dans PITCOT, puis le package revient
   chercher la journee suivante.

   Le "=" et non "<=" : chaque journee a sa propre borne et sa propre image,
   il n'y a plus de journee intermediaire a rattraper. Un "<=" marquerait
   comme traitees des journees anterieures qui ne l'auraient pas ete, et
   elles seraient perdues.

   PWTTRE n'est pas modifiee ici : c'est la procedure maison T004 qui fait
   avancer la periode, en toute fin de package.
   ============================================================================ */
UPDATE <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND DT_CAL = '#V_IOM_LIG_DT_TRACES'
  AND TRAITE = 0
