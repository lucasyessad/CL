@echo off
REM  Copie d'un fichier du datalib source vers un repertoire cible.
REM  Appel : copy_bcp.bat <nom_fichier> <repertoire_cible>
@call E:\dsi\exploit\parmlib\chemin.bat

set infile=%datalib%\%~1
set outfile=%~2\%~1
call %proclib%\copy_proc.bat
