@{
    Server        = "ASM"
    Database      = "Ligis5_Test_Data"
    Schema        = "export_cdc"
    PriorityTable = "TEC_AUD_CDC"   # audit CDC : porte les bornes LSN
    OutputDir     = "\\sion\dsi\datalib"    # doit correspondre a %datalib%
    LogDir        = "\\sion\dsi\datalib\log"
    TargetCopyDir = "\\kenya\dsi\datalib"
    ListFileName  = "tables-to-load.txt"
    ZipFileName   = "TRACES_LIGIS.zip"
}
