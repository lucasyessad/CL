SELECT ligne =
       SUBSTRING(v.name, 12, LEN(v.name) - 13)
FROM sys.views v
JOIN sys.schemas s ON s.schema_id = v.schema_id
WHERE s.name = 'export_cdc'
  AND v.name LIKE 'ZBCP[_]LIGIS[_]%[_]V'
ORDER BY CASE WHEN v.name = 'ZBCP_LIGIS_TEC_AUD_CDC_V' THEN 0 ELSE 1 END,
         v.name;
