@{
    Server       = "ERM"
    Database     = "DWH"
    InputDir     = "\\kenya\dsi\datalib"
    LogDir       = "\\kenya\dsi\datalib\log"
    ListFileName = "tables-to-load.txt"
    TableSchema  = "ods"
    TablePrefix  = "OIT_"
    # Table d'audit CDC : rechargee integralement (photo, pas flux).
    AuditTable   = "OIT_TEC_AUD_CDC"
}
