/* ============================================================================
   INITIALISATION ONE-SHOT (mise en production) - a executer UNE fois,
   apres creation des tables (01_TABLES) et avant le premier lancement.
   Completer les valeurs <...>.
   ============================================================================ */

-- 1. Bornage PWTTRE : DA_DEB_DEL_TRT = veille ouvree du premier jour a
--    traiter (les dates generees sont STRICTEMENT superieures).
--    Completer les autres colonnes selon la structure reelle de PWTTRE.
IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE
               WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
    INSERT INTO dbo.PWTTRE (LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_FIN_DEL_FOR)
    VALUES ('IOM_LIGIS_TRACE_CSTIMG', '<AAAA-MM-JJ veille ouvree>', NULL);

-- 2. Borne initiale : debut de la toute premiere fenetre (idealement la
--    derniere datetime extraite lue dans l'audit CDC a l'activation).
INSERT INTO dbo.ORT_BORNE_JOURNEE
    (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
VALUES
    ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss.mmm>', 'INIT', 'MANUEL',
     'Borne initiale - demarrage historisation traces LIGIS');
