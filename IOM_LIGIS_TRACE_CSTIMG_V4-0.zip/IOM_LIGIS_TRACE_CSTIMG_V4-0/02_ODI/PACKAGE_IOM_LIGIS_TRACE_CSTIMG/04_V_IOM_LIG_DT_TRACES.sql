/* ============================================================================
   [B] VARIABLE ODI : V_IOM_LIG_DT_TRACES
   Type Alphanumerique, action Rafraichir, schema logique MSSQL_DWH.
   Seules les journees BORNEES sont eligibles : une journee sans borne
   (extraction non close / periode en accumulation) attend. Les journees
   intermediaires d'une periode MULTI_JOURS n'ont pas de borne : la
   variable saute a la derniere journee de la periode, [E] les absorbera.
   Renvoie NULL quand plus rien n'est eligible -> sortie via l'evaluation.
   ============================================================================ */
SELECT CONVERT(varchar(10), MIN(P.DT_CAL), 23)
FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.<%=snpRef.getSchemaName("MSSQL_DWH", "D")%>.PITCOT_PERIODE_REPRISE P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND EXISTS (SELECT 1 FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.<%=snpRef.getSchemaName("MSSQL_DWH", "D")%>.ORT_BORNE_JOURNEE B
              WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))
