/* ============================================================================
   [F] PROCEDURE ODI : IOM_LIG_MAJ_PWTTRE  (fin de boucle)
   Avance la borne de depart au dernier jour traite. Grace a l'absorption
   de [E], il ne reste jamais de trou TRAITE = 0 derriere la derniere
   journee traitee : le MAX est sur.
   ============================================================================ */
UPDATE <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.<%=snpRef.getSchemaName("MSSQL_DWH", "D")%>.PWTTRE
SET DA_DEB_DEL_TRT = (SELECT MAX(DT_CAL)
                      FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.<%=snpRef.getSchemaName("MSSQL_DWH", "D")%>.PITCOT_PERIODE_REPRISE
                      WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
                        AND TRAITE = 1)
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND EXISTS (SELECT 1
              FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.<%=snpRef.getSchemaName("MSSQL_DWH", "D")%>.PITCOT_PERIODE_REPRISE
              WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
                AND TRAITE = 1)
