#-----------------------------------------------------------------------------#
# SCHEDULE : quotidien, apres le batch LIGIS                                  #
#                                                                             #
# PROJET   : EXPORT / IMPORT BCP                                              #
#                                                                             #
# TITRE SCRIPT  : Extraction des vues vers fichiers BCP                       #
#                 et copie vers le repertoire d'import                        #
#                                                                             #
# DATE CREATION : 23/07/2026                              MAJ  : 23/07/2026   #
#                                                         USER : LYE          #
#-----------------------------------------------------------------------------#
# OBJECTIF : Export des vues cdc vers des fichiers binaires natifs (bcp),     #
#            archivage ZIP et copie vers le repertoire cible via copy_proc.   #
#            Arret et code retour non nul des la premiere table en echec.     #
#                                                                             #
# CALL : ./export_bcpout.ps1                                                  #
#                                                                             #
# CODES RETOUR : 0 = OK   1 = configuration / connexion   2 = table en echec  #
#-----------------------------------------------------------------------------#

[CmdletBinding()]
param([string]$ConfigFile = "export-parameters.psd1")

$ErrorActionPreference = 'Stop'
$cfg   = Import-PowerShellDataFile (Join-Path $PSScriptRoot $ConfigFile)
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$code  = 0

if (-not (Test-Path $cfg.LogDir))    { New-Item -ItemType Directory $cfg.LogDir -Force | Out-Null }
if (-not (Test-Path $cfg.OutputDir)) { New-Item -ItemType Directory $cfg.OutputDir -Force | Out-Null }
Start-Transcript -Path (Join-Path $cfg.LogDir "EXPORT_$stamp.log") | Out-Null

try {
    # Liste des tables : noms nus (CONTRAT, TEC_AUD_CDC...), audit CDC en tete
    $tables = Invoke-Sqlcmd -ServerInstance $cfg.Server -Database $cfg.Database `
                            -InputFile (Join-Path $PSScriptRoot "liste_vues.sql") |
              Select-Object -ExpandProperty ligne

    if (-not $tables) { throw "Aucune vue ZBCP_LIGIS_%_V dans le schema $($cfg.Schema)." }

    # Sans l'audit CDC, aucune borne de journee ne peut etre posee cote ODI :
    # rien ne serait traitable, autant echouer maintenant.
    if ($tables -notcontains $cfg.PriorityTable) {
        throw "Vue prioritaire absente : $($cfg.PriorityTable) (audit CDC)."
    }
    Write-Host "$($tables.Count) vue(s) a exporter." -ForegroundColor Cyan

    # Purge : un .bcp d'un export precedent serait rezippe et reimporte
    Get-ChildItem $cfg.OutputDir -Filter "*.bcp" | Remove-Item -Force
    Set-Content (Join-Path $cfg.OutputDir $cfg.ListFileName) -Value $tables -Encoding UTF8

    foreach ($t in $tables) {
        $file = Join-Path $cfg.OutputDir "$t.bcp"
        & bcp "$($cfg.Database).$($cfg.Schema).ZBCP_LIGIS_$($t)_V" out $file -n -S $cfg.Server -T
        if ($LASTEXITCODE -ne 0)              { $code = 2 ; throw "BCP OUT en echec pour $t (code $LASTEXITCODE)." }
        if (-not (Test-Path $file))           { $code = 2 ; throw "Fichier non produit pour $t." }
        if ((Get-Item $file).Length -eq 0)    { $code = 2 ; throw "Fichier vide pour $t." }
    }

    # Archive : liste + fichiers, sous un nom fixe attendu par l'import
    $zip = Join-Path $cfg.OutputDir $cfg.ZipFileName
    if (Test-Path $zip) { Remove-Item $zip -Force }
    $aZipper = @(Join-Path $cfg.OutputDir $cfg.ListFileName) +
               (Get-ChildItem $cfg.OutputDir -Filter "*.bcp" | Select-Object -ExpandProperty FullName)
    Compress-Archive -Path $aZipper -DestinationPath $zip -Force

    # Copie par la procedure maison (chemin.bat + copy_proc.bat)
    & (Join-Path $PSScriptRoot "copy_bcp.bat") $cfg.ZipFileName $cfg.TargetCopyDir
    if ($LASTEXITCODE -ne 0) { $code = 2 ; throw "Copie de $($cfg.ZipFileName) en echec (code $LASTEXITCODE)." }

    Write-Host "Export termine - $($tables.Count) table(s)." -ForegroundColor Green
}
catch {
    if ($code -eq 0) { $code = 1 }
    Write-Host "*** EXPORT EN ECHEC (code $code) : $_" -ForegroundColor Red
    Write-Host "*** L'IMPORT NE DOIT PAS ETRE LANCE." -ForegroundColor Red
}
finally { Stop-Transcript | Out-Null }

exit $code
