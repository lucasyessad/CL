/* ============================================================================
   Generation des DDL  ods.OIT_<table>  et  dbo.OWT_<table>
   A EXECUTER SUR LA BASE SOURCE LIGIS : le perimetre (tables sous CDC), les
   structures et les cles primaires y sont lus. La sortie s'execute sur le DWH.

   ods.OIT_<table> reproduit la structure de la vue exportee
   cdc.ZBCP_LIGIS_<table>_V, dans le meme ordre - le BCP natif est positionnel :
       1. colonnes techniques CDC : ID_INSTANCE_TEC, CD_SEQ_TEC, CD_CMD_TEC,
          DT_COMMIT_TEC, CD_LSN_TEC
       2. colonnes metier de la source (hors CS% et colonnes calculees)
       3. FL_FIN_JOURNEE en derniere position

   dbo.OWT_<table> = colonnes metier + colonnes techniques CDC (tracabilite de
   la trace retenue) + bloc technique maison, aux noms et dans l'ordre de
   PS_CHARGEMENT_ODS_DWH : NO_SEQ, DT_DEB_VAL, DT_FIN_VAL, FL_SUP, FL_VER_CRT,
   DT_MAJ, CD_USR_MAJ, ID_TRT_ALI.
   PK = (PK source + DT_DEB_VAL). IDENTITY non reprise : elle imposerait
   KEEPIDENTITY / IDENTITY_INSERT a chaque chargement.

   Index crees sur les OWT :
     UX_..._VER_CRT   unique filtre sur la cle WHERE FL_VER_CRT = 1. Garantit
                      qu'une cle n'a jamais deux versions courantes : un
                      doublon fait echouer l'INSERT avant ecriture.
     IX_..._DT_DEB_VAL / _DT_FIN_VAL   supportent la purge et la reouverture
                      de l'etape ODI 10 (DT_DEB_VAL etant en derniere position
                      de la PK, ces predicats ne seraient pas indexables).

   OPTIONS EN TETE DE SCRIPT
     @DROP_EXISTANT     = 0 par defaut. A 1, le script DROP les tables : cela
                          VIDE l'historique des OWT deja alimentees.
     @REPRENDRE_DEFAUTS = 0 par defaut : les contraintes DEFAULT de la source
                          peuvent referencer des fonctions propres a LIGIS,
                          absentes du DWH.

   Les colonnes metier des OIT sont toutes NULLables : une table
   d'atterrissage ne doit pas rejeter un fichier sur une contrainte heritee.
   Cote OWT la nullabilite d'origine est conservee (la PK exige NOT NULL).

   RAPPEL : les vues exportees doivent se terminer par
       , CONVERT(bit, 0) AS FL_FIN_JOURNEE
   et porter C.__$start_lsn AS CD_LSN_TEC en 5e colonne technique.
   ============================================================================ */

IF EXISTS (SELECT 1 FROM tempdb.sys.tables WHERE name LIKE '##TableListODS%')
    DROP TABLE ##TableListODS;
GO

CREATE TABLE ##TableListODS (
    TableNameSource   sysname NOT NULL,
    TableNameCibleODS sysname NOT NULL,
    TableNameCibleDWH sysname NOT NULL,
    NbColonnesCle     int     NULL,
    CreateScriptODS   nvarchar(MAX) NULL,
    CreateScriptDWH   nvarchar(MAX) NULL
);
GO

--  Perimetre : tables sous CDC (table d'audit cdc.TEC_AUD_CDC)
INSERT INTO ##TableListODS (TableNameSource, TableNameCibleODS, TableNameCibleDWH)
SELECT
    t.name              AS TableNameSource,
    'OIT_' + t.name     AS TableNameCibleODS,
    'OWT_' + t.name     AS TableNameCibleDWH
FROM sys.tables t
INNER JOIN sys.schemas s
    ON s.schema_id = t.schema_id
INNER JOIN [cdc].[TEC_AUD_CDC] tm
    ON tm.LB_INSTANCE = ('dbo_' + t.name)
ORDER BY t.name;

SET NOCOUNT ON;

DECLARE @SchemaSource   sysname = N'dbo';
DECLARE @SchemaCibleODS sysname = N'ods';   -- <<< schema cible ODS
DECLARE @SchemaCibleDWH sysname = N'dbo';   -- <<< schema cible DWH

/* ----------------------------------------------------------------
   OPTIONS DE GENERATION
   ---------------------------------------------------------------- */
DECLARE @DROP_EXISTANT    bit = 0;  -- 1 = DROP + CREATE (DESTRUCTIF : vide les OWT)
DECLARE @REPRENDRE_DEFAUTS bit = 0; -- 1 = recopier les contraintes DEFAULT de la source

/* ----------------------------------------------------------------
   COLONNES TECHNIQUES (listes ajustables)
   ---------------------------------------------------------------- */
-- En TETE de OIT (memes noms/ordre que la vue CDC exportee) :
DECLARE @TechColsCDC nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL';
-- CD_LSN_TEC = __$start_lsn. Necessaire au rechargement idempotent : avant
-- chaque BCP IN, l'import supprime la plage ] LB_DEB_LSN ; LB_FIN_LSN ] que
-- le fichier va recharger. Le LSN est exact, la datetime ne l'est pas (deux
-- commits peuvent partager la meme milliseconde).

-- En FIN de OIT :
DECLARE @TechColsODS nvarchar(MAX) = N'[FL_FIN_JOURNEE] bit NOT NULL DEFAULT (0)';

-- En FIN de OWT (tracabilite TEC + bloc technique maison).
-- Noms et ordre ALIGNES sur PS_CHARGEMENT_ODS_DWH pour que les deux moteurs
-- d'historisation produisent des tables lisibles de la meme facon.
DECLARE @TechColsDWH nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL,' + CHAR(13) +
      N'        [NO_SEQ] int NULL,' + CHAR(13) +
      N'        [DT_DEB_VAL] date NOT NULL,' + CHAR(13) +
      N'        [DT_FIN_VAL] date NOT NULL DEFAULT (''2400-01-01''),' + CHAR(13) +
      N'        [FL_SUP] bit NULL,' + CHAR(13) +
      N'        [FL_VER_CRT] bit NOT NULL DEFAULT (1),' + CHAR(13) +
      N'        [DT_MAJ] datetime NULL DEFAULT (GETDATE()),' + CHAR(13) +
      N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13) +
      N'        [ID_TRT_ALI] int NULL';

DECLARE
    @TableNameSource   sysname,
    @TableNameCibleODS sysname,
    @TableNameCibleDWH sysname,
    @CreateODS         nvarchar(MAX),
    @CreateDWH         nvarchar(MAX),
    @PKSorted          nvarchar(MAX),
    @PKPlain           nvarchar(MAX),
    @NbCle             int,
    @IsClustered       bit;

DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT TableNameSource, TableNameCibleODS, TableNameCibleDWH
    FROM ##TableListODS;

OPEN cur;
FETCH NEXT FROM cur INTO @TableNameSource, @TableNameCibleODS, @TableNameCibleDWH;

WHILE @@FETCH_STATUS = 0
BEGIN
    /* 1) Colonnes metier de la source (types exacts) */
    IF OBJECT_ID('tempdb..#cols') IS NOT NULL DROP TABLE #cols;

    SELECT
        c.column_id,
        ColumnName = QUOTENAME(c.name),
        TypeBase =
            CASE
                WHEN t.name IN ('varchar','char','varbinary','binary')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length = -1 THEN 'MAX'
                              ELSE CAST(c.max_length AS varchar(10)) END + ')'
                WHEN t.name IN ('nvarchar','nchar')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length <> -1 THEN CAST(c.max_length/2 AS varchar(10))
                              ELSE 'MAX' END + ')'
                WHEN t.name IN ('decimal','numeric')
                    THEN t.name + '(' + CAST(c.precision AS varchar(10)) + ',' + CAST(c.scale AS varchar(10)) + ')'
                WHEN t.name IN ('datetime2','time','datetimeoffset')
                    THEN t.name + '(' + CAST(c.scale AS varchar(10)) + ')'
                ELSE t.name
            END,
        DefaultClause =
            CASE WHEN @REPRENDRE_DEFAUTS = 1 AND dc.definition IS NOT NULL
                 THEN ' DEFAULT ' + dc.definition
                 ELSE '' END,
        NullClause =
            CASE WHEN c.is_nullable = 1 THEN ' NULL' ELSE ' NOT NULL' END
    INTO #cols
    FROM sys.tables tb
    JOIN sys.schemas s ON s.schema_id = tb.schema_id
    JOIN sys.columns c ON c.object_id = tb.object_id
    JOIN sys.types   t ON t.user_type_id = c.user_type_id
    LEFT JOIN sys.default_constraints dc
           ON dc.parent_object_id = tb.object_id AND dc.parent_column_id = c.column_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND c.is_computed = 0
      AND c.name NOT LIKE 'CS%';        -- colonnes techniques CDC source exclues (comme la vue)

    /* 2) PK de la source (2 formats) */
    SELECT @PKSorted = NULL, @PKPlain = NULL, @IsClustered = NULL, @NbCle = 0;

    SELECT
        @IsClustered = CASE WHEN idx.type = 1 THEN 1 ELSE 0 END,
        @NbCle    = COUNT(*),
        @PKSorted = STRING_AGG(QUOTENAME(c.name)
                        + CASE WHEN ic.is_descending_key = 1 THEN ' DESC' ELSE ' ASC' END,
                        ', ') WITHIN GROUP (ORDER BY ic.key_ordinal),
        @PKPlain  = STRING_AGG(QUOTENAME(c.name), ', ') WITHIN GROUP (ORDER BY ic.key_ordinal)
    FROM sys.tables tb
    JOIN sys.schemas s          ON s.schema_id = tb.schema_id
    JOIN sys.key_constraints kc ON kc.parent_object_id = tb.object_id
    JOIN sys.indexes idx        ON idx.object_id = kc.parent_object_id
                               AND idx.index_id  = kc.unique_index_id
    JOIN sys.index_columns ic   ON ic.object_id = idx.object_id
                               AND ic.index_id  = idx.index_id
    JOIN sys.columns c          ON c.object_id = ic.object_id
                               AND c.column_id = ic.column_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND kc.type = 'PK'
    GROUP BY idx.type;

    /* 3) Script ODS : TEC en tete + metier (tout NULLable) + FL_FIN_JOURNEE
          SANS PK (plusieurs traces par cle) ; index cle + DT_COMMIT_TEC */
    SELECT @CreateODS =
        CASE WHEN @DROP_EXISTANT = 1
             THEN 'IF OBJECT_ID(N''' + @SchemaCibleODS + '.' + @TableNameCibleODS + ''',''U'') IS NOT NULL DROP TABLE '
                  + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS) + ';' + CHAR(13) + CHAR(13)
             ELSE '' END +
        'IF OBJECT_ID(N''' + @SchemaCibleODS + '.' + @TableNameCibleODS + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS) + ' (' + CHAR(13) +
        '        ' + @TechColsCDC + ',' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + DefaultClause + ' NULL',
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsODS + CHAR(13) +
        '    );' + CHAR(13)
        + CASE WHEN @PKPlain IS NOT NULL
               THEN 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleODS + '_CLE')
                    + ' ON ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS)
                    + ' (' + @PKPlain + ', [DT_COMMIT_TEC]);' + CHAR(13)
               ELSE 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleODS + '_COMMIT')
                    + ' ON ' + QUOTENAME(@SchemaCibleODS) + '.' + QUOTENAME(@TableNameCibleODS)
                    + ' ([DT_COMMIT_TEC]);' + CHAR(13) END
        + 'END;'
    FROM #cols;

    /* 4) Script DWH : metier + TEC + tech DWH ; PK = (PK source + DT_DEB_VAL)
          + index de purge / fermeture SCD2 (voir R4 en tete de fichier) */
    SELECT @CreateDWH =
        CASE WHEN @DROP_EXISTANT = 1
             THEN 'IF OBJECT_ID(N''' + @SchemaCibleDWH + '.' + @TableNameCibleDWH + ''',''U'') IS NOT NULL DROP TABLE '
                  + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH) + ';' + CHAR(13) + CHAR(13)
             ELSE '' END +
        'IF OBJECT_ID(N''' + @SchemaCibleDWH + '.' + @TableNameCibleDWH + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH) + ' (' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + DefaultClause + NullClause,
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsDWH +
        CASE WHEN @PKSorted IS NOT NULL
             THEN ',' + CHAR(13) + '        CONSTRAINT ' + QUOTENAME('PK_' + @TableNameCibleDWH)
                  + ' PRIMARY KEY ' + CASE WHEN @IsClustered = 1 THEN 'CLUSTERED ' ELSE 'NONCLUSTERED ' END
                  + '(' + @PKSorted + ', [DT_DEB_VAL] ASC)'
             ELSE '' END
        + CHAR(13) + '    );' + CHAR(13)
        -- Index UNIQUE filtre : garantit STRUCTURELLEMENT qu'une cle n'a
        -- jamais plus d'une version courante. Remplace le controle
        -- anti-doublon qui balayait la table entiere a chaque journee :
        -- un doublon fait echouer l'INSERT immediatement, avant ecriture.
        + CASE WHEN @PKPlain IS NOT NULL
               THEN 'CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME('UX_' + @TableNameCibleDWH + '_VER_CRT')
                    + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
                    + ' (' + @PKPlain + ') WHERE [FL_VER_CRT] = 1;' + CHAR(13)
               ELSE '' END
        -- purge de la journee (etape D2) : DELETE ... WHERE DT_DEB_VAL = @jour
        + 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleDWH + '_DT_DEB_VAL')
        + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
        + ' ([DT_DEB_VAL]);' + CHAR(13)
        -- reouverture (etape D2) : UPDATE ... WHERE DT_FIN_VAL = @jour AND FL_VER_CRT = 0
        + 'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameCibleDWH + '_DT_FIN_VAL')
        + ' ON ' + QUOTENAME(@SchemaCibleDWH) + '.' + QUOTENAME(@TableNameCibleDWH)
        + ' ([DT_FIN_VAL], [FL_VER_CRT]);' + CHAR(13)
        + 'END;'
    FROM #cols;

    /* 5) Mise a jour dans la table de correspondance */
    UPDATE ##TableListODS
       SET CreateScriptODS = @CreateODS,
           CreateScriptDWH = @CreateDWH,
           NbColonnesCle   = @NbCle
     WHERE TableNameSource = @TableNameSource;

    /* ==============================================================
       OPTION A : EXECUTER LES SCRIPTS IMMEDIATEMENT (uniquement si ce
       script tourne sur le DWH ; sinon copier la sortie ci-dessous)
       ==============================================================
     PRINT 'Execution ODS : ' + @TableNameCibleODS;  EXEC(@CreateODS);
     PRINT 'Execution DWH : ' + @TableNameCibleDWH;  EXEC(@CreateDWH); */

    FETCH NEXT FROM cur INTO @TableNameSource, @TableNameCibleODS, @TableNameCibleDWH;
END

CLOSE cur;
DEALLOCATE cur;
GO

/* ---------------------------------------------------------------------------
   RESULTAT
--------------------------------------------------------------------------- */
SELECT * FROM ##TableListODS ORDER BY TableNameSource;

/* Tables SANS cle primaire : elles seront generees sans PK cote OWT et
   devront recevoir une cle fonctionnelle manuelle dans le parametrage,
   sinon le package les ignorera (aucune ligne FL_CLEF = 1). */
SELECT TableNameSource, TableNameCibleODS, TableNameCibleDWH
FROM ##TableListODS
WHERE ISNULL(NbColonnesCle, 0) = 0
ORDER BY TableNameSource;
