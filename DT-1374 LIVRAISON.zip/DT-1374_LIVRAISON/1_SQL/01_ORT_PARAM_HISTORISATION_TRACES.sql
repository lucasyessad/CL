/* ============================================================================
   dbo.ORT_PARAM_HISTORISATION_TRACES   (base DWH)

   Perimetre et regles de l'historisation, au grain COLONNE : une ligne par
   champ, format maison PARAM_CHARGEMENT.

     FL_CLEF = 1        colonne de la cle fonctionnelle
     FL_CHARGEMENT = 1  (sur les lignes cle) table active dans le perimetre
     FL_ORDRE_TRI = 1   colonne d'horodatage : la premiere au sens NO_CHAMP
                        borne la fenetre, les suivantes departagent
     LB_FILTRE_WHERE    filtre optionnel sur la source, porte par la ligne cle
     LB_CHAMP_ODS/DWH   mapping ; les noms peuvent differer

   Alimentee par le generateur 09. Script non destructif : il ne recree pas
   la table si elle existe, pour ne pas perdre les ajustements manuels.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PARAM_HISTORISATION_TRACES', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
    (
        LB_PROJET        NVARCHAR(50)   NOT NULL DEFAULT ('LIGIS'),
        LB_SOURCE        NVARCHAR(200)  NULL,
        LB_TABLE_ODS     NVARCHAR(128)  NOT NULL,
        LB_TABLE_DWH     NVARCHAR(200)  NOT NULL,
        NO_CHAMP         INT            NOT NULL,
        LB_CHAMP_ODS     NVARCHAR(128)  NULL,
        LB_CHAMP_DWH     NVARCHAR(128)  NULL,
        LB_SCD           NVARCHAR(30)   NULL,
        FL_CLEF          BIT            NOT NULL DEFAULT (0),
        FL_CHARGEMENT    BIT            NULL,
        FL_ORDRE_TRI     BIT            NOT NULL DEFAULT (0),
        LB_FILTRE_WHERE  NVARCHAR(1000) NULL,
        CONSTRAINT PK_ORT_PARAM_HISTORISATION_TRACES
            PRIMARY KEY (LB_PROJET, LB_TABLE_ODS, NO_CHAMP)
    );

    CREATE NONCLUSTERED INDEX IX_ORT_PARAM_HISTO_ACTIVES
        ON dbo.ORT_PARAM_HISTORISATION_TRACES (FL_CLEF, FL_CHARGEMENT)
        INCLUDE (LB_TABLE_ODS, LB_TABLE_DWH);
END
GO
