/* ============================================================================
   dbo.OWT_TEC_AUD_CDC   (base DWH)

   Archive historique de l'audit CDC. ods.OIT_TEC_AUD_CDC etant videe a chaque
   import, la couverture LSN de chaque extraction y serait perdue.

   Mode APPEND : une ligne d'audit est un evenement (une extraction pour une
   instance), pas un etat qui se ferme et se rouvre. Pas de DT_DEB_VAL /
   DT_FIN_VAL / FL_VER_CRT. L'index unique (LB_INSTANCE, LB_FIN_LSN) rend
   l'alimentation rejouable : deux imports sans nouvelle extraction
   n'archivent qu'une fois.

   Alimentee par l'etape ODI 03.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.OWT_TEC_AUD_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.OWT_TEC_AUD_CDC
    (
        ID_INSTANCE   BINARY(32)     NULL,
        LB_INSTANCE   NVARCHAR(128)  NULL,
        LB_DEB_LSN    BINARY(10)     NULL,
        LB_FIN_LSN    BINARY(10)     NULL,
        DT_DEB_LSN    DATETIME2(3)   NULL,
        DT_FIN_LSN    DATETIME2(3)   NULL,
        DT_EXTRACT    DATETIME2(3)   NULL,
        DT_JOUR_TEC   DATE           NULL,   -- journee bornee de rattachement
        ID_TRT_ALI    INT            NULL,
        DT_MAJ        DATETIME       NOT NULL DEFAULT (GETDATE())
    );

    CREATE UNIQUE NONCLUSTERED INDEX UX_OWT_TEC_AUD_CDC_EXTRACTION
        ON dbo.OWT_TEC_AUD_CDC (LB_INSTANCE, LB_FIN_LSN);

    CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUD_CDC_JOUR
        ON dbo.OWT_TEC_AUD_CDC (DT_JOUR_TEC) INCLUDE (LB_INSTANCE, DT_FIN_LSN);
END
GO

/* Exploitation
-------------------------------------------------------------------------------
-- Quelle instance a determine la borne d'une journee (la moins avancee) :
SELECT LB_INSTANCE, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM dbo.OWT_TEC_AUD_CDC
WHERE DT_JOUR_TEC = '2026-07-22'
ORDER BY COALESCE(DT_FIN_LSN, DT_EXTRACT);

-- Continuite des LSN par instance : le debut d'une extraction doit egaler la
-- fin de la precedente. Toute ligne remontee signale un trou de capture.
SELECT LB_INSTANCE, DT_MAJ, LB_DEB_LSN,
       lsn_fin_precedent = LAG(LB_FIN_LSN) OVER (PARTITION BY LB_INSTANCE ORDER BY DT_MAJ)
FROM dbo.OWT_TEC_AUD_CDC
WHERE LB_DEB_LSN <> ISNULL(LAG(LB_FIN_LSN) OVER (PARTITION BY LB_INSTANCE ORDER BY DT_MAJ), LB_DEB_LSN);
---------------------------------------------------------------------------- */
