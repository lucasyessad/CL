/* ============================================================================
   dbo.ORT_BORNE_JOURNEE   (base DWH)

   Frontieres des journees fonctionnelles. La journee J couvre
       ] DT_BORNE(J-1) ; DT_BORNE(J) ]
   avec DT_BORNE(J) = jour ouvrable suivant J, a 07:45:00.000.

   Une trace ecrite le 23 a 03:08 appartient donc a la journee du 22, sa
   frontiere etant le 23 a 07:45.

   Alimentee par l'etape ODI 02, une ligne par journee close.
   DATETIME2(3) : meme precision que DT_COMMIT_TEC, pas d'ambiguite aux
   frontieres.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_BORNE_JOURNEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_BORNE_JOURNEE
    (
        DT_JOUR         DATE           NOT NULL,
        DT_BORNE        DATETIME2(3)   NOT NULL,
        TYPE_BORNE      NVARCHAR(15)   NOT NULL DEFAULT ('QUOTIDIEN'),
        ORIGINE_VALEUR  NVARCHAR(20)   NOT NULL DEFAULT ('AUDIT_CDC'),
        DT_POSE         DATETIME       NOT NULL DEFAULT (GETDATE()),
        COMMENTAIRE     NVARCHAR(500)  NULL,
        CONSTRAINT PK_ORT_BORNE_JOURNEE PRIMARY KEY (DT_JOUR),
        CONSTRAINT UQ_ORT_BORNE_JOURNEE_DT_BORNE UNIQUE (DT_BORNE),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_TYPE
            CHECK (TYPE_BORNE IN ('QUOTIDIEN','INIT')),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_ORIGINE
            CHECK (ORIGINE_VALEUR IN ('AUDIT_CDC','MANUEL'))
    );
END
GO
