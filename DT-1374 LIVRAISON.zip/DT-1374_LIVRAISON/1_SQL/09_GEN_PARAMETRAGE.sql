/* ============================================================================
   Generation de l'alimentation de dbo.ORT_PARAM_HISTORISATION_TRACES
   A EXECUTER SUR LA BASE SOURCE LIGIS. Produit, pour chaque table sous CDC,
   un DELETE + INSERT a executer sur le DWH.

   Numerotation generee, continue et sans collision :
     1..k      colonnes de la PK source      FL_CLEF = 1, FL_CHARGEMENT = 1
     k+1       DT_COMMIT_TEC                 FL_ORDRE_TRI = 1  (borne de fenetre)
     k+2       CD_SEQ_TEC                    FL_ORDRE_TRI = 1  (departage)
     k+3..k+5  ID_INSTANCE_TEC, CD_CMD_TEC, CD_LSN_TEC   tracabilite
     ensuite   colonnes metier hors cle
     fin       lignes documentaires : FL_FIN_JOURNEE puis le bloc technique
               DWH (NO_SEQ, DT_DEB_VAL, DT_FIN_VAL, FL_SUP, FL_VER_CRT,
               DT_MAJ, CD_USR_MAJ, ID_TRT_ALI)

   Le DELETE porte sur (LB_PROJET, LB_TABLE_ODS) : un autre projet utilisant
   le meme nom de table n'est pas efface.

   La sortie est aussi fournie en colonne XML : SSMS tronque l'affichage des
   colonnes nvarchar(max), le script copie serait incomplet sans avertissement.

   A ajuster manuellement apres generation : renommages ODS -> DWH,
   LB_FILTRE_WHERE sur la ligne cle, FL_CHARGEMENT = 0 pour desactiver une
   table, et la cle des tables sans PK (voir le controle en fin de script).
   ============================================================================ */

IF EXISTS (SELECT 1 FROM tempdb.sys.tables WHERE name LIKE '##ParamHistoScript%')
    DROP TABLE ##ParamHistoScript;
GO

CREATE TABLE ##ParamHistoScript (
    TableNameSource sysname NOT NULL,
    NbColonnesCle   int     NULL,
    NbLignesParam   int     NULL,
    InsertScript    nvarchar(MAX) NULL
);
GO

SET NOCOUNT ON;

DECLARE @SchemaSource sysname       = N'dbo';
DECLARE @LB_PROJET    nvarchar(50)  = N'LIGIS';
DECLARE @TableParam   nvarchar(300) = N'dbo.ORT_PARAM_HISTORISATION_TRACES';
        -- prefixer par la base DWH si execution directe cross-base

INSERT INTO ##ParamHistoScript (TableNameSource)
SELECT t.name
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN [cdc].[TEC_AUD_CDC] tm ON tm.LB_INSTANCE = ('dbo_' + t.name)
WHERE s.name = @SchemaSource
ORDER BY t.name;

DECLARE @TableNameSource sysname, @Script nvarchar(MAX), @NbCle int, @NbLignes int;

DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT TableNameSource FROM ##ParamHistoScript;

OPEN cur;
FETCH NEXT FROM cur INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Script = NULL;

    SELECT @NbCle = COUNT(*)
    FROM sys.key_constraints kc
    JOIN sys.index_columns ic ON ic.object_id = kc.parent_object_id
                             AND ic.index_id  = kc.unique_index_id
    WHERE kc.parent_object_id = OBJECT_ID(@SchemaSource + '.' + @TableNameSource)
      AND kc.type = 'PK';

    ;WITH pk_cols AS (
        SELECT c.name, ic.key_ordinal
        FROM sys.key_constraints kc
        JOIN sys.index_columns ic ON ic.object_id = kc.parent_object_id
                                 AND ic.index_id  = kc.unique_index_id
        JOIN sys.columns c        ON c.object_id = ic.object_id
                                 AND c.column_id = ic.column_id
        WHERE kc.parent_object_id = OBJECT_ID(@SchemaSource + '.' + @TableNameSource)
          AND kc.type = 'PK'
    ),
    src_cols AS (
        SELECT c.name, c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@SchemaSource + '.' + @TableNameSource)
          AND c.is_computed = 0
          AND c.name NOT LIKE 'CS%'
    ),
    lignes AS (
        /* 1. cle fonctionnelle = PK source */
        SELECT grp = 1, ord = key_ordinal,
               champ_ods = name, champ_dwh = name,
               scd = 'TYPE 2', clef = 1, chg = 1, tri = 0
        FROM pk_cols
        UNION ALL
        /* 2. colonnes techniques CDC : ordre puis tracabilite */
        SELECT 2, 1, 'DT_COMMIT_TEC',   'DT_COMMIT_TEC',   NULL, 0, NULL, 1
        UNION ALL
        SELECT 2, 2, 'CD_SEQ_TEC',      'CD_SEQ_TEC',      NULL, 0, NULL, 1
        UNION ALL
        SELECT 2, 3, 'ID_INSTANCE_TEC', 'ID_INSTANCE_TEC', NULL, 0, NULL, 0
        UNION ALL
        SELECT 2, 4, 'CD_CMD_TEC',      'CD_CMD_TEC',      NULL, 0, NULL, 0
        UNION ALL
        SELECT 2, 5, 'CD_LSN_TEC',      'CD_LSN_TEC',      NULL, 0, NULL, 0
        UNION ALL
        /* 3. colonnes metier hors cle */
        SELECT 3, column_id, name, name, NULL, 0, NULL, 0
        FROM src_cols
        WHERE name NOT IN (SELECT name FROM pk_cols)
        UNION ALL
        /* 4. lignes documentaires (numerotees a la suite) */
        SELECT 4, 1, 'FL_FIN_JOURNEE', NULL,           NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 2, NULL,             'NO_SEQ',       NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 3, NULL,             'DT_DEB_VAL',   NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 4, NULL,             'DT_FIN_VAL',   NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 5, NULL,             'FL_SUP',       NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 6, NULL,             'FL_VER_CRT',   NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 7, NULL,             'DT_MAJ',       NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 8, NULL,             'CD_USR_MAJ',   NULL, 0, NULL, 0
        UNION ALL
        SELECT 4, 9, NULL,             'ID_TRT_ALI',   NULL, 0, NULL, 0
    ),
    numerotees AS (
        SELECT *, NO_CHAMP = ROW_NUMBER() OVER (ORDER BY grp, ord)
        FROM lignes
    )
    SELECT @Script =
        'DELETE FROM ' + @TableParam
        + ' WHERE LB_PROJET = ''' + @LB_PROJET + ''''
        + ' AND LB_TABLE_ODS = ''OIT_' + @TableNameSource + ''';' + CHAR(13) +
        'INSERT INTO ' + @TableParam + CHAR(13) +
        '    (LB_PROJET, LB_SOURCE, LB_TABLE_ODS, LB_TABLE_DWH, NO_CHAMP,' + CHAR(13) +
        '     LB_CHAMP_ODS, LB_CHAMP_DWH, LB_SCD, FL_CLEF, FL_CHARGEMENT,' + CHAR(13) +
        '     FL_ORDRE_TRI, LB_FILTRE_WHERE)' + CHAR(13) +
        'VALUES' + CHAR(13) +
        STRING_AGG(CAST(
            ' (''' + @LB_PROJET + ''',''dbo_' + @TableNameSource + ''',''OIT_' + @TableNameSource
            + ''',''OWT_' + @TableNameSource + ''',' + CAST(NO_CHAMP AS nvarchar(10)) + ','
            + CASE WHEN champ_ods IS NULL THEN 'NULL'
                   ELSE '''' + REPLACE(champ_ods, '''', '''''') + '''' END + ','
            + CASE WHEN champ_dwh IS NULL THEN 'NULL'
                   ELSE '''' + REPLACE(champ_dwh, '''', '''''') + '''' END + ','
            + CASE WHEN scd IS NULL THEN 'NULL' ELSE '''' + scd + '''' END + ','
            + CAST(clef AS nvarchar(1)) + ','
            + CASE WHEN chg IS NULL THEN 'NULL' ELSE CAST(chg AS nvarchar(1)) END + ','
            + CAST(tri AS nvarchar(1)) + ',NULL)'
        AS nvarchar(MAX)), ',' + CHAR(13)) WITHIN GROUP (ORDER BY NO_CHAMP)
        + ';',
        @NbLignes = COUNT(*)
    FROM numerotees;

    UPDATE ##ParamHistoScript
       SET InsertScript  = @Script,
           NbColonnesCle = @NbCle,
           NbLignesParam = @NbLignes
     WHERE TableNameSource = @TableNameSource;

    /* ==============================================================
       OPTION A : EXECUTER IMMEDIATEMENT (si @TableParam est atteignable
       depuis cette base ; sinon copier la sortie XML ci-dessous)
       ==============================================================
     PRINT 'Alimentation parametrage : OIT_' + @TableNameSource;
     EXEC(@Script); */

    FETCH NEXT FROM cur INTO @TableNameSource;
END

CLOSE cur;
DEALLOCATE cur;
GO

/* ---------------------------------------------------------------------------
   1. SCRIPT COMPLET A EXECUTER SUR LE DWH (colonne XML : cliquer pour ouvrir
      le texte integral, sans troncature d'affichage)
--------------------------------------------------------------------------- */
SELECT ScriptComplet =
    (SELECT CHAR(13) + InsertScript + CHAR(13)
     FROM ##ParamHistoScript
     ORDER BY TableNameSource
     FOR XML PATH(''), TYPE);

/* 2. Detail table par table */
SELECT TableNameSource, NbColonnesCle, NbLignesParam, InsertScript
FROM ##ParamHistoScript
ORDER BY TableNameSource;

/* 3. CONTROLE : tables SANS cle primaire. Elles n'auront aucune ligne
      FL_CLEF = 1 et seront donc IGNOREES par le package tant qu'une cle
      fonctionnelle n'aura pas ete renseignee manuellement. */
SELECT TableNameSource, NbLignesParam
FROM ##ParamHistoScript
WHERE ISNULL(NbColonnesCle, 0) = 0
ORDER BY TableNameSource;

/* 4. CONTROLE A PASSER SUR LE DWH APRES EXECUTION : coherence du
      parametrage charge (doit renvoyer 0 ligne).
-------------------------------------------------------------------------------
SELECT LB_TABLE_ODS, probleme
FROM (
    SELECT LB_TABLE_ODS,
           probleme = CASE
             WHEN SUM(CASE WHEN FL_CLEF = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne cle (FL_CLEF = 1)'
             WHEN SUM(CASE WHEN FL_ORDRE_TRI = 1 THEN 1 ELSE 0 END) = 0
                  THEN 'aucune colonne d''ordre (FL_ORDRE_TRI = 1)'
             WHEN SUM(CASE WHEN FL_CLEF = 1 AND (LB_CHAMP_ODS IS NULL OR LB_CHAMP_DWH IS NULL)
                           THEN 1 ELSE 0 END) > 0
                  THEN 'ligne cle avec mapping ODS/DWH incomplet'
             ELSE NULL END
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE LB_PROJET = 'LIGIS'
    GROUP BY LB_TABLE_ODS
) c
WHERE probleme IS NOT NULL
ORDER BY LB_TABLE_ODS;
--------------------------------------------------------------------------- */
