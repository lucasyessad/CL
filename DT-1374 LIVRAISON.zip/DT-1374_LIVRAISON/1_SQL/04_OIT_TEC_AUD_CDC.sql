/* ============================================================================
   ods.OIT_TEC_AUD_CDC   (base DWH, schema ods)

   Reception de la vue d'audit CDC cdc.ZBCP_LIGIS_TEC_AUD_CDC_V, chargee par
   le BCPIN avec les traces.

   C'est la seule source de la couverture d'extraction : l'etape ODI 02 y lit
   MIN(COALESCE(DT_FIN_LSN, DT_EXTRACT)) sur les instances du perimetre. Le
   MIN et non le MAX : la table la moins avancee determine jusqu'ou TOUTES
   les tables sont completes.

   Table d'atterrissage : videe et rechargee a chaque import. L'historique
   est conserve dans dbo.OWT_TEC_AUD_CDC.

   Elle n'est pas produite par le generateur 07 : son perimetre est celui des
   tables sous CDC, or l'audit n'est pas une table capturee.

   L'ordre des colonnes doit etre celui de la vue exportee : le BCP en format
   natif est positionnel.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF SCHEMA_ID('ods') IS NULL
    EXEC('CREATE SCHEMA ods');
GO

IF OBJECT_ID('ods.OIT_TEC_AUD_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE ods.OIT_TEC_AUD_CDC
    (
        ID_INSTANCE   BINARY(32)     NULL,   -- identifiant de l'instance de capture
        LB_INSTANCE   NVARCHAR(128)  NULL,   -- 'dbo_' + nom de la table source
        LB_DEB_LSN    BINARY(10)     NULL,   -- borne basse d'extraction (exclue)
        LB_FIN_LSN    BINARY(10)     NULL,   -- borne haute d'extraction (incluse)
        DT_DEB_LSN    DATETIME2(3)   NULL,
        DT_FIN_LSN    DATETIME2(3)   NULL,   -- datetime de couverture
        DT_EXTRACT    DATETIME2(3)   NULL    -- utilisee si DT_FIN_LSN est NULL
    );

    CREATE NONCLUSTERED INDEX IX_OIT_TEC_AUD_CDC_INSTANCE
        ON ods.OIT_TEC_AUD_CDC (LB_INSTANCE) INCLUDE (DT_FIN_LSN, DT_EXTRACT);
END
GO

/* Controle : les datetimes doivent etre alimentees par le traitement amont.
   Tant qu'elles sont NULL, aucune journee ne peut etre bornee.
-------------------------------------------------------------------------------
SELECT LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM ods.OIT_TEC_AUD_CDC
ORDER BY LB_INSTANCE;
---------------------------------------------------------------------------- */
