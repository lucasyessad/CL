/* ============================================================================
   dbo.ORT_AUDIT_CHARGEMENT   (base DWH)

   Audit du traitement, structure identique au standard maison
   AUDIT_CHARGEMENT (CL_ESTIM), prefixee ORT.

   Volumetrie : une ligne par table et par journee traitee, plus une ligne
   de bilan par journee et trois lignes par execution (borne, archive audit,
   cadrage). Les etapes intermediaires n'ecrivent qu'en cas d'anomalie.

   Elle est aussi LUE par le traitement : les etapes 10, 11 et 12 y cherchent
   les tables deja en KO dans la session pour les ecarter, d'ou l'index sur
   (ID_TRT_ALI, LB_PROJET, CD_STATUT).

   Conventions : LB_PROJET = 'LIGIS', journee entre crochets dans
   LB_CHARGEMENT, CD_STATUT limite a OK / KO (les avertissements sont des OK
   avec LB_ERREUR renseigne), ID_TRT_ALI = numero de session ODI.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_AUDIT_CHARGEMENT', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_AUDIT_CHARGEMENT
    (
        ID_TRT_ALI     INT             NULL,
        LB_PROJET      NVARCHAR(50)    NULL,
        LB_CHARGEMENT  NVARCHAR(100)   NULL,
        LB_SOURCE      NVARCHAR(200)   NULL,
        LB_CIBLE       NVARCHAR(200)   NULL,
        NB_LIGNE       INT             NULL,
        CD_STATUT      NVARCHAR(10)    NULL,
        LB_ERREUR      NVARCHAR(MAX)   NULL,
        DT_DEBUT       DATETIME        NULL,
        DT_FIN         DATETIME        NULL
    );

    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_PROJET_DT
        ON dbo.ORT_AUDIT_CHARGEMENT (LB_PROJET, DT_DEBUT);

    CREATE NONCLUSTERED INDEX IX_ORT_AUDIT_CHARGEMENT_SESSION
        ON dbo.ORT_AUDIT_CHARGEMENT (ID_TRT_ALI, LB_PROJET, CD_STATUT)
        INCLUDE (LB_SOURCE, LB_CHARGEMENT);
END
GO
