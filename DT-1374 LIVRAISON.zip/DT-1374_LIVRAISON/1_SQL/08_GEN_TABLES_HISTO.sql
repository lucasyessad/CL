/* ============================================================================
   DT-1374 - Generation des tables d'archive  ODS_Traces.dbo.OIT_<table>_HISTO
   A EXECUTER SUR LA BASE SOURCE LIGIS (le perimetre et les structures y sont
   lus). Les scripts produits sont a executer sur la base ODS_Traces.

   ods.OIT_<table> (base DWH) est un SAS DE TRAVAIL : il ne contient que les
   traces pas encore traitees. Des qu'une journee est historisee, ses traces
   sont copiees ici puis supprimees du sas.
   ODS_Traces.dbo.OIT_<table>_HISTO conserve l'integralite des traces deja
   traitees : source pour rejouer un historique, auditer une image passee ou
   alimenter un autre traitement.

   STRUCTURE : identique a ods.OIT_<table>, colonne pour colonne et dans le
   meme ordre, pour que la copie soit un simple INSERT ... SELECT sans
   mapping. FL_FIN_JOURNEE est conservee : elle indique quelle trace a servi
   d'image de fin de journee, information qui a de la valeur a posteriori.

   Colonnes techniques ajoutees en fin, alignees sur le bloc maison des
   tables OWT (PS_CHARGEMENT_ODS_DWH) :
     DT_JOUR_TEC   journee fonctionnelle a laquelle la trace a ete rattachee
     DT_MAJ        horodatage de l'archivage
     CD_USR_MAJ    'SUPERVIS'
     ID_TRT_ALI    numero de session ODI ayant archive la trace

   LA DATE DE CHARGEMENT DANS LE SAS N'EST PAS STOCKEE ICI, et ce n'est pas
   un oubli : le BCP en format natif est positionnel, une colonne absente du
   fichier ferait echouer le chargement. Elle reste neanmoins retrouvable -
   ID_INSTANCE_TEC identifie l'extraction, et dbo.OWT_TEC_AUD_CDC en
   conserve les datetimes :
     SELECT H.CD_LSN_TEC, H.DT_COMMIT_TEC, H.DT_JOUR_TEC, H.DT_MAJ,
            A.DT_FIN_LSN AS dt_extraction, A.DT_MAJ AS dt_archivage_audit
     FROM ODS_Traces.dbo.OIT_CONTRAT_HISTO H
     JOIN DWH.dbo.OWT_TEC_AUD_CDC A ON A.ID_INSTANCE = H.ID_INSTANCE_TEC;

   CES TABLES NE SONT JAMAIS VIDEES PAR LE PACKAGE. Leur purge (retention
   13 mois evoquee au ticket) releve d'un traitement distinct, d'ou l'index
   sur DT_JOUR_TEC.
   ============================================================================ */

IF EXISTS (SELECT 1 FROM tempdb.sys.tables WHERE name LIKE '##TableListHisto%')
    DROP TABLE ##TableListHisto;
GO

CREATE TABLE ##TableListHisto (
    TableNameSource sysname NOT NULL,
    TableNameHisto  sysname NOT NULL,
    CreateScript    nvarchar(MAX) NULL
);
GO

SET NOCOUNT ON;

DECLARE @SchemaSource sysname = N'dbo';
DECLARE @BaseHisto    sysname = N'ODS_Traces';   -- <<< base d'archive
DECLARE @SchemaHisto  sysname = N'dbo';          -- <<< schema d'archive

INSERT INTO ##TableListHisto (TableNameSource, TableNameHisto)
SELECT t.name, 'OIT_' + t.name + '_HISTO'
FROM sys.tables t
INNER JOIN sys.schemas s ON s.schema_id = t.schema_id
INNER JOIN [cdc].[TEC_AUD_CDC] tm ON tm.LB_INSTANCE = ('dbo_' + t.name)
WHERE s.name = @SchemaSource
ORDER BY t.name;

/* Colonnes techniques : memes definitions que dans 07_GENERATION_OIT_OWT.sql */
DECLARE @TechColsCDC nvarchar(MAX) =
      N'[ID_INSTANCE_TEC] binary(32) NULL,' + CHAR(13) +
      N'        [CD_SEQ_TEC] varbinary(10) NULL,' + CHAR(13) +
      N'        [CD_CMD_TEC] int NULL,' + CHAR(13) +
      N'        [DT_COMMIT_TEC] datetime2(3) NULL,' + CHAR(13) +
      N'        [CD_LSN_TEC] binary(10) NULL';

DECLARE @TechColsFin nvarchar(MAX) =
      N'[FL_FIN_JOURNEE] bit NULL,' + CHAR(13) +
      N'        [DT_JOUR_TEC] date NULL,' + CHAR(13) +
      N'        [DT_MAJ] datetime NOT NULL DEFAULT (GETDATE()),' + CHAR(13) +
      N'        [CD_USR_MAJ] nvarchar(20) NULL,' + CHAR(13) +
      N'        [ID_TRT_ALI] int NULL';

DECLARE @TableNameSource sysname, @TableNameHisto sysname, @Create nvarchar(MAX);

DECLARE cur CURSOR FAST_FORWARD FOR
    SELECT TableNameSource, TableNameHisto FROM ##TableListHisto;

OPEN cur;
FETCH NEXT FROM cur INTO @TableNameSource, @TableNameHisto;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID('tempdb..#cols') IS NOT NULL DROP TABLE #cols;

    SELECT
        c.column_id,
        ColumnName = QUOTENAME(c.name),
        TypeBase =
            CASE
                WHEN t.name IN ('varchar','char','varbinary','binary')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length = -1 THEN 'MAX'
                              ELSE CAST(c.max_length AS varchar(10)) END + ')'
                WHEN t.name IN ('nvarchar','nchar')
                    THEN t.name + '(' +
                         CASE WHEN c.max_length <> -1 THEN CAST(c.max_length/2 AS varchar(10))
                              ELSE 'MAX' END + ')'
                WHEN t.name IN ('decimal','numeric')
                    THEN t.name + '(' + CAST(c.precision AS varchar(10)) + ',' + CAST(c.scale AS varchar(10)) + ')'
                WHEN t.name IN ('datetime2','time','datetimeoffset')
                    THEN t.name + '(' + CAST(c.scale AS varchar(10)) + ')'
                ELSE t.name
            END
    INTO #cols
    FROM sys.tables tb
    JOIN sys.schemas s ON s.schema_id = tb.schema_id
    JOIN sys.columns c ON c.object_id = tb.object_id
    JOIN sys.types   t ON t.user_type_id = c.user_type_id
    WHERE s.name = @SchemaSource
      AND tb.name = @TableNameSource
      AND c.is_computed = 0
      AND c.name NOT LIKE 'CS%';

    SELECT @Create =
        'IF OBJECT_ID(N''' + @SchemaHisto + '.' + @TableNameHisto + ''',''U'') IS NULL' + CHAR(13) +
        'BEGIN' + CHAR(13) +
        'CREATE TABLE ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto) + ' (' + CHAR(13) +
        '        ' + @TechColsCDC + ',' + CHAR(13) +
        '        ' +
        STRING_AGG(ColumnName + ' ' + TypeBase + ' NULL',
                   ',' + CHAR(13) + '        ') WITHIN GROUP (ORDER BY column_id) +
        ',' + CHAR(13) + '        ' + @TechColsFin + CHAR(13) +
        '    );' + CHAR(13) +
        -- purge de retention et consultation par journee
        'CREATE NONCLUSTERED INDEX ' + QUOTENAME('IX_' + @TableNameHisto + '_JOUR')
        + ' ON ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto)
        + ' ([DT_JOUR_TEC]);' + CHAR(13) +
        -- anti-doublon : une trace CDC est identifiee par son LSN et sa sequence.
        -- Rend la copie rejouable : un second passage echoue au lieu de dupliquer.
        'CREATE UNIQUE NONCLUSTERED INDEX ' + QUOTENAME('UX_' + @TableNameHisto + '_TRACE')
        + ' ON ' + QUOTENAME(@SchemaHisto) + '.' + QUOTENAME(@TableNameHisto)
        + ' ([CD_LSN_TEC], [CD_SEQ_TEC]);' + CHAR(13) +
        'END;'
    FROM #cols;

    UPDATE ##TableListHisto SET CreateScript = @Create
     WHERE TableNameSource = @TableNameSource;

    FETCH NEXT FROM cur INTO @TableNameSource, @TableNameHisto;
END

CLOSE cur;
DEALLOCATE cur;
GO

/* Scripts a executer sur la base ODS_Traces */
SELECT ScriptComplet =
    (SELECT CHAR(13) + CreateScript + CHAR(13)
     FROM ##TableListHisto ORDER BY TableNameSource
     FOR XML PATH(''), TYPE);

SELECT * FROM ##TableListHisto ORDER BY TableNameSource;
