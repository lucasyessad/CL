/* ============================================================================
   dbo.PITCOT_PERIODE_REPRISE   (base DWH, standard maison)

   File des journees a traiter, regeneree a chaque execution par l'etape ODI
   06 et flaguee par l'etape 13.

   CETTE TABLE EXISTE PROBABLEMENT DEJA : elle est partagee avec les autres
   chaines du projet. Le script est donc non destructif et ne modifie jamais
   une table existante.

   Si elle existe avec d'autres noms ou types de colonnes, NE PAS la recreer :
   aligner a la place les etapes ODI 06 et 13 sur la structure reelle.
   L'INSERT de l'etape 06 est positionnel, l'ordre compte :
       DT_CAL, NO_SEQ, TRAITE, LB_NOM_SCN_SUN
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.PITCOT_PERIODE_REPRISE
    (
        DT_CAL          DATE           NOT NULL,
        NO_SEQ          INT            NOT NULL,
        TRAITE          BIT            NOT NULL DEFAULT (0),
        LB_NOM_SCN_SUN  NVARCHAR(100)  NOT NULL,
        CONSTRAINT PK_PITCOT_PERIODE_REPRISE PRIMARY KEY (LB_NOM_SCN_SUN, DT_CAL)
    );

    CREATE NONCLUSTERED INDEX IX_PITCOT_PERIODE_REPRISE_A_TRAITER
        ON dbo.PITCOT_PERIODE_REPRISE (LB_NOM_SCN_SUN, TRAITE, DT_CAL);
END
GO

/* Controle de structure si la table preexiste
-------------------------------------------------------------------------------
SELECT c.name, t.name AS type, c.max_length, c.is_nullable
FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id
WHERE c.object_id = OBJECT_ID('dbo.PITCOT_PERIODE_REPRISE')
ORDER BY c.column_id;
---------------------------------------------------------------------------- */
