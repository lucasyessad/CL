/* ============================================================================
   Initialisation - a executer UNE FOIS a la mise en production, apres les
   scripts 01 a 09 et avant le premier lancement du package.
   Script manuel : les noms sont en clair, sans substitution ODI.
   Completer les valeurs entre chevrons.
   ============================================================================ */

/* 1. Ligne de pilotage PWTTRE.
      LB_NOM_SCN_SUN doit valoir EXACTEMENT le nom du scenario genere, soit
      le SESS_NAME du package : c'est la cle utilisee par les procedures
      maison T003 / T004 et par les etapes ODI 04, 06 et 13.
      DA_DEB_DEL_TRT = derniere journee ouvrable deja couverte ; les journees
      generees sont strictement superieures.
      DA_DON_A_TRT et DA_FIN_DEL_FOR restent NULL : ils sont positionnes a
      chaque execution.
      Aligner les autres colonnes sur une ligne existante, par exemple celle
      de IOM_MNI_COTATION_PRUD_CHGODS.                                        */
IF NOT EXISTS (SELECT 1 FROM dbo.PWTTRE
               WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
    INSERT INTO dbo.PWTTRE (LB_NOM_SCN_SUN, DA_DEB_DEL_TRT, DA_DON_A_TRT,
                            DA_FIN_DEL_FOR, NO_SEQ)
    VALUES ('IOM_LIGIS_TRACE_CSTIMG', '<AAAA-MM-JJ derniere journee couverte>',
            NULL, NULL, 1);

/* 2. Borne initiale : point de depart de la premiere fenetre.
      DT_JOUR doit etre la meme journee que DA_DEB_DEL_TRT ci-dessus.
      DT_BORNE = jour ouvrable SUIVANT a 07:45:00.000, c'est-a-dire le format
      que pose l'etape ODI 02.                                                */
IF NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE)
    INSERT INTO dbo.ORT_BORNE_JOURNEE
        (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
    VALUES ('<AAAA-MM-JJ derniere journee couverte>',
            '<AAAA-MM-JJ jour ouvrable suivant> 07:45:00.000',
            'INIT', 'MANUEL', 'Borne initiale - demarrage DT-1374');

/* 3. Verification : PWTCHE ne doit contenir aucune ligne pour ce scenario,
      le traitement n'etant pas alimente par fichier. Si c'est le cas, la
      troisieme tache de T003 insere 0 ligne dans PWTSPF, ce qui est le
      comportement attendu.                                                   */
SELECT * FROM dbo.PWTCHE WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG';
