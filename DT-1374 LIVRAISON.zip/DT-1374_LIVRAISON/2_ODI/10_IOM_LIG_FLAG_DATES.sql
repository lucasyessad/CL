/* ============================================================================
   PROCEDURE ODI : IOM_LIG_FLAG_DATES
   Marque la journee traitee dans PITCOT. Atteinte uniquement si
   IOM_LIG_BILAN_JOURNEE est OK, puis retour au rafraichissement de la
   variable pour la journee suivante.

   "DT_CAL =" et non "<=" : chaque journee ouvrable possede sa propre borne
   et sa propre image. Un "<=" marquerait comme traitee une journee
   anterieure qui ne l'aurait pas ete, donc perdue.

   PWTTRE n'est pas touchee ici : son avancement est assure par la procedure
   maison IOR.T004.ref_OKfintracechgt en fin de package.
   ============================================================================ */
UPDATE <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND DT_CAL = '#V_IOM_LIG_DT_TRACES'
  AND TRAITE = 0
