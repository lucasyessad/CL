/* ============================================================================
   PROCEDURE ODI : IOM_LIG_ARCHIVE_AUDIT_CDC
   Archive le contenu de ods.OIT_TEC_AUD_CDC (photo de la derniere extraction,
   videe a chaque BCPIN) dans dbo.OWT_TEC_AUD_CDC (historique complet).

   POSITION : juste APRES 02_IOM_LIG_A0_POSE_BORNE, pour pouvoir rattacher
   chaque extraction archivee a la journee que la borne vient de clore
   (DT_JOUR_TEC). Si A0 n'a pose aucune borne (audit inchange, datetimes non
   alimentees), cette etape s'execute quand meme : elle n'archivera rien de
   nouveau, ou archivera avec DT_JOUR_TEC rattache a la derniere borne
   connue.

   MODE APPEND, PAS SCD2 : une ligne d'audit est un EVENEMENT (une extraction
   pour une instance), pas un etat qui se ferme et se rouvre.

   IDEMPOTENT : anti-doublon par NOT EXISTS sur (LB_INSTANCE, LB_FIN_LSN),
   qui identifie une extraction. Relancer l'etape, ou tout le package,
   n'insere jamais deux fois la meme extraction.

   Les lignes sans LB_FIN_LSN sont ECARTEES (elles feraient echouer l'index
   unique de la cible, cf. commentaire dans 06_OWT_TEC_AUD_CDC.sql) et
   comptees dans l'audit : c'est le signal que l'amont n'alimente pas les
   LSN de fin.

   Cette etape ne sort jamais en KO pour un probleme de contenu : elle trace
   et laisse le package continuer. Seule une erreur SQL reelle la fait
   echouer.
   ============================================================================ */
DECLARE @ID_TRT_ALI INT          = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50) = N'LIGIS';

DECLARE @dt_step   DATETIME = GETDATE(),
        @dt_jour   DATE,
        @nb_ins    INT = 0,
        @nb_total  INT = 0,
        @nb_sans_lsn INT = 0;

/* Journee de rattachement = derniere journee bornee (posee par A0) --------- */
SELECT @dt_jour = MAX(DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>;

SELECT @nb_total    = COUNT(*),
       @nb_sans_lsn = SUM(CASE WHEN LB_FIN_LSN IS NULL THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?>;

/* Archivage des extractions non encore historisees ------------------------- */
INSERT INTO <?=odiRef.getObjectName("L", "OWT_TEC_AUD_CDC", "MSSQL_DWH", "D") ?>
    (ID_INSTANCE, LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN,
     DT_DEB_LSN, DT_FIN_LSN, DT_EXTRACT,
     DT_JOUR_TEC, ID_TRT_ALI, DT_MAJ)
SELECT A.ID_INSTANCE, A.LB_INSTANCE, A.LB_DEB_LSN, A.LB_FIN_LSN,
       A.DT_DEB_LSN, A.DT_FIN_LSN, A.DT_EXTRACT,
       @dt_jour, @ID_TRT_ALI, GETDATE()
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?> AS A
WHERE A.LB_FIN_LSN IS NOT NULL
  AND NOT EXISTS (
        SELECT 1
        FROM <?=odiRef.getObjectName("L", "OWT_TEC_AUD_CDC", "MSSQL_DWH", "D") ?> AS H
        WHERE H.LB_INSTANCE = A.LB_INSTANCE
          AND H.LB_FIN_LSN  = A.LB_FIN_LSN);

SET @nb_ins = @@ROWCOUNT;

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET,
        N'ARCHIVE AUDIT CDC'
        + CASE WHEN @dt_jour IS NOT NULL
               THEN N' [' + CONVERT(NVARCHAR(10), @dt_jour, 23) + N']'
               ELSE N'' END,
        N'OIT_TEC_AUD_CDC', N'OWT_TEC_AUD_CDC', @nb_ins, N'OK',
        CASE
          WHEN ISNULL(@nb_total, 0) = 0
               THEN N'AVERTISSEMENT: ods.OIT_TEC_AUD_CDC est vide - le BCPIN de la vue d''audit a-t-il tourne ?'
          WHEN ISNULL(@nb_sans_lsn, 0) > 0
               THEN N'AVERTISSEMENT: ' + CAST(@nb_sans_lsn AS NVARCHAR(10))
                    + N' ligne(s) ecartee(s) faute de LB_FIN_LSN (sur '
                    + CAST(@nb_total AS NVARCHAR(10)) + N'). Verifier le traitement amont.'
          WHEN @nb_ins = 0
               THEN N'IGNORE: aucune nouvelle extraction depuis le dernier archivage.'
          ELSE N'Extractions archivees : ' + CAST(@nb_ins AS NVARCHAR(10))
               + N' sur ' + CAST(@nb_total AS NVARCHAR(10)) + N' instance(s) presentes.'
        END,
        @dt_step, GETDATE());
