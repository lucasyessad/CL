/* ============================================================================
   VARIABLE ODI : V_IOM_LIG_DT_TRACES
   Type alphanumerique, action Rafraichir, schema logique MSSQL_DWH.

   Renvoie la plus ancienne journee non traitee ET bornee, ou NULL quand il
   n'y a plus rien a traiter - ce qui fait sortir la boucle du package.

   Le test d'existence d'une borne est essentiel : une journee sans borne
   correspond a une extraction qui ne couvre pas encore sa frontiere. Elle
   attend, elle n'est jamais traitee a moitie.
   ============================================================================ */
SELECT CONVERT(varchar(10), MIN(P.DT_CAL), 23)
FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B
              WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))
