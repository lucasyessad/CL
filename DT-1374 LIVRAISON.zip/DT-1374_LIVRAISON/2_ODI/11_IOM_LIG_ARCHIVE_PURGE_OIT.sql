/* ============================================================================
   PROCEDURE ODI : IOM_LIG_ARCHIVE_PURGE_OIT
   Derniere etape avant T004, executee UNE FOIS toutes les journees traitees
   (branche "plus de journee eligible" de l'evaluation de variable).

   Pour chaque table du perimetre, et dans cet ordre imperatif :
      1. COPIE  vers ODS_Traces.dbo.OIT_<table>_HISTO
      2. CONTROLE de volumetrie (copiees = concernees)
      3. PURGE de ods.OIT_<table>  -- uniquement si le controle est bon

   BORNE DE TRAITEMENT
   -------------------
   Copie et purge sont bornees par  DT_COMMIT_TEC <= @frontiere, ou
   @frontiere = MAX(DT_BORNE) des journees effectivement traitees dans
   cette session. C'est EXACTEMENT la borne qui a servi a construire les
   images : on ne peut donc jamais archiver ni supprimer une trace qui
   n'aurait pas ete traitee.

   Les traces posterieures a cette borne RESTENT dans le sas ods.OIT_x :
   ce sont celles qui appartiennent a une journee pas encore close (par
   exemple ecrites apres 07:45 alors que l'extraction a tourne a 09:00).
   Elles seront archivees par le quotidien suivant, avec leur journee.

   IDEMPOTENT : la copie est protegee par l'index unique
   (CD_LSN_TEC, CD_SEQ_TEC) de la table d'archive, et le NOT EXISTS evite
   d'y buter en marche normale. Relancer l'etape ne duplique rien et ne
   supprime que ce qui a ete archive.

   SECURITE : si la copie d'une table echoue, sa purge n'est PAS executee
   et l'etape sort en erreur. Les traces restent dans le sas, la relance
   reprend. Aucune donnee ne peut etre perdue entre les deux operations.
   ============================================================================ */
DECLARE @ID_TRT_ALI INT          = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50) = N'LIGIS';
DECLARE @CD_USR_MAJ NVARCHAR(20) = N'SUPERVIS';

/* Base d'archive : ODS_Traces est une base DISTINCTE du DWH */
DECLARE @PFX_ODS   NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_HISTO NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS_TRACES", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS_TRACES", "D") ?>.';
/* Prefixe BASE SEULE : les vues catalogue (sys.columns) sont par base et
   non par schema. Un nom a quatre parties serait invalide. */
DECLARE @CAT_HISTO NVARCHAR(200) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS_TRACES", "D") ?>.';

DECLARE @frontiere DATETIME2(3), @msg NVARCHAR(500), @nb_ko INT = 0,
        @dt_step DATETIME;

/* Borne = derniere frontiere traitee dans cette session ---------------------- */
SELECT @frontiere = MAX(B.DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B
WHERE EXISTS (
        SELECT 1
        FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> A
        WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
          AND A.LB_PROJET = @LB_PROJET
          AND A.CD_STATUT = 'OK'
          AND A.LB_CHARGEMENT = N'BILAN JOURNEE [' + CONVERT(NVARCHAR(10), B.DT_JOUR, 23) + N']');

IF @frontiere IS NULL
BEGIN
    -- Aucune journee traitee dans cette session : rien a archiver.
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT', N'*TOUTES*', NULL, 0, N'OK',
            N'IGNORE: aucune journee traitee dans cette session.', GETDATE(), GETDATE());
    RETURN;
END

DECLARE @tbl_ods NVARCHAR(128), @tbl_histo NVARCHAR(200),
        @src NVARCHAR(400), @tgt NVARCHAR(400), @cols NVARCHAR(MAX),
        @jour_expr NVARCHAR(MAX), @sql NVARCHAR(MAX),
        @nb_a_copier INT, @nb_copiees INT, @nb_purgees INT;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT DISTINCT LB_TABLE_ODS
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
    WHERE FL_CLEF = 1 AND FL_CHARGEMENT = 1
    ORDER BY LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @tbl_histo = @tbl_ods + N'_HISTO';
    SET @src = @PFX_ODS   + QUOTENAME(@tbl_ods);
    SET @tgt = @PFX_HISTO + QUOTENAME(@tbl_histo);
    SET @nb_a_copier = 0; SET @nb_copiees = 0; SET @nb_purgees = 0;

    BEGIN TRY
        /* Liste des colonnes communes, dans l'ordre de la table d'archive.
           Construite depuis le catalogue et non depuis le parametrage : la
           copie porte TOUTES les colonnes, y compris celles non historisees
           dans les OWT. */
        SET @cols = NULL;
        SET @sql = N'SELECT @p_cols = STRING_AGG(QUOTENAME(c.name), N'', '') WITHIN GROUP (ORDER BY c.column_id)' +
                   N' FROM ' + @CAT_HISTO + N'sys.columns c' +
                   N' WHERE c.object_id = OBJECT_ID(''' + @tgt + N''')' +
                   N'   AND c.name NOT IN (''DT_JOUR_TEC'', ''DT_MAJ'', ''CD_USR_MAJ'', ''ID_TRT_ALI'')';
        EXEC sp_executesql @sql, N'@p_cols nvarchar(max) OUTPUT', @p_cols = @cols OUTPUT;

        IF @cols IS NULL
        BEGIN
            SET @msg = N'Table d''archive introuvable ou vide de colonnes : ' + @tgt;
            THROW 50040, @msg, 1;
        END

        /* Rattachement a la journee fonctionnelle : la borne immediatement
           superieure au commit de la trace. */
        SET @jour_expr = N'(SELECT TOP (1) B.DT_JOUR FROM '
                       + N'<?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B '
                       + N'WHERE B.DT_BORNE >= S.DT_COMMIT_TEC ORDER BY B.DT_BORNE)';

        /* 1. Volumetrie attendue */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src +
                   N' WHERE DT_COMMIT_TEC <= @p_front;';
        EXEC sp_executesql @sql, N'@p_front datetime2(3), @p_nb int OUTPUT',
             @p_front = @frontiere, @p_nb = @nb_a_copier OUTPUT;

        IF @nb_a_copier > 0
        BEGIN
            /* 2. Copie vers l'archive */
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols +
                       N', DT_JOUR_TEC, DT_MAJ, CD_USR_MAJ, ID_TRT_ALI)' +
                       N' SELECT ' + @cols + N', ' + @jour_expr +
                       N', GETDATE(), @p_usr, @p_trt' +
                       N' FROM ' + @src + N' AS S' +
                       N' WHERE S.DT_COMMIT_TEC <= @p_front' +
                       N'   AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS H' +
                       N'                   WHERE H.CD_LSN_TEC = S.CD_LSN_TEC' +
                       N'                     AND H.CD_SEQ_TEC = S.CD_SEQ_TEC);' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_front datetime2(3), @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                 @p_front = @frontiere, @p_usr = @CD_USR_MAJ,
                 @p_trt = @ID_TRT_ALI, @p_nb = @nb_copiees OUTPUT;

            /* 3. Controle : tout ce qui devait etre archive doit s'y trouver */
            SET @nb_absentes = 0;
            SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src + N' AS S' +
                       N' WHERE S.DT_COMMIT_TEC <= @p_front' +
                       N'   AND NOT EXISTS (SELECT 1 FROM ' + @tgt + N' AS H' +
                       N'                   WHERE H.CD_LSN_TEC = S.CD_LSN_TEC' +
                       N'                     AND H.CD_SEQ_TEC = S.CD_SEQ_TEC);';
            EXEC sp_executesql @sql, N'@p_front datetime2(3), @p_nb int OUTPUT',
                 @p_front = @frontiere, @p_nb = @nb_absentes OUTPUT;

            IF @nb_absentes > 0
            BEGIN
                SET @msg = N'Copie incomplete vers ' + @tbl_histo + N' : '
                         + CAST(@nb_absentes AS NVARCHAR(10)) + N' trace(s) absente(s). Purge annulee.';
                THROW 50041, @msg, 1;
            END

            /* 4. Purge du sas - uniquement apres controle reussi */
            SET @sql = N'DELETE FROM ' + @src + N' WHERE DT_COMMIT_TEC <= @p_front;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_front datetime2(3), @p_nb int OUTPUT',
                 @p_front = @frontiere, @p_nb = @nb_purgees OUTPUT;
        END

        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT', @tbl_ods, @tbl_histo,
                @nb_copiees, N'OK',
                N'Archivees: ' + CAST(@nb_copiees AS NVARCHAR(10))
                + N' / purgees: ' + CAST(@nb_purgees AS NVARCHAR(10))
                + N' (borne ' + CONVERT(NVARCHAR(23), @frontiere, 121) + N').',
                @dt_step, GETDATE());
    END TRY
    BEGIN CATCH
        SET @nb_ko += 1;
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'ARCHIVE OIT', @tbl_ods, @tbl_histo,
                0, N'KO', ERROR_MESSAGE(), @dt_step, GETDATE());
        /* on continue : les autres tables peuvent etre archivees */
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;

IF @nb_ko > 0
BEGIN
    SET @msg = N'IOM_LIG_ARCHIVE_PURGE_OIT : ' + CAST(@nb_ko AS NVARCHAR(10))
             + N' table(s) non archivee(s). Les traces concernees restent dans le sas ODS'
             + N' et seront archivees a la prochaine execution.';
    THROW 50042, @msg, 1;
END
