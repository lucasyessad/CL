/* ============================================================================
   PROCEDURE ODI : IOM_LIG_RECUP_DATES
   Regenere la file des journees a traiter dans PITCOT_PERIODE_REPRISE.
   S'execute APRES la procedure maison IOR.T003.ref_inittracechgt, qui a
   fige la fin de periode dans PWTTRE.DA_DON_A_TRT.

   PERIODE RETENUE :  ] DA_DEB_DEL_TRT ; DA_DON_A_TRT ]
     - borne basse EXCLUE  : derniere journee traitee au run precedent
       (positionnee par T004) ;
     - borne haute INCLUSE : fin de periode figee par T003, cadree par
       [A1] sur la derniere journee bornee.
   Le "<=" est essentiel : c'est cette meme valeur que T004 reportera dans
   DA_DEB_DEL_TRT en fin de traitement. Avec un "<", la journee egale a
   DA_DON_A_TRT ne serait jamais generee alors que T004 ferait avancer la
   periode au-dela : elle serait perdue.

   IDEMPOTENT : DELETE + INSERT complet de la file pour ce scenario.
   ============================================================================ */
DELETE FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'

INSERT INTO <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SELECT T.DT_CAL,
       (ROW_NUMBER() OVER (ORDER BY T.DT_CAL)) AS SEQ,
       0 AS TRAITE,
       '<?=odiRef.getSession("SESS_NAME") ?>' AS LB_NOM_SCN_SUN
FROM
(
    SELECT DISTINCT convert(date, DT_CAL, 121) as DT_CAL
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1
      AND convert(date, DT_CAL, 121) >  (select convert(date, DA_DEB_DEL_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
      and convert(date, DT_CAL, 121) <= (select convert(date, DA_DON_A_TRT, 121)
                                         from <?=odiRef.getObjectName("L", "PWTTRE", "MSSQL_DWH", "D") ?>
                                         where LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>')
) AS T
ORDER BY SEQ ASC

-- FILTRE FL_OVR = 1 : PRTCAL est un CALENDRIER COMPLET (tous les jours y
-- figurent, qualifies par CD_OUV / FL_OUV / FL_OVR / FL_FER). Sans ce
-- filtre, les dimanches et jours feries etaient generes comme journees a
-- traiter alors qu'ils ne peuvent pas etre bornes : ils bloquaient la file.
-- FL_OVR (ouvrable) et non FL_OUV (ouvre) : le samedi peut etre travaille.
-- Un jour ouvrable sans trace est gere (cible non modifiee, avertissement
-- dans ORT_AUDIT_CHARGEMENT).
