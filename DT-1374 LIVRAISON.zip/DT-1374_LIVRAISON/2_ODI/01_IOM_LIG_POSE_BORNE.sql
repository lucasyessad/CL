/* ============================================================================
   PROCEDURE ODI : IOM_LIG_A0_POSE_BORNE
   Premiere etape du package. Pose les bornes de fin de journee a partir de
   l'audit CDC ramene par le BCPIN dans ods.OIT_TEC_AUD_CDC.

   FRONTIERE DE JOURNEE : 07:45 DU JOUR OUVRABLE SUIVANT
   -----------------------------------------------------
   La journee fonctionnelle J couvre  ] frontiere(J-1) ; frontiere(J) ]
   avec  frontiere(J) = jour ouvrable suivant J, a 07:45:00.
   Tout ce qui est ecrit apres 07:45 appartient a la journee en cours ; le
   quotidien LIGIS du 22, termine le 23 a 03:08, reste donc compte sur le
   22 puisque 03:08 est anterieur au 23 07:45.

   Jour OUVRABLE (PRTCAL.FL_OVR = 1) et non jour ouvre : le samedi peut
   etre travaille. PRTCAL etant un calendrier complet, ce filtre ecarte les
   dimanches et les feries (FL_FER = 1).

   QUOTIDIEN OU RATTRAPAGE : LA MEME REGLE
   ---------------------------------------
   Le mode se DEDUIT du nombre de frontieres franchies par l'extraction, il
   n'y a pas deux logiques a maintenir :
       extraction <  frontiere(J)                   -> journee J incomplete,
                                                       aucune borne, on attend
       frontiere(J) <= extraction < frontiere(J+1)  -> 1 borne   (quotidien)
       extraction >= frontiere(J+1)                 -> n bornes  (rattrapage)
   Chaque journee d'un rattrapage recoit SA PROPRE borne, donc sa propre
   image : aucune journee intermediaire n'est plus absorbee dans la
   derniere.

   La valeur de la borne est deterministe (07:45) et non la datetime
   d'extraction : les fenetres sont stables et reproductibles.

   PREREQUIS D'ORDONNANCEMENT : l'extraction doit tourner APRES 07:45 pour
   pouvoir clore la journee precedente. Une extraction plus matinale (04:00
   par exemple) ne couvre pas la fenetre jusqu'a 07:45 : la journee ne sera
   close que par l'extraction suivante. C'est volontaire - clore une
   fenetre que l'extraction n'a pas couverte ferait perdre les traces
   ecrites entre les deux.

   IDEMPOTENT : une journee deja bornee n'est jamais reposee. Sans nouvelle
   extraction, aucune borne n'est posee et le package se termine proprement
   (aucune journee eligible), sans erreur.
   ============================================================================ */
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';
DECLARE @MIN_FRONTIERE INT        = 465;   -- 07h45 exprime en minutes

DECLARE @fin_extraction DATETIME2(3), @nb_inst_sans_date INT,
        @dt_jour_prec DATE, @jour DATE, @jour_suivant DATE,
        @frontiere DATETIME2(3), @nb_bornes INT = 0,
        @premiere DATE, @derniere DATE,
        @dt_step DATETIME = GETDATE();

/* 1. Couverture de l'extraction --------------------------------------------- */
SELECT @fin_extraction    = MIN(COALESCE(A.DT_FIN_LSN, A.DT_EXTRACT)),
       @nb_inst_sans_date = SUM(CASE WHEN A.DT_FIN_LSN IS NULL AND A.DT_EXTRACT IS NULL THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?> A
WHERE A.LB_INSTANCE IN (
        SELECT DISTINCT 'dbo_' + SUBSTRING(P.LB_TABLE_ODS, 5, 200)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
        WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
          AND P.LB_TABLE_ODS LIKE 'OIT[_]%');

IF @fin_extraction IS NULL OR ISNULL(@nb_inst_sans_date, 0) > 0
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: audit CDC sans datetime exploitable ('
            + CAST(ISNULL(@nb_inst_sans_date, 0) AS NVARCHAR(10))
            + N' instance(s) avec DT_FIN_LSN et DT_EXTRACT NULL, ou audit vide).'
            + N' Verifier le traitement amont. Aucune journee eligible.',
            @dt_step, GETDATE());
    RETURN;
END

/* 2. Derniere journee bornee ------------------------------------------------- */
SELECT @dt_jour_prec = MAX(DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>;

IF @dt_jour_prec IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: aucune borne initiale (TYPE_BORNE = INIT) - executer 01_INIT_MEP_ONE_SHOT.sql.',
            @dt_step, GETDATE());
    RETURN;
END

/* 3. Pose des bornes : une par journee ouvrable entierement couverte --------- */
WHILE 1 = 1
BEGIN
    SET @jour = NULL;
    SELECT TOP (1) @jour = CONVERT(date, DT_CAL, 121)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1 AND CONVERT(date, DT_CAL, 121) > @dt_jour_prec
    ORDER BY DT_CAL;

    IF @jour IS NULL BREAK;              -- calendrier epuise

    SET @jour_suivant = NULL;
    SELECT TOP (1) @jour_suivant = CONVERT(date, DT_CAL, 121)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1 AND CONVERT(date, DT_CAL, 121) > @jour
    ORDER BY DT_CAL;

    IF @jour_suivant IS NULL BREAK;      -- frontiere inconnue : prolonger PRTCAL

    SET @frontiere = DATEADD(minute, @MIN_FRONTIERE, CAST(@jour_suivant AS DATETIME2(3)));

    -- Fenetre non entierement couverte par l'extraction : on s'arrete ici.
    IF @fin_extraction < @frontiere BREAK;

    INSERT INTO <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
        (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR)
    VALUES (@jour, @frontiere, 'QUOTIDIEN', 'AUDIT_CDC');

    IF @nb_bornes = 0 SET @premiere = @jour;
    SET @derniere     = @jour;
    SET @nb_bornes   += 1;
    SET @dt_jour_prec = @jour;
END

/* 4. Audit : une seule ligne recapitulative ---------------------------------- */
INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
        @nb_bornes, N'OK',
        CASE WHEN @nb_bornes = 0
             THEN N'IGNORE: extraction arretee au ' + CONVERT(NVARCHAR(23), @fin_extraction, 121)
                  + N' - journee suivante non encore complete (frontiere '
                  + ISNULL(CONVERT(NVARCHAR(23), @frontiere, 121), N'inconnue') + N').'
             ELSE N'Extraction au ' + CONVERT(NVARCHAR(23), @fin_extraction, 121) + N' : '
                  + CAST(@nb_bornes AS NVARCHAR(10)) + N' journee(s) bornee(s) du '
                  + CONVERT(NVARCHAR(10), @premiere, 23) + N' au '
                  + CONVERT(NVARCHAR(10), @derniere, 23)
                  + CASE WHEN @nb_bornes > 1 THEN N' (rattrapage).' ELSE N' (quotidien).' END
        END,
        @dt_step, GETDATE());
