/* ============================================================================
   PROCEDURE ODI : IOM_LIG_BILAN_JOURNEE
   Conclut la journee #V_IOM_LIG_DT_TRACES :
      1. bilan dans ORT_AUDIT_CHARGEMENT ;
      2. si au moins une table est en KO dans cette session, THROW : l'etape
         passe KO, la date reste TRAITE = 0 dans PITCOT et la journee est
         entierement recalculee a la relance.

   Il n'y a pas de controle anti-doublon ici : la garantie est structurelle,
   portee par l'index unique filtre UX_OWT_x_VER_CRT (une seule version
   courante par cle). Un doublon fait echouer l'INSERT de HISTO_OWT avant
   toute ecriture, ce qui est plus sur et moins couteux qu'un balayage de la
   table a chaque journee.

   Etape en lecture seule sur les donnees.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';

DECLARE @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23),
        @msg NVARCHAR(500), @dt_deb_bilan DATETIME = GETDATE(),
        @nb_ok INT, @nb_ko INT, @nb_tbl_ko INT;

/* 1. Bilan de la journee ----------------------------------------------------- */
SELECT @nb_ok = SUM(CASE WHEN CD_STATUT = 'OK' THEN 1 ELSE 0 END),
       @nb_ko = SUM(CASE WHEN CD_STATUT = 'KO' THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
WHERE ISNULL(ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
  AND LB_PROJET = @LB_PROJET
  AND CHARINDEX('[' + @jour + ']', LB_CHARGEMENT) > 0
  AND LB_SOURCE <> '*TOUTES*';

SELECT @nb_tbl_ko = COUNT(DISTINCT LB_SOURCE)
FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
WHERE ISNULL(ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
  AND LB_PROJET = @LB_PROJET
  AND CD_STATUT = 'KO'
  AND CHARINDEX('[' + @jour + ']', LB_CHARGEMENT) > 0
  AND LB_SOURCE <> '*TOUTES*';

SET @nb_ok     = ISNULL(@nb_ok, 0);
SET @nb_ko     = ISNULL(@nb_ko, 0);
SET @nb_tbl_ko = ISNULL(@nb_tbl_ko, 0);

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'BILAN JOURNEE [' + @jour + N']',
        N'*TOUTES*', NULL, @nb_ok,
        CASE WHEN @nb_ko > 0 THEN N'KO' ELSE N'OK' END,
        CASE WHEN @nb_ko > 0
             THEN CAST(@nb_tbl_ko AS NVARCHAR(10)) + N' table(s) en KO sur la journee.'
             ELSE NULL END,
        @dt_deb_bilan, GETDATE());

/* 2. Remontee d'erreur a ODI ------------------------------------------------- */
IF @nb_ko > 0
BEGIN
    SET @msg = N'IOM_LIG_BILAN_JOURNEE : ' + CAST(@nb_tbl_ko AS NVARCHAR(10))
             + N' table(s) en KO pour la journee ' + @jour
             + N'. Detail dans ORT_AUDIT_CHARGEMENT (LB_PROJET = ''LIGIS'').';
    THROW 50010, @msg, 1;
END
