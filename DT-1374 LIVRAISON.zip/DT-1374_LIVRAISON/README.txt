================================================================================
DT-1374 - HISTORISATION DES TRACES LIGIS
Construction de l'image de fin de journee et alimentation du DWH en SCD2
================================================================================


1. CE QUE FAIT LE DISPOSITIF
--------------------------------------------------------------------------------

Les traces CDC de LIGIS contiennent toutes les modifications, plusieurs par
jour et par enregistrement. Le besoin est d'en tirer UNE image par jour et par
cle fonctionnelle - l'etat en fin de journee - et de l'historiser en SCD2 dans
le DWH.

Le parcours d'une trace :

  LIGIS                    vues CDC exportees  ->  fichiers .bcp
  Export PowerShell        bcp out + zip + copie vers le repertoire d'import
  Import PowerShell        bcp in vers ods.OIT_xxx  (sas de travail)
  Package ODI              image de fin de journee, historique SCD2, archivage
  DWH                      dbo.OWT_xxx           (historique SCD2)
  Archive                  ODS_Traces.dbo.OIT_xxx_HISTO  (traces traitees)


2. LA NOTION CENTRALE : LA JOURNEE FONCTIONNELLE
--------------------------------------------------------------------------------

Une journee ne s'arrete pas a minuit mais a 07:45 du jour ouvrable suivant.

    journee J  =  ] frontiere(J-1) ; frontiere(J) ]
    frontiere(J) = jour ouvrable suivant J, a 07:45:00.000

Le quotidien LIGIS du 22 juillet peut se terminer le 23 a 03:08 : ses ecritures
appartiennent bien a la journee du 22, puisque 03:08 est anterieur au 23 07:45.

Jour OUVRABLE et non jour ouvre : le samedi peut etre travaille. La reference
est PRTCAL.FL_OVR = 1, qui sert a la fois aux frontieres et a la generation des
journees a traiter - les deux ne peuvent donc pas se desynchroniser.

Une journee n'est traitee que lorsque l'extraction couvre sa frontiere. Il n'y
a pas de mode "quotidien" et de mode "rattrapage" a distinguer : c'est la meme
regle, appliquee autant de fois que necessaire.

    extraction <  frontiere(J)                   -> on attend
    frontiere(J) <= extraction < frontiere(J+1)  -> 1 journee
    extraction >= frontiere(J+1)                 -> n journees, chacune avec
                                                    sa propre image


3. POURQUOI LE SAS ODS N'EST PAS VIDE A CHAQUE IMPORT
--------------------------------------------------------------------------------

L'extraction est declenchee par la fin des batchs LIGIS : son heure varie et
n'est pas maitrisee. Si elle tourne a 09:00, elle ramene des traces ecrites
entre 07:45 et 09:00, qui appartiennent a la journee SUIVANTE. Elles sont hors
fenetre, donc non traitees ce jour-la.

Un TRUNCATE au chargement suivant les detruirait, et le pointeur LSN ayant
avance, elles ne seraient jamais reextraites : perte silencieuse.

D'ou le fonctionnement retenu :

  - ods.OIT_xxx est un SAS : l'import y AJOUTE les traces ;
  - il ne contient que ce qui n'a pas encore ete traite ;
  - en fin de package, les traces des journees traitees sont copiees dans
    ODS_Traces.dbo.OIT_xxx_HISTO, puis supprimees du sas ;
  - copie et purge sont bornees par la derniere frontiere traitee, donc ce qui
    depasse reste en attente de sa propre journee.

L'import reste rejouable sans TRUNCATE : avant chaque bcp, il supprime la plage
] LB_DEB_LSN ; LB_FIN_LSN ] que le fichier va recharger, lue dans l'audit CDC.
C'est le role de la colonne CD_LSN_TEC (le LSN est exact, la datetime ne l'est
pas : deux commits peuvent partager la meme milliseconde).


4. CONTENU DE LA LIVRAISON
--------------------------------------------------------------------------------

1_SQL - tables et generateurs, a executer sur SQL Server

  01_ORT_PARAM_HISTORISATION_TRACES.sql  perimetre et regles, au grain colonne
  02_ORT_BORNE_JOURNEE.sql               frontieres des journees
  03_ORT_AUDIT_CHARGEMENT.sql            audit du traitement
  04_OIT_TEC_AUD_CDC.sql                 reception de l'audit CDC (sas)
  05_OWT_TEC_AUD_CDC.sql                 archive de l'audit CDC
  06_PITCOT_PERIODE_REPRISE.sql          file des journees (standard maison)
  07_GEN_TABLES_OIT_OWT.sql              genere les DDL des OIT et OWT
  08_GEN_TABLES_HISTO.sql                genere les DDL des archives HISTO
  09_GEN_PARAMETRAGE.sql                 genere l'alimentation du parametrage
  10_INIT_MEP.sql                        PWTTRE et borne initiale (one-shot)
  11_CONTROLES.sql                       controles de deploiement et d'exploit.

2_ODI - objets du package IOM.LIGIS_TRACE_CSTIMG

  01_IOM_LIG_POSE_BORNE.sql          pose les bornes des journees couvertes
  02_IOM_LIG_ARCHIVE_AUDIT_CDC.sql   archive l'audit CDC de l'extraction
  03_IOM_LIG_CADRAGE_PERIODE.sql     cadre la periode PWTTRE avant T003
  04_IOM_LIG_RECUP_DATES.sql         alimente la file des journees
  05_V_IOM_LIG_DT_TRACES.sql         variable : prochaine journee eligible
  06_IOM_LIG_FLAG_OIT.sql            marque l'image de fin de journee
  07_IOM_LIG_PURGE_OWT.sql           remet la cible a l'etat d'avant la journee
  08_IOM_LIG_HISTO_OWT.sql           fermeture SCD2 et insertion des versions
  09_IOM_LIG_BILAN_JOURNEE.sql       bilan et remontee d'erreur
  10_IOM_LIG_FLAG_DATES.sql          marque la journee traitee
  11_IOM_LIG_ARCHIVE_PURGE_OIT.sql   archive puis purge le sas

3_POWERSHELL - export et import BCP

  liste_vues.sql            requete listant les vues a exporter
  export-parameters.psd1    parametres d'export
  export_bcpout.ps1         bcp out, zip, copie
  copy_bcp.bat              copie via chemin.bat et copy_proc.bat
  import-parameters.psd1    parametres d'import
  import_bcpin.ps1          dezip, suppression de plage, bcp in


5. ENCHAINEMENT DU PACKAGE ODI
--------------------------------------------------------------------------------

  01 POSE_BORNE
       |
  02 ARCHIVE_AUDIT_CDC
       |
  03 CADRAGE_PERIODE
       |
  [T003] IOR.T003.ref_inittracechgt        procedure MAISON existante
       |
  04 RECUP_DATES
       |
  05 V_IOM_LIG_DT_TRACES  (rafraichir)  <-----------------+
       |                                                  |
  EVALUATION : variable NON NULL ?                        |
       | oui                        | non                 |
  06 FLAG_OIT              11 ARCHIVE_PURGE_OIT           |
       |                            |                     |
  07 PURGE_OWT             [T004] ref_OKfintracechgt      |
       |                            |                     |
  08 HISTO_OWT                   (FIN OK)                 |
       |                                                  |
  09 BILAN_JOURNEE                                        |
       | OK                                               |
  10 FLAG_DATES ------------------------------------------+

Lien KO de 09 BILAN_JOURNEE : fin KO du package, AVANT T004. PWTSDC reste a
'KO', PWTTRE n'avance pas, la date reste TRAITE = 0.

Les etapes 06, 07 et 08 ne sortent jamais en KO : une table en erreur est
tracee dans l'audit et ecartee des etapes suivantes de la meme session ; c'est
09 qui conclut la journee.

T003 et T004 s'ajoutent en tant que PROCEDURES glissees dans le package, et
surtout pas en OdiStartScen : elles filtrent sur SESS_NAME et doivent
s'executer dans la session du package pour que LB_NOM_SCN_SUN corresponde et
que ID_TRT_ALI soit le meme partout.

Schemas logiques ODI : MSSQL_DWH, MSSQL_ODS et MSSQL_ODS_TRACES (base
d'archive, distincte du DWH).


6. ORDRE DE DEPLOIEMENT
--------------------------------------------------------------------------------

  1. Vues CDC cote LIGIS : ajouter les deux colonnes techniques
       C.__$start_lsn AS CD_LSN_TEC        (5e colonne technique)
       , CONVERT(bit, 0) AS FL_FIN_JOURNEE (derniere colonne)
     L'audit ZBCP_LIGIS_TEC_AUD_CDC_V n'est pas concerne.

  2. Sur le DWH : scripts 01 a 06.

  3. Sur la base LIGIS : executer 07, 08 et 09 (generateurs).
     Executer la sortie de 07 sur le DWH, celle de 08 sur ODS_Traces, celle de
     09 sur le DWH.

  4. Ajuster le parametrage a la main : renommages, filtres, tables a
     desactiver, cle des tables sans PK.

  5. Sur le DWH : script 10 (initialisation), puis 11 (controles).

  6. Creer les objets ODI et le package, declarer les schemas logiques.

  7. Deployer les scripts PowerShell et renseigner les deux .psd1.


7. EN EXPLOITATION
--------------------------------------------------------------------------------

Chaine quotidienne :

    export_bcpout.ps1   ->  import_bcpin.ps1  ->  package ODI

Chaque etape ne demarre que si la precedente a rendu 0 :

    .\export_bcpout.ps1
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    .\import_bcpin.ps1
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Codes retour PowerShell : 0 = OK, 1 = configuration ou connexion,
2 = table en echec. Journaux dans le repertoire LogDir.

Suivi du package : dbo.ORT_AUDIT_CHARGEMENT, LB_PROJET = 'LIGIS'.
Une ligne par table et par journee (libelle TRACES [jour]) portant les
volumetries, plus une ligne de bilan par journee. Les etapes intermediaires
n'ecrivent qu'en cas d'anomalie.

    SELECT LB_CHARGEMENT, LB_SOURCE, NB_LIGNE, CD_STATUT, LB_ERREUR
    FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE LB_PROJET = 'LIGIS'
      AND CHARINDEX('[2026-07-22]', LB_CHARGEMENT) > 0
    ORDER BY DT_DEBUT;

Reprise apres incident : relancer le package depuis le debut. Toutes les
etapes sont idempotentes, la journee en erreur est integralement recalculee.
Ne jamais relancer une seule etape isolee sur une journee en echec.


8. GARDE-FOUS A NE PAS RETIRER
--------------------------------------------------------------------------------

  - Index unique filtre UX_OWT_x_VER_CRT : interdit deux versions courantes
    pour une meme cle. C'est ce qui remplace un controle anti-doublon a
    posteriori, plus couteux et plus tardif.

  - Suppression de plage LSN avant chaque bcp in : rend l'import rejouable
    sans vider le sas.

  - Copie avant purge, et purge conditionnee au controle de volumetrie :
    aucune trace ne peut disparaitre entre les deux.

  - Arret du package avant T004 en cas d'erreur : la periode n'avance pas,
    la journee est reprise.

  - Ordre fermeture puis insertion dans HISTO_OWT : evite une violation
    transitoire de l'index unique.


9. POINTS RESTANT A TRAITER
--------------------------------------------------------------------------------

  - Verifier avec la DSI que DT_FIN_LSN et DT_EXTRACT sont alimentees dans
    l'audit CDC. Tant qu'elles sont NULL, aucune journee ne peut etre bornee
    (le package le signale par un avertissement et se termine proprement).

  - Tables sans cle primaire : elles n'auront aucune ligne FL_CLEF = 1 et
    seront ignorees. Diagnostiquer la cle via cdc.index_columns, puis la
    renseigner manuellement dans le parametrage.

  - Purge de retention des archives OIT_xxx_HISTO (13 mois evoques au
    ticket) : traitement distinct, l'index sur DT_JOUR_TEC est en place.
================================================================================
