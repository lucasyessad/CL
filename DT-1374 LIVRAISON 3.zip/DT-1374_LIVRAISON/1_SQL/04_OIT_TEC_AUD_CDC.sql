/* ============================================================================
   RECEPTION DE L'AUDIT CDC  -  ods.OIT_TEC_AUD_CDC

   A chaque extraction, LIGIS produit un fichier d'audit qui dit, pour chaque
   table, jusqu'ou l'extraction est allee : le dernier LSN lu et sa date.

   C'est cette date qui permet de savoir si une journee est complete.

   Cette borne est GLOBALE : le script d'audit cote LIGIS fait un seul UPDATE
   sans WHERE, avec sys.fn_cdc_get_max_lsn(), qui renvoie le dernier LSN
   capture pour toute la base. Toutes les lignes portent donc la meme valeur.

   Une table peu modifiee n'est pas "en retard" : elle a simplement moins de
   lignes dans la fenetre.

   L'audit est mis a jour AVANT les extractions, et les vues exportees
   filtrent sur __$start_lsn <= LB_FIN_LSN : la donnee qui arrive s'arrete
   donc exactement a ce LSN.

   C'est DT_FIN_LSN, calculee dans la vue exportee, qui en donne l'heure.
   Le traitement n'utilise que cette colonne.

   DT_EXTRACT (heure a laquelle le script d'audit a tourne) est conservee
   pour l'exploitation mais n'entre pas dans le calcul : elle est posterieure
   a la prise du LSN, s'en servir reviendrait a declarer couverte une periode
   qui ne le sera pas.

   Cette table est videe et rechargee a chaque import : elle ne contient que
   la derniere extraction. L'historique est conserve dans OWT_TEC_AUD_CDC.

   L'ordre des colonnes doit etre exactement celui de la vue exportee : le
   chargement BCP en format natif se fait par position, pas par nom.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF SCHEMA_ID('ods') IS NULL
    EXEC('CREATE SCHEMA ods');
GO

IF OBJECT_ID('ods.OIT_TEC_AUD_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE ods.OIT_TEC_AUD_CDC
    (
        ID_INSTANCE   BINARY(32)     NULL,   -- identifiant de l'instance de capture
        LB_INSTANCE   NVARCHAR(128)  NULL,   -- 'dbo_' + nom de la table source
        LB_DEB_LSN    BINARY(10)     NULL,   -- borne basse d'extraction (exclue)
        LB_FIN_LSN    BINARY(10)     NULL,   -- borne haute d'extraction (incluse)
        DT_DEB_LSN    DATETIME2(3)   NULL,
        DT_FIN_LSN    DATETIME2(3)   NULL,   -- datetime de couverture
        DT_EXTRACT    DATETIME2(3)   NULL    -- utilisee si DT_FIN_LSN est NULL
    );

    CREATE NONCLUSTERED INDEX IX_OIT_TEC_AUD_CDC_INSTANCE
        ON ods.OIT_TEC_AUD_CDC (LB_INSTANCE) INCLUDE (DT_FIN_LSN, DT_EXTRACT);
END
GO

/* Controle : les datetimes doivent etre alimentees par le traitement amont.
   Tant qu'elles sont NULL, aucune journee ne peut etre bornee.
-------------------------------------------------------------------------------
SELECT LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM ods.OIT_TEC_AUD_CDC
ORDER BY LB_INSTANCE;
---------------------------------------------------------------------------- */
