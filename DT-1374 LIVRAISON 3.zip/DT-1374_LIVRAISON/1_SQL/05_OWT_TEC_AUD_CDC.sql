/* ============================================================================
   HISTORIQUE DES EXTRACTIONS  -  dbo.OWT_TEC_AUD_CDC

   La table ods.OIT_TEC_AUD_CDC etant videe a chaque import, on perdrait la
   trace de ce que chaque extraction a couvert. Cette table la conserve.

   A quoi ca sert concretement :
     - expliquer apres coup pourquoi une journee a ete close a telle heure ;
     - suivre l'evolution de la borne d'extraction dans le temps, et donc
       l'heure reelle de fin des batchs LIGIS ;
     - detecter un trou de capture : le LSN de debut d'une extraction doit
       toujours egaler le LSN de fin de la precedente.

   On ajoute simplement les nouvelles lignes, sans jamais en modifier : une
   extraction est un evenement, pas un etat qui evolue. L'index unique
   empeche d'archiver deux fois la meme.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.OWT_TEC_AUD_CDC', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.OWT_TEC_AUD_CDC
    (
        ID_INSTANCE   BINARY(32)     NULL,
        LB_INSTANCE   NVARCHAR(128)  NULL,
        LB_DEB_LSN    BINARY(10)     NULL,
        LB_FIN_LSN    BINARY(10)     NULL,
        DT_DEB_LSN    DATETIME2(3)   NULL,
        DT_FIN_LSN    DATETIME2(3)   NULL,
        DT_EXTRACT    DATETIME2(3)   NULL,
        DT_JOUR_TEC   DATE           NULL,   -- journee bornee de rattachement
        ID_TRT_ALI    INT            NULL,
        DT_MAJ        DATETIME       NOT NULL DEFAULT (GETDATE())
    );

    CREATE UNIQUE NONCLUSTERED INDEX UX_OWT_TEC_AUD_CDC_EXTRACTION
        ON dbo.OWT_TEC_AUD_CDC (LB_INSTANCE, LB_FIN_LSN);

    CREATE NONCLUSTERED INDEX IX_OWT_TEC_AUD_CDC_JOUR
        ON dbo.OWT_TEC_AUD_CDC (DT_JOUR_TEC) INCLUDE (LB_INSTANCE, DT_FIN_LSN);
END
GO

/* Exploitation
-------------------------------------------------------------------------------
-- Couverture retenue pour une journee donnee :
SELECT DISTINCT LB_FIN_LSN, DT_FIN_LSN, DT_EXTRACT
FROM dbo.OWT_TEC_AUD_CDC
WHERE DT_JOUR_TEC = '2026-07-22';

-- Heure de fin des extractions sur les trois derniers mois : sert a verifier
-- si elle passe reellement apres 07:45, donc si une journee peut etre close
-- des le lendemain matin ou seulement le surlendemain.
SELECT jour            = CONVERT(date, DT_FIN_LSN),
       fin_de_couverture = MAX(CONVERT(time(0), DT_FIN_LSN)),
       heure_extraction  = MAX(CONVERT(time(0), DT_EXTRACT))
FROM dbo.OWT_TEC_AUD_CDC
WHERE DT_MAJ >= DATEADD(month, -3, GETDATE())
GROUP BY CONVERT(date, DT_FIN_LSN)
ORDER BY 1;

-- Continuite des LSN par instance : le debut d'une extraction doit egaler la
-- fin de la precedente. Toute ligne remontee signale un trou de capture.
SELECT LB_INSTANCE, DT_MAJ, LB_DEB_LSN,
       lsn_fin_precedent = LAG(LB_FIN_LSN) OVER (PARTITION BY LB_INSTANCE ORDER BY DT_MAJ)
FROM dbo.OWT_TEC_AUD_CDC
WHERE LB_DEB_LSN <> ISNULL(LAG(LB_FIN_LSN) OVER (PARTITION BY LB_INSTANCE ORDER BY DT_MAJ), LB_DEB_LSN);
---------------------------------------------------------------------------- */
