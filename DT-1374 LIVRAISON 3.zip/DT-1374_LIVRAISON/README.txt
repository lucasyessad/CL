================================================================================
DT-1374  -  HISTORISATION DES TRACES LIGIS
================================================================================


A QUOI SERT CE TRAITEMENT
--------------------------------------------------------------------------------

LIGIS enregistre toutes les modifications faites sur ses tables : si un
contrat est modifie dix fois dans la journee, il y a dix lignes de trace.

Ce que veut le metier, ce n'est pas les dix modifications, c'est l'etat du
contrat a la fin de la journee. Et il veut pouvoir retrouver cet etat pour
n'importe quelle journee passee.

Le traitement fait donc deux choses :
  - il retient, pour chaque contrat et chaque journee, la derniere
    modification de la journee ;
  - il range cet etat dans une table d'historique ou l'on peut lire, pour
    n'importe quelle date, quel etait le contrat ce jour-la.


LES CINQ PRINCIPES A COMPRENDRE
--------------------------------------------------------------------------------

1. UNE JOURNEE SE TERMINE A 07:45, PAS A MINUIT

   Les batchs LIGIS tournent la nuit. Le traitement du 22 juillet peut se
   terminer le 23 a 3 heures du matin. Ces ecritures de 3 heures font partie
   du travail du 22, pas du 23.

   On considere donc qu'une journee couvre la periode qui va de 07:45 a
   07:45 le lendemain ouvrable.

       journee du 22  =  du 22 a 07:45  au  23 a 07:45

   Une modification faite le 23 a 03h08 appartient au 22.
   Une modification faite le 23 a 08h00 appartient au 23.

   Le samedi compte comme jour ouvrable s'il est travaille. La reference est
   le calendrier PRTCAL, colonne FL_OVR.


2. ON NE TRAITE UNE JOURNEE QUE SI ON EST SUR DE L'AVOIR EN ENTIER

   L'extraction LIGIS demarre quand les batchs sont finis : son heure change
   tous les jours et on ne la maitrise pas.

   Avant de traiter la journee du 22, il faut donc verifier que l'extraction
   est bien allee jusqu'au 23 a 07:45. Sinon, on ne sait pas ce qui s'est
   passe entre la fin de l'extraction et cette heure.

   Comment le sait-on ? Cote LIGIS, un script met a jour la table d'audit
   AVANT de lancer les extractions : il y note le point d'arret, et les vues
   exportees ne renvoient rien au-dela. La colonne DT_FIN_LSN de l'audit
   donne donc l'heure exacte jusqu'a laquelle la donnee va arriver.

   Cette limite est la meme pour toutes les tables : le script enregistre le
   dernier changement capture pour l'ensemble de la base. Une table peu
   modifiee n'est pas en retard sur une autre, elle a simplement moins de
   lignes dans la fenetre.

   Tant que ce n'est pas le cas, la journee attend. Elle sera traitee des que
   l'extraction suivante couvrira sa fin. Rien n'est perdu, rien n'est traite
   a moitie.

   Si plusieurs journees sont en retard, chacune est traitee separement et
   obtient sa propre image : il n'y a pas de cas particulier a gerer.


3. LES TRACES NON TRAITEES RESTENT EN ATTENTE

   Si l'extraction tourne a 09h00, elle ramene aussi des traces ecrites entre
   07:45 et 09h00. Celles-la appartiennent au 23, elles ne sont pas traitees
   avec le 22.

   La table ods.OIT_xxx n'est donc pas videe a chaque chargement : c'est un
   sas, il ne contient que ce qui n'a pas encore ete traite.

   Une fois une journee traitee, ses traces sont recopiees dans l'archive
   ODS_Traces.dbo.OIT_xxx_HISTO, puis effacees du sas. Ce qui n'a pas ete
   traite reste sur place et sera pris le lendemain.

   Si on vidait le sas a chaque fois, ces traces disparaitraient - et comme
   l'extraction suivante repart du dernier point lu, elles ne reviendraient
   jamais.


4. L'HISTORIQUE FONCTIONNE PAR PERIODES DE VALIDITE

   Chaque ligne de la table d'historique est valable entre deux dates :

     NUM_CONTRAT   DT_DEB_VAL    DT_FIN_VAL    FL_VER_CRT
     C12345        2026-07-15    2026-07-22    0
     C12345        2026-07-22    2400-01-01    1

   La ligne courante porte la date de fin 2400-01-01 (une date volontairement
   lointaine, plus simple a manipuler qu'un NULL) et FL_VER_CRT = 1.

   Quand le contrat change, on ferme la ligne en cours - sa date de fin
   devient la journee traitee - et on en insere une nouvelle qui commence a
   cette meme date. Les periodes se suivent sans trou.

   Pour connaitre l'etat au 18 juillet :

     SELECT * FROM dbo.OWT_CONTRAT
     WHERE NUM_CONTRAT = 'C12345'
       AND '2026-07-18' >= DT_DEB_VAL
       AND '2026-07-18' <  DT_FIN_VAL;

   Si le contrat a ete supprime dans LIGIS, on insere quand meme une ligne,
   avec FL_SUP = 1 : il garde une version courante, explicitement marquee
   comme supprimee.


5. TOUT EST PILOTE PAR UNE TABLE DE PARAMETRAGE

   Aucun nom de table ni de colonne n'est ecrit dans les scripts. Tout est
   lu dans dbo.ORT_PARAM_HISTORISATION_TRACES, qui contient une ligne par
   colonne et quatre indicateurs :

     FL_CHARGEMENT = 1   la table fait partie du perimetre
     FL_CLEF       = 1   cette colonne fait partie de la cle
     FL_ORDRE_TRI  = 1   cette colonne sert a trier dans le temps
     LB_FILTRE_WHERE     condition SQL si on ne veut qu'une partie des lignes

   Ajouter une table au perimetre, en retirer une, changer une cle : cela se
   fait dans cette table, jamais dans le code.


UN EXEMPLE COMPLET
--------------------------------------------------------------------------------

Le contrat C12345 est modifie trois fois le 22 juillet :

     11h20   changement d'etat
     16h45   changement de montant
     23h10   changement d'etat  (batch de nuit)

Le quotidien LIGIS se termine le 23 a 03h08, l'extraction suit et s'arrete a
03h15. Le package tourne a 04h00.

  Etape 1   La frontiere du 22 est le 23 a 07:45. L'extraction s'est arretee
            a 03h15, avant cette heure : la journee n'est pas complete.
            Aucune borne posee, aucune journee traitee, le package se termine
            normalement.

Le lendemain, l'extraction s'arrete le 24 a 04h00. Le package retourne.

  Etape 1   La frontiere du 22 (le 23 a 07:45) est depassee : borne posee
            pour le 22. Celle du 23 (le 24 a 07:45) ne l'est pas : on
            s'arrete la.
  Etape 6   Sur la periode du 22 a 07:45 au 23 a 07:45, les trois
            modifications du contrat sont presentes. La plus recente est
            celle de 23h10 : elle est marquee FL_FIN_JOURNEE = 1.
  Etape 7   Le 22 n'a jamais ete traite : il n'y a rien a defaire.
  Etape 8   La version courante du contrat est fermee au 22 juillet, et une
            nouvelle version est inseree, qui commence au 22 et reste
            courante.
  Etape 9   Aucune table en erreur : le bilan est OK.
  Etape 10  Le 22 est marque comme traite.
  Etape 5   Plus de journee eligible : on sort de la boucle.
  Etape 11  Les traces jusqu'au 23 a 07:45 sont copiees dans l'archive puis
            effacees du sas. Les modifications faites apres 07:45 restent en
            attente : elles seront traitees avec la journee du 23.


CONTENU DE LA LIVRAISON
--------------------------------------------------------------------------------

1_SQL  -  tables et generateurs

  01  ORT_PARAM_HISTORISATION_TRACES  le parametrage : quelles tables,
                                      quelles cles, quels filtres
  02  ORT_BORNE_JOURNEE               les frontieres de journee
  03  ORT_AUDIT_CHARGEMENT            le journal du traitement
  04  OIT_TEC_AUD_CDC                 reception du fichier d'audit CDC
  05  OWT_TEC_AUD_CDC                 historique des extractions
  06  PITCOT_PERIODE_REPRISE          liste des journees a traiter
  07  GEN_TABLES_OIT_OWT              ecrit les CREATE TABLE des OIT et OWT
  08  GEN_TABLES_HISTO                ecrit les CREATE TABLE des archives
  09  GEN_PARAMETRAGE                 ecrit le contenu du parametrage
  10  INIT_MEP                        a executer une fois, a la mise en prod
  11  CONTROLES                       requetes de verification

2_ODI  -  les onze objets du package IOM.LIGIS_TRACE_CSTIMG

  01  POSE_BORNE            determine les journees traitables
  02  ARCHIVE_AUDIT_CDC     conserve l'historique des extractions
  03  CADRAGE_PERIODE       prepare PWTTRE avant T003
  04  RECUP_DATES           construit la liste des journees
  05  V_IOM_LIG_DT_TRACES   variable : prochaine journee a traiter
  06  FLAG_OIT              marque l'etat de fin de journee
  07  PURGE_OWT             defait un traitement precedent si besoin
  08  HISTO_OWT             ferme et insere les versions
  09  BILAN_JOURNEE         conclut la journee, remonte les erreurs
  10  FLAG_DATES            marque la journee comme traitee
  11  ARCHIVE_PURGE_OIT     archive puis vide le sas

3_POWERSHELL  -  export et import des fichiers

  liste_vues.sql          liste des vues a exporter
  export-parameters.psd1  parametres de l'export
  export_bcpout.ps1       extraction vers .bcp, archive, copie
  copy_bcp.bat            copie via chemin.bat et copy_proc.bat
  import-parameters.psd1  parametres de l'import
  import_bcpin.ps1        chargement dans les tables ods


ENCHAINEMENT DU PACKAGE ODI
--------------------------------------------------------------------------------

  01 POSE_BORNE
       |
  02 ARCHIVE_AUDIT_CDC
       |
  03 CADRAGE_PERIODE
       |
  T003  (procedure maison, existante)
       |
  04 RECUP_DATES
       |
  05 variable V_IOM_LIG_DT_TRACES  <-------------------+
       |                                               |
  evaluation : une journee a traiter ?                 |
       | oui                     | non                 |
  06 FLAG_OIT           11 ARCHIVE_PURGE_OIT           |
       |                        |                      |
  07 PURGE_OWT              T004  (maison)             |
       |                        |                      |
  08 HISTO_OWT              fin OK                     |
       |                                               |
  09 BILAN_JOURNEE                                     |
       | OK                                            |
  10 FLAG_DATES -----------------------------------------+

Si l'etape 09 tombe en erreur, le package s'arrete AVANT T004 : la periode
n'avance pas, la journee reste a traiter, la relance la reconstruit.

T003 et T004 doivent etre ajoutees comme PROCEDURES dans le package, et non
lancees comme scenarios : elles travaillent sur le nom de la session en
cours, qui doit etre celui du package.

Schemas logiques ODI a declarer : MSSQL_DWH, MSSQL_ODS et MSSQL_ODS_TRACES.


INSTALLATION
--------------------------------------------------------------------------------

  1. Modifier les vues CDC cote LIGIS pour ajouter deux colonnes :
         C.__$start_lsn AS CD_LSN_TEC           en 5e colonne technique
         , CONVERT(bit, 0) AS FL_FIN_JOURNEE    en toute derniere colonne
     La vue d'audit ZBCP_LIGIS_TEC_AUD_CDC_V n'est pas concernee.

  2. Sur le DWH : executer les scripts 01 a 06.

  3. Sur la base LIGIS : executer 07, 08 et 09. Ils ne creent rien, ils
     produisent du SQL. Executer ensuite :
       - la sortie de 07 sur le DWH
       - la sortie de 08 sur ODS_Traces
       - la sortie de 09 sur le DWH

  4. Relire le parametrage et l'ajuster : renommages, filtres, tables a
     desactiver, cles des tables sans cle primaire.

  5. Sur le DWH : executer 10 (initialisation) puis 11 (controles).

  6. Creer les objets ODI, le package, et declarer les schemas logiques.

  7. Installer les scripts PowerShell et renseigner les deux fichiers .psd1.


AU QUOTIDIEN
--------------------------------------------------------------------------------

Trois traitements s'enchainent, chacun ne demarrant que si le precedent a
reussi :

    export_bcpout.ps1   ->   import_bcpin.ps1   ->   package ODI

Les scripts PowerShell renvoient 0 si tout va bien, autre chose sinon.

Pour savoir ce qui s'est passe :

    SELECT LB_CHARGEMENT, LB_SOURCE, NB_LIGNE, CD_STATUT, LB_ERREUR
    FROM dbo.ORT_AUDIT_CHARGEMENT
    WHERE LB_PROJET = 'LIGIS'
      AND CHARINDEX('[2026-07-22]', LB_CHARGEMENT) > 0
    ORDER BY DT_DEBUT;

Une ligne par table, avec les volumetries. Les lignes en KO indiquent quelle
table a echoue et pourquoi.

En cas d'erreur : relancer le package depuis le debut. Toutes les etapes
savent defaire ce qu'elles ont fait, la journee est integralement recalculee.
Ne pas relancer une etape isolee sur une journee en echec.


CE QU'IL NE FAUT PAS ENLEVER
--------------------------------------------------------------------------------

  - L'index unique sur les tables OWT. C'est lui qui rend impossible d'avoir
    deux versions courantes pour un meme contrat.

  - La suppression de la plage LSN avant chaque chargement. C'est elle qui
    permet de relancer un import sans creer de doublons, alors que les tables
    ne sont pas videes.

  - L'ordre copier / verifier / supprimer de l'etape 11. Il garantit qu'il
    n'existe aucun moment ou une trace pourrait n'etre nulle part.

  - L'arret du package avant T004 en cas d'erreur. C'est ce qui garantit
    qu'une journee en echec sera reprise.


POINTS RESTANT A TRAITER
--------------------------------------------------------------------------------

  - Les tables LIGIS sans cle primaire sont ignorees tant qu'on ne leur a pas
    donne de cle dans le parametrage. La cle utilisee par le CDC lui-meme est
    consultable dans cdc.index_columns.

  - La purge des archives (13 mois de retention prevus au ticket) reste a
    ecrire : c'est un traitement separe, l'index necessaire est deja en place.
================================================================================
