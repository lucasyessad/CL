/* ============================================================================
   ETAPE 1  -  IOM_LIG_POSE_BORNE

   Determine quelles journees peuvent etre traitees, et le note dans
   ORT_BORNE_JOURNEE.

   LE PRINCIPE

   Une journee se termine a 07:45 le lendemain ouvrable. On ne peut la
   traiter que si l'extraction LIGIS est allee au-dela de cette heure : sinon
   on ne sait pas ce qui s'est passe entre les deux.

   L'etape compare donc la couverture de l'extraction avec les frontieres
   successives, et pose une borne pour chaque journee entierement couverte.

   Exemple, on a deja traite jusqu'au 21 :
     extraction arretee le 22 a 21h00  ->  la frontiere du 22 est le 23 a
       07:45, on n'y est pas : aucune borne, on attend.
     extraction arretee le 23 a 03h08  ->  meme chose, 03h08 est avant 07:45.
     extraction arretee le 23 a 09h00  ->  la frontiere du 22 est franchie :
       une borne pour le 22. Celle du 23 (le 24 a 07:45) ne l'est pas : on
       s'arrete la.
     extraction arretee le 25 a 09h00  ->  trois bornes, pour le 22, le 23 et
       le 24. Chaque journee sera traitee separement et aura sa propre image.

   Il n'y a donc pas de mode quotidien et de mode rattrapage : c'est la meme
   regle, appliquee autant de fois que necessaire.

   OU S'ARRETE L'EXTRACTION : DT_FIN_LSN

   Cote LIGIS, l'audit est mis a jour AVANT de lancer les extractions. Il
   enregistre le dernier LSN capture pour toute la base
   (sys.fn_cdc_get_max_lsn), et les vues exportees filtrent ensuite sur
   __$start_lsn <= LB_FIN_LSN.

   La donnee qui arrivera s'arrete donc exactement a ce LSN, et DT_FIN_LSN en
   donne l'heure. Ce n'est pas une estimation : c'est la borne haute reelle
   de ce qui va etre charge.

   Cette borne est GLOBALE, la meme pour toutes les tables : l'UPDATE n'a pas
   de clause WHERE et fn_cdc_get_max_lsn ne travaille pas par table. Une
   table peu modifiee n'est pas "en retard", elle a simplement moins de
   lignes dans la fenetre. Le MIN ne sert que de securite, au cas ou une
   instance recemment ajoutee au CDC n'aurait pas encore ete mise a jour.

   L'etape ne tombe jamais en erreur parce qu'il n'y a rien de nouveau. Elle
   ecrit une ligne dans le journal et le package se termine normalement.
   ============================================================================ */
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';
DECLARE @H_FRONTIERE TIME(0)      = '07:45:00';   -- heure de frontiere de journee

DECLARE @fin_extraction DATETIME2(3), @nb_inst_sans_date INT,
        @dt_jour_prec DATE, @jour DATE, @jour_suivant DATE,
        @frontiere DATETIME2(3), @nb_bornes INT = 0,
        @premiere DATE, @derniere DATE,
        @dt_step DATETIME = GETDATE();

/* 1. Jusqu'ou l'extraction est allee.
      L'audit est mis a jour AVANT les extractions et fixe LB_FIN_LSN ; les
      vues exportees filtrent ensuite sur __$start_lsn <= LB_FIN_LSN. La
      donnee extraite s'arrete donc exactement a ce LSN, dont DT_FIN_LSN est
      l'heure. C'est une couverture exacte, pas une estimation.

      DT_EXTRACT n'est pas utilisee : elle vaut GETDATE() au moment de la
      mise a jour de l'audit, donc APRES la prise du LSN. S'en servir
      reviendrait a declarer couverte une periode qui ne le sera pas.       */
SELECT @fin_extraction    = MIN(A.DT_FIN_LSN),
       @nb_inst_sans_date = SUM(CASE WHEN A.DT_FIN_LSN IS NULL THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?> A
WHERE A.LB_INSTANCE IN (
        SELECT DISTINCT 'dbo_' + SUBSTRING(P.LB_TABLE_ODS, 5, 200)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
        WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
          AND P.LB_TABLE_ODS LIKE 'OIT[_]%');

IF @fin_extraction IS NULL OR ISNULL(@nb_inst_sans_date, 0) > 0
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: couverture d''extraction indeterminable ('
            + CAST(ISNULL(@nb_inst_sans_date, 0) AS NVARCHAR(10))
            + N' instance(s) sans DT_FIN_LSN, ou audit vide). Aucune journee'
            + N' eligible : mieux vaut attendre que traiter une periode dont'
            + N' on ignore ou elle s''arrete.',
            @dt_step, GETDATE());
    RETURN;
END

/* 2. Derniere journee bornee ------------------------------------------------- */
SELECT @dt_jour_prec = MAX(DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>;

IF @dt_jour_prec IS NULL
BEGIN
    INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
        (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
    VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
            0, N'OK',
            N'AVERTISSEMENT: aucune borne initiale (TYPE_BORNE = INIT) - executer 01_INIT_MEP_ONE_SHOT.sql.',
            @dt_step, GETDATE());
    RETURN;
END

/* 3. Pose des bornes : une par journee ouvrable entierement couverte --------- */
WHILE 1 = 1
BEGIN
    SET @jour = NULL;
    SELECT TOP (1) @jour = CONVERT(date, DT_CAL, 121)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1 AND CONVERT(date, DT_CAL, 121) > @dt_jour_prec
    ORDER BY DT_CAL;

    IF @jour IS NULL BREAK;              -- calendrier epuise

    SET @jour_suivant = NULL;
    SELECT TOP (1) @jour_suivant = CONVERT(date, DT_CAL, 121)
    FROM <?=odiRef.getObjectName("L", "PRTCAL", "MSSQL_DWH", "D") ?>
    WHERE FL_OVR = 1 AND CONVERT(date, DT_CAL, 121) > @jour
    ORDER BY DT_CAL;

    IF @jour_suivant IS NULL BREAK;      -- frontiere inconnue : prolonger PRTCAL

    SET @frontiere = DATETIME2FROMPARTS(
                         DATEPART(year,  @jour_suivant),
                         DATEPART(month, @jour_suivant),
                         DATEPART(day,   @jour_suivant),
                         DATEPART(hour,   @H_FRONTIERE),
                         DATEPART(minute, @H_FRONTIERE),
                         0, 0, 3);

    -- Fenetre non entierement couverte par l'extraction : on s'arrete ici.
    IF @fin_extraction < @frontiere BREAK;

    INSERT INTO <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
        (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR)
    VALUES (@jour, @frontiere, 'QUOTIDIEN', 'AUDIT_CDC');

    IF @nb_bornes = 0 SET @premiere = @jour;
    SET @derniere     = @jour;
    SET @nb_bornes   += 1;
    SET @dt_jour_prec = @jour;
END

/* 4. Audit : une seule ligne recapitulative ---------------------------------- */
INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET, N'POSE BORNE', N'OIT_TEC_AUD_CDC', N'ORT_BORNE_JOURNEE',
        @nb_bornes, N'OK',
        CASE WHEN @nb_bornes = 0
             THEN N'IGNORE: extraction arretee au ' + CONVERT(NVARCHAR(23), @fin_extraction, 121)
                  + N' - journee suivante non encore complete (frontiere '
                  + ISNULL(CONVERT(NVARCHAR(23), @frontiere, 121), N'inconnue') + N').'
             ELSE N'Extraction au ' + CONVERT(NVARCHAR(23), @fin_extraction, 121) + N' : '
                  + CAST(@nb_bornes AS NVARCHAR(10)) + N' journee(s) bornee(s) du '
                  + CONVERT(NVARCHAR(10), @premiere, 23) + N' au '
                  + CONVERT(NVARCHAR(10), @derniere, 23)
                  + CASE WHEN @nb_bornes > 1 THEN N' (rattrapage).' ELSE N' (quotidien).' END
        END,
        @dt_step, GETDATE());
