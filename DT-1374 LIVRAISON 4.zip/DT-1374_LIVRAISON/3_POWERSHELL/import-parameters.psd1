@{
    Server       = "ERM"
    Database     = "DWH"
    InputDir     = "\\kenya\dsi\datalib"
    LogDir       = "\\kenya\dsi\datalib\log"
    ListFileName = "tables-to-load.txt"
    TableSchema  = "ods"
    TablePrefix  = "OIT_"
    # Table d'audit CDC : photo de la derniere extraction, rechargee en entier.
    AuditTable   = "TEC_AUD_CDC"
}
