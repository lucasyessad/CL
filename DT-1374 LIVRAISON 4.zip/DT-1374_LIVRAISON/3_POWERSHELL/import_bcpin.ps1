#-----------------------------------------------------------------------------#
# SCHEDULE : quotidien, apres export_bcpout.ps1                               #
#                                                                             #
# PROJET   : EXPORT / IMPORT BCP                                              #
#                                                                             #
# TITRE SCRIPT  : Chargement des fichiers BCP vers les tables cibles          #
#                                                                             #
# DATE CREATION : 24/07/2026                              MAJ  : 24/07/2026   #
#                                                         USER : LYE          #
#-----------------------------------------------------------------------------#
# OBJECTIF : Charge les fichiers .bcp dans les tables ods.OIT_xxx.            #
#                                                                             #
#            Les tables de traces sont alimentees en AJOUT : elles            #
#            conservent les traces pas encore traitees, c'est-a-dire celles   #
#            ecrites apres la derniere fin de journee. Les vider les ferait   #
#            disparaitre, sans possibilite de les recuperer ensuite.          #
#                                                                             #
#            Comme la table n'est pas videe, rejouer un import chargerait     #
#            deux fois les memes traces. Le script supprime donc d'abord la   #
#            plage de LSN que le fichier va recharger, lue dans l'audit CDC   #
#            deja charge. Une relance ne cree ainsi aucun doublon.            #
#                                                                             #
#            Seule exception : la table d'audit CDC, qui ne contient que la   #
#            derniere extraction et doit donc etre rechargee en entier.       #
#                                                                             #
#            Arret et code retour non nul des la premiere table en echec :    #
#            un ODS incomplet produirait une image de fin de journee fausse.  #
#                                                                             #
# CALL : ./import_bcpin.ps1                                                   #
#                                                                             #
# CODES RETOUR : 0 = OK   1 = configuration / connexion   2 = table en echec  #
#-----------------------------------------------------------------------------#

[CmdletBinding()]
param([string]$ConfigFile = "import-parameters.psd1")

$ErrorActionPreference = 'Stop'
$cfg   = Import-PowerShellDataFile (Join-Path $PSScriptRoot $ConfigFile)
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$code  = 0

if (-not (Test-Path $cfg.LogDir)) { New-Item -ItemType Directory $cfg.LogDir -Force | Out-Null }
Start-Transcript -Path (Join-Path $cfg.LogDir "IMPORT_$stamp.log") | Out-Null

try {
    if (-not (Test-Path $cfg.InputDir)) { throw "Repertoire d'import introuvable : $($cfg.InputDir)." }

    Get-ChildItem $cfg.InputDir -Filter "*.zip" | ForEach-Object {
        Expand-Archive -Path $_.FullName -DestinationPath $cfg.InputDir -Force
        Write-Host "Archive extraite : $($_.Name)" -ForegroundColor Cyan
    }

    # La liste vient de l'export : elle seule garantit l'exhaustivite du
    # chargement. Se fier aux .bcp presents laisserait passer un fichier
    # manquant sans que rien ne le signale.
    $listFile = Join-Path $cfg.InputDir $cfg.ListFileName
    if (-not (Test-Path $listFile)) { throw "Fichier de liste absent : $listFile." }
    $tables = Get-Content $listFile | Where-Object { $_.Trim() }

    foreach ($t in $tables) {
        $t    = $t.Trim()
        $tbl  = "$($cfg.TablePrefix)$t"
        $file = Join-Path $cfg.InputDir "$t.bcp"

        if (-not (Test-Path $file))        { $code = 2 ; throw "Fichier absent : $file." }
        if ((Get-Item $file).Length -eq 0) { $code = 2 ; throw "Fichier vide : $file." }

        if ($t -eq $cfg.AuditTable) {
            # Photo de la derniere extraction : rechargee en entier.
            Invoke-Sqlcmd -ServerInstance $cfg.Server -Database $cfg.Database `
                          -Query "TRUNCATE TABLE [$($cfg.TableSchema)].[$tbl]"
        }
        else {
            # Table de traces : alimentee en ajout, jamais videe. On supprime
            # uniquement la plage que ce fichier va recharger, bornee par les
            # LSN de l'audit. Rejouer l'import est donc sans effet de bord.
            # L'audit est charge en premier : ses bornes sont disponibles ici.
            $purge = @"
DELETE T
FROM [$($cfg.TableSchema)].[$tbl] AS T
INNER JOIN [$($cfg.TableSchema)].[$($cfg.TablePrefix)$($cfg.AuditTable)] AS A
        ON A.LB_INSTANCE = 'dbo_$t'
WHERE T.CD_LSN_TEC >  A.LB_DEB_LSN
  AND T.CD_LSN_TEC <= A.LB_FIN_LSN;
"@
            Invoke-Sqlcmd -ServerInstance $cfg.Server -Database $cfg.Database -Query $purge
        }

        & bcp "$($cfg.Database).$($cfg.TableSchema).$tbl" in $file -n -S $cfg.Server -T
        if ($LASTEXITCODE -ne 0) { $code = 2 ; throw "BCP IN en echec pour $tbl (code $LASTEXITCODE)." }
    }

    Write-Host "Import termine - $($tables.Count) table(s)." -ForegroundColor Green
}
catch {
    if ($code -eq 0) { $code = 1 }
    Write-Host "*** IMPORT EN ECHEC (code $code) : $_" -ForegroundColor Red
    Write-Host "*** L'ODS EST INCOMPLET : NE PAS LANCER LE PACKAGE ODI." -ForegroundColor Red
}
finally { Stop-Transcript | Out-Null }

exit $code
