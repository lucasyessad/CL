#-----------------------------------------------------------------------------#
# SCHEDULE : quotidien, apres le batch LIGIS                                  #
#                                                                             #
# PROJET   : EXPORT / IMPORT BCP                                              #
#                                                                             #
# TITRE SCRIPT  : Extraction des vues vers fichiers BCP                       #
#                 et copie vers le repertoire d'import                        #
#                                                                             #
# DATE CREATION : 24/07/2026                              MAJ  : 24/07/2026   #
#                                                         USER : LYE          #
#-----------------------------------------------------------------------------#
# OBJECTIF : Extrait les vues CDC de LIGIS vers des fichiers .bcp, les        #
#            regroupe dans une archive et la copie vers le repertoire lu par  #
#            l'import.                                                        #
#                                                                             #
#            La liste des vues est lue dans la base : rien n'est fige dans le #
#            script. L'audit CDC est traite en premier car sans lui aucune    #
#            journee ne peut etre bornee cote ODI.                            #
#                                                                             #
#            Le repertoire est vide avant l'export : un fichier d'un export   #
#            precedent serait sinon renvoye comme s'il etait a jour.          #
#                                                                             #
#            Arret et code retour non nul des la premiere table en echec.     #
#                                                                             #
# CALL : ./export_bcpout.ps1                                                  #
#                                                                             #
# CODES RETOUR : 0 = OK   1 = configuration / connexion   2 = table en echec  #
#-----------------------------------------------------------------------------#

[CmdletBinding()]
param([string]$ConfigFile = "export-parameters.psd1")

$ErrorActionPreference = 'Stop'
$cfg   = Import-PowerShellDataFile (Join-Path $PSScriptRoot $ConfigFile)
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$code  = 0

if (-not (Test-Path $cfg.LogDir))    { New-Item -ItemType Directory $cfg.LogDir -Force | Out-Null }
if (-not (Test-Path $cfg.OutputDir)) { New-Item -ItemType Directory $cfg.OutputDir -Force | Out-Null }
Start-Transcript -Path (Join-Path $cfg.LogDir "EXPORT_$stamp.log") | Out-Null

try {
    # Liste des vues a exporter. Le nom retourne est le nom NU de la table :
    # ZBCP_LIGIS_CONTRAT_V donne CONTRAT. C'est ce nom qui circule dans le
    # fichier de liste et qui nomme le fichier .bcp.
    # 'ZBCP_LIGIS_' fait 11 caracteres et '_V' en fait 2, d'ou 12 et -13.
    # L'audit CDC est place en tete : sans lui, aucune journee ne peut etre
    # bornee cote ODI, autant s'en apercevoir tout de suite.
    $requete = @"
SELECT nom = SUBSTRING(v.name, 12, LEN(v.name) - 13)
FROM sys.views v
JOIN sys.schemas s ON s.schema_id = v.schema_id
WHERE s.name = '$($cfg.Schema)'
  AND v.name LIKE 'ZBCP[_]LIGIS[_]%[_]V'
ORDER BY CASE WHEN SUBSTRING(v.name, 12, LEN(v.name) - 13) = '$($cfg.PriorityTable)'
              THEN 0 ELSE 1 END,
         v.name;
"@

    $tables = Invoke-Sqlcmd -ServerInstance $cfg.Server -Database $cfg.Database `
                            -Query $requete | Select-Object -ExpandProperty nom

    if (-not $tables) { throw "Aucune vue ZBCP_LIGIS_%_V dans le schema $($cfg.Schema)." }

    if ($tables -notcontains $cfg.PriorityTable) {
        throw "Vue prioritaire absente : $($cfg.PriorityTable) (audit CDC)."
    }
    Write-Host "$($tables.Count) vue(s) a exporter." -ForegroundColor Cyan

    # Purge : un .bcp d'un export precedent serait rezippe et reimporte
    Get-ChildItem $cfg.OutputDir -Filter "*.bcp" | Remove-Item -Force
    Set-Content (Join-Path $cfg.OutputDir $cfg.ListFileName) -Value $tables -Encoding UTF8

    foreach ($t in $tables) {
        $file = Join-Path $cfg.OutputDir "$t.bcp"
        & bcp "$($cfg.Database).$($cfg.Schema).ZBCP_LIGIS_$($t)_V" out $file -n -S $cfg.Server -T
        if ($LASTEXITCODE -ne 0)           { $code = 2 ; throw "BCP OUT en echec pour $t (code $LASTEXITCODE)." }
        if (-not (Test-Path $file))        { $code = 2 ; throw "Fichier non produit pour $t." }
        if ((Get-Item $file).Length -eq 0) { $code = 2 ; throw "Fichier vide pour $t." }
    }

    # Archive : liste + fichiers, sous un nom fixe attendu par l'import
    $zip = Join-Path $cfg.OutputDir $cfg.ZipFileName
    if (Test-Path $zip) { Remove-Item $zip -Force }
    $aZipper = @(Join-Path $cfg.OutputDir $cfg.ListFileName) +
               (Get-ChildItem $cfg.OutputDir -Filter "*.bcp" | Select-Object -ExpandProperty FullName)
    Compress-Archive -Path $aZipper -DestinationPath $zip -Force

    # Copie par la procedure maison (chemin.bat puis copy_proc.bat)
    & (Join-Path $PSScriptRoot "copy_bcp.bat") $cfg.ZipFileName $cfg.TargetCopyDir
    if ($LASTEXITCODE -ne 0) { $code = 2 ; throw "Copie de $($cfg.ZipFileName) en echec (code $LASTEXITCODE)." }

    Write-Host "Export termine - $($tables.Count) table(s)." -ForegroundColor Green
}
catch {
    if ($code -eq 0) { $code = 1 }
    Write-Host "*** EXPORT EN ECHEC (code $code) : $_" -ForegroundColor Red
    Write-Host "*** L'IMPORT NE DOIT PAS ETRE LANCE." -ForegroundColor Red
}
finally { Stop-Transcript | Out-Null }

exit $code
