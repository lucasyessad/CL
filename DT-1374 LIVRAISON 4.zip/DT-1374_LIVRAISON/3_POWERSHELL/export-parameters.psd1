@{
    Server        = "ASM"
    Database      = "Ligis5_Test_Data"
    Schema        = "export_cdc"
    PriorityTable = "TEC_AUD_CDC"   # audit CDC : exporte en premier
    OutputDir     = "\\sion\dsi\datalib"    # doit correspondre a %datalib%
    LogDir        = "\\sion\dsi\datalib\log"
    TargetCopyDir = "\\kenya\dsi\datalib"
    ListFileName  = "tables-to-load.txt"
    ZipFileName   = "TRACES_LIGIS.zip"
}
