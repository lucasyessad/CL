/* ============================================================================
   ETAPE 10  -  IOM_LIG_ARCHIVE_AUDIT_CDC

   Recopie le contenu de ods.OIT_TEC_AUD_CDC dans dbo.OWT_TEC_AUD_CDC.

   La premiere est videe a chaque import : sans cette copie, on ne saurait
   plus, quelques jours plus tard, jusqu'ou chaque extraction etait allee.

   PLACEE EN FIN DE PACKAGE, juste avant l'archivage des traces. Deux
   raisons : les journees sont alors toutes traitees, donc l'extraction est
   rattachee a la bonne journee ; et si cette copie echoue, elle echoue AVANT
   que le sas ne soit purge, donc rien n'est encore perdu.

   On ajoute seulement les extractions absentes de l'archive, reconnues par
   le couple (table, LSN de fin). Relancer l'etape ne cree pas de doublon.

   Les lignes sans LSN de fin sont mises de cote et comptees : c'est le
   signal que le traitement amont ne remplit pas cette colonne.
   ============================================================================ */
DECLARE @ID_TRT_ALI INT          = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50) = N'LIGIS';

DECLARE @dt_step   DATETIME = GETDATE(),
        @dt_jour   DATE,
        @nb_ins    INT = 0,
        @nb_total  INT = 0,
        @nb_sans_lsn INT = 0;

/* Journee de rattachement = derniere journee bornee (posee par A0) --------- */
SELECT @dt_jour = MAX(DT_JOUR)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>;

SELECT @nb_total    = COUNT(*),
       @nb_sans_lsn = SUM(CASE WHEN LB_FIN_LSN IS NULL THEN 1 ELSE 0 END)
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?>;

/* Archivage des extractions non encore historisees ------------------------- */
INSERT INTO <?=odiRef.getObjectName("L", "OWT_TEC_AUD_CDC", "MSSQL_DWH", "D") ?>
    (ID_INSTANCE, LB_INSTANCE, LB_DEB_LSN, LB_FIN_LSN,
     DT_DEB_LSN, DT_FIN_LSN, DT_EXTRACT,
     DT_JOUR_TEC, ID_TRT_ALI, DT_MAJ)
SELECT A.ID_INSTANCE, A.LB_INSTANCE, A.LB_DEB_LSN, A.LB_FIN_LSN,
       A.DT_DEB_LSN, A.DT_FIN_LSN, A.DT_EXTRACT,
       @dt_jour, @ID_TRT_ALI, GETDATE()
FROM <?=odiRef.getObjectName("L", "OIT_TEC_AUD_CDC", "MSSQL_ODS", "D") ?> AS A
WHERE A.LB_FIN_LSN IS NOT NULL
  AND NOT EXISTS (
        SELECT 1
        FROM <?=odiRef.getObjectName("L", "OWT_TEC_AUD_CDC", "MSSQL_DWH", "D") ?> AS H
        WHERE H.LB_INSTANCE = A.LB_INSTANCE
          AND H.LB_FIN_LSN  = A.LB_FIN_LSN);

SET @nb_ins = @@ROWCOUNT;

INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
VALUES (@ID_TRT_ALI, @LB_PROJET,
        N'ARCHIVE AUDIT CDC'
        + CASE WHEN @dt_jour IS NOT NULL
               THEN N' [' + CONVERT(NVARCHAR(10), @dt_jour, 23) + N']'
               ELSE N'' END,
        N'OIT_TEC_AUD_CDC', N'OWT_TEC_AUD_CDC', @nb_ins, N'OK',
        CASE
          WHEN ISNULL(@nb_total, 0) = 0
               THEN N'AVERTISSEMENT: ods.OIT_TEC_AUD_CDC est vide - le BCPIN de la vue d''audit a-t-il tourne ?'
          WHEN ISNULL(@nb_sans_lsn, 0) > 0
               THEN N'AVERTISSEMENT: ' + CAST(@nb_sans_lsn AS NVARCHAR(10))
                    + N' ligne(s) ecartee(s) faute de LB_FIN_LSN (sur '
                    + CAST(@nb_total AS NVARCHAR(10)) + N'). Verifier le traitement amont.'
          WHEN @nb_ins = 0
               THEN N'IGNORE: aucune nouvelle extraction depuis le dernier archivage.'
          ELSE N'Extractions archivees : ' + CAST(@nb_ins AS NVARCHAR(10))
               + N' sur ' + CAST(@nb_total AS NVARCHAR(10)) + N' instance(s) presentes.'
        END,
        @dt_step, GETDATE());
