/* ============================================================================
   ETAPE 4  -  VARIABLE V_IOM_LIG_DT_TRACES

   Type alphanumerique, action Rafraichir, schema logique MSSQL_DWH.

   Renvoie la plus ancienne journee qui reste a traiter ET qui possede une
   borne, ou NULL quand il n'y a plus rien : c'est ce NULL qui fait sortir le
   package de sa boucle.

   La condition sur la borne est essentielle. Une journee sans borne est une
   journee dont l'extraction n'a pas encore couvert la fin : elle attend son
   tour, elle n'est jamais traitee a moitie.
   ============================================================================ */
SELECT CONVERT(varchar(10), MIN(P.DT_CAL), 23)
FROM <?=odiRef.getObjectName("L", "PITCOT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?> P
WHERE P.TRAITE = 0
  AND P.LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>'
  AND EXISTS (SELECT 1 FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?> B
              WHERE B.DT_JOUR = CONVERT(date, P.DT_CAL, 121))
