/* ============================================================================
   ETAPE 7  -  IOM_LIG_HISTO_OWT

   Construit l'historique dans dbo.OWT_xxx a partir des traces marquees par
   l'etape 5.

   COMMENT FONCTIONNE L'HISTORIQUE

   Chaque ligne de l'historique est valable sur une periode : de DT_DEB_VAL a
   DT_FIN_VAL. La version en cours porte la date de fin 2400-01-01, une date
   volontairement lointaine qui evite d'avoir a gerer des NULL dans les
   comparaisons, et FL_VER_CRT = 1.

   Quand un contrat change, deux operations :
     1. on ferme la version en cours : sa date de fin devient la journee
        traitee et FL_VER_CRT passe a 0 ;
     2. on insere la nouvelle version, qui commence a cette meme journee.

   Les periodes se suivent donc sans trou ni chevauchement, et on peut
   retrouver l'etat d'un contrat a n'importe quelle date passee.

   Fermer AVANT d'inserer n'est pas un detail : l'index unique de la table
   interdit deux versions courantes pour une meme cle. L'ordre inverse le
   violerait.

   LE CAS DES SUPPRESSIONS

   Si la derniere modification de la journee est une suppression dans LIGIS
   (CD_CMD_TEC = 1), on insere quand meme une ligne, avec FL_SUP = 1. Le
   contrat garde ainsi une version courante, explicitement marquee comme
   supprimee - plus lisible que de le voir simplement disparaitre.

   NO_SEQ

   Numero de version, par cle : 1 pour la premiere, puis 2, 3... On reprend
   le maximum existant pour cette cle et on ajoute 1. Si la journee est
   recalculee, l'etape 6 a d'abord supprime la version concernee : le maximum
   redescend et le numero est identique. Pas de trou dans la numerotation.

   TROIS SECURITES

     - une table en erreur a une etape precedente est ignoree ;
     - si aucune trace n'est marquee, la cible n'est pas touchee ;
     - si la journee est deja presente dans l'historique, l'etape refuse de
       travailler : il faut repasser par l'etape 7 pour recalculer.

   C'est cette etape qui ecrit la ligne recapitulative de la table dans le
   journal, avec les trois volumetries.
   ============================================================================ */
DECLARE @DT_TRACES  DATE          = '#V_IOM_LIG_DT_TRACES';
DECLARE @ID_TRT_ALI INT           = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET  NVARCHAR(50)  = N'LIGIS';
DECLARE @DATE_INFINIE DATE        = '2400-01-01';
DECLARE @CD_USR_MAJ NVARCHAR(20)  = N'SUPERVIS';

DECLARE @PFX_ODS NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_ODS", "D") ?>.<?=odiRef.getSchemaName("MSSQL_ODS", "D") ?>.';
DECLARE @PFX_DWH NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @dt_deb DATETIME2(3), @dt_fin DATETIME2(3), @msg NVARCHAR(500),
        @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23);

SELECT @dt_fin = DT_BORNE
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR = @DT_TRACES;

SELECT @dt_deb = MAX(DT_BORNE)
FROM <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
WHERE DT_JOUR < @DT_TRACES;

IF @dt_fin IS NULL OR @dt_deb IS NULL
BEGIN
    SET @msg = N'Fenetre non definie pour le ' + @jour + N' (ORT_BORNE_JOURNEE).';
    THROW 50011, @msg, 1;
END

DECLARE @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200),
        @src NVARCHAR(400), @tgt NVARCHAR(400),
        @cle_ods NVARCHAR(MAX),
        @join_cond NVARCHAR(MAX), @join_max NVARCHAR(MAX),
        @cols_dwh NVARCHAR(MAX), @vals_ods NVARCHAR(MAX),
        @col_fen NVARCHAR(128), @filtre NVARCHAR(1000),
        @sql NVARCHAR(MAX), @nb_flag INT, @nb_deja INT, @nb_ferm INT, @nb_ins INT,
        @dt_step DATETIME;

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT P.LB_TABLE_ODS, MIN(P.LB_TABLE_DWH)
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?> P
    WHERE P.FL_CLEF = 1 AND P.FL_CHARGEMENT = 1
      AND NOT EXISTS (
            SELECT 1
            FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> A
            WHERE ISNULL(A.ID_TRT_ALI, -1) = ISNULL(@ID_TRT_ALI, -1)
              AND A.LB_PROJET = @LB_PROJET
              AND A.CD_STATUT = 'KO'
              AND A.LB_SOURCE = P.LB_TABLE_ODS
              AND CHARINDEX('[' + @jour + ']', A.LB_CHARGEMENT) > 0)
    GROUP BY P.LB_TABLE_ODS
    ORDER BY P.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = GETDATE();
    SET @nb_flag = 0; SET @nb_deja = 0; SET @nb_ferm = 0; SET @nb_ins = 0;

    BEGIN TRY
        SET @src = @PFX_ODS + QUOTENAME(@tbl_ods);
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        SELECT @cle_ods = NULL, @join_cond = NULL, @join_max = NULL,
               @cols_dwh = NULL, @vals_ods = NULL, @col_fen = NULL, @filtre = NULL;

        SELECT @cle_ods   = STRING_AGG(QUOTENAME(LB_CHAMP_ODS), N',') WITHIN GROUP (ORDER BY NO_CHAMP),
               @join_cond = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS) + N' = T.' + QUOTENAME(LB_CHAMP_DWH), N' AND '),
               @join_max  = STRING_AGG(N'T2.' + QUOTENAME(LB_CHAMP_DWH) + N' = S.' + QUOTENAME(LB_CHAMP_ODS), N' AND ')
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT @cols_dwh = STRING_AGG(QUOTENAME(LB_CHAMP_DWH), N', ') WITHIN GROUP (ORDER BY NO_CHAMP),
               @vals_ods = STRING_AGG(N'S.' + QUOTENAME(LB_CHAMP_ODS), N', ') WITHIN GROUP (ORDER BY NO_CHAMP)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods
          AND LB_CHAMP_ODS IS NOT NULL AND LB_CHAMP_DWH IS NOT NULL;

        SELECT TOP (1) @col_fen = LB_CHAMP_ODS
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_ORDRE_TRI = 1 AND LB_CHAMP_ODS IS NOT NULL
        ORDER BY NO_CHAMP;

        SELECT @filtre = MAX(LB_FILTRE_WHERE)
        FROM <?=odiRef.getObjectName("L", "ORT_PARAM_HISTORISATION_TRACES", "MSSQL_DWH", "D") ?>
        WHERE LB_TABLE_ODS = @tbl_ods AND FL_CLEF = 1;

        IF @cle_ods IS NULL OR @cols_dwh IS NULL OR @col_fen IS NULL
        BEGIN
            SET @msg = N'Parametrage incomplet pour ' + @tbl_ods
                     + N' (cle, mapping colonnes ou FL_ORDRE_TRI manquants).';
            THROW 50032, @msg, 1;
        END

        SET @filtre = ISNULL(@filtre, N'');

        /* Garde-fou 1 : source vide sur la fenetre */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @src +
                   N' WHERE FL_FIN_JOURNEE = 1' +
                   N'   AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                   CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';';
        EXEC sp_executesql @sql, N'@p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
             @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_flag OUTPUT;

        /* Garde-fou 2 : journee deja historisee pour cette table */
        SET @sql = N'SELECT @p_nb = COUNT(*) FROM ' + @tgt + N' WHERE DT_DEB_VAL = @p_dt;';
        EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
             @p_dt = @DT_TRACES, @p_nb = @nb_deja OUTPUT;

        IF @nb_flag = 0 OR @nb_deja > 0
        BEGIN
            -- Source vide : deja signale par FLAG_OIT, on n'ecrit rien de plus.
            -- Journee deja historisee : anomalie de sequencement, on trace.
            IF @nb_deja > 0
                INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                    (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
                VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']',
                        @tbl_ods, @tbl_dwh, 0, N'OK',
                        N'IGNORE: journee deja historisee (' + CAST(@nb_deja AS NVARCHAR(10))
                        + N' version(s) DT_DEB_VAL = ' + @jour + N') - relancer depuis PURGE_OWT pour recalculer.',
                        @dt_step, GETDATE());
        END
        ELSE
        BEGIN
            /* 1. Fermeture des versions courantes concernees */
            SET @sql = N'UPDATE T SET DT_FIN_VAL = @p_dt, FL_VER_CRT = 0' +
                       N' FROM ' + @tgt + N' AS T' +
                       N' INNER JOIN (SELECT DISTINCT ' + @cle_ods +
                       N'             FROM ' + @src +
                       N'             WHERE FL_FIN_JOURNEE = 1' +
                       N'               AND ' + QUOTENAME(@col_fen) + N' > @p_deb AND ' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                       CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END +
                       N'            ) AS S ON ' + @join_cond +
                       N' WHERE T.FL_VER_CRT = 1;' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql, N'@p_dt date, @p_deb datetime2(3), @p_fin datetime2(3), @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_ferm OUTPUT;

            /* 2. Insertion des nouvelles versions courantes.
                  Une suppression LIGIS (CD_CMD_TEC = 1) donne une ligne
                  portant FL_SUP = 1 : la cle garde une version courante,
                  explicitement marquee supprimee.
                  NO_SEQ poursuit la numerotation de la cle. La sous-requete
                  correlee fait un seek sur l'index de cle, la ou un agregat
                  sur toute la table imposerait un balayage complet.        */
            SET @sql = N'INSERT INTO ' + @tgt + N' (' + @cols_dwh +
                       N', NO_SEQ, DT_DEB_VAL, DT_FIN_VAL, FL_SUP, FL_VER_CRT,'
                     + N' DT_MAJ, CD_USR_MAJ, ID_TRT_ALI)' +
                       N' SELECT ' + @vals_ods +
                       N', ISNULL((SELECT MAX(T2.NO_SEQ) FROM ' + @tgt + N' AS T2'
                     + N'          WHERE ' + @join_max + N'), 0) + 1' +
                       N', @p_dt, @p_infini' +
                       N', CASE WHEN S.CD_CMD_TEC = 1 THEN 1 ELSE NULL END' +
                       N', 1, GETDATE(), @p_usr, @p_trt' +
                       N' FROM ' + @src + N' AS S' +
                       N' WHERE S.FL_FIN_JOURNEE = 1' +
                       N'   AND S.' + QUOTENAME(@col_fen) + N' > @p_deb'
                     + N'   AND S.' + QUOTENAME(@col_fen) + N' <= @p_fin' +
                       CASE WHEN @filtre <> N'' THEN N' AND ' + @filtre ELSE N'' END + N';' +
                       N' SELECT @p_nb = @@ROWCOUNT;';
            EXEC sp_executesql @sql,
                 N'@p_dt date, @p_infini date, @p_deb datetime2(3), @p_fin datetime2(3),'
               + N' @p_usr nvarchar(20), @p_trt int, @p_nb int OUTPUT',
                 @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE,
                 @p_deb = @dt_deb, @p_fin = @dt_fin,
                 @p_usr = @CD_USR_MAJ, @p_trt = @ID_TRT_ALI, @p_nb = @nb_ins OUTPUT;

            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']',
                    @tbl_ods, @tbl_dwh, @nb_ins, N'OK',
                    N'Flaguees: ' + CAST(@nb_flag AS NVARCHAR(10))
                    + N' / fermees: ' + CAST(@nb_ferm AS NVARCHAR(10))
                    + N' / inserees: ' + CAST(@nb_ins AS NVARCHAR(10)) + N'.',
                    @dt_step, GETDATE());
        END
    END TRY
    BEGIN CATCH
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']',
                @tbl_ods, @tbl_dwh, 0, N'KO', N'HISTO : ' + ERROR_MESSAGE(), @dt_step, GETDATE());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
