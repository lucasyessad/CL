/* ============================================================================
   [E] PROCEDURE ODI : IOM_LIG_FLAG_DATES
   Atteinte uniquement si IOM_LIG_TRT_JOURNEE est OK. "<=" et non "=" :
   absorbe automatiquement les journees intermediaires d'une periode
   MULTI_JOURS (sans borne, jamais eligibles, mais dont les traces sont
   dans la fenetre elargie). Puis lien OK -> retour rafraichissement de
   V_IOM_LIG_DT_TRACES.
   ============================================================================ */
UPDATE <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
SET TRAITE = 1
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'
  AND DT_CAL <= '#V_IOM_LIG_DT_TRACES'
  AND TRAITE = 0
