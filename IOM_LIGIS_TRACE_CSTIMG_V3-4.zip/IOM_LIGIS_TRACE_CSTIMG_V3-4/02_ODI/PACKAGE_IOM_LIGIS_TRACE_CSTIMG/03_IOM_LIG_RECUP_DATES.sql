/* ============================================================================
   [A] PROCEDURE ODI : IOM_LIG_RECUP_DATES
   Commande sur la cible, technologie SQL Server (copie du standard maison).
   Regenere la file des journees a traiter dans PITCOT_PERIODE_REPRISE.
   ============================================================================ */
DELETE FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
WHERE LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG'

INSERT INTO <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PITCOT_PERIODE_REPRISE
SELECT T.DT_CAL,
       (ROW_NUMBER() OVER (ORDER BY T.DT_CAL)) AS SEQ,
       0 AS TRAITE,
       'IOM_LIGIS_TRACE_CSTIMG' AS LB_NOM_SCN_SUN
FROM
(
    SELECT DISTINCT convert(date, DT_CAL, 121) as DT_CAL
    FROM <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PRTCAL
    WHERE DT_CAL > (select convert(date, DA_DEB_DEL_TRT, 121)
                    from <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PWTTRE
                    where LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
      and DT_CAL < (select isnull(DA_FIN_DEL_FOR, convert(date, GETDATE(), 121))
                    from <%=snpRef.getCatalogName("MSSQL_DWH", "D")%>.dbo.PWTTRE
                    where LB_NOM_SCN_SUN = 'IOM_LIGIS_TRACE_CSTIMG')
) AS T
ORDER BY SEQ ASC

-- NOTE : LIGIS ne tourne que les jours ouvres -> PRTCAL est la bonne source
-- de dates. Un jour ouvre sans trace pour une table est gere (OK_VIDE).
