/* ============================================================================
   DT-1374 - Sous-procedure : PURGE des donnees de la journee dans la cible
   V1.0 - 20/07/2026
   Pour la table designee par @ID_PARAM et la journee @DT_TRACES :
     1. supprime, si elles existent, les versions inserees avec DD_VAL = jour
        (donnees d'un precedent passage sur cette journee)
     2. rouvre les versions que cette journee avait fermees
        (DF_VAL = jour et FLAG_COURANT = 0  ->  DF_VAL = 2400-01-01, flag 1)
   La cible revient ainsi a son etat "avant traitement de la journee" :
   le recalcul est idempotent et sans doublon.
   Appelee par ORT_PRC_TRAITEMENT_JOUR ; en erreur, remonte l'exception (THROW).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_PURGE_OWT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_PURGE_OWT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_PURGE_OWT
    @DT_TRACES      DATE,
    @ID_PARAM       INT,
    @NB_SUPPRIMEES  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DATE_INFINIE DATE = '2400-01-01';

    DECLARE @table_source NVARCHAR(200), @table_cible NVARCHAR(200),
            @col_dd_val NVARCHAR(128), @col_df_val NVARCHAR(128),
            @col_flag_cour NVARCHAR(128),
            @sql NVARCHAR(MAX), @nb_rouvertes INT = 0;

    SELECT @table_source = NOM_TABLE_SOURCE, @table_cible = NOM_TABLE_CIBLE,
           @col_dd_val = COLONNE_DD_VAL, @col_df_val = COLONNE_DF_VAL,
           @col_flag_cour = COLONNE_FLAG_COURANT
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE ID_PARAM = @ID_PARAM;

    IF @table_source IS NULL
    BEGIN
        RAISERROR('ORT_PRC_SS_PURGE_OWT : ID_PARAM %d introuvable.', 16, 1, @ID_PARAM);
        RETURN;
    END

    SET @NB_SUPPRIMEES = 0;

    -- 1. Suppression des versions de la journee (si un passage precedent existe)
    SET @sql = N'DELETE FROM ' + @table_cible +
               N' WHERE ' + @col_dd_val + N' = @p_dt;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_nb = @NB_SUPPRIMEES OUTPUT;

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'PURGE_CIBLE', @NB_SUPPRIMEES, 'OK');

    -- 2. Reouverture des versions fermees par cette journee
    SET @sql = N'UPDATE ' + @table_cible +
               N' SET ' + @col_df_val + N' = @p_infini, ' + @col_flag_cour + N' = 1' +
               N' WHERE ' + @col_df_val + N' = @p_dt AND ' + @col_flag_cour + N' = 0;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_infini date, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_nb = @nb_rouvertes OUTPUT;

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'REOUVERTURE', @nb_rouvertes, 'OK');
END
GO
