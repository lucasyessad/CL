/* ============================================================================
   DT-1374 - Sous-procedure : FLAG de l'image fin de journee dans ods.OIT_XXXX
   V2.0 - 20/07/2026 - Fenetre de journee definie par les BORNES enregistrees
   (ORT_BORNE_JOURNEE, posees a la fin reelle des batchs LIGIS ou lors d'un
   passage force en journee) :
       fenetre(J) = ] borne(J-1) ; borne(J) ]
   Aucune heure d'horloge n'est supposee : les fenetres se touchent
   exactement, aucune trace ne peut etre perdue ni comptee deux fois.
   Le predicat par bornes ( > / <= ) est sargable (index utilisables).

   Pour la table designee par @ID_PARAM et la journee @DT_TRACES :
     1. remet le flag a 0 sur toutes les traces de la fenetre (recalcul propre)
     2. flague a 1 la derniere trace de la fenetre par cle fonctionnelle
        (ROW_NUMBER sur COLONNE_ORDRE_TRI, sens parametrable)
   Appelee par ORT_PRC_TRAITEMENT_JOUR ; en erreur, remonte l'exception (THROW).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_FLAG_OIT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_FLAG_OIT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_FLAG_OIT
    @DT_TRACES    DATE,
    @ID_PARAM     INT,
    @NB_FLAGUEES  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @table_source NVARCHAR(200), @cle_fonc NVARCHAR(500),
            @col_ordre NVARCHAR(128), @sens_tri NVARCHAR(4),
            @col_date NVARCHAR(128), @col_flag NVARCHAR(128),
            @filtre NVARCHAR(1000), @where_supp NVARCHAR(1000),
            @sql NVARCHAR(MAX), @msg NVARCHAR(500);

    SELECT @table_source = NOM_TABLE_SOURCE, @cle_fonc = CLE_FONCTIONNELLE,
           @col_ordre = COLONNE_ORDRE_TRI, @sens_tri = SENS_TRI,
           @col_date = COLONNE_DATE_JOUR, @col_flag = COLONNE_FLAG,
           @filtre = FILTRE_WHERE
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE ID_PARAM = @ID_PARAM;

    IF @table_source IS NULL
    BEGIN
        RAISERROR('ORT_PRC_SS_FLAG_OIT : ID_PARAM %d introuvable.', 16, 1, @ID_PARAM);
        RETURN;
    END

    ------------------------------------------------------------------
    -- Fenetre de la journee : ] borne(J-1) ; borne(J) ]
    ------------------------------------------------------------------
    DECLARE @dt_deb DATETIME, @dt_fin DATETIME;

    SELECT @dt_fin = DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES;
    IF @dt_fin IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_FLAG_OIT : borne non posee pour la journee '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
                 + N' (ORT_BORNE_JOURNEE) : extraction non close, journee non traitable.';
        THROW 50030, @msg, 1;
    END

    SELECT @dt_deb = MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES;
    IF @dt_deb IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_FLAG_OIT : aucune borne anterieure au '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
                 + N' : poser la borne initiale (ORIGINE = INIT) avant traitement.';
        THROW 50031, @msg, 1;
    END

    SET @where_supp = ISNULL(@filtre, N'');
    SET @NB_FLAGUEES = 0;

    -- 1. Reset du flag sur la fenetre (idempotence du recalcul)
    SET @sql = N'UPDATE ' + @table_source +
               N' SET ' + @col_flag + N' = 0' +
               N' WHERE ' + @col_date + N' > @p_deb AND ' + @col_date + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';';
    EXEC sp_executesql @sql, N'@p_deb datetime, @p_fin datetime',
         @p_deb = @dt_deb, @p_fin = @dt_fin;

    -- 2. Flag de la derniere trace de la fenetre par cle fonctionnelle
    SET @sql = N';WITH cte AS (' +
               N'  SELECT *, ROW_NUMBER() OVER (PARTITION BY ' + @cle_fonc +
               N'    ORDER BY ' + @col_ordre + N' ' + @sens_tri + N') AS rn_ort' +
               N'  FROM ' + @table_source +
               N'  WHERE ' + @col_date + N' > @p_deb AND ' + @col_date + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
               N') UPDATE cte SET ' + @col_flag + N' = 1 WHERE rn_ort = 1;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_deb datetime, @p_fin datetime, @p_nb int OUTPUT',
         @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @NB_FLAGUEES OUTPUT;

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'FLAG', @NB_FLAGUEES, 'OK');
END
GO
