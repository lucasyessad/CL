/* ============================================================================
   DT-1374 - Sous-procedure : CONSTRUCTION DE L'HISTORIQUE (SCD2) dans la cible
   V2.0 - 20/07/2026 - Fenetre de journee definie par les BORNES enregistrees
   (ORT_BORNE_JOURNEE) : fenetre(J) = ] borne(J-1) ; borne(J) ]

   Pour la table designee par @ID_PARAM et la journee @DT_TRACES :
     1. ferme les versions courantes dont la cle fonctionnelle a une trace
        flaguee dans la fenetre (DF_VAL = jour, borne exclusive ; FLAG_COURANT = 0)
     2. insere les nouvelles versions courantes depuis les traces flaguees
        (DD_VAL = jour, DF_VAL = 2400-01-01, FLAG_COURANT = 1) ;
        la liste des colonnes communes est detectee via INFORMATION_SCHEMA
        (support des noms de source en 2 ou 3 parties)
     3. controle anti-doublon : aucune cle fonctionnelle ne doit avoir
        plus d'une version courante -> sinon erreur (THROW)
   Appelee par ORT_PRC_TRAITEMENT_JOUR ; en erreur, remonte l'exception (THROW).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_SS_HISTORISATION_OWT', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_SS_HISTORISATION_OWT
GO

CREATE PROCEDURE dbo.ORT_PRC_SS_HISTORISATION_OWT
    @DT_TRACES    DATE,
    @ID_PARAM     INT,
    @NB_INSEREES  INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DATE_INFINIE DATE = '2400-01-01';

    DECLARE @table_source NVARCHAR(200), @table_cible NVARCHAR(200),
            @cle_fonc NVARCHAR(500), @col_date NVARCHAR(128), @col_flag NVARCHAR(128),
            @col_dd_val NVARCHAR(128), @col_df_val NVARCHAR(128), @col_flag_cour NVARCHAR(128),
            @filtre NVARCHAR(1000), @where_supp NVARCHAR(1000),
            @sql NVARCHAR(MAX), @nb_fermees INT = 0, @nb_doublons INT = 0,
            @base_source NVARCHAR(128), @schema_source NVARCHAR(128), @nom_table_src NVARCHAR(128),
            @col_list_src NVARCHAR(MAX), @join_cond NVARCHAR(MAX), @cle_col_list NVARCHAR(500),
            @msg NVARCHAR(500);

    SELECT @table_source = NOM_TABLE_SOURCE, @table_cible = NOM_TABLE_CIBLE,
           @cle_fonc = CLE_FONCTIONNELLE, @col_date = COLONNE_DATE_JOUR,
           @col_flag = COLONNE_FLAG, @col_dd_val = COLONNE_DD_VAL,
           @col_df_val = COLONNE_DF_VAL, @col_flag_cour = COLONNE_FLAG_COURANT,
           @filtre = FILTRE_WHERE
    FROM dbo.ORT_PARAM_HISTORISATION_TRACES
    WHERE ID_PARAM = @ID_PARAM;

    IF @table_source IS NULL
    BEGIN
        RAISERROR('ORT_PRC_SS_HISTORISATION_OWT : ID_PARAM %d introuvable.', 16, 1, @ID_PARAM);
        RETURN;
    END

    ------------------------------------------------------------------
    -- Fenetre de la journee : ] borne(J-1) ; borne(J) ]
    ------------------------------------------------------------------
    DECLARE @dt_deb DATETIME, @dt_fin DATETIME;

    SELECT @dt_fin = DT_BORNE FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES;
    IF @dt_fin IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : borne non posee pour la journee '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23) + N'.';
        THROW 50030, @msg, 1;
    END

    SELECT @dt_deb = MAX(DT_BORNE) FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES;
    IF @dt_deb IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : aucune borne anterieure au '
                 + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
                 + N' : poser la borne initiale (ORIGINE = INIT).';
        THROW 50031, @msg, 1;
    END

    SET @where_supp = ISNULL(@filtre, N'');
    SET @NB_INSEREES = 0;

    -- Decomposition de la cle fonctionnelle (1..n colonnes)
    SELECT @join_cond    = STRING_AGG('t.' + QUOTENAME(LTRIM(RTRIM(value))) + ' = s.' + QUOTENAME(LTRIM(RTRIM(value))), ' AND '),
           @cle_col_list = STRING_AGG(QUOTENAME(LTRIM(RTRIM(value))), ',')
    FROM STRING_SPLIT(@cle_fonc, ',');

    ------------------------------------------------------------------
    -- 1. Fermeture des versions courantes concernees
    ------------------------------------------------------------------
    SET @sql = N'UPDATE t SET ' + @col_df_val + N' = @p_dt, ' + @col_flag_cour + N' = 0' +
               N' FROM ' + @table_cible + N' AS t' +
               N' INNER JOIN (SELECT DISTINCT ' + @cle_col_list +
               N'             FROM ' + @table_source +
               N'             WHERE ' + @col_flag + N' = 1' +
               N'               AND ' + @col_date + N' > @p_deb AND ' + @col_date + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END +
               N'            ) AS s ON ' + @join_cond +
               N' WHERE t.' + @col_flag_cour + N' = 1;' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql, N'@p_dt date, @p_deb datetime, @p_fin datetime, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @nb_fermees OUTPUT;

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'FERMETURE', @nb_fermees, 'OK');

    ------------------------------------------------------------------
    -- 2. Insertion des nouvelles versions courantes
    --    Liste des colonnes de la source via INFORMATION_SCHEMA
    --    (gere 'schema.table' et 'base.schema.table')
    ------------------------------------------------------------------
    SET @base_source   = PARSENAME(@table_source, 3);
    SET @schema_source = ISNULL(PARSENAME(@table_source, 2), 'dbo');
    SET @nom_table_src = PARSENAME(@table_source, 1);

    SET @sql = N'SELECT @p_cols = STRING_AGG(QUOTENAME(COLUMN_NAME), '','') WITHIN GROUP (ORDER BY ORDINAL_POSITION)' +
               N' FROM ' + CASE WHEN @base_source IS NOT NULL THEN QUOTENAME(@base_source) + N'.' ELSE N'' END +
               N'INFORMATION_SCHEMA.COLUMNS' +
               N' WHERE TABLE_SCHEMA = @p_schema AND TABLE_NAME = @p_table' +
               N'   AND COLUMN_NAME NOT IN (@p_dd, @p_df, @p_fc);';
    EXEC sp_executesql @sql,
         N'@p_schema sysname, @p_table sysname, @p_dd sysname, @p_df sysname, @p_fc sysname, @p_cols nvarchar(max) OUTPUT',
         @p_schema = @schema_source, @p_table = @nom_table_src,
         @p_dd = @col_dd_val, @p_df = @col_df_val, @p_fc = @col_flag_cour,
         @p_cols = @col_list_src OUTPUT;

    IF @col_list_src IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_SS_HISTORISATION_OWT : colonnes introuvables pour la source ' + @table_source + N'.';
        THROW 50002, @msg, 1;
    END

    SET @sql = N'INSERT INTO ' + @table_cible + N' (' + @col_list_src + N', ' +
               @col_dd_val + N', ' + @col_df_val + N', ' + @col_flag_cour + N')' +
               N' SELECT ' + @col_list_src + N', @p_dt, @p_infini, 1' +
               N' FROM ' + @table_source +
               N' WHERE ' + @col_flag + N' = 1' +
               N'   AND ' + @col_date + N' > @p_deb AND ' + @col_date + N' <= @p_fin' +
               CASE WHEN @where_supp <> N'' THEN N' AND ' + @where_supp ELSE N'' END + N';' +
               N' SELECT @p_nb = @@ROWCOUNT;';
    EXEC sp_executesql @sql,
         N'@p_dt date, @p_infini date, @p_deb datetime, @p_fin datetime, @p_nb int OUTPUT',
         @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE,
         @p_deb = @dt_deb, @p_fin = @dt_fin, @p_nb = @NB_INSEREES OUTPUT;

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'INSERTION', @NB_INSEREES, 'OK');

    ------------------------------------------------------------------
    -- 3. Controle anti-doublon : 1 seule version courante par cle
    ------------------------------------------------------------------
    SET @sql = N'SELECT @p_nb = COUNT(*) FROM (' +
               N'  SELECT ' + @cle_col_list +
               N'  FROM ' + @table_cible +
               N'  WHERE ' + @col_flag_cour + N' = 1' +
               N'  GROUP BY ' + @cle_col_list +
               N'  HAVING COUNT(*) > 1' +
               N') d;';
    EXEC sp_executesql @sql, N'@p_nb int OUTPUT', @p_nb = @nb_doublons OUTPUT;

    IF @nb_doublons > 0
    BEGIN
        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_TRACES, @table_source, 'CONTROLE_DOUBLON', @nb_doublons, 'ERREUR',
                N'Cles fonctionnelles avec plusieurs versions courantes detectees.');

        SET @msg = N'Controle anti-doublon en echec sur ' + @table_cible + N' : ' +
                   CAST(@nb_doublons AS NVARCHAR(20)) + N' cle(s) avec plusieurs versions courantes.';
        THROW 50001, @msg, 1;
    END

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT)
    VALUES (@DT_TRACES, @table_source, 'CONTROLE_DOUBLON', 0, 'OK');
END
GO
