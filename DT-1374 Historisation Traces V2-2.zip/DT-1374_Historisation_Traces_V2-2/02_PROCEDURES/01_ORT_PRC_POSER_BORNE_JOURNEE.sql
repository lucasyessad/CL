/* ============================================================================
   DT-1374 - Pose de la borne de fin de journee
   V2.2 - 20/07/2026
   A appeler en fin de chaine de recuperation des traces (apres extraction /
   chargement), dans les deux cas d'exploitation :
     - fin du quotidien LIGIS (heure variable, ex 22h00)      -> QUOTIDIEN
     - rattrapage couvrant plusieurs jours (batch KO non repris,
       CDC multi-jours)                                        -> MULTI_JOURS

   VALEUR DE LA BORNE (@DT_BORNE) :
     - RECOMMANDE : passer la DERNIERE DATETIME EXTRAITE lue dans la table
       d'audit du CDC (recuperee avec les traces). C'est la verite de
       l'extraction : tout ce qui est <= borne est livre, tout ce qui est
       > borne appartient a la fenetre suivante -> aucune perte possible,
       y compris pour les modifications entre la fin du quotidien (22h30)
       et 07h45 : elles partent dans la journee suivante.
       Exemple d'appel (a brancher sur la vraie table d'audit) :
         DECLARE @b datetime =
             (SELECT MAX(<COL_DERNIERE_DATETIME_EXTRAITE>)
              FROM <TABLE_AUDIT_CDC>);
         EXEC dbo.ORT_PRC_POSER_BORNE_JOURNEE @DT_BORNE = @b;
     - A DEFAUT (@DT_BORNE NULL) : valeur calculee type V4
       (ps_INEO_lock_traces) : GETDATE(), clampee a 07:45 si l'appel a lieu
       pendant les TP (07:45-19:00). Un AVERTISSEMENT est logue.

   JOURNEE CLOSE (@DT_JOUR) par defaut :
     - appel a 19:00 ou apres un jour ouvre -> aujourd'hui
     - sinon (nuit, matin, journee TP)      -> veille ouvree (PRTCAL)
     RECOMMANDE : passer @DT_JOUR explicitement depuis la chaine.

   TYPE DE BORNE (@TYPE_BORNE) par defaut : detection automatique.
     Si @DT_JOUR est bien la journee ouvree qui suit la derniere borne
     posee -> QUOTIDIEN ; sinon -> MULTI_JOURS (et DT_JOUR_DEBUT_PERIODE
     est renseigne avec la premiere journee non couverte).

   Controles ("infaillibilite") :
     - chainage strictement croissant des bornes (sinon erreur) ;
     - borne deja posee pour la journee -> erreur, sauf @FORCER = 1
       (remplacement = deplacement de frontiere : recalculer J et J+1).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_POSER_BORNE_JOURNEE', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
GO

CREATE PROCEDURE dbo.ORT_PRC_POSER_BORNE_JOURNEE
    @DT_JOUR      DATE           = NULL,
    @DT_BORNE     DATETIME       = NULL,
    @TYPE_BORNE   NVARCHAR(15)   = NULL,
    @COMMENTAIRE  NVARCHAR(500)  = NULL,
    @FORCER       BIT            = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @now DATETIME = GETDATE(),
            @auj DATE     = CAST(GETDATE() AS DATE),
            @h_tp_ouverture TIME(0) = '07:45:00',
            @h_tp_fermeture TIME(0) = '19:00:00',
            @origine_valeur NVARCHAR(20),
            @dt_jour_prec DATE, @dt_borne_prec DATETIME,
            @dt_jour_attendu DATE, @dt_debut_periode DATE,
            @msg NVARCHAR(500);

    ------------------------------------------------------------------
    -- 1. Valeur de la borne : audit CDC si fournie, sinon defaut V4
    ------------------------------------------------------------------
    IF @DT_BORNE IS NOT NULL
        SET @origine_valeur = 'AUDIT_CDC';
    ELSE
    BEGIN
        SET @origine_valeur = 'DEFAUT';
        IF CAST(@now AS TIME(0)) > @h_tp_ouverture AND CAST(@now AS TIME(0)) < @h_tp_fermeture
            SET @DT_BORNE = CAST(@auj AS DATETIME) + CAST(@h_tp_ouverture AS DATETIME);  -- clamp 07:45
        ELSE
            SET @DT_BORNE = @now;
    END

    ------------------------------------------------------------------
    -- 2. Journee close par defaut
    ------------------------------------------------------------------
    IF @DT_JOUR IS NULL
    BEGIN
        IF CAST(@now AS TIME(0)) >= @h_tp_fermeture
           AND EXISTS (SELECT 1 FROM dbo.PRTCAL WHERE CONVERT(date, DT_CAL, 121) = @auj)
            SET @DT_JOUR = @auj;   -- quotidien termine avant minuit (ex 22h) : on clot aujourd'hui
        ELSE
            SELECT @DT_JOUR = MAX(CONVERT(date, DT_CAL, 121))
            FROM dbo.PRTCAL
            WHERE CONVERT(date, DT_CAL, 121) < @auj;   -- nuit / matin / journee : on clot la veille ouvree
    END

    IF @DT_JOUR IS NULL
    BEGIN
        SET @msg = N'ORT_PRC_POSER_BORNE_JOURNEE : impossible de determiner la journee close (PRTCAL vide ?).';
        THROW 50020, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 3. Detection automatique du type (QUOTIDIEN / MULTI_JOURS)
    ------------------------------------------------------------------
    SELECT TOP (1) @dt_jour_prec = DT_JOUR, @dt_borne_prec = DT_BORNE
    FROM dbo.ORT_BORNE_JOURNEE
    WHERE DT_JOUR < @DT_JOUR
    ORDER BY DT_JOUR DESC;

    IF @dt_jour_prec IS NOT NULL
        SELECT @dt_jour_attendu = MIN(CONVERT(date, DT_CAL, 121))
        FROM dbo.PRTCAL
        WHERE CONVERT(date, DT_CAL, 121) > @dt_jour_prec;   -- journee ouvree suivant la derniere borne

    IF @TYPE_BORNE IS NULL
        SET @TYPE_BORNE = CASE WHEN @dt_jour_prec IS NULL THEN 'QUOTIDIEN'
                               WHEN @DT_JOUR = @dt_jour_attendu THEN 'QUOTIDIEN'
                               ELSE 'MULTI_JOURS' END;

    IF @TYPE_BORNE = 'MULTI_JOURS'
        SET @dt_debut_periode = @dt_jour_attendu;   -- premiere journee couverte par la periode

    ------------------------------------------------------------------
    -- 4. Controles : borne existante et chainage strictement croissant
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR) AND @FORCER = 0
    BEGIN
        SET @msg = N'Borne deja posee pour la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                 + N'. @FORCER = 1 uniquement en connaissance de cause '
                 + N'(deplacement de frontiere : recalculer les journees J et J+1).';
        THROW 50021, @msg, 1;
    END

    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR < @DT_JOUR AND DT_BORNE >= @DT_BORNE)
       OR EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE
               WHERE DT_JOUR > @DT_JOUR AND DT_BORNE <= @DT_BORNE)
    BEGIN
        SET @msg = N'Chainage des bornes incoherent : la borne '
                 + CONVERT(NVARCHAR(19), @DT_BORNE, 120)
                 + N' de la journee ' + CONVERT(NVARCHAR(10), @DT_JOUR, 23)
                 + N' chevauche une borne existante.';
        THROW 50022, @msg, 1;
    END

    ------------------------------------------------------------------
    -- 5. Pose (insert ou remplacement force) + logs
    ------------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_JOUR)
    BEGIN
        UPDATE dbo.ORT_BORNE_JOURNEE
        SET DT_BORNE = @DT_BORNE, TYPE_BORNE = @TYPE_BORNE,
            ORIGINE_VALEUR = @origine_valeur,
            DT_JOUR_DEBUT_PERIODE = @dt_debut_periode,
            DT_POSE = GETDATE(),
            COMMENTAIRE = ISNULL(@COMMENTAIRE, N'Borne remplacee (FORCER) le ' + CONVERT(NVARCHAR(19), GETDATE(), 120))
        WHERE DT_JOUR = @DT_JOUR;

        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_JOUR, N'*BORNE*', 'BORNE', 'AVERTISSEMENT',
                N'Borne remplacee : recalcul des journees J et J+1 requis (@FORCER = 1 sur le traitement).');
    END
    ELSE
    BEGIN
        INSERT INTO dbo.ORT_BORNE_JOURNEE
            (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, DT_JOUR_DEBUT_PERIODE, COMMENTAIRE)
        VALUES (@DT_JOUR, @DT_BORNE, @TYPE_BORNE, @origine_valeur, @dt_debut_periode, @COMMENTAIRE);

        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_JOUR, N'*BORNE*', 'BORNE', 'OK',
                N'Borne ' + CONVERT(NVARCHAR(19), @DT_BORNE, 120)
                + N' posee (' + @TYPE_BORNE + N', valeur ' + @origine_valeur + N')'
                + CASE WHEN @dt_debut_periode IS NOT NULL
                       THEN N' - periode depuis le ' + CONVERT(NVARCHAR(10), @dt_debut_periode, 23)
                       ELSE N'' END + N'.');
    END

    ------------------------------------------------------------------
    -- 6. Avertissement si valeur par defaut (audit CDC indisponible)
    ------------------------------------------------------------------
    IF @origine_valeur = 'DEFAUT'
        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_JOUR, N'*BORNE*', 'BORNE', 'AVERTISSEMENT',
                N'Borne posee avec la valeur par defaut (calcul type V4) : privilegier la derniere datetime extraite de la table d''audit CDC.');
END
GO
