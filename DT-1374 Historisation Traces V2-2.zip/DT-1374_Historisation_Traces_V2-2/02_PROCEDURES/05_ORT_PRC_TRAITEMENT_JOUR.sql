/* ============================================================================
   DT-1374 - Procedure maitre : traitement complet d'UNE journee
   V2.0 - 20/07/2026 - Fenetres par bornes (ORT_BORNE_JOURNEE) :
     - garde-fou en entree : la borne de la journee doit etre posee
       (extraction LIGIS close), sinon erreur immediate -> la date reste
       TRAITE = 0 dans PITCOT_PERIODE_REPRISE et sera reprise plus tard ;
     - le pilotage des journees (file, flag TRAITE, reprise) est assure par
       ODI via PITCOT_PERIODE_REPRISE / PWTTRE (voir 03_ODI) ;
     - en cas d'erreur sur au moins une table, l'erreur est REMONTEE a ODI
       (THROW final) : l'etape ODI passe KO, la date reste TRAITE = 0 et la
       relance du job global reprend sur cette journee. Grace a
       ORT_SUIVI_JOUR_TABLE, la relance ne retraite que les tables non-OK.

   Appel dans la boucle ODI (interieur de la boucle jour) :
       EXEC dbo.ORT_PRC_TRAITEMENT_JOUR @DT_TRACES = '#V_DT_TRACES'

   Enchainement interne par table active du parametrage :
       1. ORT_PRC_SS_FLAG_OIT            (image fin de journee dans OIT)
       2. ORT_PRC_SS_PURGE_OWT           (suppression jour + reouverture)
       3. ORT_PRC_SS_HISTORISATION_OWT   (fermeture + insertion + controle)
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PRC_TRAITEMENT_JOUR', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ORT_PRC_TRAITEMENT_JOUR
GO

CREATE PROCEDURE dbo.ORT_PRC_TRAITEMENT_JOUR
    @DT_TRACES DATE,
    @FORCER    BIT = 0     -- 1 = retraite aussi les tables deja OK pour cette journee
AS
BEGIN
    SET NOCOUNT ON;

    IF @DT_TRACES IS NULL
    BEGIN
        RAISERROR('ORT_PRC_TRAITEMENT_JOUR : @DT_TRACES est obligatoire.', 16, 1);
        RETURN;
    END

    ------------------------------------------------------------------
    -- Garde-fou : la borne de la journee doit etre posee (extraction
    -- close) ainsi qu'une borne anterieure (debut de fenetre)
    ------------------------------------------------------------------
    IF NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR = @DT_TRACES)
       OR NOT EXISTS (SELECT 1 FROM dbo.ORT_BORNE_JOURNEE WHERE DT_JOUR < @DT_TRACES)
    BEGIN
        DECLARE @msg_borne NVARCHAR(500);
        SET @msg_borne = N'ORT_PRC_TRAITEMENT_JOUR : fenetre non definie pour le '
            + CONVERT(NVARCHAR(10), @DT_TRACES, 23)
            + N' (borne de la journee et/ou borne anterieure absente dans ORT_BORNE_JOURNEE).'
            + N' Journee non traitable : extraction LIGIS non close ou borne initiale manquante.';

        INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
            (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
        VALUES (@DT_TRACES, N'*TOUTES*', 'JOURNEE', 'ERREUR', @msg_borne);

        THROW 50011, @msg_borne, 1;
    END

    ------------------------------------------------------------------
    -- Boucle sur les tables actives du parametrage
    ------------------------------------------------------------------
    DECLARE @id_param INT, @table_source NVARCHAR(200),
            @nb_flag INT, @nb_supp INT, @nb_ins INT,
            @statut_table NVARCHAR(20);

    DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
        SELECT ID_PARAM, NOM_TABLE_SOURCE
        FROM dbo.ORT_PARAM_HISTORISATION_TRACES
        WHERE ACTIF = 1
        ORDER BY ID_PARAM;

    OPEN cur_tables;
    FETCH NEXT FROM cur_tables INTO @id_param, @table_source;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        --------------------------------------------------------------
        -- Reprise fine : table deja OK pour cette journee -> ignoree
        --------------------------------------------------------------
        IF @FORCER = 0 AND EXISTS (
            SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
            WHERE DT_JOUR = @DT_TRACES AND ID_PARAM = @id_param
              AND STATUT IN ('OK','OK_VIDE'))
        BEGIN
            INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
                (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT)
            VALUES (@DT_TRACES, @table_source, 'TABLE', 'IGNORE');
        END
        ELSE
        BEGIN
            -- Ouverture / reinitialisation de la ligne de suivi
            IF EXISTS (SELECT 1 FROM dbo.ORT_SUIVI_JOUR_TABLE
                       WHERE DT_JOUR = @DT_TRACES AND ID_PARAM = @id_param)
                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET STATUT = 'EN_COURS', DT_DEBUT = GETDATE(), DT_FIN = NULL,
                    NB_LIGNES_FLAGUEES = NULL, NB_LIGNES_SUPPRIMEES = NULL,
                    NB_LIGNES_INSEREES = NULL, MESSAGE_ERREUR = NULL
                WHERE DT_JOUR = @DT_TRACES AND ID_PARAM = @id_param;
            ELSE
                INSERT INTO dbo.ORT_SUIVI_JOUR_TABLE
                    (DT_JOUR, ID_PARAM, NOM_TABLE_SOURCE, STATUT, DT_DEBUT)
                VALUES (@DT_TRACES, @id_param, @table_source, 'EN_COURS', GETDATE());

            SET @nb_flag = 0; SET @nb_supp = 0; SET @nb_ins = 0;
            SET @statut_table = 'OK';

            BEGIN TRY
                -- 1. Flag de l'image fin de journee dans la source OIT
                EXEC dbo.ORT_PRC_SS_FLAG_OIT
                     @DT_TRACES = @DT_TRACES, @ID_PARAM = @id_param,
                     @NB_FLAGUEES = @nb_flag OUTPUT;

                IF @nb_flag = 0
                BEGIN
                    -- Source vide pour la journee : avertissement, on n'altere pas
                    -- la cible (un passage precedent valide reste intact)
                    SET @statut_table = 'OK_VIDE';
                    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
                        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT, MESSAGE_ERREUR)
                    VALUES (@DT_TRACES, @table_source, 'TABLE', 0, 'AVERTISSEMENT',
                            N'Aucune trace pour cette journee (BCPIN non charge ou journee sans mouvement).');
                END
                ELSE
                BEGIN
                    -- 2. Purge des donnees de la journee dans la cible (si existantes)
                    EXEC dbo.ORT_PRC_SS_PURGE_OWT
                         @DT_TRACES = @DT_TRACES, @ID_PARAM = @id_param,
                         @NB_SUPPRIMEES = @nb_supp OUTPUT;

                    -- 3. Construction de l'historique SCD2
                    EXEC dbo.ORT_PRC_SS_HISTORISATION_OWT
                         @DT_TRACES = @DT_TRACES, @ID_PARAM = @id_param,
                         @NB_INSEREES = @nb_ins OUTPUT;
                END

                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET STATUT = @statut_table, DT_FIN = GETDATE(),
                    NB_LIGNES_FLAGUEES = @nb_flag,
                    NB_LIGNES_SUPPRIMEES = @nb_supp,
                    NB_LIGNES_INSEREES = @nb_ins
                WHERE DT_JOUR = @DT_TRACES AND ID_PARAM = @id_param;
            END TRY
            BEGIN CATCH
                UPDATE dbo.ORT_SUIVI_JOUR_TABLE
                SET STATUT = 'ERREUR', DT_FIN = GETDATE(),
                    NB_LIGNES_FLAGUEES = @nb_flag,
                    NB_LIGNES_SUPPRIMEES = @nb_supp,
                    NB_LIGNES_INSEREES = @nb_ins,
                    MESSAGE_ERREUR = ERROR_MESSAGE()
                WHERE DT_JOUR = @DT_TRACES AND ID_PARAM = @id_param;

                INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
                    (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, STATUT, MESSAGE_ERREUR)
                VALUES (@DT_TRACES, @table_source, 'TABLE', 'ERREUR', ERROR_MESSAGE());
                -- on continue avec la table suivante : toutes les tables sont
                -- tentees, le bilan est fait en fin de procedure
            END CATCH
        END

        FETCH NEXT FROM cur_tables INTO @id_param, @table_source;
    END

    CLOSE cur_tables;
    DEALLOCATE cur_tables;

    ------------------------------------------------------------------
    -- Bilan de la journee : log recapitulatif + remontee d'erreur a ODI
    ------------------------------------------------------------------
    DECLARE @nb_ok INT, @nb_err INT, @msg NVARCHAR(500);

    SELECT @nb_ok  = SUM(CASE WHEN STATUT IN ('OK','OK_VIDE') THEN 1 ELSE 0 END),
           @nb_err = SUM(CASE WHEN STATUT = 'ERREUR' THEN 1 ELSE 0 END)
    FROM dbo.ORT_SUIVI_JOUR_TABLE
    WHERE DT_JOUR = @DT_TRACES;

    SET @nb_ok  = ISNULL(@nb_ok, 0);
    SET @nb_err = ISNULL(@nb_err, 0);

    INSERT INTO dbo.ORT_LOG_HISTORISATION_TRACES
        (DT_TRACES_TRAITEE, NOM_TABLE_SOURCE, ETAPE, NB_LIGNES, STATUT, MESSAGE_ERREUR)
    VALUES (@DT_TRACES, N'*TOUTES*', 'JOURNEE', @nb_ok,
            CASE WHEN @nb_err > 0 THEN 'ERREUR' ELSE 'OK' END,
            CASE WHEN @nb_err > 0
                 THEN CAST(@nb_err AS NVARCHAR(10)) + N' table(s) en erreur (detail dans ORT_SUIVI_JOUR_TABLE).'
                 ELSE NULL END);

    IF @nb_err > 0
    BEGIN
        -- L'etape ODI passe KO -> la date reste TRAITE = 0 dans
        -- PITCOT_PERIODE_REPRISE -> reprise automatique a la relance du job.
        SET @msg = N'ORT_PRC_TRAITEMENT_JOUR : ' + CAST(@nb_err AS NVARCHAR(10)) +
                   N' table(s) en erreur pour la journee ' + CONVERT(NVARCHAR(10), @DT_TRACES, 23) +
                   N'. Voir ORT_SUIVI_JOUR_TABLE / ORT_LOG_HISTORISATION_TRACES.';
        THROW 50010, @msg, 1;
    END
END
GO
