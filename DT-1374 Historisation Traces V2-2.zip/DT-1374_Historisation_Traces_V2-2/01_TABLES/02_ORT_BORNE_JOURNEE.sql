/* ============================================================================
   DT-1374 - Table des bornes de fin de journee
   V2.2 - 20/07/2026
   La fenetre de la journee J est :  ] borne(J-1) ; borne(J) ]
   -> les fenetres se touchent exactement : AUCUNE modification n'est perdue,
      y compris celles faites apres la fin du quotidien (ex: quotidien fini a
      22h00, modifications de 22h30 a 07h45 -> elles appartiennent a la
      fenetre de la journee suivante, par construction).

   DEUX TYPES DE BORNE :
     - QUOTIDIEN   : cas nominal, une borne par journee ouvree, posee a la
                     fin du quotidien LIGIS (heure variable, ex 22h00) ;
     - MULTI_JOURS : cas rattrapage (batch KO non repris, CDC couvrant
                     plusieurs jours) : UNE borne clot toute la periode et
                     l'image construite est celle de la DERNIERE journee de
                     la periode ; les journees intermediaires n'ont pas
                     d'image propre (elles sont absorbees, aucune donnee
                     perdue).

   VALEUR DE LA BORNE (DT_BORNE) : de preference la DERNIERE DATETIME
   EXTRAITE lue dans la TABLE D'AUDIT DU CDC (verite de l'extraction),
   recuperee avec les traces. A defaut, une valeur calculee type V4
   (ps_INEO_lock_traces) est utilisee, avec avertissement au log.
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_BORNE_JOURNEE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_BORNE_JOURNEE
    (
        DT_JOUR                 DATE           NOT NULL PRIMARY KEY,  -- journee ouvree que cette borne CLOT
                                                                      -- (pour MULTI_JOURS : DERNIERE journee de la periode)
        DT_BORNE                DATETIME       NOT NULL,              -- derniere datetime extraite (audit CDC de preference)
        TYPE_BORNE              NVARCHAR(15)   NOT NULL DEFAULT ('QUOTIDIEN'),
        ORIGINE_VALEUR          NVARCHAR(20)   NOT NULL DEFAULT ('DEFAUT'),
        DT_JOUR_DEBUT_PERIODE   DATE           NULL,                  -- MULTI_JOURS : premiere journee couverte (informatif)
        DT_POSE                 DATETIME       NOT NULL DEFAULT (GETDATE()),
        COMMENTAIRE             NVARCHAR(500)  NULL,
        CONSTRAINT UQ_ORT_BORNE_JOURNEE_DT_BORNE UNIQUE (DT_BORNE),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_TYPE
            CHECK (TYPE_BORNE IN ('QUOTIDIEN','MULTI_JOURS','INIT')),
        CONSTRAINT CK_ORT_BORNE_JOURNEE_ORIGINE
            CHECK (ORIGINE_VALEUR IN ('AUDIT_CDC','DEFAUT','MANUEL'))
    );
END
GO

/* ----------------------------------------------------------------------------
   Borne initiale (one-shot a la mise en production) : point de depart de la
   toute premiere fenetre. DT_JOUR = veille ouvree du premier jour a traiter,
   DT_BORNE = derniere datetime extraite AVANT le demarrage du perimetre
   (idealement lue dans l'audit CDC au moment de l'activation).
-----------------------------------------------------------------------------
INSERT INTO dbo.ORT_BORNE_JOURNEE
    (DT_JOUR, DT_BORNE, TYPE_BORNE, ORIGINE_VALEUR, COMMENTAIRE)
VALUES
    ('<AAAA-MM-JJ veille ouvree>', '<AAAA-MM-JJ hh:mm:ss>', 'INIT', 'MANUEL',
     'Borne initiale - demarrage historisation DT-1374');
---------------------------------------------------------------------------- */
GO
