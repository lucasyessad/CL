/* ============================================================================
   DT-1374 - Log detaille des etapes du traitement d'historisation
   V1.0 - 20/07/2026
   Une ligne par etape executee (FLAG, PURGE, REOUVERTURE, FERMETURE,
   INSERTION, CONTROLE_DOUBLON, IGNORE, AVERTISSEMENT...).
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_LOG_HISTORISATION_TRACES', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_LOG_HISTORISATION_TRACES
    (
        ID_LOG                 INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        DT_EXECUTION           DATETIME           NOT NULL DEFAULT (GETDATE()),
        DT_TRACES_TRAITEE      DATE               NOT NULL,
        NOM_TABLE_SOURCE       NVARCHAR(200)      NOT NULL,
        ETAPE                  NVARCHAR(30)       NOT NULL,
        NB_LIGNES              INT                NULL,
        STATUT                 NVARCHAR(20)       NOT NULL,   -- OK / ERREUR / AVERTISSEMENT / IGNORE
        MESSAGE_ERREUR         NVARCHAR(MAX)      NULL
    );

    CREATE INDEX IX_ORT_LOG_HISTO_DT ON dbo.ORT_LOG_HISTORISATION_TRACES (DT_TRACES_TRAITEE, DT_EXECUTION);
END
GO
