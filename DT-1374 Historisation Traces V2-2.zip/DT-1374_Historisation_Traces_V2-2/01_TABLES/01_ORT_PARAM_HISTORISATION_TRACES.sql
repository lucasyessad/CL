/* ============================================================================
   DT-1374 - Table de parametrage de l'historisation des traces
   V1.0 - 20/07/2026
   Un enregistrement = un couple (table source OIT / table cible OWT-IWT)
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_PARAM_HISTORISATION_TRACES', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_PARAM_HISTORISATION_TRACES
    (
        ID_PARAM               INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        NOM_TABLE_SOURCE       NVARCHAR(200)      NOT NULL,  -- ex: 'ods.OIT_CONTRAT'
        NOM_TABLE_CIBLE        NVARCHAR(200)      NOT NULL,  -- ex: 'dbo.OWT_CONTRAT' ou 'DWH_EXP.dbo.IWT_CONTRAT'
        CLE_FONCTIONNELLE      NVARCHAR(500)      NOT NULL,  -- ex: 'NUM_CONTRAT' ou 'NUM_CONTRAT,NUM_AVENANT'
        COLONNE_ORDRE_TRI      NVARCHAR(128)      NOT NULL,  -- colonne determinant la derniere trace du jour (horodatage/sequence)
        SENS_TRI               NVARCHAR(4)        NOT NULL DEFAULT ('DESC'),  -- DESC = la plus grande valeur gagne
        COLONNE_DATE_JOUR      NVARCHAR(128)      NOT NULL,  -- colonne date filtrant la journee traitee dans la source
        COLONNE_FLAG           NVARCHAR(128)      NOT NULL DEFAULT ('FL_FIN_JOURNEE'),
        COLONNE_DD_VAL         NVARCHAR(128)      NOT NULL DEFAULT ('DD_VAL'),        -- date debut validite (cible)
        COLONNE_DF_VAL         NVARCHAR(128)      NOT NULL DEFAULT ('DF_VAL'),        -- date fin validite (cible)
        COLONNE_FLAG_COURANT   NVARCHAR(128)      NOT NULL DEFAULT ('FLAG_COURANT'),  -- 1 = version courante, 0 = historique (cible)
        FILTRE_WHERE           NVARCHAR(1000)     NULL,      -- filtre optionnel sur la source (ex: MEM_TYPE = ''CNT'')
        ACTIF                  BIT                NOT NULL DEFAULT (1),
        COMMENTAIRE            NVARCHAR(500)      NULL,
        CONSTRAINT UQ_ORT_PARAM_HISTO_SOURCE UNIQUE (NOM_TABLE_SOURCE)
    );
END
GO

/* ----------------------------------------------------------------------------
   Modele d'alimentation (a completer table par table)
-----------------------------------------------------------------------------
INSERT INTO dbo.ORT_PARAM_HISTORISATION_TRACES
    (NOM_TABLE_SOURCE, NOM_TABLE_CIBLE, CLE_FONCTIONNELLE, COLONNE_ORDRE_TRI,
     SENS_TRI, COLONNE_DATE_JOUR, COLONNE_FLAG, COLONNE_DD_VAL, COLONNE_DF_VAL,
     COLONNE_FLAG_COURANT, FILTRE_WHERE, ACTIF, COMMENTAIRE)
VALUES
    ('ods.OIT_CONTRAT', 'dbo.OWT_CONTRAT', 'NUM_CONTRAT', 'DT_HORODATAGE',
     'DESC', 'DT_HORODATAGE', 'FL_FIN_JOURNEE', 'DD_VAL', 'DF_VAL',
     'FLAG_COURANT', NULL, 1, 'Traces contrat CDC LIGIS V5');
---------------------------------------------------------------------------- */
GO
