/* ============================================================================
   DT-1374 - Securisation des journees x tables traitees (esprit BUHTRACE_E)
   V1.0 - 20/07/2026
   Une ligne par (journee, table du parametrage) avec statut et volumetries.
   Sert a la reprise fine : les tables deja OK pour une journee sont ignorees
   lors d'une relance (sauf @FORCER = 1).
   Statuts : EN_COURS -> OK / OK_VIDE / ERREUR
   ============================================================================ */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('dbo.ORT_SUIVI_JOUR_TABLE', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ORT_SUIVI_JOUR_TABLE
    (
        ID_SUIVI               INT IDENTITY(1,1)  NOT NULL PRIMARY KEY,
        DT_JOUR                DATE               NOT NULL,
        ID_PARAM               INT                NOT NULL,
        NOM_TABLE_SOURCE       NVARCHAR(200)      NOT NULL,
        STATUT                 NVARCHAR(20)       NOT NULL DEFAULT ('EN_COURS'),
        NB_LIGNES_FLAGUEES     INT                NULL,
        NB_LIGNES_SUPPRIMEES   INT                NULL,   -- purge cible (recalcul)
        NB_LIGNES_INSEREES     INT                NULL,
        DT_DEBUT               DATETIME           NULL,
        DT_FIN                 DATETIME           NULL,
        MESSAGE_ERREUR         NVARCHAR(MAX)      NULL,
        CONSTRAINT UQ_ORT_SUIVI_JOUR_TABLE UNIQUE (DT_JOUR, ID_PARAM),
        CONSTRAINT CK_ORT_SUIVI_STATUT
            CHECK (STATUT IN ('EN_COURS','OK','OK_VIDE','ERREUR'))
    );
END
GO
