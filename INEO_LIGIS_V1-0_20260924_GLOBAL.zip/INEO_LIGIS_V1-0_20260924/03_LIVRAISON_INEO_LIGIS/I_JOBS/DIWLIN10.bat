@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIN1                                            JOB : RIWLIN10 #
REM                                                                               #
REM  PROJET   : INEO                                            APPLICATION : DWH #
REM                                                                               #
REM  TITRE SCRIPT  : Initialisation des tables LIGISV5 dans l'ODS INEO            #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                              URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIN0                                                         #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Argument : nom du projet, LIGIS par defaut.                                  #
REM  Charge l'etat complet de toutes les tables du projet declarees dans          #
REM    ORT_PARAM_FLUX (LB_FICHIER_INIT), meme deroulement que RIWLIG10. Les       #
REM    lignes s'ajoutent au sas, rien n'est vide.                                 #
REM  Fichier d'etat complet absent = erreur : la journee INIT fermerait les       #
REM    cles de la table dont la photo manque. Ligne rejetee = erreur.             #
REM  Enchainement : borne INIT dans ORT_BORNE_JOURNEE, RHMEIN0, RIWLIN10, puis    #
REM    RIWLIN11.                                                                  #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set SERVER=ERM
set DBNAME=DWH
set SCHEMA=ods
set PROJET=%~1
if "%PROJET%"=="" set PROJET=LIGIS
set BCP="X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe"
set RUNID=%DATALIB%\riwlin10-runid.txt

setlocal enableDelayedExpansion

rem 1. Table d'audit : videe et rechargee seule, avant tout le reste
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "TRUNCATE TABLE [%SCHEMA%].[OIT_TEC_AUDIT_CDC];"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

if exist "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err" del "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err"
%BCP% "%DBNAME%.%SCHEMA%.[OIT_TEC_AUDIT_CDC]" in "%DATALIB%\ZBCP_%PROJET%_TEC_AUDIT_CDC_V.bcp" -T -S %SERVER% -n -o "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.out" -e "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err"
set RC=!ERRORLEVEL!
type "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.out"

rem Une ligne rejetee par bcp n'arrete pas bcp : le fichier .err le revele.
if !RC! EQU 0 if exist "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err" for %%A in ("%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err") do if %%~zA GTR 0 (
    echo ERREUR : lignes rejetees pour OIT_TEC_AUDIT_CDC, voir %%~fA
    set RC=1
)
if !RC! NEQ 0 goto :ERR

rem 2. Preparation des tables : plage de la photo supprimee, volumetrie relevee
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; DECLARE @id bigint = CONVERT(bigint, FORMAT(SYSDATETIME(),'yyyyMMddHHmmss')); EXEC dbo.PS_PREPARATION_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=@id, @CD_FORMAT='BCP'; SELECT 'ID_TRT_ALI=' + CONVERT(varchar(20), @id);" ^
       -o "%RUNID%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem Recuperation de l'identifiant retourne par SQL Server
set ID_TRT_ALI=

for /F "usebackq tokens=1,2 delims==" %%a in ("%RUNID%") do (
    if /I "%%a"=="ID_TRT_ALI" set ID_TRT_ALI=%%b
)

if "!ID_TRT_ALI!"=="" (
    echo Identifiant d'execution introuvable.
    set RC=1
    goto :ERR
)

echo Identifiant d'execution : !ID_TRT_ALI!

rem 3. Liste table + fichier d'etat complet, lue dans le parametrage
set LISTE=%DATALIB%\riwlin10-tables.txt

sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; SELECT LB_TABLE_ODS + ' ' + LB_FICHIER_INIT FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET='%PROJET%' AND FL_ACTIF=1 AND CD_FORMAT='BCP' AND LB_FICHIER_INIT IS NOT NULL ORDER BY NO_ORDRE, LB_TABLE_ODS;" ^
       -o "%LISTE%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 4. BCP IN des fichiers d'etat complet. Fichier absent = erreur : une table
rem    sans photo aurait ses cles fermees par la journee INIT.
for /F "usebackq tokens=1,2" %%i in ("%LISTE%") do (

    set TABLE=%%i
    set WKF01=%%j

    if not exist "%DATALIB%\!WKF01!" (
        echo ERREUR : !WKF01! absent, initialisation de !TABLE! impossible.
        set RC=1
        goto :ERR
    ) else (
        if exist "%loglib%\%~n0_!TABLE!.err" del "%loglib%\%~n0_!TABLE!.err"
        %BCP% "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n -o "%loglib%\%~n0_!TABLE!.out" -e "%loglib%\%~n0_!TABLE!.err"
        set RC=!ERRORLEVEL!
        type "%loglib%\%~n0_!TABLE!.out"
        if !RC! EQU 0 if exist "%loglib%\%~n0_!TABLE!.err" for %%A in ("%loglib%\%~n0_!TABLE!.err") do if %%~zA GTR 0 (
            echo ERREUR : lignes rejetees pour !TABLE!, voir %%~fA
            set RC=1
        )
        if !RC! NEQ 0 goto :ERR
    )
)

rem 5. Controle du chargement des tables ODS
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "EXEC dbo.PS_CONTROLE_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=!ID_TRT_ALI!;"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

endlocal
goto :FIN

:ERR
exit /B %RC%

:FIN
exit /B 0