#-----------------------------------------------------------------------------#
# SCHEDULE : RIWLIG1                                           JOB : RIWLIG14 #
#                                                                             #
# PROJET   : INEO                                           APPLICATION : DWH #
#                                                                             #
# TITRE SCRIPT  : Archivage GDG du fichier ZIP issu de LIGISV5                #
#                                                                             #
# DATE CREATION : 24/09/26                             DATE M.A.J. : 24/09/26 #
#                                                              USER : uflpfgi #
#-----------------------------------------------------------------------------#
# FREQUENCE  : Quotidien                                URGENCE :             #
#                                                                             #
# DEPENDANCE : RIWLIG13                                                       #
#                                                                             #
#-----------------------------------------------------------------------------#
# CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.   #
#-----------------------------------------------------------------------------#
# Ajoute IOT_LIGISV5_DONNEE_CDC.zip au GDG (%proclib%\GDGAdd.ps1),            #
# 30 generations conservees. Module PowerShell requis : Pscx.                 #
#-----------------------------------------------------------------------------#

Import-Module Pscx # module provided by pcsx.codeplex.org
If ($env:proclib -eq $null) {Invoke-BatchFile "E:\dsi\exploit\parmlib\chemin.bat" | out-null}

$exitCode = 0

& "$env:proclib\GDGAdd.ps1" -FileIn "$env:datalib\IOT_LIGISV5_DONNEE_CDC.zip" -GDGLimit 30
If ($LastExitCode -ne 0) {$exitCode = 1}

Exit $exitCode
