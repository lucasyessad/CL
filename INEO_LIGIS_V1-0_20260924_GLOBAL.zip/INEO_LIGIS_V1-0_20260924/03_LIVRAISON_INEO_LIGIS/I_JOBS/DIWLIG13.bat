@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG13 #
REM                                                                               #
REM  PROJET   : INEO                                            APPLICATION : DWH #
REM                                                                               #
REM  TITRE SCRIPT  : ZIP des fichiers ZBCP_* traites                              #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                               URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RIWLIG12                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Compresse %DATALIB%\ZBCP_*.bcp dans IOT_LIGISV5_DONNEE_CDC.zip avec          #
REM    %proclib%\7za.exe. Les .bcp sont supprimes apres compression.              #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

setlocal enableDelayedExpansion

set "ZIP_RUN=%DATALIB%\IOT_LIGISV5_DONNEE_CDC.zip"

set "INZIP=%DATALIB%\ZBCP_*.bcp"
echo %INZIP%
call %proclib%\7za.exe a -tzip !ZIP_RUN! !INZIP! -sdel	
set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

Echo ZIP : %ZIP_RUN% - OK
endlocal
goto FIN

:ERR
exit /B 1
goto :EOF

:FIN
exit /B 0
