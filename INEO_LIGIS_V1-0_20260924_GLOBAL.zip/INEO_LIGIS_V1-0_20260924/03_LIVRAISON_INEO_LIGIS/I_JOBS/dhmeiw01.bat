@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIW0                                            JOB : RHMEIW01 #
REM                                                                               #
REM  PROJET   : CREALIA                                     APPLICATION : LIGISV5 #
REM                                                                               #
REM  TITRE SCRIPT  : Export BCP des donnees LIGISV5 (CDC et etat complet hors CDC)#
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                               URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIW00                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Exporte en natif dans %DATALIB% les vues export_cdc.ZBCP_LIGIS_*_V, audit    #
REM    compris, et la vue d'etat complet ZBCP_INIT_LIGIS_*_V des tables sans      #
REM    vue CDC. Un fichier par vue, nomme comme la vue.                           #
REM  Rejouable : les fichiers sont reecrits.                                      #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set DBNAME=Ligis5_Dev_Data

rem A renseigner
set SQL_SRVNAME=ASM

setlocal enableDelayedExpansion

rem Lancement des BCP_OUT : vues CDC (audit compris), plus la vue d'etat
rem complet des tables de l'audit qui ne sont pas sous CDC (mode FULL).
for /F "usebackq tokens=*" %%i in (`sqlcmd -S %SQL_SRVNAME% -d %DBNAME% -E -h -1 -W -Q "SET NOCOUNT ON; SELECT v.name FROM sys.views v INNER JOIN sys.schemas s ON s.schema_id = v.schema_id WHERE s.name = 'export_cdc' AND (v.name LIKE 'ZBCP_LIGIS[_]%%[_]V' OR (v.name LIKE 'ZBCP_INIT_LIGIS[_]%%[_]V' AND NOT EXISTS (SELECT 1 FROM sys.views c WHERE c.schema_id = v.schema_id AND c.name = REPLACE(v.name, 'ZBCP_INIT_LIGIS_', 'ZBCP_LIGIS_')))) ORDER BY v.name;"`) do (

	set WKF01=%%i.bcp
	set VIEW=%%i

	"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe" "%DBNAME%.export_cdc.[!VIEW!]" out "%DATALIB%\!WKF01!" -T -S %SQL_SRVNAME% -n

	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

endlocal

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0