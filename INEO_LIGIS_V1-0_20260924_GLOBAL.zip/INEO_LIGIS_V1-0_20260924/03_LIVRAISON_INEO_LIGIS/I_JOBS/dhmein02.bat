@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIN0                                            JOB : RHMEIN02 #
REM                                                                               #
REM  PROJET   : CREALIA                                     APPLICATION : LIGISV5 #
REM                                                                               #
REM  TITRE SCRIPT  : Transfert etat complet et audit vers INEO                    #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                              URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIN01                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Deplace ZBCP_INIT_LIGIS_*.bcp et ZBCP_LIGIS_TEC_AUDIT_CDC_V.bcp vers le      #
REM    %DATALIB% du serveur INEO (REP_DESTINATION). Un echec de deplacement       #
REM    arrete le job.                                                             #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************


@call E:\dsi\exploit\parmlib\chemin.bat


SET RC=0

set	REP_SOURCE=%DATALIB%

rem A renseigner : %DATALIB% du serveur INEO
set	REP_DESTINATION=\\Kenya\dsi\exploit\datalib\dt1374

move /Y %REP_SOURCE%\ZBCP_INIT_LIGIS_*.bcp %REP_DESTINATION%
set RC=%ERRORLEVEL%
if %RC% NEQ 0 goto :ERR

move /Y %REP_SOURCE%\ZBCP_LIGIS_TEC_AUDIT_CDC_V.bcp %REP_DESTINATION%
set RC=%ERRORLEVEL%
if %RC% NEQ 0 goto :ERR

goto :FIN

:ERR
exit /B %RC%

:FIN
exit /B 0
