@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIW0                                            JOB : RHMEIW02 #
REM                                                                               #
REM  PROJET   : CREALIA                                     APPLICATION : LIGISV5 #
REM                                                                               #
REM  TITRE SCRIPT  : Transfert des fichiers ZBCP_*.bcp vers INEO                  #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                               URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIW01                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Deplace %DATALIB%\ZBCP_*.bcp vers le %DATALIB% du serveur INEO               #
REM    (REP_DESTINATION). Un echec de deplacement arrete le job.                  #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************


@call E:\dsi\exploit\parmlib\chemin.bat


SET RC=0

set	REP_SOURCE=%DATALIB%

rem A renseigner : %DATALIB% du serveur INEO
set	REP_DESTINATION=\\Kenya\dsi\exploit\datalib\dt1374

move /Y %REP_SOURCE%\ZBCP_*.bcp %REP_DESTINATION%
set RC=%ERRORLEVEL%
if %RC% NEQ 0 goto :ERR

goto :FIN

:ERR
exit /B %RC%

:FIN
exit /B 0
