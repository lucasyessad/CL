@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RHMEIN0                                            JOB : RHMEIN00 #
REM                                                                               #
REM  PROJET   : CREALIA                                     APPLICATION : LIGISV5 #
REM                                                                               #
REM  TITRE SCRIPT  : Mise a jour de l'audit CDC avant export etat complet         #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                              URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIW0 et RIWLIG1 suspendus                                    #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Meme mise a jour de l'audit que RHMEIW00. L'etat complet est pris au LSN     #
REM    LB_FIN_LSN ; les extractions quotidiennes reprennent a ce LSN.             #
REM  RHMEIW0 et RIWLIG1 restent suspendus jusqu'a la fin de RIWLIN11.             #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0


rem - recuperation date et heure pour constitution nom fichier
set tsp=%date:~6,4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set tsp=%tsp: =0%

rem A renseigner
set	DBNAME=Ligis5_Dev_Data
set	SERVER=ASM

"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\SQLCMD.EXE" -S %SERVER% -d %DBNAME% -M -E -b -i %proclib%\HMEIW00_Update_Ligis_TEC_AUDIT_CDC.sql -f o:1252
set RC=%ERRORLEVEL%
endlocal

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0