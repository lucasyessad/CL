@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG10 #
REM                                                                               #
REM  PROJET   : INEO                                            APPLICATION : DWH #
REM                                                                               #
REM  TITRE SCRIPT  : Import des fichiers BCP LIGISV5 dans l'ODS INEO              #
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                USER : uflpfgi #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIERE                               URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RHMEIW0                                                         #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Argument : nom du projet, LIGIS par defaut.                                  #
REM  1. Audit : ods.OIT_TEC_AUDIT_CDC vide puis recharge seul ; il porte les      #
REM    bornes LSN dont depend la preparation.                                     #
REM  2. PS_PREPARATION_ODS supprime dans chaque table la plage que le fichier     #
REM    recharge, ce qui rend le job rejouable, et releve la volumetrie.           #
REM  3. Liste table + fichier lue dans ORT_PARAM_FLUX (LB_FICHIER).               #
REM  4. bcp in par table. Fichier absent = avertissement ; ligne rejetee =        #
REM    erreur.                                                                    #
REM  5. PS_CONTROLE_ODS complete ORT_AUDIT_CHARGEMENT.                            #
REM  Sorties et rejets bcp : %loglib%\JOB_TABLE.out / .err.                       #
REM  En echec : ne lancer ni RIWLIG12 ni le RHMEIW0 suivant avant la reprise      #
REM    de ce job.                                                                 #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set SERVER=ERM
set DBNAME=DWH
set SCHEMA=ods
set PROJET=%~1
if "%PROJET%"=="" set PROJET=LIGIS
set BCP="X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe"
set RUNID=%DATALIB%\riwlig10-runid.txt

setlocal enableDelayedExpansion

rem 1. Table d'audit : videe et rechargee seule, avant tout le reste
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "TRUNCATE TABLE [%SCHEMA%].[OIT_TEC_AUDIT_CDC];"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

if exist "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err" del "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err"
%BCP% "%DBNAME%.%SCHEMA%.[OIT_TEC_AUDIT_CDC]" in "%DATALIB%\ZBCP_%PROJET%_TEC_AUDIT_CDC_V.bcp" -T -S %SERVER% -n -o "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.out" -e "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err"
set RC=!ERRORLEVEL!
type "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.out"

rem Une ligne rejetee par bcp n'arrete pas bcp : le fichier .err le revele.
if !RC! EQU 0 if exist "%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err" for %%A in ("%loglib%\%~n0_OIT_TEC_AUDIT_CDC.err") do if %%~zA GTR 0 (
    echo ERREUR : lignes rejetees pour OIT_TEC_AUDIT_CDC, voir %%~fA
    set RC=1
)
if !RC! NEQ 0 goto :ERR

rem 2. Preparation des tables : plage LSN supprimee, volumetrie relevee
sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; DECLARE @id bigint = CONVERT(bigint, FORMAT(SYSDATETIME(),'yyyyMMddHHmmss')); EXEC dbo.PS_PREPARATION_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=@id, @CD_FORMAT='BCP'; SELECT 'ID_TRT_ALI=' + CONVERT(varchar(20), @id);" ^
       -o "%RUNID%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

set ID_TRT_ALI=

for /F "usebackq tokens=1,2 delims==" %%a in ("%RUNID%") do (
    if /I "%%a"=="ID_TRT_ALI" set ID_TRT_ALI=%%b
)

if "!ID_TRT_ALI!"=="" (
    echo Identifiant d'execution introuvable.
    set RC=1
    goto :ERR
)

rem 3. Liste table + fichier, lue dans le parametrage
set LISTE=%DATALIB%\riwlig10-tables.txt

sqlcmd -S %SERVER% -d %DBNAME% -E -b -h -1 -W ^
       -Q "SET NOCOUNT ON; SELECT LB_TABLE_ODS + ' ' + LB_FICHIER FROM dbo.ORT_PARAM_FLUX WHERE LB_PROJET='%PROJET%' AND FL_ACTIF=1 AND CD_FORMAT='BCP' AND LB_FICHIER IS NOT NULL ORDER BY NO_ORDRE, LB_TABLE_ODS;" ^
       -o "%LISTE%"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

rem 4. BCP IN sur chaque table de la liste. Fichier absent = pas de traces
rem    ce jour pour cette table : avertissement, PS_CONTROLE_ODS constatera 0.
for /F "usebackq tokens=1,2" %%i in ("%LISTE%") do (

    set TABLE=%%i
    set WKF01=%%j

    if not exist "%DATALIB%\!WKF01!" (
        echo AVERTISSEMENT : !WKF01! absent, !TABLE! non chargee.
    ) else (
        if exist "%loglib%\%~n0_!TABLE!.err" del "%loglib%\%~n0_!TABLE!.err"
        %BCP% "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n -o "%loglib%\%~n0_!TABLE!.out" -e "%loglib%\%~n0_!TABLE!.err"
        set RC=!ERRORLEVEL!
        type "%loglib%\%~n0_!TABLE!.out"
        if !RC! EQU 0 if exist "%loglib%\%~n0_!TABLE!.err" for %%A in ("%loglib%\%~n0_!TABLE!.err") do if %%~zA GTR 0 (
            echo ERREUR : lignes rejetees pour !TABLE!, voir %%~fA
            set RC=1
        )
        if !RC! NEQ 0 goto :ERR
    )
)

rem 5. Controle : chaque table a-t-elle recu des lignes ?
sqlcmd -S %SERVER% -d %DBNAME% -E -b ^
       -Q "EXEC dbo.PS_CONTROLE_ODS @LB_PROJET='%PROJET%', @ID_TRT_ALI=!ID_TRT_ALI!;"

set RC=!ERRORLEVEL!
if !RC! NEQ 0 goto :ERR

endlocal
goto :FIN

:ERR
exit /B %RC%

:FIN
exit /B 0