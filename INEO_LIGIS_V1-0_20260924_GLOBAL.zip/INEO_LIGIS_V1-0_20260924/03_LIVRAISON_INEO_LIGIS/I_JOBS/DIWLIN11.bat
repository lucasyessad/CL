@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIN1                                            JOB : RIWLIN11 #
REM                                                                               #
REM  PROJET   : INEO                                            APPLICATION : DWH #
REM                                                                               #
REM  TITRE SCRIPT  : Initialisation des donnees LIGISV5 dans le DWH (scenario ODI)#
REM                                                                               #
REM  DATE CREATION : 24/09/26                              DATE M.A.J. : 24/09/26 #
REM                                                                 USER : ufluly #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : A LA DEMANDE                              URGENCE :             #
REM                                                                               #
REM  DEPENDANCE : RIWLIN10                                                        #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job, reprise apres analyse DSI/SED/EDD.    #
REM ------------------------------------------------------------------------------#
REM  Meme scenario que RIWLIG12. La journee INIT est traitee et sa borne          #
REM    consommee.                                                                 #
REM  A la fin OK, reactiver RHMEIW0 et RIWLIG1. A renseigner par environnement    #
REM    : SCEN_CTX.                                                                #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call e:\dsi\exploit\parmlib\Chemin.bat
REM *********** HORS MAESTRO ******************************************************


SET RC=0

SET SCEN_NAME=IWI_LIGIS_TRACES_CSTIMG
SET SCEN_VERS=0_1
SET SCEN_CTX=CTX_DEV

pushd "X:\Oracle\ODI12c\user_projects\domains\base_domain\bin"

echo ***** Lancement Scenario ODI
echo.
call startscen "%SCEN_NAME%" "%SCEN_VERS%" %SCEN_CTX%

set RC=%ERRORLEVEL%
echo Code Retour : %RC%
popd

if .%RC%.==.-1. goto ERR_SCEN
echo %SCEN_NAME% : RC=%RC%

if %RC% NEQ 0 goto ERR

goto fin


:ERR_SCEN
echo Scenario Error 7000


:ERR
echo Error %RC%
exit /B 1

:FIN
