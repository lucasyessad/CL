/* ============================================================================
   PS_PREPARATION_ODS

   Appelée par le job d'import avant la boucle bcp, une fois par format.
   Prépare chaque cible du projet :
     FULL   la table est vidée, le fichier porte l'état complet ;
     DELTA  seule la plage rechargée par le fichier est supprimée, ce qui rend
            l'import rejouable sans doublon. La plage est lue dans l'audit :
              CDC        ]LB_DEB_LSN ; LB_FIN_LSN]
              INIT/FULL  le LSN de la photo, LB_FIN_LSN
   Une ligne par table dans ORT_AUDIT_CHARGEMENT, statut vide, avec la
   volumétrie AVANT chargement : PS_CONTROLE_ODS la complète après la boucle
   bcp. Le détail bcp est dans le journal du job.
   ============================================================================ */
USE [DWH];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.PS_PREPARATION_ODS
(
    @LB_PROJET  NVARCHAR(50),
    @ID_TRT_ALI BIGINT,
    @CD_FORMAT  NVARCHAR(10) = N'BCP'
)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE
        @dt_debut    DATETIME2(3) = SYSDATETIME(),
        @sql         NVARCHAR(MAX),
        @msg         NVARCHAR(2000),
        @table_ods   NVARCHAR(128),
        @ods_complet NVARCHAR(300),
        @source      NVARCHAR(260),
        @entree      NVARCHAR(10),
        @schema_ods  NVARCHAR(128),
        @table_audit NVARCHAR(128),
        @nb          BIGINT,
        @nb_flux     INT = 0,
        @nb_ko       INT = 0;

    /* Sans audit, aucune plage n'est connue : un flux DELTA chargerait en
       double. Erreur réelle, le job s'arrête et se relance après correction. */
    IF EXISTS
    (
        SELECT 1 FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1
          AND CD_FORMAT = @CD_FORMAT AND CD_MODE_ENTREE = N'DELTA'
    )
    BEGIN
        SELECT TOP (1) @schema_ods = LB_SCHEMA_ODS, @table_audit = LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET AND FL_ACTIF = 1
          AND CD_FORMAT = @CD_FORMAT AND CD_MODE_ENTREE = N'DELTA'
          AND LB_TABLE_AUDIT IS NOT NULL
        ORDER BY NO_ORDRE, LB_TABLE_ODS;

        IF @table_audit IS NULL
        BEGIN
            SET @msg = N'PS_PREPARATION_ODS : aucun flux DELTA ne déclare LB_TABLE_AUDIT.';
            THROW 56000, @msg, 1;
        END;

        SET @nb = 0;
        SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM '
                 + QUOTENAME(@schema_ods) + N'.' + QUOTENAME(@table_audit) + N';';
        EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;

        IF ISNULL(@nb, 0) = 0
        BEGIN
            SET @msg = N'PS_PREPARATION_ODS : ' + @schema_ods + N'.' + @table_audit
                     + N' est vide. Charger l''audit avant d''appeler cette procédure.';
            THROW 56001, @msg, 1;
        END;
    END;

    DECLARE cur_flux CURSOR LOCAL FAST_FORWARD FOR
        SELECT LB_TABLE_ODS,
               QUOTENAME(LB_SCHEMA_ODS) + N'.' + QUOTENAME(LB_TABLE_ODS),
               LB_SOURCE, CD_MODE_ENTREE, LB_SCHEMA_ODS, LB_TABLE_AUDIT
        FROM dbo.ORT_PARAM_FLUX
        WHERE LB_PROJET = @LB_PROJET
          AND FL_ACTIF  = 1
          AND CD_FORMAT = @CD_FORMAT
        ORDER BY NO_ORDRE, LB_TABLE_ODS;

    OPEN cur_flux;
    FETCH NEXT FROM cur_flux
    INTO @table_ods, @ods_complet, @source, @entree, @schema_ods, @table_audit;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @nb = NULL;

        BEGIN TRY
            IF @entree = N'FULL'
            BEGIN
                SET @sql = N'TRUNCATE TABLE ' + @ods_complet + N';';
                EXEC sp_executesql @sql;
                SET @msg = N'Table vidée (FULL).';
                SET @nb = 0;
            END
            ELSE
            BEGIN
                SET @sql =
                      N'DELETE T'                                                 + CHAR(13)
                    + N'FROM ' + @ods_complet + N' AS T'                          + CHAR(13)
                    + N'INNER JOIN ' + QUOTENAME(@schema_ods) + N'.'
                                     + QUOTENAME(@table_audit) + N' AS A'         + CHAR(13)
                    + N'        ON A.LB_INSTANCE = @p_source'                     + CHAR(13)
                    + N'WHERE (T.LB_LSN_COMMIT_TEC >  A.LB_DEB_LSN'               + CHAR(13)
                    + N'       AND T.LB_LSN_COMMIT_TEC <= A.LB_FIN_LSN)'          + CHAR(13)
                    + N'   OR (T.LB_LSN_COMMIT_TEC =  A.LB_FIN_LSN);'             + CHAR(13)
                    + N'SELECT @p_nb = @@ROWCOUNT;';
                EXEC sp_executesql @sql, N'@p_source nvarchar(260), @p_nb bigint OUTPUT',
                     @p_source = @source, @p_nb = @nb OUTPUT;
                SET @msg = N'Plage rechargée supprimée : ' + CONVERT(NVARCHAR(20), ISNULL(@nb, 0)) + N' ligne(s).';

                SET @sql = N'SELECT @p_nb = COUNT_BIG(*) FROM ' + @ods_complet + N';';
                EXEC sp_executesql @sql, N'@p_nb bigint OUTPUT', @p_nb = @nb OUTPUT;
            END;

            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement ' + LOWER(@CD_FORMAT) + N' -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 ISNULL(@nb, 0), NULL, @msg, @dt_debut, NULL);

            SET @nb_flux += 1;
        END TRY
        BEGIN CATCH
            SET @nb_ko += 1;
            INSERT INTO dbo.ORT_AUDIT_CHARGEMENT
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE,
                 NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES
                (@ID_TRT_ALI, @LB_PROJET, N'Chargement ' + LOWER(@CD_FORMAT) + N' -> ods',
                 ISNULL(@source, @table_ods), @table_ods,
                 0, N'KO', N'Preparation : ' + ERROR_MESSAGE(), @dt_debut, SYSDATETIME());
        END CATCH;

        FETCH NEXT FROM cur_flux
        INTO @table_ods, @ods_complet, @source, @entree, @schema_ods, @table_audit;
    END;

    CLOSE cur_flux;
    DEALLOCATE cur_flux;

    /* Charger par-dessus une cible mal préparée produirait des doublons :
       le job s'arrête, la relance repart proprement. */
    IF @nb_ko > 0
    BEGIN
        SET @msg = N'PS_PREPARATION_ODS : ' + CONVERT(NVARCHAR(10), @nb_ko)
                 + N' flux en échec. Détail dans ORT_AUDIT_CHARGEMENT pour'
                 + N' ID_TRT_ALI = ' + CONVERT(NVARCHAR(20), @ID_TRT_ALI) + N'.';
        THROW 56002, @msg, 1;
    END;
END;
GO
