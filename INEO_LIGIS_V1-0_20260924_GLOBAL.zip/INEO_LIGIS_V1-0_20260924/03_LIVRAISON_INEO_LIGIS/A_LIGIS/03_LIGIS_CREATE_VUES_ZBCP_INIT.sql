/* ================================================================
   Vues d'état complet ZBCP_INIT_LIGIS_<TABLE>_V

   Une vue par table de l'audit, lue directement sur la table source.
   Elle sert à l'initialisation, et au quotidien pour une table sans
   CDC (mode FULL).

   MÊME CONTRAT que la vue ZBCP_LIGIS_<TABLE>_V, colonne pour colonne :
   même liste, même ordre, même type, même nullabilité. bcp -n écrit
   le fichier d'après la nullabilité de la vue et le relit d'après celle
   de la table OIT, générée depuis la vue CDC : un écart casse l'import.
     bloc technique  NOT NULL, sauf DT_COMMIT_TEC
     colonnes métier toutes NULL (jointure externe)
   Colonnes : celles de la table de capture quand elle existe (les
   colonnes calculées n'y sont pas), sinon celles de la table source
   hors colonnes calculées.

     LB_LSN_COMMIT_TEC  LSN de la photo (LB_FIN_LSN de l'audit)
     LB_SEQVAL_TEC      rang de la ligne ; le couple (LSN, rang)
                        identifie la ligne dans l'archive
     CD_DML_TEC         2 (insertion)
     DT_COMMIT_TEC      date d'extraction portée par l'audit (DT_EXTRACT)
   La ligne d'audit de l'instance doit donc être mise à jour par
   HMEIW00_Update_Ligis_TEC_AUDIT_CDC.sql avant l'export (dhmein00 en
   initialisation, dhmeiw00 au quotidien).
   ================================================================ */
DROP TABLE IF EXISTS ##TableListODS;
GO

CREATE TABLE ##TableListODS
(
    TableNameSource sysname NOT NULL
);
GO

INSERT INTO ##TableListODS (TableNameSource)
SELECT t.name
FROM sys.tables AS t
INNER JOIN sys.schemas AS s
    ON s.schema_id = t.schema_id
INNER JOIN export_cdc.TEC_AUDIT_CDC AS tm
    ON tm.LB_INSTANCE = N'dbo_' + t.name
WHERE s.name = N'dbo'
ORDER BY t.name;

SET NOCOUNT ON;

DECLARE
    @SchemaSource    sysname = N'dbo',
    @SchemaCDC       sysname = N'cdc',
    @SchemaCDCExport sysname = N'export_cdc',
    @TableNameSource sysname,
    @DropSQL         nvarchar(MAX),
    @CreateSQL       nvarchar(MAX),
    @SourceTable     nvarchar(517),
    @CDC_Table       nvarchar(517),
    @CDC_ObjectId    int,
    @CaptureInstance sysname;

DECLARE cur_view CURSOR LOCAL FAST_FORWARD FOR
SELECT TableNameSource FROM ##TableListODS;

OPEN cur_view;
FETCH NEXT FROM cur_view INTO @TableNameSource;

WHILE @@FETCH_STATUS = 0
BEGIN
    /* L'instance CDC porte le préfixe du schéma : c'est elle qui est
       dans TEC_AUDIT_CDC, pas le nom de table. */
    SET @CaptureInstance = @SchemaSource + N'_' + @TableNameSource;
    SET @SourceTable = QUOTENAME(@SchemaSource) + N'.' + QUOTENAME(@TableNameSource);
    SET @CDC_Table   = QUOTENAME(@SchemaCDC) + N'.' + QUOTENAME(@CaptureInstance + N'_CT');
    SET @CDC_ObjectId = OBJECT_ID(@CDC_Table);

    IF OBJECT_ID(@SourceTable) IS NULL
    BEGIN
        PRINT 'Table source absente : ' + @SourceTable;
        FETCH NEXT FROM cur_view INTO @TableNameSource;
        CONTINUE;
    END

    SET @DropSQL =
        N'DROP VIEW IF EXISTS '
        + QUOTENAME(@SchemaCDCExport)
        + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N';';

    ;WITH cols AS (
        SELECT c.name, c.column_id
        FROM sys.columns c
        WHERE c.object_id = OBJECT_ID(@SourceTable)
          AND c.is_computed = 0
          AND (@CDC_ObjectId IS NULL
               OR EXISTS (SELECT 1 FROM sys.columns k
                          WHERE k.object_id = @CDC_ObjectId AND k.name = c.name))
    )
    SELECT @CreateSQL =
N'CREATE VIEW ' + QUOTENAME(@SchemaCDCExport) + N'.' + QUOTENAME(N'ZBCP_INIT_LIGIS_' + @TableNameSource + N'_V') + N'
AS
    WITH CTE_AUDIT AS (
        SELECT ID_INSTANCE, LB_FIN_LSN, DT_EXTRACT, NO_SEQUENCE
        FROM ' + QUOTENAME(@SchemaCDCExport) + N'.ZBCP_LIGIS_TEC_AUDIT_CDC_V
        WHERE LB_INSTANCE = ''' + @CaptureInstance + N'''
    )
    SELECT
        ISNULL(T.ID_INSTANCE, CONVERT(binary(32), 0))                                          AS ID_INSTANCE_TEC,
        ISNULL(T.NO_SEQUENCE, 0)                                                               AS NO_SEQUENCE_TEC,
        ISNULL(CONVERT(binary(10), ROW_NUMBER() OVER (ORDER BY (SELECT NULL))), 0x00000000000000000000) AS LB_SEQVAL_TEC,
        ISNULL(CONVERT(int, 2), 0)                                                             AS CD_DML_TEC,
        CONVERT(DATETIME2(3), T.DT_EXTRACT)                                                    AS DT_COMMIT_TEC,
        ISNULL(T.LB_FIN_LSN, 0x00000000000000000000)                                           AS LB_LSN_COMMIT_TEC,
        ' +
        STRING_AGG(N'C.' + QUOTENAME(name), N',' + CHAR(13) + N'        ')
        WITHIN GROUP (ORDER BY column_id) + N',
        ISNULL(CONVERT(BIT, 0), 0) AS FL_FIN_JOURNEE
    FROM CTE_AUDIT AS T
    LEFT JOIN (SELECT 1 AS ORT_LIGNE, * FROM ' + @SourceTable + N') AS C
           ON 1 = 1
    WHERE C.ORT_LIGNE = 1;'
    FROM cols
    WHERE name NOT LIKE 'CS/_%' ESCAPE '/';


	-- print @CreateSQL; 
    EXEC(@DropSQL);
    EXEC(@CreateSQL);

    FETCH NEXT FROM cur_view INTO @TableNameSource;
END

CLOSE cur_view;
DEALLOCATE cur_view;
GO
