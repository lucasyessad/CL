----------------------------------------------------------
-- Mise a jour de la table d'audit avant export
-- Base de donnees : LigisV5_xxx_Data
-- Script : HMEIW00_Update_Ligis_TEC_AUDIT_CDC.sql
-- Lance par dhmeiw00 (quotidien) et dhmein00 (initialisation).
-- Chaque instance recoit la plage ]ancien LB_FIN_LSN ; LSN max],
-- la date d'extraction et un nouveau numero de sequence. Les vues
-- CDC exportent les traces de cette plage, les vues d'etat complet
-- sont prises au LSN LB_FIN_LSN et datees de DT_EXTRACT.
----------------------------------------------------------

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @DT_EXTRACT	DATETIME2(3);
DECLARE @LB_FIN_LSN	BINARY(10);
DECLARE @NO_SEQUENCE	BIGINT;

SET @DT_EXTRACT = SYSDATETIME();
SET @LB_FIN_LSN = sys.fn_cdc_get_max_lsn();

BEGIN TRY

	BEGIN TRANSACTION;

	SELECT
		@NO_SEQUENCE = ISNULL(MAX(NO_SEQUENCE), 0) + 1
	FROM export_cdc.TEC_AUDIT_CDC
	WITH (UPDLOCK, HOLDLOCK);

	UPDATE export_cdc.TEC_AUDIT_CDC
	SET
		LB_DEB_LSN		= LB_FIN_LSN,
		LB_FIN_LSN		= @LB_FIN_LSN,
		DT_EXTRACT		= @DT_EXTRACT,
		NO_SEQUENCE		= @NO_SEQUENCE;

	COMMIT TRANSACTION;

	SELECT
		@DT_EXTRACT		AS DT_EXTRACT,
		@NO_SEQUENCE		AS NO_SEQUENCE,
		@LB_FIN_LSN		AS LB_FIN_LSN;

END TRY
BEGIN CATCH

	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION;

	THROW;

END CATCH;
GO