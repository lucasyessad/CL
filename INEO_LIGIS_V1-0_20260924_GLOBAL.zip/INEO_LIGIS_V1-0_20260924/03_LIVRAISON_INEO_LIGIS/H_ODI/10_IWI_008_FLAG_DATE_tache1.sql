-- schema logique : MSSQL_DWH
-- type : S

/* ============================================================================
   IWI.008  -  FLAG DE LA JOURNEE TRAITEE

   Marque la journee comme traitee, une fois l'historisation et le bilan OK.

   Deux tables :
     ORT_PERIODE_REPRISE  file de travail de l'execution courante, videe et
                          reconstruite a chaque lancement ;
     ORT_BORNE_JOURNEE    historique permanent des frontieres. On y pose aussi
                          FL_TRAITE pour garder, dans le temps, la trace des
                          journees consommees - notamment les bornes INIT, qui
                          ne doivent pas etre reprises par une init ulterieure.

   La boucle traite une journee a la fois : chaque borne est marquee quand sa
   journee passe, init comme quotidienne.
   ============================================================================ */

UPDATE <?=odiRef.getObjectName("L", "ORT_PERIODE_REPRISE", "MSSQL_DWH", "D") ?>
SET FL_TRAITE = 1
WHERE LB_NOM_SCN_SUN = '<?=odiRef.getSession("SESS_NAME") ?>' AND LB_PROJET = '#INEO.V_NOM_PROJET'
  AND DT_JOUR <= '#INEO.V_IWI_LIGIS_DT_TRACES'
  AND FL_TRAITE = 0
