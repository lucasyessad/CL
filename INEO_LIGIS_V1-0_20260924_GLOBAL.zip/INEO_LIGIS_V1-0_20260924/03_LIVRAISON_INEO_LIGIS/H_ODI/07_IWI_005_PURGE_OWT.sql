-- schema logique : MSSQL_DWH
-- type : S

/* ============================================================================
   IWI.005  -  PURGE DES VERSIONS DE LA JOURNÉE

   Rend la journée recalculable : supprime les versions datées de la journée
   ou après, et rouvre la version fermée ce jour-là. Sur une journée jamais
   traitée, rien n'est touché. En journée INIT, les versions postérieures à
   la date de reprise disparaissent, les journées suivantes seront rejouées.

   Concerne SCD2 et AJOUT, les seuls modes qui créent des lignes datées. En
   SCD1 la ligne est mise à jour sur place ; en AUCUNE il n'y a pas de cible.
   Journalise uniquement si quelque chose a été défait.
   ============================================================================ */

DECLARE @DT_TRACES    DATE         = '#INEO.V_IWI_LIGIS_DT_TRACES';
DECLARE @ID_TRT_ALI   BIGINT       = <?=odiRef.getSession("SESS_NO") ?>;
DECLARE @LB_PROJET    NVARCHAR(50) = N'#INEO.V_NOM_PROJET';
DECLARE @DATE_INFINIE DATE         = '2400-01-01';
DECLARE @PFX_DWH NVARCHAR(300) =
    N'<?=odiRef.getCatalogName("MSSQL_DWH", "D") ?>.<?=odiRef.getSchemaName("MSSQL_DWH", "D") ?>.';

DECLARE @jour NVARCHAR(10) = CONVERT(NVARCHAR(10), @DT_TRACES, 23),
        @tbl_ods NVARCHAR(128), @tbl_dwh NVARCHAR(200), @tgt NVARCHAR(400),
        @sql NVARCHAR(MAX), @msg NVARCHAR(2000),
        @nb_supp INT, @nb_rouv INT, @dt_step DATETIME2(3);

DECLARE cur_tables CURSOR LOCAL FAST_FORWARD FOR
    SELECT F.LB_TABLE_ODS, F.LB_TABLE_DWH
    FROM <?=odiRef.getObjectName("L", "ORT_PARAM_FLUX", "MSSQL_DWH", "D") ?> AS F
    WHERE F.LB_PROJET = @LB_PROJET
      AND F.FL_ACTIF = 1
      AND F.CD_MODE_ALIM IN (N'SCD2', N'AJOUT')
      AND F.LB_TABLE_DWH IS NOT NULL
      AND NOT EXISTS
      (
          SELECT 1
          FROM <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?> AS A
          WHERE A.ID_TRT_ALI = @ID_TRT_ALI
            AND A.LB_PROJET = @LB_PROJET
            AND A.CD_STATUT = N'KO'
            AND A.LB_SOURCE = F.LB_TABLE_ODS
            AND CHARINDEX(N'[' + @jour + N']', A.LB_CHARGEMENT) > 0
      )
    ORDER BY F.NO_ORDRE, F.LB_TABLE_ODS;

OPEN cur_tables;
FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @dt_step = SYSDATETIME();
    SELECT @nb_supp = 0, @nb_rouv = 0;

    BEGIN TRY
        SET @tgt = @PFX_DWH + QUOTENAME(@tbl_dwh);

        BEGIN TRANSACTION;

        SET @sql = N'DELETE FROM ' + @tgt + N' WHERE DD_VAL >= @p_dt;'
                 + N' SELECT @p_nb = @@ROWCOUNT;';
        EXEC sp_executesql @sql, N'@p_dt date, @p_nb int OUTPUT',
             @p_dt = @DT_TRACES, @p_nb = @nb_supp OUTPUT;

        SET @sql = N'UPDATE ' + @tgt + N' SET DF_VAL = @p_infini, FL_VER_CRT = 1'
                 + N' WHERE DF_VAL = @p_dt AND FL_VER_CRT = 0;'
                 + N' SELECT @p_nb = @@ROWCOUNT;';
        EXEC sp_executesql @sql, N'@p_dt date, @p_infini date, @p_nb int OUTPUT',
             @p_dt = @DT_TRACES, @p_infini = @DATE_INFINIE, @p_nb = @nb_rouv OUTPUT;

        COMMIT TRANSACTION;

        IF @nb_supp > 0 OR @nb_rouv > 0
            INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
                (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
            VALUES (@ID_TRT_ALI, @LB_PROJET, N'RECALCUL [' + @jour + N']', @tbl_ods, @tbl_dwh, @nb_supp, N'OK',
                    N'Journée déjà traitée : ' + CONVERT(NVARCHAR(10), @nb_supp) + N' version(s) supprimée(s), '
                    + CONVERT(NVARCHAR(10), @nb_rouv) + N' rouverte(s) avant reconstruction.',
                    @dt_step, SYSDATETIME());
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        SET @msg = N'PURGE OWT : ' + ERROR_MESSAGE()
                 + N' [erreur ' + CONVERT(NVARCHAR(20), ERROR_NUMBER())
                 + N', ligne ' + CONVERT(NVARCHAR(20), ERROR_LINE()) + N']';
        INSERT INTO <?=odiRef.getObjectName("L", "ORT_AUDIT_CHARGEMENT", "MSSQL_DWH", "D") ?>
            (ID_TRT_ALI, LB_PROJET, LB_CHARGEMENT, LB_SOURCE, LB_CIBLE, NB_LIGNE, CD_STATUT, LB_ERREUR, DT_DEBUT, DT_FIN)
        VALUES (@ID_TRT_ALI, @LB_PROJET, N'TRACES [' + @jour + N']', @tbl_ods, @tbl_dwh, 0, N'KO',
                @msg, @dt_step, SYSDATETIME());
    END CATCH

    FETCH NEXT FROM cur_tables INTO @tbl_ods, @tbl_dwh;
END

CLOSE cur_tables;
DEALLOCATE cur_tables;
