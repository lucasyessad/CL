-- schema logique : MSSQL_DWH
-- type : S

UPDATE <?=odiRef.getObjectName("L", "ORT_BORNE_JOURNEE", "MSSQL_DWH", "D") ?>
SET FL_TRAITE = 1
WHERE LB_PROJET = '#INEO.V_NOM_PROJET'
  AND DT_JOUR = '#INEO.V_IWI_LIGIS_DT_TRACES'
  AND FL_TRAITE = 0
