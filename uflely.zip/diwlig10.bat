@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG10 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : Importation des fichiers CDC LigisV5 dans ODS INEO via BCP   #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 26/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE : RHMEIW0                                                         #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

rem A renseigner
set	SERVER=COOS
set	DBNAME=DWH
set SCHEMA=ods

setlocal enableDelayedExpansion

rem Lancement des BCP_IN sur toutes les vues concernées
for %%i in (ADRESSE,
	BIEN,
	BIEN_HISTO,
	CLIENT,
	CONTRAT,
	CONTRAT_CAUTIONS,
	CONTRAT_EMPRUNTEURS,
	DECOMPTE,
	DECOMPTE_CONTRATS,
	DOSSIER,
	EMPLOYEUR,
	GARANTIE,
	GARANTIE_CONTRATS,
	IDJ,
	IMPUTATION,
	LIG_ECHEANCE,
	LIG_ECHEANCIER,
	LOTMOUVEMENT,
	MANDAT,
	MOUVEMENT,
	ORGANISATION,
	POSTE,
	RIB,
	SOLVABILITE_LIGNES,
	TEC_AUDIT_CDC,
	TIERS,
	UTILISATEUR,
	WRK_PROCESS,
	WRK_TASK,
	WRK_TASKPARAMETER) do (
	
	set	WKF01=ZBCP_LIGIS_%%i_V.bcp
	set	TABLE=OIT_%%i

 	"X:\Microsoft SQL Server\Client SDK\ODBC\170\Tools\Binn\bcp.exe" "%DBNAME%.%SCHEMA%.[!TABLE!]" in "%DATALIB%\!WKF01!" -T -S %SERVER% -n
	set RC=!ERRORLEVEL!
	if !RC! NEQ 0 goto :ERR
)

endlocal
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0