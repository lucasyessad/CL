@echo off
REM ------------------------------------------------------------------------------#
REM  SCHEDULE : RIWLIG1                                            JOB : RIWLIG12 #
REM                                                                               #
REM  PROJET   : INEO                                       APPLICATION : DWH      #
REM                                                                               #
REM  TITRE SCRIPT  : ZIP des fichiers ZBCP_LIGIS_*                                #
REM                                                                               #
REM                                                                               #
REM  DATE CREATION : 26/08/26                              DATE M.A.J. : 26/08/26 #
REM                                                               USER : uflpfgi  #
REM ------------------------------------------------------------------------------#
REM  FREQUENCE  : JOURNALIER                               URGENCE :              #
REM                                                                               #
REM  DEPENDENCE :                                                                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#
REM  CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                 #
REM                                                                               #
REM ------------------------------------------------------------------------------#

REM *********** HORS MAESTRO ******************************************************
@call "E:\dsi\exploit\parmlib\Chemin.bat"
REM *********** HORS MAESTRO ******************************************************

SET RC=0

set "ZIP_RUN=%DATALIB%\IOT_LIGISV5_DONNEE_CDC.zip"

set "INZIP=%DATALIB%\ZBCP_LIGIS_*.bcp"
echo %INZIP%
call %proclib%\7za.exe a -tzip !ZIP_RUN! !INZIP! -sdel	
set RC=%ERRORLVEL%
if %RC% NEQ 0 1 goto ERR

Echo ZIP : %ZIP_RUN% - OK
goto FIN

:ERR
exit /B %RC%
goto :EOF

:FIN
exit /B 0