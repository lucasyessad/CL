#-----------------------------------------------------------------------------#
# SCHEDULE : RIWLIG1                                      JOB : RIWLIG13      #
#                                                                             #
# PROJET   : INEO                                       APPLICATION : DWH     #
#                                                                             #
# TITRE SCRIPT  : Archivage fichier ZIP issus de LIGISV5                      #
#                							                                  #
# DATE CREATION : 26/08/26                             DATE M.A.J. : 26/08/26 #
#                                                             USER : uflpfgi  #
#-----------------------------------------------------------------------------#
# FREQUENCE  : Quotidien                               URGENCE :              #
#                                                                             #
# DEPENDENCE :                                                                #
#                                                                             #
#                                                                             #
#-----------------------------------------------------------------------------#
# CODE RETOUR : > 0 fin anormale du job. reprise le lendemain.                #
#                                                                             #
#-----------------------------------------------------------------------------#

Import-Module Pscx # module provided by pcsx.codeplex.org
If ($env:proclib -eq $null) {Invoke-BatchFile "E:\dsi\exploit\parmlib\chemin.bat" | out-null}

$exitCode = 0

& "$env:proclib\GDGAdd.ps1" -FileIn "$env:datalib\IOT_LIGISV5_DONNEE_CDC.zip" -GDGLimit 30
If ($LastExitCode -ne 0) {$exitCode = 1}

Exit $exitCode